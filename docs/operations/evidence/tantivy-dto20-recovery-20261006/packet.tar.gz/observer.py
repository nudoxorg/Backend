#!/usr/bin/env python3
"""Real matched CLI/MCP Tantivy recovery over a private published corpus copy.

Provider-only recovery: query token traversal is evaluated by a separate gate.
Every fault is deliberately injected into a private copy.
"""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import socket
import subprocess
import threading
import time
import uuid


def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def resources():
    mem = dict((x.split(':')[0], int(x.split()[1])) for x in Path('/proc/meminfo').read_text().splitlines())
    return {'available_memory_bytes': mem['MemAvailable'] * 1024, 'free_disk_bytes': shutil.disk_usage('/root').free}


def content(p):
    return sorted((x.relative_to(p).as_posix(), x.stat().st_size, sha(x)) for x in p.rglob('*') if x.is_file() and not x.is_symlink())


def comparable(value):
    return sorted(json.dumps(x, sort_keys=True) for x in value.get('records', []))


parser = argparse.ArgumentParser()
parser.add_argument('--run', required=True, type=Path)
parser.add_argument('--donor-run', required=True, type=Path)
parser.add_argument('--query', action='append', required=True)
parser.add_argument('--concurrent-rounds', type=int, default=10)
parser.add_argument('--limit', type=int, default=10)
parser.add_argument('--oversized-query')
args = parser.parse_args()
assert 1 <= args.limit <= 200
setup = json.loads((args.run / 'setup.json').read_text())
manifest_path = Path(setup['runtime_manifest'])
manifest = json.loads(manifest_path.read_text())
assert sha(manifest_path) == setup['runtime_manifest_sha256']
assert sha(manifest['root_receipt']['path']) == manifest['root_receipt']['sha256']
images = {}
for name, row in manifest['executables'].items():
    p = Path(row['path'])
    assert p.is_file() and not p.is_symlink() and p.stat().st_size == row['bytes'] and sha(p) == row['sha256']
    images[name] = str(p)
root = args.run.parent / (args.run.name + '-tantivy-' + uuid.uuid4().hex[:8])
root.mkdir(mode=0o700)
owned_processes=[]
project = args.run / 'project'
source_before = content(project)
wire = (root / 'wire.jsonl').open('w')
lock = threading.Lock()
receipt = {'schema': 'nudox.real-tantivy-recovery.v1', 'root': str(root), 'original_run': str(args.run), 'donor_run': str(args.donor_run), 'manifest': manifest, 'manifest_sha256': sha(manifest_path), 'source_origin': setup.get('source_origin'), 'whole_project_runtime_pass': False, 'known_excluded_failure': 'provider-only gate; query continuation tested separately on DTO20', 'source_modified': False, 'driver_sha256': sha(__file__), 'page_limit': args.limit, 'original_state_modified': False, 'cases': [], 'baseline': {}, 'resources': []}


def record(kind, **data):
    with lock:
        wire.write(json.dumps({'kind': kind, 'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **data}) + '\n')
        wire.flush()


class Session:
    def __init__(self, label, state):
        self.label, self.state = label, state
        self.folder = root / label
        self.folder.mkdir(mode=0o700, exist_ok=True)
        home, tmp = self.folder / 'home', self.folder / 'tmp'
        home.mkdir(mode=0o700); tmp.mkdir(mode=0o700)
        self.env = dict(setup['env'])
        self.env.update(HOME=str(home), XDG_CONFIG_HOME=str(home / '.config'), XDG_DATA_HOME=str(home / '.local/share'), XDG_STATE_HOME=str(home / '.local/state'), TMPDIR=str(tmp))
        self.endpoint = '/tmp/nudox-tantivy-' + uuid.uuid4().hex[:16] + '.sock'
        self.common = ['--project', str(project), '--workspace', str(state), '--endpoint', self.endpoint]
        self.owner = self.client = None
        self.files = []
        self.sequence, self.buffer = 0, b''

    def start(self):
        r = resources(); receipt['resources'].append(r)
        assert min(r.values()) >= 24 * 1024**3, 'resource launch reserve'
        out, err = [(self.folder / ('owner.' + x)).open('wb') for x in ['stdout', 'stderr']]
        self.files += [out, err]
        argv = [images['backend-locald'], '--workspace', str(self.state), '--endpoint', self.endpoint, '--idle-timeout-ms', '0']
        argv = ['strace', '-ff', '-o', str(self.folder / 'owner.syscalls'), '-e', 'trace=fsync,fchmod', *argv]
        self.owner = subprocess.Popen(argv, cwd=project, env=self.env, stdout=out, stderr=err, start_new_session=True)
        owned_processes.append(self.owner)
        record('owner-start', label=self.label, pid=self.owner.pid, argv=argv, resources=r)
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            if self.owner.poll() is not None:
                break
            probe = socket.socket(socket.AF_UNIX)
            try:
                probe.connect(self.endpoint)
                record('owner-ready', label=self.label, pid=self.owner.pid)
                return
            except (FileNotFoundError, ConnectionRefusedError):
                time.sleep(.05)
            finally:
                probe.close()
        raise RuntimeError('owned daemon did not accept a live connection; no client autostart allowed')

    def cli(self, label, words):
        argv = [images['backend-cli'], '--json', '--detail', 'full', *self.common, *words]
        start = time.monotonic()
        p = subprocess.Popen(argv, cwd=project, env=self.env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        try:
            out, err = p.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM); out, err = p.communicate(timeout=10)
        (self.folder / (label + '.stdout')).write_bytes(out)
        (self.folder / (label + '.stderr')).write_bytes(err)
        assert len(out) <= 4 * 1024 * 1024, 'bounded diagnostic body'
        value = json.loads(out) if out else {}
        record('cli-reply', label=self.label + '/' + label, argv=argv, exit=p.returncode, bytes=len(out), stderr_bytes=len(err), seconds=time.monotonic()-start, payload=value)
        return p.returncode, value

    def mcp(self):
        err = (self.folder / 'mcp.stderr').open('wb'); self.files.append(err)
        self.client = subprocess.Popen([images['backend-mcp'], *self.common], cwd=project, env=self.env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err, start_new_session=True)
        self.selector = selectors.DefaultSelector(); self.selector.register(self.client.stdout, selectors.EVENT_READ)
        self.rpc('initialize', {'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {'name': 'real-tantivy-recovery', 'version': '1'}})
        self.rpc('notifications/initialized', {}, True)

    def rpc(self, method, params, notify=False):
        self.sequence += 1
        request = {'jsonrpc':'2.0', 'method':method, 'params':params}
        if not notify: request['id'] = self.sequence
        record('mcp-request', label=self.label, payload=request)
        self.client.stdin.write((json.dumps(request)+'\n').encode()); self.client.stdin.flush()
        if notify: return
        deadline = time.monotonic()+60
        while b'\n' not in self.buffer:
            if not self.selector.select(max(0,deadline-time.monotonic())): raise TimeoutError('bounded MCP query')
            block = os.read(self.client.stdout.fileno(),65536)
            if not block: raise RuntimeError('MCP EOF')
            self.buffer += block
            assert len(self.buffer) <= 4*1024*1024, 'bounded diagnostic body'
        line,self.buffer=self.buffer.split(b'\n',1)
        reply=json.loads(line); assert reply.get('id')==self.sequence
        record('mcp-reply',label=self.label,bytes=len(line)+1,payload=reply)
        return reply

    def stop_client(self):
        if self.client and self.client.poll() is None:
            try: self.client.stdin.close()
            except BrokenPipeError: pass
            try: self.client.wait(timeout=10)
            except subprocess.TimeoutExpired: os.killpg(self.client.pid,signal.SIGTERM);self.client.wait(timeout=10)
        if self.client: self.selector.close()
        self.client=None

    def stop(self):
        self.stop_client()
        if self.owner and self.owner.poll() is None:
            os.killpg(self.owner.pid,signal.SIGTERM)
            try: self.owner.wait(timeout=20)
            except subprocess.TimeoutExpired: os.killpg(self.owner.pid,signal.SIGKILL);self.owner.wait(timeout=10)
            record('owner-stop',label=self.label,pid=self.owner.pid,exit=self.owner.returncode)
        self.owner=None
        for f in self.files: f.close()


def check_hits(value, query):
    assert value.get('answer') == 'records' and value.get('records'), (query,value)
    witnesses=[]
    for row in value['records']:
        identity=row.get('identity',{})
        path,line=identity.get('path'),identity.get('line')
        if path and line:
            source=project/path
            if source.is_file():
                text=source.read_text(errors='replace').splitlines()
                if 0 < line <= len(text) and query.casefold() in text[line-1].casefold():
                    witnesses.append({'query':query,'coordinate':identity.get('coordinate'),'path':path,'line':line,'source_sha256':sha(source),'line_text':text[line-1]})
    assert witnesses, ('no actual source-line hit',query,value)
    return witnesses


def parity(session, baseline=None):
    values={};witnesses=[]
    for q in args.query:
        code,value=session.cli('search-'+q,['search',q,'--limit',str(args.limit)])
        assert code==0 and value.get('answer')!='fault', (code,value)
        witnesses += check_hits(value,q); values[q]=value
        if baseline is not None: assert comparable(value)==comparable(baseline[q]), ('cold/fault result drift',q)
    session.mcp()
    try:
        for q,value in values.items():
            reply=session.rpc('tools/call',{'name':'backend.search','arguments':{'query':q,'limit':args.limit,'detail':'full'}})
            result=reply['result'];assert not result.get('isError'),reply
            structured=result['structuredContent'];assert comparable(structured)==comparable(value),('CLI/MCP drift',q)
        first=witnesses[0]
        code,source=session.cli('source-witness',['source',first['coordinate']]);assert code==0,(code,source)
        reply=session.rpc('tools/call',{'name':'backend.source','arguments':{'coordinate':first['coordinate'],'detail':'full'}})
        assert not reply['result'].get('isError'),reply
    finally: session.stop_client()
    return values,witnesses


base=root/'state';shutil.copytree(args.run/'state',base)
base_head=sha(base/'objects/HEAD')
selected=list((base/'search-index-v2/v4').glob('*/.last-used'))
assert len(selected)==1,'first-publication cache has one selected root'
selected_relative=selected[0].parent.relative_to(base)
donor_stamps=list((args.donor_run/'state/search-index-v2/v4').glob('*/.last-used'))
assert len(donor_stamps)==1 and donor_stamps[0].parent.name!=selected_relative.name
baseline=None
try:
    s=Session('warm',base)
    try:
        s.start();baseline,witnesses=parity(s)
        if args.oversized_query:
            code,fault=s.cli('oversized-query',['search',args.oversized_query,'--limit','200'])
            assert fault.get('answer')=='fault' and fault.get('slug')=='transport' and fault.get('cause')=='oversized',fault
            assert len(json.dumps(fault).encode()) <= 16384
            s.mcp()
            try:
                reply=s.rpc('tools/call',{'name':'backend.search','arguments':{'query':args.oversized_query,'limit':200,'detail':'full'}})
                mcp_fault=reply['result']['structuredContent']
                assert mcp_fault.get('answer')=='fault' and mcp_fault.get('slug')==fault['slug'] and mcp_fault.get('cause')==fault['cause'],reply
                assert len(json.dumps(reply).encode()) <= 16384
                receipt['typed_oversized_refusal']={'cli_exit':code,'cli_fault':fault,'mcp_fault':mcp_fault}
            finally:s.stop_client()
        receipt['baseline']={'witnesses':witnesses,'queries':list(baseline),'head_sha256':base_head,'selected_root':str(selected_relative)}
        def concurrent_read(item):
            n,q=item;code,value=s.cli('concurrent-'+str(n),['search',q,'--limit',str(args.limit)])
            assert code==0 and comparable(value)==comparable(baseline[q]),('concurrent result drift',n,q,value)
            return {'query':q,'number':n,'records':len(value['records'])}
        work=[(n,args.query[n%len(args.query)]) for n in range(args.concurrent_rounds*len(args.query)*3)]
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            receipt['concurrent_reads']=list(pool.map(concurrent_read,work))
    finally:s.stop()
    assert sha(base/'objects/HEAD')==base_head,'read-only warm/concurrent head changed'
    s=Session('cold',base)
    try:s.start();parity(s,baseline)
    finally:s.stop()
    assert sha(base/'objects/HEAD')==base_head,'cold read head changed'
    cases=['selected-stamp-0','selected-stamp-7','selected-stamp-17','unused-stamp-0','unused-stamp-7','unused-stamp-17','stale-selected-index','corrupt-selected-index','partial-publication']
    for label in cases:
        state=root/(label+'-state');shutil.copytree(base,state)
        target=state/selected_relative;injection={'classification':'deliberate-private-cache-fault','case':label}
        if label.startswith('selected-stamp-'):
            length=int(label.rsplit('-',1)[1]);stamp=target/'.last-used';before=stamp.read_bytes();stamp.write_bytes((before+b'\0')[:length]);injection.update(file=str(stamp),bytes=length,before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=sha(stamp))
        elif label.startswith('unused-stamp-'):
            unused=target.parent/donor_stamps[0].parent.name;shutil.copytree(donor_stamps[0].parent,unused)
            length=int(label.rsplit('-',1)[1]);stamp=unused/'.last-used';before=stamp.read_bytes();stamp.write_bytes((before+b'\0')[:length]);injection.update(file=str(stamp),bytes=length,unused_existing_root_transplant=True,donor_root=str(donor_stamps[0].parent),selected_stamp_sha256=sha(target/'.last-used'),after_sha256=sha(stamp))
        elif label=='stale-selected-index':
            shutil.rmtree(target);shutil.copytree(donor_stamps[0].parent,target);injection.update(donor_root=str(donor_stamps[0].parent),transplanted_file_inventory=content(target))
        elif label=='corrupt-selected-index':
            payload=next(target.glob('*.idx'));data=bytearray(payload.read_bytes());assert data;data[len(data)//2]^=1;before=sha(payload);payload.write_bytes(data);injection.update(file=str(payload),before_sha256=before,after_sha256=sha(payload),same_length=True)
        else:
            marker=target/'backend-binding-v3';before=sha(marker);marker.write_bytes(b'partial authority');stage=target.parent/('.'+'0'*64+'.building-1-1');stage.mkdir(mode=0o700);injection.update(file=str(marker),before_sha256=before,after_sha256=sha(marker),stage=str(stage))
        record('deliberate-injection',**injection)
        s=Session(label,state);row={'injection':injection,'head_before_sha256':sha(state/'objects/HEAD'),'pass':False}
        try:
            s.start();_,found=parity(s,baseline);row.update(witnesses=found)
            row['pass']=True
            if label=='partial-publication':assert not stage.exists(),'dead partial stage was retained'
        except Exception as error:
            row['error_type']=type(error).__name__;row['error']=str(error)[:16384]
            record('case-failure',**row)
        finally:s.stop()
        if row['pass']:
            recovered=Session(label+'-recovered-cold',state)
            try:
                recovered.start();parity(recovered,baseline)
                row['second_cold_reopen_pass']=True
            except Exception as error:
                row['pass']=False;row['second_cold_reopen_pass']=False
                row['error_type']=type(error).__name__;row['error']=str(error)[:16384]
            finally:recovered.stop()
        row['cache_after_file_inventory']=content(target)
        row['head_after_sha256']=sha(state/'objects/HEAD');assert row['head_after_sha256']==row['head_before_sha256'],'fault query published owner mutation'
        receipt['cases'].append(row)
        print(json.dumps({'case':label,'pass':row['pass'],'error':row.get('error')}),flush=True)
    receipt['provider_gate_pass']=all(x['pass'] for x in receipt['cases'])
except Exception as error:
    receipt['error_type']=type(error).__name__;receipt['error']=str(error)[:16384]
finally:
    receipt['source_unchanged']=content(project)==source_before
    receipt['original_state_head_sha256']=sha(args.run/'state/objects/HEAD')
    receipt['remaining_owned_daemons']=[p.pid for p in owned_processes if p.poll() is None]
    wire.close();receipt['wire_sha256']=sha(root/'wire.jsonl')
    (root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'root':str(root),'provider_gate_pass':receipt.get('provider_gate_pass',False),'error':receipt.get('error'),'source_unchanged':receipt['source_unchanged']}),flush=True)
