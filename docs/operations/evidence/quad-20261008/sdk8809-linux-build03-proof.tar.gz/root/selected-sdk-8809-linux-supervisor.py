import argparse, datetime, fcntl, hashlib, json, os, pathlib, shlex, subprocess, threading, time
p=argparse.ArgumentParser();p.add_argument('--plan',required=True);p.add_argument('--plan-sha',required=True);p.add_argument('--admission',required=True);p.add_argument('--out',required=True);a=p.parse_args()
def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert sha(a.plan)==a.plan_sha
plan=json.loads(pathlib.Path(a.plan).read_text());wt=pathlib.Path(plan['worktree']);target=wt/'.local/target';role=wt/'.local/sdk-release-role';out=pathlib.Path(a.out)
git='/run/current-system/sw/bin/git'
def identity():
 def run(*args):return subprocess.check_output([git,'-C',str(wt),*args],text=True).strip()
 return dict(commit=run('rev-parse','HEAD'),tree=run('rev-parse','HEAD^{tree}'),clean=not run('status','--porcelain'),cargo_lock_sha256=sha(wt/'Cargo.lock'))
before=identity();assert before==plan['source'];assert before['clean']
assert not wt.is_symlink() and wt.resolve()==wt
(wt/'.local').mkdir(exist_ok=True)
lockpath=wt/'.local/sdk-release-source.lock';assert not lockpath.is_symlink();held=lockpath.open('a+');fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB)
for path,digest in plan['tools'].items():assert sha(path)==digest
for path in [target,role]:
 assert not path.is_symlink()
 if path.exists():
  stamp=path/'.nudox-worktree-root'
  if stamp.exists():assert not stamp.is_symlink() and stamp.read_text().strip()==str(wt)
leases=role/'.nudox-cargo/leases'
if leases.exists():assert not list(leases.iterdir())
# Hash all compile-relevant materialized tracked files, with checked-out links recorded as links.
tracked=subprocess.check_output([git,'-C',str(wt),'ls-files','-z','--','Cargo.toml','Cargo.lock','.cargo','.config','crates','frontends','extensions','apps','tests','tools','vendor','third_party','assets','server','workspace']).split(b'\0')
tree_entries={}
for row in subprocess.check_output([git,'-C',str(wt),'ls-tree','-rz','HEAD']).split(b'\0'):
 if row:
  spec,rel=row.split(b'\t',1);tree_entries[os.fsdecode(rel)]=os.fsdecode(spec).split()
def inputs():
 result={}
 for raw in tracked:
  if not raw:continue
  rel=os.fsdecode(raw);path=wt/rel
  if tree_entries[rel][0]=='160000':
   assert not path.exists() or (path.is_dir() and not any(path.iterdir())),('unadmitted materialized gitlink',rel)
   result[rel]={'kind':'unmaterialized-gitlink','commit':tree_entries[rel][2]}
  elif path.is_symlink():result[rel]={'kind':'tracked-link','sha256':hashlib.sha256(os.fsencode(os.readlink(path))).hexdigest()}
  else:
   assert path.is_file(),('tracked input absent',rel)
   result[rel]={'kind':'file','sha256':sha(path),'bytes':path.stat().st_size}
 return result
source_inputs=inputs();source_sha=hashlib.sha256(json.dumps(source_inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest()
fleet=json.loads(pathlib.Path(a.admission).read_text());now=datetime.datetime.now(datetime.timezone.utc)
assert fleet['advisory_allowed'] and fleet['destination']=='ilo' and fleet['requested_cargo_jobs']==plan['allocation']['jobs']
assert fleet['allow_local_over_cap_for_remote'] is True and fleet['destination_memory_only_for_remote'] is True and fleet['memory_guard_scope']=='destination'
assert fleet['minimum_available_memory_bytes_each_host'] is None and fleet['minimum_available_memory_bytes_destination']==8*1024**3
assert all(h['complete'] and isinstance(h['available_memory_bytes'],int) and not isinstance(h['available_memory_bytes'],bool) and h['available_memory_bytes']>=0 and h['memory_floor_applies']==(name=='ilo') and 0<=(now-datetime.datetime.fromisoformat(h['resource_sampled_at_utc'])).total_seconds()<30 for name,h in fleet['hosts'].items())
assert fleet['current_fleet_compiler_group_count']<16 and fleet['hosts']['ilo']['compiler_group_count']<8
assert fleet['hosts']['ilo']['available_memory_bytes']>=plan['allocation']['extra_memory_floor_bytes'] and fleet['hosts']['ilo']['root_disk_available_bytes']>=plan['allocation']['extra_disk_floor_bytes']
out.mkdir(mode=0o700,parents=True);(out/'source-inputs.json').write_text(json.dumps(source_inputs,sort_keys=True,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith(('NUDOX_','BACKEND_')) and k not in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_TARGET_DIR','CARGO_BUILD_BUILD_DIR','SCCACHE_SERVER_UDS','LD_LIBRARY_PATH','LD_PRELOAD','LD_AUDIT','NIX_LD','NIX_LD_LIBRARY_PATH','NODE_OPTIONS','NODE_PATH']}
env.update(plan['environment']);env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_BUILD_DIR=str(role),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS=str(plan['allocation']['jobs']),NUDOX_CARGO_BUILD_SLOTS='6',NUDOX_CARGO_SLOT_WAIT_MS='0',NUDOX_CARGO_WORKTREE_WAIT_MS='0',NUDOX_CARGO_CACHE_VERBOSE='1')
argv=[plan['runner'],*plan['argv']]
receipt={'schema':'nudox.runtime-artifact-build-receipt.v1','source':dict(before,clean_before=True,clean_after=False),'source_before':before,'source_input_manifest_sha256':source_sha,'source_input_count':len(source_inputs),'plan_sha256':a.plan_sha,'admission_sha256':sha(a.admission),'argv':argv,'cwd':str(wt),'started_utc':utc(),'supervisor_pid':os.getpid(),'rustc_processes':[],'allocation':plan['allocation'],'toolchain':{'unchanged':False,'tool_sha256':plan['tools']}}
stop=threading.Event()
def watch(child):
 seen=set()
 while not stop.wait(.15):
  try:rows=subprocess.check_output(['/run/current-system/sw/bin/ps','-eo','pid=,pgid=,comm='],text=True).splitlines()
  except subprocess.CalledProcessError:continue
  for row in rows:
   values=row.split()
   if len(values)!=3:continue
   pid,pgid,comm=values
   if int(pgid)!=child.pid or pid in seen or comm not in ['rustc','rustc-real']:continue
   proc=pathlib.Path('/proc')/pid
   try:
    cwd=str((proc/'cwd').readlink());tokens=os.fsdecode((proc/'cmdline').read_bytes()).rstrip('\0').split('\0')
    sources=[str((pathlib.Path(cwd)/v).resolve()) for v in tokens if v.endswith('.rs')]
    if not sources or not all(pathlib.Path(v).is_relative_to(wt) for v in sources):continue
    crate=tokens[tokens.index('--crate-name')+1]
    seen.add(pid);receipt['rustc_processes'].append(dict(pid=int(pid),cwd=cwd,argv=tokens,crate_name=crate,source_paths=sources,observed_utc=utc(),executable=str((proc/'exe').readlink())))
   except (OSError,ValueError,IndexError):continue
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(argv,cwd=wt,env=env,stdout=stdout,stderr=stderr,start_new_session=True);receipt['pid']=child.pid;(out/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'pid':child.pid,'out':str(out),'source':before}),flush=True)
 observer=threading.Thread(target=watch,args=(child,),daemon=True);observer.start();receipt['exit']=child.wait();stop.set();observer.join()
after=identity();receipt.update(source_after=after,ended_utc=utc(),retirement='owned-child-kernel-wait',managed_leases_empty=not list(leases.iterdir()) if leases.exists() else True)
receipt['source']['clean_after']=after==before and inputs()==source_inputs
receipt['toolchain']['unchanged']=all(sha(path)==digest for path,digest in plan['tools'].items())
receipt['stdout_sha256']=sha(out/'stdout.log');receipt['stderr_sha256']=sha(out/'stderr.log');receipt['artifacts']={};receipt['cargo_artifact_records']={}
for line in (out/'stdout.log').read_text().splitlines():
 try:item=json.loads(line)
 except json.JSONDecodeError:continue
 name=item.get('target',{}).get('name')
 if item.get('reason')=='compiler-artifact' and item.get('executable') and name in ['backend-cli','backend-mcp','backend-locald']:
  assert name not in receipt['artifacts'];image=pathlib.Path(item['executable']);assert image.is_file() and not image.is_symlink() and image.is_relative_to(target) and 0<image.stat().st_size<=512*1024**2
  receipt['artifacts'][name]={'path':str(image),'bytes':image.stat().st_size,'sha256':sha(image)};receipt['cargo_artifact_records'][name]=item
required={'backend-cli':'backend_cli','backend-mcp':'backend_mcp','backend-locald':'backend_locald'}
receipt['compiler_source_bound']=set(receipt['artifacts'])==set(required) and all(receipt['cargo_artifact_records'][name]['fresh'] is False and not receipt['cargo_artifact_records'][name]['profile']['test'] and any(r['crate_name']==crate for r in receipt['rustc_processes']) for name,crate in required.items())
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert after==before and receipt['source']['clean_after'] and receipt['toolchain']['unchanged'] and receipt['managed_leases_empty']
if receipt['exit']==0:
 assert receipt['compiler_source_bound'],'No matched release proof: compiler-source binding incomplete'
 # Copy just the produced product executables to evidence, never a Cargo graph/cache.
 images=out/'images';images.mkdir(mode=0o700)
 import shutil
 for name,record in receipt['artifacts'].items():
  image=images/name;shutil.copyfile(record['path'],image);image.chmod(0o555);assert sha(image)==record['sha256'];record['path']=str(image)
 # Product hashes do not change when evidence paths change; root receipt binds immutable image paths.
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 build={'schema':'nudox.runtime-build-manifest.v1','source':before,'executables':receipt['artifacts'],'root_receipt':{'schema':receipt['schema'],'path':str(out/'receipt.json'),'sha256':sha(out/'receipt.json')}}
 (out/'runtime-build-manifest.json').write_text(json.dumps(build,indent=2)+'\n')
print(json.dumps({k:receipt.get(k) for k in ['exit','compiler_source_bound','artifacts','ended_utc']}),flush=True)
raise SystemExit(receipt['exit'])
