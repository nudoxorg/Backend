"""Normalize only optional public source metadata; never alter compiler proof or artifacts."""
import datetime,hashlib,json,pathlib
base=pathlib.Path('/root/sol61-sdk-current-06697079-linux-release-20261008/build-03');original=base/'runtime-build-manifest.json';output=base/'runtime-build-manifest-canonical-source.json';evidence=base/'public-source-adapter-receipt.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
raw=original.read_bytes();build=json.loads(raw);source=build['source'];assert set(source)=={'commit','tree','clean','cargo_lock_sha256'};assert source['commit']=='8809eb34a5c44ee83145c143b9d444124542adc8' and source['tree']=='aa8ddaad4213ac5e84368fa96cdc59a1963221c0' and source['clean'] is True
root_path=pathlib.Path(build['root_receipt']['path']);assert sha(root_path)==build['root_receipt']['sha256'];receipt=json.loads(root_path.read_bytes());assert receipt['exit']==0 and receipt['compiler_source_bound'] and receipt['source']['clean_before'] and receipt['source']['clean_after'] and receipt['toolchain']['unchanged'];assert source['cargo_lock_sha256']==receipt['source']['cargo_lock_sha256']=='5d0b0b75a5acb9fd95db98d160ede1e3c780069cdc9989561491fe2cb5ba3da0'
assert build['executables']==receipt['artifacts'] and set(build['executables'])=={'backend-cli','backend-mcp','backend-locald'}
for record in build['executables'].values():
 p=pathlib.Path(record['path']);assert p.is_file() and not p.is_symlink() and p.stat().st_size==record['bytes'] and sha(p)==record['sha256']
normalized=json.loads(raw);removed=normalized['source'].pop('cargo_lock_sha256');assert {**normalized['source'],'cargo_lock_sha256':removed}==source;assert {k:v for k,v in normalized.items() if k!='source'}=={k:v for k,v in build.items() if k!='source'}
with output.open('x') as f:f.write(json.dumps(normalized,indent=2)+'\n')
assert original.read_bytes()==raw
proof={'schema':'nudox.public-source-generator-adaptation.v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'adapter_path':str(pathlib.Path(__file__).resolve()),'adapter_sha256':sha(pathlib.Path(__file__)),'original_manifest':str(original),'original_sha256':sha(original),'normalized_manifest':str(output),'normalized_sha256':sha(output),'only_change':{'removed_key':'source.cargo_lock_sha256','value':removed},'root_receipt_unchanged':{'path':str(root_path),'sha256':sha(root_path)},'artifacts_unchanged':build['executables'],'reason':'Production public build manifest source schema keeps commit/tree/clean; package and nativeSDK compare that object exactly. Authentic compiler rootreceipt retains andattests Cargo.lock.'}
with evidence.open('x') as f:f.write(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2),flush=True)
