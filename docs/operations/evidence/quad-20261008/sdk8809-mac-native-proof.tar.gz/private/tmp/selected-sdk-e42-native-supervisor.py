import argparse,datetime,fcntl,hashlib,json,os,pathlib,resource,shlex,subprocess,threading,time
p=argparse.ArgumentParser();p.add_argument('--plan',required=True);p.add_argument('--plan-sha',required=True);p.add_argument('--admission',required=True);p.add_argument('--gate',type=int,choices=[0,1,2,3],required=True);p.add_argument('--out',required=True);p.add_argument('--build-receipt');a=p.parse_args()
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert sha(a.plan)==a.plan_sha;plan=json.loads(pathlib.Path(a.plan).read_text());alloc=plan['allocation'];source=pathlib.Path(alloc['source_worktree']);graph=pathlib.Path(alloc['graph_root']);role=pathlib.Path(alloc['build_role']);slot=pathlib.Path(alloc['slot']);out=pathlib.Path(a.out)
def identity(root):
 def git(*v):return subprocess.check_output(['/usr/bin/git','-C',str(root),*v],text=True).strip()
 return dict(commit=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),clean=not git('status','--porcelain'),cargo_lock_sha256=sha(root/'Cargo.lock'))
before=identity(source);frozen=identity(graph);assert before['commit']==plan['source']['commit'] and before['tree']==plan['source']['tree'] and before['clean'];assert frozen==alloc['frozen_graph_source'];assert before['cargo_lock_sha256']==plan['source']['cargo_lock_sha256'];assert sha(alloc['handoff_path'])==alloc['handoff_sha256'];assert sha(alloc['prior_return_path'])==alloc['prior_return_sha256']
source.joinpath('.local').mkdir(exist_ok=True);held=[]
for path in [pathlib.Path(alloc['lifetime_lock']),source/'.local/sdk-source-lifetime.lock']:
 assert not path.is_symlink();f=path.open('a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);held.append(f)
assert not list((role/'.nudox-cargo/leases').iterdir())
for path,record in alloc['tools'].items():assert sha(path)==record['sha256']
# No compiler or test image is admitted to the graph while another process uses it.
for line in subprocess.check_output(['/bin/ps','-axo','pid=,comm=,args='],text=True).splitlines():
 parts=line.strip().split(None,2)
 if len(parts)<3:continue
 pid,comm,args=parts
 if pathlib.Path(args.split()[0]).name not in ['cargo','rustc','rustc-real','clippy-driver'] and 'backend_engine-' not in args:continue
 assert str(graph/'.local') not in args,(pid,args)
 state=subprocess.run(['/usr/sbin/lsof','-a','-p',pid,'-d','cwd','-Fn'],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if state.returncode==0:assert not any(l.startswith('n'+str(graph)) or l.startswith('n'+str(source)) for l in state.stdout.splitlines()),(pid,state.stdout)
 elif subprocess.run(['/bin/kill','-0',pid],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:raise AssertionError(('live graph candidate cwd unreadable',pid))
# Content hashes close all workspace crates/frontend sources used by this compiler recipe.
paths=subprocess.check_output(['/usr/bin/git','-C',str(source),'ls-files','-z','--','Cargo.toml','Cargo.lock','.cargo','.config','crates','frontends','tools/package/linux_system_sonames.txt']).split(b'\0')
def inputs():
 result={}
 for v in paths:
  if not v:continue
  relative=os.fsdecode(v);path=source/relative
  if path.is_symlink():result[relative]={'kind':'tracked-link','sha256':hashlib.sha256(os.fsencode(os.readlink(path))).hexdigest()}
  else:
   assert path.is_file(),('tracked source not a checked-out file',relative)
   result[relative]={'kind':'file','sha256':sha(path)}
 return result
source_inputs=inputs();source_input_sha=hashlib.sha256(json.dumps(source_inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest()
out.mkdir(mode=0o700,parents=True);(out/'source-inputs.json').write_text(json.dumps(source_inputs,sort_keys=True,indent=2)+'\n')
fleet=json.loads(pathlib.Path(a.admission).read_text());now=datetime.datetime.now(datetime.timezone.utc)
assert fleet['advisory_allowed'] and fleet['memory_guard_scope']=='destination' and fleet['destination_memory_only_for_remote'] is True and fleet['minimum_available_memory_bytes_each_host'] is None and fleet['minimum_available_memory_bytes_destination']==8*1024**3
assert all(h['complete'] and isinstance(h['available_memory_bytes'],int) and not isinstance(h['available_memory_bytes'],bool) and h['available_memory_bytes']>=0 and h['memory_floor_applies']==(name=='h16001mac') and 0<=(now-datetime.datetime.fromisoformat(h['resource_sampled_at_utc'])).total_seconds()<30 for name,h in fleet['hosts'].items())
assert fleet['current_fleet_compiler_group_count']<16 and fleet['hosts']['h16001mac']['compiler_group_count']<8 and fleet['hosts']['h16001mac']['available_memory_bytes']>=8*1024**3 and fleet['hosts']['h16001mac']['root_disk_available_bytes']>=16*1024**3
stamps=[]
for path,record in alloc['original_stamps'].items():
 stamp=pathlib.Path(path);assert stamp.is_file() and not stamp.is_symlink();previous=stamp.read_text();assert previous.strip() in [str(graph),str(source)];tmp=stamp.with_name(stamp.name+'.sdk-'+str(os.getpid()));tmp.write_text(str(source)+'\n');os.replace(tmp,stamp);stamps.append({'path':path,'before':previous,'after':str(source)+'\n'})
raw=subprocess.check_output(['/bin/bash','-c','set -a; source "$1"; /usr/bin/env -0','sdk-env',alloc['environment_file']]);env=dict(v.split('=',1) for v in os.fsdecode(raw).split('\0') if v)
env.update(CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',NUDOX_CARGO_BUILD_SLOTS='6',NUDOX_CARGO_SLOT_WAIT_MS='0',NUDOX_CARGO_WORKTREE_WAIT_MS='0',CARGO_TARGET_DIR=alloc['target'],CARGO_BUILD_BUILD_DIR=str(role),SCCACHE_DIR=alloc['sccache']);env.pop('SCCACHE_SERVER_UDS',None)
soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE);resource.setrlimit(resource.RLIMIT_NOFILE,(alloc['fd_limit'],hard))
receipt=dict(source_before=before,frozen_graph_before=frozen,source_input_manifest_sha256=source_input_sha,source_input_count=len(source_inputs),plan_sha256=a.plan_sha,handoff_sha256=alloc['handoff_sha256'],admission_sha256=sha(a.admission),stamps=stamps,started_utc=utc(),cwd=str(source),gate=a.gate,supervisor_pid=os.getpid(),rustc_processes=[])
if a.gate==0:
 argv=[alloc['runner'],*plan['native_controls'][0]['managed_runner_subcommand']]
else:
 build=json.loads(pathlib.Path(a.build_receipt).read_text());assert build['exit']==0 and build['source_after']==before and build['source_input_manifest_sha256']==source_input_sha and build['compiler_source_bound'] is True
 image=pathlib.Path(build['artifact']['path']);assert image.is_file() and not image.is_symlink() and image.is_relative_to(slot) and sha(image)==build['artifact']['sha256'];receipt['artifact_before']=dict(path=str(image),sha256=sha(image),bytes=image.stat().st_size);receipt['build_receipt_sha256']=sha(a.build_receipt);argv=[str(image),*plan['native_controls'][a.gate]['argv']]
receipt['argv']=argv
stop=threading.Event()
def watch(child):
 seen=set()
 while not stop.wait(.1):
  for line in subprocess.check_output(['/bin/ps','-axo','pid=,comm=,args='],text=True).splitlines():
   parts=line.strip().split(None,2)
   if len(parts)<3:continue
   pid,comm,args=parts
   if pid in seen or '--crate-name backend_engine ' not in args:continue
   try:
    if os.getpgid(int(pid))!=child.pid:continue
    sample=subprocess.run(['/usr/sbin/lsof','-a','-p',pid,'-d','cwd','-Fn'],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    cwd=next(l[1:] for l in sample.stdout.splitlines() if l.startswith('n'))
    tokens=shlex.split(args);sources=[str((pathlib.Path(cwd)/v).resolve()) for v in tokens if v.endswith('.rs')]
    if not sources or not all(pathlib.Path(v).is_relative_to(source) for v in sources):continue
    if pathlib.Path(tokens[0]).name not in ['rustc','rustc-real']:continue
    seen.add(pid);receipt['rustc_processes'].append(dict(pid=int(pid),cwd=cwd,args=args,source_paths=sources,args_sha256=hashlib.sha256(args.encode()).hexdigest(),observed_utc=utc()))
   except (OSError,StopIteration,ValueError):continue
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(argv,cwd=source,env=env,stdout=stdout,stderr=stderr,start_new_session=True);receipt['pid']=child.pid;(out/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(pid=child.pid,out=str(out),gate=a.gate)),flush=True);observer=threading.Thread(target=watch,args=(child,),daemon=True);observer.start();receipt['exit']=child.wait();stop.set();observer.join()
receipt.update(source_after=identity(source),frozen_graph_after=identity(graph),ended_utc=utc(),retirement='owned-child-kernel-wait',managed_leases_empty=not list((role/'.nudox-cargo/leases').iterdir()))
assert receipt['source_after']==before and receipt['frozen_graph_after']==frozen and inputs()==source_inputs and receipt['managed_leases_empty']
assert all(sha(path)==record['sha256'] for path,record in alloc['tools'].items())
if a.gate==0:
 artifacts=[]
 for line in (out/'stdout.log').read_text().splitlines():
  try:item=json.loads(line)
  except json.JSONDecodeError:continue
  if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='backend_engine' and item.get('profile',{}).get('test') and item.get('executable'):artifacts.append(item)
 receipt['cargo_test_artifacts']=artifacts;receipt['compiler_source_bound']=bool(receipt['rustc_processes']) and len(artifacts)==1 and artifacts[0]['fresh'] is False and pathlib.Path(artifacts[0]['manifest_path'])==source/'crates/engine/Cargo.toml'
 if artifacts:
  image=pathlib.Path(artifacts[-1]['executable']);assert image.is_file() and not image.is_symlink() and image.is_relative_to(slot);receipt['artifact']=dict(path=str(image),sha256=sha(image),bytes=image.stat().st_size)
else:
 receipt['artifact_after']=dict(path=str(image),sha256=sha(image),bytes=image.stat().st_size);assert receipt['artifact_after']==receipt['artifact_before']
receipt['stdout_sha256']=sha(out/'stdout.log');receipt['stderr_sha256']=sha(out/'stderr.log');(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt.get(k) for k in ['exit','compiler_source_bound','rustc_processes','artifact','ended_utc']}),flush=True)
if a.gate==0 and receipt['exit']==0:assert receipt['compiler_source_bound'],'compiled source provenance not attested; no native test claim'
raise SystemExit(receipt['exit'])
