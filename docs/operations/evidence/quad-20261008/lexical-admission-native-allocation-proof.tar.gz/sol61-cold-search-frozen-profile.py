import hashlib,json,os,pathlib,re,subprocess,sys,time
root=pathlib.Path('/root/codex-worktrees/sol61-cold-search-owned-tests-20261008')
label=sys.argv[1]
assert label in ['candidate','baseline']
manifest=json.loads((root/f'{label}-testbin.json').read_text())
binary=pathlib.Path(manifest['binary'])
assert binary.resolve().is_relative_to(root)
assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['sha256']
results=[]
for size in [16384,1048576,16777216]:
    env=dict(os.environ,BACKEND_DOCUMENT_ADMISSION_PROFILE_BYTES=str(size))
    argv=[str(binary),'--exact','tests::document_relation_admission_profile','--ignored','--nocapture','--test-threads=1']
    log_path=root/f'frozen-profile-{label}-{size}.log'
    r={'label':label,'input_bytes':size,'binary':manifest,'argv':argv,'started_unix':time.time()}
    with log_path.open('w') as log:
        p=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        r.update(pid=p.pid,start_ticks=pathlib.Path(f'/proc/{p.pid}/stat').read_text().split()[21])
        (root/f'frozen-profile-{label}-{size}.json').write_text(json.dumps(r,indent=2)+'\n')
        status=p.wait()
    output=log_path.read_text()
    assert status==0,output
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in output,output
    found=re.search(r'document_relation_admission text_bytes=(\d+) iterations=(\d+) elapsed_ns=(\d+) allocation_count=(\d+) allocation_bytes=(\d+) allocation_peak_bytes=(\d+)',output)
    assert found and int(found[1])==size and int(found[2])==64,output
    r.update(exit_code=status,completed_unix=time.time(),metrics=dict(zip(['text_bytes','iterations','elapsed_ns','allocation_count','allocation_bytes','allocation_peak_bytes'],map(int,found.groups()))))
    (root/f'frozen-profile-{label}-{size}.json').write_text(json.dumps(r,indent=2)+'\n')
    results.append(r)
    print(json.dumps(r['metrics']),flush=True)
(root/f'frozen-profile-{label}-summary.json').write_text(json.dumps(results,indent=2)+'\n')
