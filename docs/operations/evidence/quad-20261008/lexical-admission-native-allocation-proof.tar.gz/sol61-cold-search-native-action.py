import hashlib, json, os, pathlib, resource, subprocess, sys, time
root = pathlib.Path('/root/codex-worktrees/sol61-cold-search-owned-tests-20261008')
source = root / 'source'
base = json.loads((root / 'native-build-v4-receipt.json').read_text())
mode = sys.argv[1]
assert mode in ['suite-candidate','profile-candidate-16384','profile-candidate-1048576','profile-candidate-16777216','build-baseline','profile-baseline-16384','profile-baseline-1048576','profile-baseline-16777216']
env = dict(os.environ, **base['environment'])
argv = [base['argv'][0], 'test', '--locked', '--offline', '-j2', '-p', 'backend-extension-tantivy', '--lib']
if mode == 'suite-candidate':
    argv += ['--', '--test-threads=2']
elif mode == 'build-baseline':
    argv += ['--no-run','--message-format=json-render-diagnostics']
else:
    env['BACKEND_DOCUMENT_ADMISSION_PROFILE_BYTES'] = mode.rsplit('-',1)[1]
    argv += ['tests::document_relation_admission_profile','--','--ignored','--exact','--nocapture','--test-threads=1']
def git(*args):
    return subprocess.check_output(['git','-C',str(source),*args],text=True).strip()
assert git('status','--porcelain') == ''
receipt = {'mode':mode,'source_commit':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD^{tree}'),
    'argv':argv,'started_unix':time.time(),'input_bytes':env.get('BACKEND_DOCUMENT_ADMISSION_PROFILE_BYTES'),
    'delta_sha256':hashlib.sha256((source/'extensions/tantivy/src/delta.rs').read_bytes()).hexdigest(),
    'test_sha256':hashlib.sha256((source/'extensions/tantivy/src/tests.rs').read_bytes()).hexdigest()}
with (root/f'{mode}.log').open('w') as log:
    process = subprocess.Popen(argv,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
    receipt.update(pid=process.pid,start_ticks=pathlib.Path(f'/proc/{process.pid}/stat').read_text().split()[21])
    (root/f'{mode}.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'mode':mode,'pid':process.pid,'source':receipt['source_commit']}),flush=True)
    status = process.wait()
receipt.update(exit_code=status,completed_unix=time.time(),child_max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
(root/f'{mode}.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'mode':mode,'exit_code':status,'child_max_rss_kib':receipt['child_max_rss_kib']}),flush=True)
raise SystemExit(status)
