import datetime, fcntl, hashlib, json, os, pathlib, re, resource, subprocess, sys, time
WT=pathlib.Path('/root/codex-worktrees/sol61-structural-graph-latency-20261007')
EVIDENCE=pathlib.Path('/root/sol61-structural-graph-evidence-20261007')
EXPECTED='9946624b0783ab4eff44105bd509cfb25f2e3d65'
RUST='/nix/store/lynmg3kdpdz41r84nafwzi2n5nss50pq-rust-1.97.1-with-components-2026-07-16/bin'
TOOLS='/nix/store/n4b80fmlzlmxx0584y7acwcnikk4k071-nudox-luna-tools-shell/bin'
MAKE='/nix/store/5hndr36f8c9d9z305r27z6dxkhysng95-gnumake-4.4.1/bin'
WRAPPER='/root/nudox-corpus-20261006/tool-recovery/cargo-wrapped-nix6'
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',str(WT),*args],text=True).strip()
def source(): return dict(commit=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),clean=not git('status','--porcelain'),lock_sha256=sha(WT/'Cargo.lock'))
def timestamp(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def validate(fleet):
 now=datetime.datetime.now(datetime.timezone.utc)
 assert fleet['schema']=='compiler-capacity-admission.v5' and fleet['advisory_allowed'] and fleet['destination']=='ilo' and fleet['requested_cargo_jobs']==2
 assert set(fleet['raw_samples'])=={'local','ilo','h16001mac'}
 ages={name:(now-timestamp(sample['census']['sample_started_at_utc'])).total_seconds() for name,sample in fleet['raw_samples'].items()}
 assert all(-5<=age<=30 for age in ages.values()),ages
 assert all(sample['transport_complete'] and sample['census']['complete'] for sample in fleet['raw_samples'].values())
 assert fleet['current_fleet_compiler_group_count']+1<=16 and fleet['hosts']['ilo']['compiler_group_count']+1<=8
 assert all(host['complete'] and host['available_memory_bytes']>=8*1024**3 for host in fleet['hosts'].values())
 assert fleet['hosts']['ilo']['root_disk_available_bytes']>=16*1024**3
 return ages
os.umask(0o077)
EVIDENCE.mkdir(exist_ok=True,mode=0o700);(WT/'.local').mkdir(exist_ok=True)
env=dict(os.environ)
env.update(PATH=RUST+':'+TOOLS+':'+MAKE+':/run/current-system/sw/bin',CARGO_HOME='/root/.cargo',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',RUSTC_WRAPPER='/nix/store/cp7wjv1pl4wapfk48svvizxd089v9h0a-coreutils-9.11/bin/env',NUDOX_CARGO_BUILD_SLOTS='6',NUDOX_CARGO_SLOT_WAIT_MS='0',NUDOX_CARGO_WORKTREE_WAIT_MS='0',CARGO_TARGET_DIR=str(WT/'.local/target'),CARGO_BUILD_BUILD_DIR=str(WT/'.local/structural-owned-build-role'),RUSTC=RUST+'/rustc',RUSTDOC=RUST+'/rustdoc',CC=TOOLS+'/cc',CXX=TOOLS+'/c++',AR=TOOLS+'/ar',LD=TOOLS+'/ld',PKG_CONFIG=TOOLS+'/pkg-config',LIBRARY_PATH='',NIX_LDFLAGS='',PKG_CONFIG_PATH='')
tools={name:{'path':path,'sha256':sha(path),'executable':os.access(path,os.X_OK)} for name,path in dict(rustc=env['RUSTC'],rustdoc=env['RUSTDOC'],cc=env['CC'],cxx=env['CXX'],ar=env['AR'],ld=env['LD'],pkgconfig=env['PKG_CONFIG'],rustc_wrapper=env['RUSTC_WRAPPER'],cargo_wrapper=WRAPPER).items()}
assert all(tool['executable'] for tool in tools.values())
assert source()['commit']==EXPECTED and source()['clean']
if sys.argv[1]=='--preflight':
 print(json.dumps(dict(source=source(),tools=tools,environment={k:env[k] for k in ["PATH","RUSTC","RUSTDOC","CC","CXX","AR","LD","PKG_CONFIG","CARGO_TARGET_DIR","CARGO_BUILD_BUILD_DIR","CARGO_BUILD_JOBS","RUSTC_WRAPPER"]},runner_sha256=sha(__file__)),sort_keys=True));sys.exit(0)
admission,attempt,filter=sys.argv[1:]
out=EVIDENCE/attempt;out.mkdir(exist_ok=False)
with open(WT/'.local/structural-lifetime-permit.lock','a+') as permit,open(WT/'.local/structural-exact-source-tree.lock','a+') as lock:
 fcntl.flock(permit,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 before=source();assert before['commit']==EXPECTED and before['clean']
 fleet=json.loads(pathlib.Path(admission).read_text());ages=validate(fleet)
 receipt=dict(source_before=before,admission=fleet,admission_raw_sample_ages=ages,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),lifetime_permit=str(WT/'.local/structural-lifetime-permit.lock'),source_tree_lock=str(WT/'.local/structural-exact-source-tree.lock'),tools=tools,runner_sha256=sha(__file__),environment={key:env[key] for key in ['PATH','RUSTC','RUSTDOC','CC','CXX','AR','LD','PKG_CONFIG','RUSTC_WRAPPER','LIBRARY_PATH','NIX_LDFLAGS','PKG_CONFIG_PATH','CARGO_TARGET_DIR','CARGO_BUILD_BUILD_DIR','CARGO_BUILD_JOBS']},test_is_product_acceptance=False)
 (out/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n')
 # The linker preflight is part of this fresh admitted workload.
 subprocess.run([env['CC'],'-x','c','-','-o',str(WT/'.local/structural-linker-preflight')],input=b'int main(void){return 0;}\n',env=env,check=True)
 subprocess.run([str(WT/'.local/structural-linker-preflight')],check=True)
 ages=validate(fleet);receipt['admission_raw_sample_ages_before_cargo']=ages
 argv=[WRAPPER,'test','--locked','--offline','-j2','-p','backend-local-service','--lib',filter,'--','--test-threads=1','--nocapture']
 receipt['argv']=argv;started=time.monotonic()
 with (out/'cargo.log').open('wb') as log:
  child=subprocess.Popen(argv,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  receipt['owned_child_pid']=child.pid;(out/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print(json.dumps(dict(pid=child.pid,out=str(out),source=before)),flush=True)
  receipt['exit']=child.wait()
 receipt['elapsed_seconds']=time.monotonic()-started;receipt['largest_waited_descendant_peak_rss_kib']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
 text=(out/'cargo.log').read_text(errors='replace')
 receipt['test_result_lines']=[line for line in text.splitlines() if line.startswith('test result:')]
 receipt['test_binaries']=[]
 for written in re.findall(r'Running (?:unittests|tests/[^\n]*?) [^\n]*?\(([^\n]+)\)',text):
  path=(WT/written).resolve();assert path.is_relative_to(WT.resolve()) and path.is_file() and os.access(path,os.X_OK)
  receipt['test_binaries'].append(dict(path=str(path),sha256=sha(path)))
 receipt.update(source_after=source(),ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),retirement='owned-child-kernel-wait')
 assert receipt['source_before']==receipt['source_after']
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(exit=receipt['exit'],out=str(out),results=receipt['test_result_lines'])),flush=True)
 sys.exit(receipt['exit'])
