import pathlib, json, hashlib, shutil, subprocess, re, fcntl, tarfile, os, datetime
WT=pathlib.Path('/root/codex-worktrees/sol61-structural-graph-latency-20261007')
BASE=pathlib.Path('/root/sol61-structural-graph-evidence-20261007')
COMMIT='6383b38dd4aa4127be09241f1fcedf1b3b71eaf6'
OUT=BASE/'final638-immutable-raw-v1'
ARCHIVE=BASE/'final638-immutable-raw-v1.tar.gz'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(WT),*a],text=True).strip()
def copy(src,dst):
 target=OUT/dst;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
def write(dst,data):
 target=OUT/dst;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
with open(WT/'.local/structural-lifetime-permit.lock','a+') as permit,open(WT/'.local/structural-exact-source-tree.lock','a+') as lock:
 fcntl.flock(permit,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert git('rev-parse','HEAD')==COMMIT and not git('status','--porcelain')
 assert not list((WT/'.local/structural-owned-build-role/.nudox-cargo/leases').iterdir())
 OUT.mkdir(exist_ok=False,mode=0o700)
 final_runs=['structural-native-03','view-build-native-02'];mapping={};runs=[]
 for run in final_runs:
  for name in ['cargo.log','launch.json','receipt.json']:copy(BASE/run/name,'final638/'+run+'/'+name)
  r=json.loads((BASE/run/'receipt.json').read_text());assert r['source_before']['commit']==COMMIT and r['source_after']==r['source_before'] and r['exit']==0
  assert not pathlib.Path('/proc/'+str(r['owned_child_pid'])).exists()
  names=set(re.findall(r'^test (builtin::\S+) ',(BASE/run/'cargo.log').read_text(),re.M))
  for name in names:mapping.setdefault(name,[]).append(run)
  runs.append({'run':run,'reported_result':r['test_result_lines'],'test_names':sorted(names),'binary':r['test_binaries'],'source':r['source_after']})
 assert len(mapping)==56 and [len(x['test_names']) for x in runs]==[25,37]
 write('final638/distinct-test-mapping.json',{'distinct_passed':56,'distinct_failed':0,'runs':runs,'test_to_runs':mapping,'overlap':sorted(name for name,run_names in mapping.items() if len(run_names)>1)})
 for run,prefix in [('view-build-native-01','prior994-view-109pass-1fail'),('structural-native-02','prior994-structural-25pass'),('structural-native-01','prior5bf-compile-failure')]:
  for name in ['cargo.log','launch.json','receipt.json']:copy(BASE/run/name,'prior/'+prefix+'/'+name)
 failed=json.loads((BASE/'view-build-native-01/receipt.json').read_text())
 assert failed['source_after']['commit']=='9946624b0783ab4eff44105bd509cfb25f2e3d65' and failed['exit']==101
 write('prior/prior-failure-disclosure.json',{'scope':'Earlier source only; not final638 control results','source_commit':failed['source_after']['commit'],'reported_result':failed['test_result_lines'],'failed_test':'builtin::view_build::call_join::tsz_source_coordinate_tests::native_tsz_source_call_retargets_to_exact_captured_declaration','failure':'semantic authority for entity 0 is inconsistent: Availability { plane: Source, claimed: Unavailable, present: true }','unchanged_fixture_source':'crates/local-service/src/builtin/view_build/call_join.rs','baseline_rebuild_performed':False,'earlier5bf_compile_failure_preserved':True})
 for name in ['638-owned-retirement.json','source-update-6383b38dd4.json','source-update-9946624b07.json','638-native-gate-union.json','sol61-structural-preflight-638.json','sol61-structural-preflight-638-view-controls.json']:copy(BASE/name,'control/'+name)
 for name in ['receipt.json','byte-for-byte-manifest.json']:copy(BASE/'owned-immutable-graph-copy-01'/name,'ownership/immutable-graph-copy/'+name)
 copy(WT/'.local/structural-owned-build-role/.nudox-cargo/slot-0/.nudox-worktree-root','ownership/managed-graph-owner-stamp.txt')
 copy('/root/sol61-structural-native-supervisor-638.py','supervisors/native638.py');copy('/root/sol61-structural-native-supervisor-994.py','supervisors/native994.py');copy('/root/sol61-structural-native-supervisor.py','supervisors/native5bf.py');copy('/root/sol61-structural-source-update-v6.py','supervisors/source-update-v6.py')
 copy('/root/nudox-corpus-20261006/tool-recovery/cargo-wrapped-nix6','supervisors/cargo-wrapped-nix6')
 copy(__file__,'supervisors/package638.py')
 changed=git('diff','--name-only','96977e74e0',COMMIT).splitlines()
 for path in changed:copy(WT/path,'source/'+path)
 copy(WT/'Cargo.lock','source/Cargo.lock')
 (OUT/'source/full-base-diff.patch').write_text(subprocess.check_output(['git','-C',str(WT),'diff','96977e74e0',COMMIT],text=True))
 write('source/source-identity.json',{'commit':COMMIT,'tree':git('rev-parse','HEAD^{tree}'),'base':git('rev-parse','96977e74e0'),'lock_sha256':sha(WT/'Cargo.lock'),'clean':True,'changed_files':changed,'git_commit':git('show','--no-patch','--format=fuller',COMMIT)})
 write('control/package-retirement.json',{'own_lifetime_and_source_locks_acquired':True,'own_leases_empty':True,'native_children_absent':[json.loads((BASE/r/'receipt.json').read_text())['owned_child_pid'] for r in final_runs],'source_commit':COMMIT,'source_tree':git('rev-parse','HEAD^{tree}'),'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'real_mealie_current_public_acceptance':'pending parent matched joined binaries; no native fixture relabeled as product proof'})
 artifacts=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.rglob('*')) if p.is_file()]
 write('artifact-hashes.json',{'schema':'nudox.raw-artifact-hashes.v1','frozen_source':COMMIT,'artifacts':artifacts,'manifest_self_hash_external':True})
 with tarfile.open(ARCHIVE,'x:gz',compresslevel=6) as archive:
  for p in sorted(OUT.rglob('*')):
   if p.is_file():
    info=archive.gettarinfo(str(p),str(p.relative_to(OUT)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o444
    with p.open('rb') as stream:archive.addfile(info,stream)
 for p in OUT.rglob('*'):p.chmod(0o444 if p.is_file() else 0o555)
 OUT.chmod(0o555);ARCHIVE.chmod(0o444)
 result={'archive_path':str(ARCHIVE),'archive_bytes':ARCHIVE.stat().st_size,'archive_sha256':sha(ARCHIVE),'artifact_manifest_path':str(OUT/'artifact-hashes.json'),'artifact_manifest_sha256':sha(OUT/'artifact-hashes.json'),'artifact_count':len(artifacts),'frozen_commit':COMMIT,'frozen_tree':git('rev-parse','HEAD^{tree}')}
 (BASE/'final638-package-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
