import fcntl,subprocess,json,pathlib,hashlib,datetime
root=pathlib.Path('/root/codex-worktrees/sol61-structural-graph-latency-20261007')
out=pathlib.Path('/root/sol61-structural-graph-evidence-20261007/source-update-6383b38dd4.json')
with open(root/'.local/structural-lifetime-permit.lock','a+') as permit,open(root/'.local/structural-exact-source-tree.lock','a+') as lock:
 fcntl.flock(permit,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
 before=git('rev-parse','HEAD');assert before=='9946624b0783ab4eff44105bd509cfb25f2e3d65' and not git('status','--porcelain')
 assert not any((root/'.local/structural-owned-build-role/.nudox-cargo/leases').iterdir())
 subprocess.run(['git','-C',str(root),'fetch','/root/sol61-structural-graph-v6.bundle','HEAD'],check=True)
 subprocess.run(['git','-C',str(root),'checkout','--detach','6383b38dd4aa4127be09241f1fcedf1b3b71eaf6'],check=True)
 receipt=dict(before_commit=before,after_commit=git('rev-parse','HEAD'),after_tree=git('rev-parse','HEAD^{tree}'),after_clean=not git('status','--porcelain'),bundle_sha256=hashlib.sha256(pathlib.Path('/root/sol61-structural-graph-v6.bundle').read_bytes()).hexdigest(),updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),own_lifetime_and_source_locks_acquired=True,own_wrapper_leases_empty=True)
 out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
