package main
import ("net/http"; "github.com/go-chi/chi/v5"; "example.com/freshservice/model")
func Router() http.Handler { router := chi.NewRouter(); router.Get("/", func(w http.ResponseWriter, r *http.Request) { w.Write([]byte(model.Welcome("visitor"))) }); return router }
