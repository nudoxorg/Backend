package main
import ("encoding/json"; "fmt"; "example.com/freshservice/model")
func main() { b, _ := json.Marshal(map[string]any{"message":model.Welcome("visitor"), "total": model.Total([]model.Invoice{{Amount:10, Customer:"sample"}})}); fmt.Println(string(b)) }
