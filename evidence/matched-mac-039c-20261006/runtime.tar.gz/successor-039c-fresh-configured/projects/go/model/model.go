package model
type Invoice struct { Amount float64; Customer string }
func Total(items []Invoice) float64 { var sum float64; for _, item := range items { sum += item.Amount }; return sum }
func Welcome(name string) string { return "Hello " + name }
