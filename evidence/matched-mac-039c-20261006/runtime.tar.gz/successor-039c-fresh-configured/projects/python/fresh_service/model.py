from dataclasses import dataclass
@dataclass
class Invoice:
    amount: float
    customer: str
def total(invoices: list[Invoice]) -> float:
    return sum(item.amount for item in invoices)
def welcome(name: str) -> str:
    return f"Hello {name}"
