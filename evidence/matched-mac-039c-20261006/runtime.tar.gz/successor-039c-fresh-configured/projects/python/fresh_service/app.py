import json
from .model import Invoice, total, welcome
def response() -> str:
    return json.dumps({"message": welcome("visitor"), "total": total([Invoice(10.0, "sample")])})
if __name__ == "__main__":
    print(response())
