import { welcome, total, type Item } from "./math.js";
export class Dashboard { items: Item[] = []; render(root: HTMLElement): void { root.textContent = welcome("visitor") + total(this.items); } }
