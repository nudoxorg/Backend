import { Dashboard } from "./app.js";
export function mount(root: HTMLElement): Dashboard { const app = new Dashboard(); app.render(root); return app; }
