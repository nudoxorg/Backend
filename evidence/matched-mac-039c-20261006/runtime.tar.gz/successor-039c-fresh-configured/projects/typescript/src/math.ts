export function welcome(name: string): string { return `Hello ${name}`; }
export interface Item { id: number; label: string; }
export function total(items: Item[]): number { return items.reduce((n, x) => n + x.id, 0); }
