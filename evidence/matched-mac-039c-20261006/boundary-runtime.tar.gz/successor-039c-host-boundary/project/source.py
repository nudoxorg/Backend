def welcome(name: str) -> str:
    return "Hello " + name
