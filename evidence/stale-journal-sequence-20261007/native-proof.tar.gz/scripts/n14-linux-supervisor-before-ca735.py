#!/usr/bin/env python3
"""Run one frozen N14 Cargo gate under a fresh whole-fleet permit."""

from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import time


GIT = "/etc/profiles/per-user/root/bin/git"
RUNNER = "/root/nudox-corpus-20261006/tool-recovery/cargo-wrapped-nix6"
TOOLS_BIN = pathlib.Path(
    "/nix/store/n4b80fmlzlmxx0584y7acwcnikk4k071-nudox-luna-tools-shell/bin"
)
RUST_BIN = pathlib.Path(
    "/nix/store/lynmg3kdpdz41r84nafwzi2n5nss50pq-rust-1.97.1-with-components-2026-07-16/bin"
)
MAKE_BIN = pathlib.Path("/nix/store/5hndr36f8c9d9z305r27z6dxkhysng95-gnumake-4.4.1/bin")
EXPECTED_SOURCE_BLOBS = {
    "crates/library/cursor.rs": "33cb373d190fc59797529a0be72ccc19a9987b37",
    "crates/local-service/src/builtin.rs": "35d4e6658efabd30c3c00353ffe8d88e7fcb70fd",
    "crates/local-service/src/builtin/view_journal.rs": "67c68e05e1b1c9dc3c55f654e7b22cccc6a55d76",
    "crates/local-service/src/builtin/view_journal_tests.rs": "218b45629d75e8a846d47efd2d79b74e8ed62604",
    "Cargo.lock": "49e3cc50cc3424d6d0eee338eca0863cfb176819",
}


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git(worktree: pathlib.Path, *args: str) -> str:
    return subprocess.check_output([GIT, "-C", str(worktree), *args], text=True).strip()


def resources() -> dict[str, int]:
    available = None
    for line in pathlib.Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemAvailable:"):
            available = int(line.split()[1]) * 1024
            break
    if available is None:
        raise RuntimeError("MemAvailable is unavailable")
    disk = os.statvfs("/")
    return {
        "available_memory_bytes": available,
        "free_disk_bytes": disk.f_bavail * disk.f_frsize,
    }


def stamp_age(value: str) -> float:
    stamp = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    return time.time() - stamp.timestamp()


def verify_fleet(path: pathlib.Path) -> tuple[dict, float]:
    fleet = json.loads(path.read_text())
    if fleet.get("schema") != "compiler-capacity-admission.v5":
        raise RuntimeError("fleet evidence is not schema v5")
    if fleet.get("destination") != "ilo" or fleet.get("advisory_allowed") is not True:
        raise RuntimeError("fleet admission does not allow ILO")
    if fleet.get("requested_cargo_jobs") != 2:
        raise RuntimeError("fleet admission was not collected for two Cargo jobs")
    samples = fleet.get("raw_samples")
    if not isinstance(samples, dict) or set(samples) != {"local", "ilo", "h16001mac"}:
        raise RuntimeError("fleet admission lacks a complete three-host sample")
    ages = []
    for host, sample in samples.items():
        if sample.get("transport_complete") is not True or sample.get("return_code") != 0:
            raise RuntimeError(f"{host} census transport did not complete")
        census = sample.get("census", {})
        if census.get("complete") is not True or census.get("resource_snapshot_complete") is not True:
            raise RuntimeError(f"{host} census or resource snapshot is incomplete")
        ages.append(stamp_age(census["sample_started_at_utc"]))
        if census.get("resource_snapshot", {}).get("available_memory_bytes", 0) < 8 * 1024**3:
            raise RuntimeError(f"{host} available memory is below 8 GiB")
    age = max(ages)
    if age > 30 or age < -5:
        raise RuntimeError(f"whole-fleet sample age is outside the allowed window: {age:.3f}s")
    ilo = samples["ilo"]["census"]["resource_snapshot"]
    if ilo.get("available_memory_bytes", 0) < 8 * 1024**3:
        raise RuntimeError("ILO available memory is below 8 GiB")
    if ilo.get("root_disk_available_bytes", 0) < 16 * 1024**3:
        raise RuntimeError("ILO free root disk is below 16 GiB")
    return fleet, age


def test_evidence(receipt: pathlib.Path, expected_suffixes: list[str]) -> dict:
    import re

    output = (receipt / "stdout.log").read_text(errors="replace")
    summaries = [
        {
            "status": match.group(1),
            "passed": int(match.group(2)),
            "failed": int(match.group(3)),
            "ignored": int(match.group(4)),
            "measured": int(match.group(5)),
        }
        for match in re.finditer(
            r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
            r"(\d+) ignored; (\d+) measured;",
            output,
        )
    ]
    case_results = [
        {"name": match.group(1), "status": match.group(2)}
        for match in re.finditer(r"^test (\S+) \.\.\. (ok|FAILED|ignored)$", output, re.MULTILINE)
    ]
    paths = re.findall(r"Running unittests .*? \(([^)\r\n]+)\)", output)
    binaries = []
    for raw_path in dict.fromkeys(paths):
        path = pathlib.Path(raw_path)
        if path.is_file():
            binaries.append({"path": str(path), "size_bytes": path.stat().st_size, "sha256": sha256(path)})
    matched = [
        suffix
        for suffix in expected_suffixes
        if sum(case["name"].endswith(suffix) for case in case_results) == 1
    ]
    return {
        "summaries": summaries,
        "cases": case_results,
        "binaries": binaries,
        "expected_test_suffixes": expected_suffixes,
        "matched_test_suffixes": matched,
        "expected_tests_match": len(matched) == len(expected_suffixes) and len(case_results) == len(expected_suffixes),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--worktree", type=pathlib.Path, required=True)
    parser.add_argument("--evidence", type=pathlib.Path, required=True)
    parser.add_argument("--lock", type=pathlib.Path, required=True)
    parser.add_argument("--fleet-proof", type=pathlib.Path, required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--tree", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--target-dir", type=pathlib.Path, required=True)
    parser.add_argument("--build-root", type=pathlib.Path, required=True)
    parser.add_argument("--sccache-dir", type=pathlib.Path, required=True)
    parser.add_argument("--direct-rustc-wrapper", type=pathlib.Path, required=True)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--expected-test-suffix", action="append", required=True)
    parser.add_argument("cargo_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    cargo_args = args.cargo_args[1:] if args.cargo_args[:1] == ["--"] else args.cargo_args
    if not cargo_args or cargo_args[0] != "test":
        parser.error("pass Cargo's `test` subcommand directly after --")
    if args.jobs != 2:
        parser.error("the N14 Cargo job bound is two")

    worktree = args.worktree.resolve(strict=True)
    evidence = args.evidence.resolve(strict=True)
    receipt = evidence / args.phase
    receipt.mkdir(mode=0o700)
    fleet, admission_age = verify_fleet(args.fleet_proof)

    lease_path = args.lock
    lease_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    lease = lease_path.open("a+")
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)

    if git(worktree, "rev-parse", "HEAD") != args.commit:
        raise RuntimeError("worktree commit does not match the frozen source identity")
    if git(worktree, "rev-parse", "HEAD^{tree}") != args.tree:
        raise RuntimeError("worktree tree does not match the frozen source identity")
    if git(worktree, "status", "--porcelain"):
        raise RuntimeError("source worktree is dirty")
    source_blobs = {
        name: git(worktree, "rev-parse", f"HEAD:{name}")
        for name in EXPECTED_SOURCE_BLOBS
    }
    if source_blobs != EXPECTED_SOURCE_BLOBS:
        raise RuntimeError("N14 tracked source blobs do not match the frozen candidate")

    target_dir = args.target_dir.resolve()
    build_root = args.build_root.resolve()
    sccache_dir = args.sccache_dir.resolve()
    direct_wrapper = args.direct_rustc_wrapper.absolute()
    if not direct_wrapper.is_file() or not os.access(direct_wrapper, os.X_OK):
        raise RuntimeError("direct rustc wrapper is not an executable file")
    for directory in (target_dir, build_root, sccache_dir):
        if directory.is_symlink():
            raise RuntimeError(f"task build path is symlinked: {directory}")
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)

    environment = os.environ.copy()
    for name in (
        "RUSTC_WRAPPER",
        "SCCACHE_SERVER_UDS",
        "BACKEND_LOCALD_STARTUP_DIAGNOSTIC_FILE",
        "BACKEND_LOCALD_BIN",
    ):
        environment.pop(name, None)
    temporary = pathlib.Path("/tmp") / f"n14-linux-{os.getpid()}"
    temporary.mkdir(mode=0o700)
    environment.update(
        {
            "PATH": f"{TOOLS_BIN}:{RUST_BIN}:{MAKE_BIN}:/run/current-system/sw/bin",
            "RUSTC": str(RUST_BIN / "rustc"),
            "RUSTDOC": str(RUST_BIN / "rustdoc"),
            "CC": str(TOOLS_BIN / "cc"),
            "CXX": str(TOOLS_BIN / "c++"),
            "AR": str(TOOLS_BIN / "ar"),
            "LD": str(TOOLS_BIN / "ld"),
            "PKG_CONFIG": str(TOOLS_BIN / "pkg-config"),
            "LIBRARY_PATH": "",
            "NIX_LDFLAGS": "",
            "PKG_CONFIG_PATH": "",
            "TMPDIR": str(temporary),
            "CARGO_INCREMENTAL": "0",
            "CARGO_BUILD_JOBS": str(args.jobs),
            "NUDOX_CARGO_BUILD_SLOTS": "6",
            "NUDOX_CARGO_SLOT_WAIT_MS": "0",
            "NUDOX_CARGO_WORKTREE_WAIT_MS": "0",
            "CARGO_TARGET_DIR": str(target_dir),
            "CARGO_BUILD_BUILD_DIR": str(build_root),
            "RUSTC_WRAPPER": str(direct_wrapper),
            "SCCACHE_DIR": str(sccache_dir),
            "SCCACHE_SERVER_UDS": f"/tmp/n14-sccache-{os.getpid()}.sock",
        }
    )
    cc_path = subprocess.check_output(["/bin/sh", "-c", "command -v cc"], env=environment, text=True).strip()
    if cc_path != str(TOOLS_BIN / "cc"):
        raise RuntimeError(f"unexpected C linker resolution: {cc_path}")
    cc_version = subprocess.check_output([cc_path, "--version"], env=environment, text=True).splitlines()[0]
    command = [RUNNER, *cargo_args]
    cargo = RUST_BIN / "cargo"
    rustc = RUST_BIN / "rustc"
    proof = {
        "schema": "nudox.n14-linux-native-gate.v1",
        "phase": args.phase,
        "commit": args.commit,
        "tree": args.tree,
        "source_blobs": source_blobs,
        "source_sha256": {name: sha256(worktree / name) for name in source_blobs},
        "cargo_lock_blob": source_blobs["Cargo.lock"],
        "cargo_lock_sha256": sha256(worktree / "Cargo.lock"),
        "direct_rustc_wrapper": str(direct_wrapper),
        "direct_rustc_wrapper_sha256": sha256(direct_wrapper),
        "source_clean_before": True,
        "source_clean_after": None,
        "cargo_args": cargo_args,
        "argv": command,
        "jobs": args.jobs,
        "target_dir": str(target_dir),
        "build_root": str(build_root),
        "sccache_dir": str(sccache_dir),
        "tmpdir": str(temporary),
            "runner_sha256": sha256(pathlib.Path(RUNNER)),
            "toolchain_environment": {
                "PATH": environment["PATH"],
                "RUSTC": environment["RUSTC"],
                "RUSTDOC": environment["RUSTDOC"],
                "CC": environment["CC"],
                "CXX": environment["CXX"],
                "AR": environment["AR"],
                "LD": environment["LD"],
                "PKG_CONFIG": environment["PKG_CONFIG"],
                "LIBRARY_PATH": "",
                "NIX_LDFLAGS": "",
                "PKG_CONFIG_PATH": "",
                "RUSTC_WRAPPER": str(direct_wrapper),
                "SCCACHE_DIR": str(sccache_dir),
                "SCCACHE_SERVER_UDS": environment["SCCACHE_SERVER_UDS"],
                "command_v_cc": cc_path,
                "cc_version": cc_version,
            },
            "tools": {
            name: {
                "path": str(path),
                "sha256": sha256(path),
                "version": subprocess.check_output([str(path), "--version"], text=True).strip(),
            }
            for name, path in (
                ("cargo", cargo),
                ("rustc", rustc),
                ("cc", TOOLS_BIN / "cc"),
                ("cxx", TOOLS_BIN / "c++"),
                ("ar", TOOLS_BIN / "ar"),
                ("ld", TOOLS_BIN / "ld"),
                ("pkg_config", TOOLS_BIN / "pkg-config"),
            )
        },
        "lease_path": str(lease_path),
        "supervisor_pid": os.getpid(),
        "resources_before": resources(),
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
    }
    if min(proof["resources_before"].values()) < 8 * 1024**3:
        raise RuntimeError("ILO runtime resource floor is below 8 GiB before launch")
    if proof["resources_before"]["free_disk_bytes"] < 16 * 1024**3:
        raise RuntimeError("ILO free disk is below 16 GiB before launch")
    fleet, admission_age = verify_fleet(args.fleet_proof)
    proof["fleet_admission_age_seconds"] = admission_age
    proof["fleet"] = fleet
    (receipt / "admission.json").write_text(json.dumps(fleet, indent=2) + "\n")
    (receipt / "launch.json").write_text(json.dumps(proof, indent=2) + "\n")

    reason = None
    with (receipt / "stdout.log").open("wb") as stdout, (receipt / "stderr.log").open("wb") as stderr:
        child = subprocess.Popen(command, cwd=worktree, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
        proof["launcher_pid"] = child.pid
        (receipt / "launch.json").write_text(json.dumps(proof, indent=2) + "\n")
        while child.poll() is None:
            sample = {"utc": dt.datetime.now(dt.timezone.utc).isoformat(), **resources()}
            with (receipt / "resources.jsonl").open("a") as stream:
                stream.write(json.dumps(sample) + "\n")
            if sample["available_memory_bytes"] < 8 * 1024**3 or sample["free_disk_bytes"] < 16 * 1024**3:
                reason = "runtime memory or disk below configured floor"
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                break
            time.sleep(5)
        exit_code = child.wait()

    actual_test_evidence = test_evidence(receipt, args.expected_test_suffix)
    proof.update(
        {
            "cargo_exit": exit_code,
            "test_evidence": actual_test_evidence,
            "exit": exit_code if actual_test_evidence["expected_tests_match"] or exit_code != 0 else 70,
            "guard_reason": reason,
            "source_clean_after": not git(worktree, "status", "--porcelain"),
            "commit_after": git(worktree, "rev-parse", "HEAD"),
            "tree_after": git(worktree, "rev-parse", "HEAD^{tree}"),
            "tools_unchanged": all(sha256(pathlib.Path(item["path"])) == item["sha256"] for item in proof["tools"].values()),
            "direct_rustc_wrapper_unchanged": sha256(direct_wrapper) == proof["direct_rustc_wrapper_sha256"],
            "ended_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "resources_after": resources(),
        }
    )
    (receipt / "completion.json").write_text(json.dumps(proof, indent=2) + "\n")
    print(json.dumps({"receipt": str(receipt), "exit": proof["exit"], "launcher_pid": proof["launcher_pid"]}))
    return proof["exit"]


if __name__ == "__main__":
    raise SystemExit(main())
