import datetime,fcntl,json,pathlib,shutil,subprocess
origin=pathlib.Path('/root/codex-worktrees/sol61-go-setup-parity-20261007');dst=pathlib.Path('/root/codex-worktrees/sol61-default-state-first-run-20261007');sha='579ab4368766e049e33b6c5f5c46cdb01408042a'
lock=open(origin/'.local/setup-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert subprocess.check_output(['git','-C',str(origin),'rev-parse','HEAD'],text=True).strip()=='17e8a0f9a57a5f9b4c4ec576479c245562759989'
subprocess.run(['git','-C',str(origin),'fetch','/root/default-state-first-run-review.bundle','codex/default-state-first-run-20261007'],check=True)
subprocess.run(['git','-C',str(origin),'worktree','add','--detach',str(dst),sha],check=True)
(dst/'.local').mkdir();own=open(dst/'.local/setup-owner.lock','a+');fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB)
source=origin/'.local/owned-build-role/.nudox-cargo/slot-0/release';target=dst/'.local/owned-build-role/.nudox-cargo/slot-0/release';target.mkdir(parents=True)
files=[p for p in (source/'deps').iterdir() if p.is_file() and p.stat().st_size<=16*1024**2 and not p.name.startswith(('backend_','libbackend_','frontend_','libfrontend_','libtsz_'))]
size=sum(p.stat().st_size for p in files);assert shutil.disk_usage(dst).free-size>=16*1024**3
(target/'deps').mkdir()
for p in files:shutil.copy2(p,target/'deps'/p.name)
shutil.copytree(source/'.fingerprint',target/'.fingerprint')
(target/'build').mkdir()
for p in (source/'build').iterdir():
 if p.name.startswith(('blake3-','serde-','serde_core-','rustix-','libc-','thiserror-')):shutil.copytree(p,target/'build'/p.name)
(target.parent/'.nudox-worktree-root').write_text(str(dst)+'\n')
receipt={'source_worktree':str(origin),'destination_worktree':str(dst),'source_commit':'17e8a0f9a57a5f9b4c4ec576479c245562759989','destination_commit':sha,'role':'read-only copy of own retired small dependency objects; no hardlinks; no foreign graph or old owner stamp','dependency_files':len(files),'dependency_bytes':size,'copied_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(dst/'.local/cache-copy-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
