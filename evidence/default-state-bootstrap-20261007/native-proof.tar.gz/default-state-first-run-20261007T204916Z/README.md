# Default first-run state bootstrap — scoped Linux native evidence

Source579ab4368766e049e33b6c5f5c46cdb01408042a/treee613544dce6ada67d0a25dbb9d5fcafa5483e17f is clean and identical before/after the owned kernel wait. Raw cargo.log merges stdout/stderr; launch/receipt preserve exact argv, selected build environment, PID, fleet-v5 admission and retirement.

Native verdict: backend-platform1pass, backend-runtime4pass. Runtime4 comprises three relevant default-state filesystem controls and one preexisting static accounting test matched by the default_ filter. The relevant controls cover genuine empty0700/0755 user homes, all three known OS data suffix layouts, existing0755 conventional-parent mode preservation, private application/workspace and credential creation/reopen, file/link/writable-component refusal without chmod, pinned path identity replacement, and refusal to repair a public existing Nudox directory.

This is Linux runtime/platform execution. Windows API body, ordinary macOS autostart/status/add, matched image packaging and whole-project semantic acceptance are unverified by this gate. Original joined4e ordinary CLI status failed before spawn with ENOENT because HOME/Library/Application Support did not yet exist; that failure remains a failure in Python owner's raw evidence. No harness precreation or path/tool overrides are the product fix.

Only the platform's known suffix is created below an admitted existing anchor. Existing XDG/LOCALAPPDATA anchors remain explicit and must be admitted; existing unsafe directories are refused without repair.
