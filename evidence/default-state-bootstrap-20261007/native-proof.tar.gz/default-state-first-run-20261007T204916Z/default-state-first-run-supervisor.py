import argparse,datetime,fcntl,hashlib,json,os,pathlib,re,subprocess
p=argparse.ArgumentParser();p.add_argument('--admission',required=True);p.add_argument('--out',required=True);a=p.parse_args()
wt=pathlib.Path('/root/codex-worktrees/sol61-default-state-first-run-20261007');out=pathlib.Path(a.out);out.mkdir(mode=0o700)
lock=open(wt/'.local/setup-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity():
 def git(*args):return subprocess.check_output(['git','-C',str(wt),*args],text=True).strip()
 return {'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'clean':not git('status','--porcelain'),'lock_sha256':hashlib.sha256((wt/'Cargo.lock').read_bytes()).hexdigest()}
source=identity();assert source['commit']=='579ab4368766e049e33b6c5f5c46cdb01408042a' and source['clean']
fleet=json.loads(pathlib.Path(a.admission).read_text());now=datetime.datetime.now(datetime.timezone.utc)
assert fleet['advisory_allowed'] and all(h['complete'] for h in fleet['hosts'].values())
assert all(0<=(now-datetime.datetime.fromisoformat(h['resource_sampled_at_utc'])).total_seconds()<30 for h in fleet['hosts'].values())
assert fleet['current_fleet_compiler_group_count']<16 and fleet['hosts']['ilo']['compiler_group_count']<8
assert all(h['available_memory_bytes']>=8*1024**3 for h in fleet['hosts'].values());assert fleet['hosts']['ilo']['root_disk_available_bytes']>=16*1024**3
rust='/nix/store/lynmg3kdpdz41r84nafwzi2n5nss50pq-rust-1.97.1-with-components-2026-07-16/bin';tools='/nix/store/n4b80fmlzlmxx0584y7acwcnikk4k071-nudox-luna-tools-shell/bin'
env=dict(os.environ);env.update(PATH=tools+':'+rust+':/nix/store/5hndr36f8c9d9z305r27z6dxkhysng95-gnumake-4.4.1/bin:/run/current-system/sw/bin',CARGO_HOME='/root/.cargo',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',NUDOX_CARGO_BUILD_SLOTS='6',NUDOX_CARGO_SLOT_WAIT_MS='0',NUDOX_CARGO_WORKTREE_WAIT_MS='0',CARGO_TARGET_DIR=str(wt/'.local/target'),CARGO_BUILD_BUILD_DIR=str(wt/'.local/owned-build-role'),RUSTC=rust+'/rustc',CC=tools+'/cc',CXX=tools+'/c++',AR=tools+'/ar',LD=tools+'/ld',PKG_CONFIG=tools+'/pkg-config',LIBRARY_PATH='',NIX_LDFLAGS='',PKG_CONFIG_PATH='')
argv=['/root/nudox-corpus-20261006/tool-recovery/cargo-wrapped-nix6','test','--locked','--offline','--release','-j2','-p','backend-runtime','-p','backend-platform','--lib','default_','--','--test-threads=1','--nocapture']
receipt={'source_before':source,'started_utc':utc(),'argv':argv,'admission':fleet,'scope':'Linux native runtime/platform default state bootstrap and filesystem controls; all three known suffix layouts, not Windows API execution or public CLI acceptance','environment':{key:env[key] for key in ['PATH','CARGO_HOME','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_TARGET_DIR','CARGO_BUILD_BUILD_DIR','RUSTC','CC','CXX','AR','LD','PKG_CONFIG','LIBRARY_PATH','NIX_LDFLAGS','PKG_CONFIG_PATH']}}
with (out/'cargo.log').open('wb') as log:
 child=subprocess.Popen(argv,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);receipt['pid']=child.pid;(out/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'pid':child.pid,'out':str(out),'source':source}),flush=True);receipt['exit']=child.wait()
receipt.update(source_after=identity(),ended_utc=utc(),retirement='owned-child-kernel-wait');assert receipt['source_before']==receipt['source_after']
receipt['test_results']=re.findall(r'test result: (?:ok|FAILED)\. [^\n]+',(out/'cargo.log').read_text());(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'out':str(out),'exit':receipt['exit'],'test_results':receipt['test_results']}),flush=True)
raise SystemExit(receipt['exit'])
