import datetime, fcntl, hashlib, json, os, pathlib, subprocess, sys
wt = pathlib.Path('/root/codex-worktrees/sol61-nonblocking-search-20261007')
out = pathlib.Path('/root/sol61-nonblocking-search-evidence/native-08')
out.mkdir(parents=True, mode=0o700)
(wt/'.local').mkdir(exist_ok=True)
lock = open(wt/'.local/nonblocking-search-owner.lock', 'a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
now = datetime.datetime.now(datetime.timezone.utc)
fleet = json.loads(pathlib.Path(sys.argv[1]).read_text())
assert fleet['advisory_allowed'] and all(host['complete'] for host in fleet['hosts'].values())
assert all(0 <= (now-datetime.datetime.fromisoformat(host['resource_sampled_at_utc'])).total_seconds() <= 30 for host in fleet['hosts'].values())
assert fleet['current_fleet_compiler_group_count'] < 16
assert fleet['hosts']['ilo']['compiler_group_count'] < 8
assert all(host['available_memory_bytes'] >= 8*1024**3 for host in fleet['hosts'].values())
assert fleet['hosts']['ilo']['root_disk_available_bytes'] >= 16*1024**3
def git(*args): return subprocess.check_output(['git','-C',str(wt),*args], text=True).strip()
def source(): return dict(commit=git('rev-parse','HEAD'), tree=git('rev-parse','HEAD^{tree}'), clean=not git('status','--porcelain'), lock_sha256=hashlib.sha256((wt/'Cargo.lock').read_bytes()).hexdigest())
before=source()
assert before['clean'] and before['commit'] == sys.argv[2] and before['tree'] == sys.argv[3]
rust='/nix/store/lynmg3kdpdz41r84nafwzi2n5nss50pq-rust-1.97.1-with-components-2026-07-16/bin'
tools='/nix/store/n4b80fmlzlmxx0584y7acwcnikk4k071-nudox-luna-tools-shell/bin'
env=dict(os.environ)
env.update(PATH=tools+':'+rust+':/nix/store/5hndr36f8c9d9z305r27z6dxkhysng95-gnumake-4.4.1/bin:/run/current-system/sw/bin', CARGO_HOME='/root/.cargo', CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', NUDOX_CARGO_BUILD_SLOTS='6', NUDOX_CARGO_SLOT_WAIT_MS='0', NUDOX_CARGO_WORKTREE_WAIT_MS='0', CARGO_TARGET_DIR=str(wt/'.local/target'), CARGO_BUILD_BUILD_DIR=str(wt/'.local/search-owned-build-role'), RUSTC=rust+'/rustc',RUSTDOC=rust+'/rustdoc', CC=tools+'/cc', CXX=tools+'/c++', AR=tools+'/ar', LD=tools+'/ld', PKG_CONFIG=tools+'/pkg-config', LIBRARY_PATH='', NIX_LDFLAGS='', PKG_CONFIG_PATH='')
subprocess.run([tools+'/cc','-x','c','-','-o',str(wt/'.local/linker-preflight')], input=b'int main(void){return 0;}\n',env=env,check=True)
subprocess.run([str(wt/'.local/linker-preflight')],check=True)
argv=['/root/nudox-corpus-20261006/tool-recovery/cargo-wrapped-nix6','test','--locked','--offline','-j2','-p','backend-local-service','-p','backend-client','-p','backend-replication','--lib','deferred_command_ack_','--','--test-threads=1','--nocapture']
receipt=dict(runner_sha256=hashlib.sha256(pathlib.Path(argv[0]).read_bytes()).hexdigest(), source_before=before, admission=fleet, started_utc=now.isoformat(), argv=argv, lifetime_lock=str(wt/'.local/nonblocking-search-owner.lock'))
with (out/'cargo.log').open('wb') as log:
 child=subprocess.Popen(argv,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 receipt['pid']=child.pid
 (out/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(dict(pid=child.pid,out=str(out),source=before)),flush=True)
 receipt['exit']=child.wait()
receipt.update(source_after=source(), ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), retirement='owned-child-kernel-wait')
assert receipt['source_before']==receipt['source_after']
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(exit=receipt['exit'],out=str(out))),flush=True)
sys.exit(receipt['exit'])
