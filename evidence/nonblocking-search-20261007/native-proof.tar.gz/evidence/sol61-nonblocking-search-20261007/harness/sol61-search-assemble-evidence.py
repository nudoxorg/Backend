import pathlib, shutil, json, hashlib, gzip, datetime, re
wt=pathlib.Path('/Users/mileswirht/Downloads/backend-sol61-nonblocking-search')
dst=wt/'evidence/sol61-nonblocking-search-20261007'
src=pathlib.Path('/private/tmp/sol61-search-evidence')
dst.mkdir(parents=True,exist_ok=True)
ledger=[]
for root in sorted(src.iterdir()):
 if not root.is_dir():continue
 for f in sorted(root.rglob('*')):
  if not f.is_file():continue
  rel=f.relative_to(src); target=dst/'raw'/rel
  target.parent.mkdir(parents=True,exist_ok=True)
  data=f.read_bytes()
  if len(data)>50000:
   target=target.with_name(target.name+'.gz');target.write_bytes(gzip.compress(data,mtime=0))
  else:target.write_bytes(data)
  ledger.append({'original_path':str(f),'retained_path':str(target.relative_to(dst)),'original_bytes':len(data),'original_sha256':hashlib.sha256(data).hexdigest(),'retained_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
for pattern in ['sol61-search-*supervisor.py','sol61-search-mac-build*.py','sol61-search-docs-default-observer*.py','sol61-search-docs-default-config*.json','sol61-search-docs-cow*.py','sol61-search-fleet-*.json','sol61-search-fleet-*.stderr','sol61-search-fleet-*.stdout']:
 for f in sorted(pathlib.Path('/private/tmp').glob(pattern)):
  if not f.is_file():continue
  target=dst/'harness'/f.name; target.parent.mkdir(parents=True,exist_ok=True)
  data=f.read_bytes()
  if len(data)>50000:target=target.with_name(target.name+'.gz');target.write_bytes(gzip.compress(data,mtime=0))
  else:target.write_bytes(data)
  ledger.append({'original_path':str(f),'retained_path':str(target.relative_to(dst)),'original_bytes':len(data),'original_sha256':hashlib.sha256(data).hexdigest(),'retained_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
(dst/'artifact-inventory.json').write_text(json.dumps(ledger,indent=2)+'\n')
print(len(ledger),'retained files')
