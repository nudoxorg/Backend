import pathlib,json,hashlib,re
p=pathlib.Path('/private/tmp/sol61-search-evidence');d=pathlib.Path('/Users/mileswirht/Downloads/backend-sol61-nonblocking-search/evidence/sol61-nonblocking-search-20261007');out=[]
reasons={'native-01':'Fixture missing required RootCommitment request certificate; strict admission rejected before preparation.','native-02':'Two test-only flat JSON assertions were incorrect; typed replies were nested. Corrected on39cc.','native-04':'Baseline client test include path referenced an absent evidence fixture. No tests ran.','native-05':'Joined Tantivy OwnedWorkspaceDirectory path type inference at two as_ref calls. No tests ran.','native-mac-04':'Same joined Tantivy path inference compilation failure. No application owner ran.','native-07':'Fixture root mode0755 rejected by joined owned-directory admission; 4 pass/1 fail, local-service group did not execute.','native-09':'Mistaken test-only Cancelled enum variant does not exist; compile failure before tests.750 must not integrate.','native-06':'Four named IR TreeItemInput test fixtures omitted new anonymous_callable_anchor. No tests ran.'}
for root in sorted(p.iterdir()):
 f=root/'receipt.json'
 if not f.is_file():continue
 x=json.loads(f.read_text());logs=root/'cargo.log';s=logs.read_text(errors='replace') if logs.is_file() else ''
 tests=[]
 matches=list(re.finditer(r'^test (?!result:)(.+?) \.\.\. ',s,re.M))
 for i,m in enumerate(matches):
  block=s[m.end():matches[i+1].start() if i+1<len(matches) else len(s)]
  result=re.search(r'^(ok|FAILED)\s*$',block,re.M)
  if result:tests.append({'name':m.group(1),'result':result.group(1)})
 summaries=[{'pass':int(a),'fail':int(b),'ignored':int(c)} for a,b,c in re.findall(r'^test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;',s,re.M)]
 out.append({'lane':root.name,'exit':x['exit'],'source':x['source_before'],'source_after':x['source_after'],'source_frozen':x['source_before']==x['source_after'],'argv':x['argv'],'pid':x['pid'],'started_utc':x['started_utc'],'ended_utc':x['ended_utc'],'retirement':x['retirement'],'receipt_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'actual_test_results':tests,'counts':{'pass':sum(y['pass'] for y in summaries),'fail':sum(y['fail'] for y in summaries)},'native_tests_executed':bool(summaries),'log_retained':logs.is_file(),'failure_class':reasons.get(root.name)})
(d/'run-ledger.json').write_text(json.dumps({'runs':out,'status':'Joined ACK/preparation native gates still running or pending. Docs4e retained-state replay completed.'},indent=2)+'\n')
print([(x['lane'],x['exit'],x['counts']) for x in out])
