import subprocess,os,json,time,hashlib,fcntl,tarfile,sys,select
from pathlib import Path
from datetime import datetime,timezone
coord=Path('/Users/rmccrar6/nudox-functional-corpus-20261006/sol61-coordination')
base=Path('/Users/rmccrar6/nudox-functional-corpus-20261006/sol-fresh-remote-runtime')
app,phase,admission,manifest_sha=sys.argv[1:]
assert app in ['mini','next']
os.umask(0o077)
images=coord/'images-pending-capture-199b-debug';manifest=coord/'pending-capture-199b-debug-runtime-build-manifest.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest()==manifest_sha
frozen=json.loads(manifest.read_text());assert frozen['source_commit']=='199bef18b011e41493a3a973f8765015b29ab412' and frozen['source_clean'] is True
for name,fact in frozen['artifacts'].items():assert hashlib.sha256((images/name).read_bytes()).hexdigest()==fact['sha256']
root=coord/('public-pending-199b-'+app);project=root/'project';workspace=root/'workspace';home=root/'home'
if phase=='warm':
 root.mkdir(exist_ok=False);project.mkdir();workspace.mkdir();home.mkdir()
 archive=coord/'sol61-pending-mini-ts-20261007.tar.gz' if app=='mini' else base/'sources/sol61-asp-equivalent-origin-20261007/fe026711c19ac3ee4589c86a738f59b84e611559.tar.gz'
 expected='65570d46d2944178566962826121c5f5a23722272abd69f528cfe2675fd7bb6f' if app=='mini' else '389d541f54d7135e87b7704715f380ddb58821853464b3e7ce384b6ead6fa0eb'
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
 with tarfile.open(archive) as archive_file:
  for member in archive_file.getmembers():
   assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
   assert not member.issym() and not member.islnk()
   if app=='next':member.name='/'.join(Path(member.name).parts[1:])
   if member.name:archive_file.extract(member,project)
 (root/'source-origin.json').write_text(json.dumps({'app':app,'archive':str(archive),'sha256':expected,'actual_user_ASP':False,'source_files':{str(p.relative_to(project)):hashlib.sha256(p.read_bytes()).hexdigest() for p in project.rglob('*') if p.is_file()}},indent=2)+'\n')
epoch=root/phase;epoch.mkdir(exist_ok=False)
endpoint=Path('/tmp/ndx-pending-199b-'+app+'-'+phase+'.sock');assert not endpoint.exists()
node='/nix/store/i5537z04agcqix2qgyg3bx6wdvhjqz1y-nodejs-slim-24.18.0/bin/node'
module='/nix/store/ndn80vhc1mai4l1hlh7n716d94apb1m7-typescript-5.9.3/lib/node_modules'
tsc=module+'/typescript/bin/tsc'
assert Path(tsc).is_file() and Path(node).is_file()
env={k:v for k,v in os.environ.items() if not k.startswith(('NUDOX_','BACKEND_'))}
env.update(HOME=str(home),XDG_DATA_HOME=str(home/'data'),XDG_CACHE_HOME=str(home/'cache'),NUDOX_DATA_ROOT=str(home/'nudox-data'),NUDOX_TSC=tsc,NUDOX_TYPESCRIPT_NODE=node,NUDOX_TYPESCRIPT_MODULE_ROOT=module,PATH=str(Path(node).parent)+':/usr/bin:/bin')
client_env=dict(env,BACKEND_LOCALD_BIN='/usr/bin/false')
cli=[str(images/'backend-cli'),'--project',str(project),'--workspace',str(workspace),'--endpoint',str(endpoint),'--json']
commands=[]
def run(label,args,timeout=600):
 start=time.monotonic();p=subprocess.Popen(cli+args,cwd=project,env=client_env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:out,err=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  p.terminate();out,err=p.communicate();(epoch/'needs-attention').write_text(label);raise
 (epoch/(label+'.stdout')).write_bytes(out);(epoch/(label+'.stderr')).write_bytes(err)
 row={'label':label,'argv':cli+args,'pid':p.pid,'exit':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_bytes':len(out),'stderr_bytes':len(err)}
 try:row['json']=json.loads(out)
 except ValueError:pass
 commands.append(row);(epoch/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');return row
lease=open(coord/'runtime-index.lock','a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
a=json.loads(Path(admission).read_text());assert a['advisory_allowed'] is True
age=max((datetime.now(timezone.utc)-datetime.fromisoformat(h['census']['sample_started_at_utc'].replace('Z','+00:00'))).total_seconds() for h in a['raw_samples'].values());assert age<=30
argv=[str(images/'backend-locald'),'--workspace',str(workspace),'--endpoint',str(endpoint),'--registry-offline','--registry-discovery-offline','--advisory-offline','--forge-offline','--idle-timeout-ms','15000']
owner_out=open(epoch/'locald.stdout','wb');owner_err=open(epoch/'locald.stderr','wb');owner=subprocess.Popen(argv,cwd=project,env=env,stdout=owner_out,stderr=owner_err,start_new_session=True)
receipt={'phase':phase,'app':app,'observer_pid':os.getpid(),'owner_pid':owner.pid,'argv':argv,'started':datetime.now(timezone.utc).isoformat(),'admission':admission,'admission_age_seconds':age,'lock':str(coord/'runtime-index.lock'),'manifest':str(manifest),'manifest_sha256':manifest_sha,'source_commit':frozen['source_commit'],'umask':'0077','home':str(home),'workspace':str(workspace),'project':str(project),'endpoint':str(endpoint),'guided_compiler_paths':{k:env[k] for k in ['NUDOX_TSC','NUDOX_TYPESCRIPT_NODE','NUDOX_TYPESCRIPT_MODULE_ROOT']}}
(epoch/'owner.launch.json').write_text(json.dumps(receipt,indent=2)+'\n')
mcp=None;wire=None;intentional_stop=False
try:
 deadline=time.monotonic()+120
 while not endpoint.exists():
  assert owner.poll() is None,'owner exited at startup';assert time.monotonic()<deadline;time.sleep(.1)
 assert run('startup-health',['--passive','health'],30)['exit']==0
 before=None
 if phase!='warm':
  before=run('semantic-before-any-index',['semantic-versions',str(project)])
  assert before['exit']==0, 'same-state persisted semantic selection read failed before indexing'
  if app=='mini':
   before_rows=before['json'].get('semantic_data',{}).get('value',[])
   selected=[r for r in before_rows if r.get('selected') and r.get('complete')]
   assert selected and selected[0]['generation']==json.loads((root/'warm'/'availability.json').read_text())['semantic_current_complete'][0]['generation'], 'cold reopen substituted the selected native generation'

 if phase=='warm':
  for label in ['first-index','second-index']:
   result=run(label,['add','.']);assert result['exit'] in [0,2],result
 elif phase.startswith('retry') or phase.startswith('remove-retry'):
  if phase.startswith('remove-retry'):assert run('remove-interrupted',['remove',str(project)])['exit']==0
  result=run('retry-index',['add','.']);assert result['exit'] in [0,2],result
 elif phase=='cold1':
  result=run('third-index',['add','.']);assert result['exit'] in [0,2],result
 run('semantic-current',['semantic-versions',str(project)])
 run('packages',['packages']);search=run('search',['--detail','full','--limit','5','search','value' if app=='mini' else 'fetchRevenue'])
 mcp=subprocess.Popen([str(images/'backend-mcp'),'--project',str(project),'--workspace',str(workspace),'--endpoint',str(endpoint)],cwd=project,env=client_env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open(epoch/'mcp.stderr','wb'))
 wire=open(epoch/'mcp.wire.jsonl','wb');seq=0
 def rpc(method,params):
  global seq
  seq+=1;request={'jsonrpc':'2.0','id':seq,'method':method,'params':params};encoded=(json.dumps(request)+'\n').encode();wire.write(b'SEND '+encoded);wire.flush();mcp.stdin.write(encoded);mcp.stdin.flush();start=time.monotonic()
  while time.monotonic()-start<60:
   if not select.select([mcp.stdout],[],[],1)[0]:continue
   line=mcp.stdout.readline();wire.write(b'RECV '+line);wire.flush();assert line,'MCP stream closed'
   response=json.loads(line)
   if response.get('id')==seq:return response
  raise RuntimeError('MCP timeout')
 rpc('initialize',{'protocolVersion':'2024-11-05','capabilities':{},'clientInfo':{'name':'pending-capture-lifecycle','version':'1'}})
 mcp.stdin.write((json.dumps({'jsonrpc':'2.0','method':'notifications/initialized','params':{}})+'\n').encode());mcp.stdin.flush()
 catalog=rpc('tools/list',{});(epoch/'mcp.tools.json').write_text(json.dumps(catalog,indent=2)+'\n')
 def tool(label,name,args):
  result=rpc('tools/call',{'name':name,'arguments':args});(epoch/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n');return result
 tool('mcp-status','backend.status',{})
 versions=tool('mcp-versions','backend.semantic_versions',{'package':str(project)})
 tool('mcp-search','backend.search',{'query':'value' if app=='mini' else 'fetchRevenue'})
 membership_request={'package':{'kind':'local','value':str(project)},'expected_source_relation_root':None,'expected_source_version':None,'cursor':None,'limit':32}
 membership_cli=run('cli-membership',['package-source-membership',json.dumps(membership_request)])
 assert membership_cli['exit']==0
 membership_mcp=tool('mcp-membership','backend.package_source_membership',{'request':membership_request})
 membership=membership_mcp['result']['structuredContent']['package_source_membership_page']
 assert membership['state']=='page' and membership['next'] is None
 assert membership_cli['json']['package_source_membership_page']==membership
 if app=='mini':
  assert sorted(f['path'] for f in membership['files'])==['package.json','src/base.ts','src/use.ts','tsconfig.json'], 'exact admitted membership differs from code and original controls'

 rows=versions.get('result',{}).get('structuredContent',{}).get('semantic_data',{}).get('value',[])
 current=[row for row in rows if row.get('selected') and row.get('complete') and row.get('freshness',{}).get('state')=='current']
 (epoch/'availability.json').write_text(json.dumps({'actual_user_ASP':False,'semantic_current_complete':current,'semantic_tool_isError':versions.get('result',{}).get('isError'),'syntactic_search_records':len(search.get('json',{}).get('records',[])),'semantic_versions':rows,'compiler_refusals_are_not_semantic_success':True},indent=2)+'\n')
 if app=='mini' and current:
  assert current[0]['generation']==json.loads((root/'warm'/'availability.json').read_text())['semantic_current_complete'][0]['generation'], 'same-source replay substituted selected native generation'
  assert current[0]['artifacts']==2
  assert current[0]['selected_source_frontier']['file_count']==4, 'two TypeScript sources plus original package/tsconfig controls; archive metadata and observer origin are not language inputs'
  expected_sources=['package.json','tsconfig.json','src/base.ts','src/use.ts']
  original=json.loads((root/'source-origin.json').read_text())['source_files']
  assert all(hashlib.sha256((project/name).read_bytes()).hexdigest()==original[name] for name in expected_sources), 'captured code and controls remain unchanged'
  identities=[r['identity'] for r in search.get('json',{}).get('records',[]) if r.get('identity',{}).get('name')=='value' and r.get('identity',{}).get('semantic_data')]
  if identities:
   coordinate=identities[0]['coordinate']
   for command in ['show','source','references','graph','resolve']:
    run('cli-'+command,[command,coordinate])
   for name in ['backend.document','backend.source','backend.references','backend.graph']:
    tool(name,name,{'coordinate':coordinate})
 if phase.startswith('interrupt'):
  started=tool('mcp-index-start','backend.index_start',{'package':str(project)})
  start_data=started['result']['structuredContent']['surface']['data'];assert start_data['state']=='started',started
  ticket=start_data['data']['ticket'];(root/'interrupted-ticket.json').write_text(json.dumps(ticket)+'\n')
  deadline=time.monotonic()+120
  while time.monotonic()<deadline:
   progress=tool('mcp-progress-'+str(seq),'backend.index_progress',{'ticket':ticket})
   data=progress['result']['structuredContent']['surface']['data']
   text=json.dumps(data)
   if 'profile-started' in text and 'terminal' not in text:
    owner.terminate();code=owner.wait(timeout=30);assert code==-15;intentional_stop=True
    (epoch/'interrupted-marker-observation.json').write_text(json.dumps({'progress':data,'owned_pid':owner.pid,'kernel_wait':code,'no_cancel_request':True})+'\n');break
   assert 'terminal' not in text,'compile finished before interruption witness; this is not Pending proof'
   time.sleep(.01)
  assert intentional_stop,'never observed accepted compiling capture'
 else:
  if (root/'interrupted-ticket.json').exists():
   tool('old-ticket-after-restart','backend.index_progress',{'ticket':json.loads((root/'interrupted-ticket.json').read_text())})
  assert run('final-health',['--passive','health'])['exit']==0
 mcp.stdin.close();mcp.wait(timeout=30);(epoch/'mcp.retired.json').write_text(json.dumps({'pid':mcp.pid,'kernel_wait':mcp.returncode})+'\n');wire.close();wire=None;mcp=None
 if not intentional_stop:
  code=owner.wait(timeout=45);assert code==0,'owner did not retire successfully through its real idle policy'
  receipt['retirement']='actual idle exit without operator signal'
 else:receipt['retirement']='intentional owned interrupted Pending stop (no cancellation request)'
except Exception as error:
 (epoch/'observer.failure.json').write_text(json.dumps({'exception':repr(error),'owner_live':owner.poll() is None})+'\n')
 raise
finally:
 if mcp is not None:
  mcp.terminate();mcp.wait(timeout=15)
 if wire is not None:wire.close()
 if owner.poll() is None:
  owner.terminate();owner.wait(timeout=30);receipt['retirement']='owned failure cleanup, not idle proof'
 receipt.update(kernel_wait=owner.returncode,ended=datetime.now(timezone.utc).isoformat());(epoch/'owner.retired.json').write_text(json.dumps(receipt,indent=2)+'\n');owner_out.close();owner_err.close()
print(json.dumps({'app':app,'phase':phase,'owner_pid':owner.pid,'wait':owner.returncode,'epoch':str(epoch)}))
