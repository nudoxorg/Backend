import subprocess,os,json,time,hashlib,fcntl,tarfile,sys,signal,select
from pathlib import Path
from datetime import datetime,timezone
coord=Path('/Users/rmccrar6/nudox-functional-corpus-20261006/sol61-coordination')
base=Path('/Users/rmccrar6/nudox-functional-corpus-20261006/sol-fresh-remote-runtime')
images=coord/'images-address-selector-d829-debug'
manifest_path=coord/'address-selector-d829-debug-runtime-build-manifest.json'
os.umask(0o077)
root=coord/'public-httpie-a659-20261006-attempt02';phase=sys.argv[1];admission=Path(sys.argv[2]);epoch=root/phase
if phase=='warm':
 root.mkdir(exist_ok=False);(root/'project').mkdir();(root/'home').mkdir();(root/'workspace').mkdir()
 archive=coord/'httpie-official-5b604c37.tar.gz'
 assert hashlib.sha256(archive.read_bytes()).hexdigest()=='6337eb893c6236ceb852020c238484745aa7c595bfabbec775eb49fdc9a6e058'
 with tarfile.open(archive) as archive_file:
  for member in archive_file.getmembers():
   assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
   if member.issym() or member.islnk():assert not Path(member.linkname).is_absolute() and '..' not in Path(member.linkname).parts
  archive_file.extractall(root/'project')
epoch.mkdir(exist_ok=False)
project=root/'project';workspace=root/'workspace';endpoint=Path('/tmp/ndx-httpie-a659-attempt02-sol61'+('' if phase=='warm' else '-'+phase)+'.sock')
assert hashlib.sha256(manifest_path.read_bytes()).hexdigest()==sys.argv[3]
frozen=json.loads(manifest_path.read_text())
assert frozen['source_commit']=='d82926eefd6fe8ce3b5c93be7ae56d009c04c8c3' and frozen['source_clean'] is True and frozen['profile']=='debug'
expected={name:fact['sha256'] for name,fact in frozen['artifacts'].items()}
assert set(expected)=={'backend-cli','backend-mcp','backend-locald'}
for name,sha in expected.items():assert hashlib.sha256((images/name).read_bytes()).hexdigest()==sha
env={k:v for k,v in os.environ.items() if not k.startswith(('NUDOX_','BACKEND_'))}
env.update(HOME=str(root/'home'),XDG_DATA_HOME=str(root/'home/data'),XDG_CACHE_HOME=str(root/'home/cache'),NUDOX_DATA_ROOT=str(root/'home/nudox-data'))
# A lost selected owner must not cause an unadmitted replacement during ordinary reads.
client_env=dict(env,BACKEND_LOCALD_BIN='/usr/bin/false')
cli=[str(images/'backend-cli'),'--project',str(project),'--workspace',str(workspace),'--endpoint',str(endpoint),'--json']
commands=[]
def run(label,args,timeout=600):
 start=time.monotonic();p=subprocess.Popen(cli+args,cwd=project,env=client_env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:out,err=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  # CLI teardown does not cancel an accepted index job. Keep owner alive for inspection.
  p.terminate();out,err=p.communicate();(epoch/'needs-attention').write_text(label);raise
 (epoch/(label+'.stdout')).write_bytes(out);(epoch/(label+'.stderr')).write_bytes(err)
 row={'label':label,'argv':cli+args,'pid':p.pid,'exit':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_bytes':len(out),'stderr_bytes':len(err)}
 try:row['json']=json.loads(out)
 except Exception:pass
 commands.append(row);(epoch/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');return row
run('ownerless-passive-health',['--passive','health'],20)
assert not endpoint.exists(), 'selected endpoint already exists before own epoch'
lease=open(coord/'runtime-index.lock','a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
a=json.loads(admission.read_text());assert a['advisory_allowed'] is True
age=max((datetime.now(timezone.utc)-datetime.fromisoformat(h['census']['sample_started_at_utc'].replace('Z','+00:00'))).total_seconds() for h in a['raw_samples'].values());assert age<60
argv=[str(images/'backend-locald'),'--workspace',str(workspace),'--endpoint',str(endpoint),'--registry-offline','--registry-discovery-offline','--advisory-offline','--forge-offline']
out=open(epoch/'locald.stdout','wb');err=open(epoch/'locald.stderr','wb');owner=subprocess.Popen(argv,cwd=project,env=env,stdout=out,stderr=err,start_new_session=True)
receipt={'phase':phase,'observer_pid':os.getpid(),'owner_pid':owner.pid,'argv':argv,'started':datetime.now(timezone.utc).isoformat(),'admission':str(admission),'admission_age_seconds':age,'lock':str(coord/'runtime-index.lock'),'manifest':str(manifest_path),'source_commit':frozen['source_commit'],'profile':'debug','manifest_sha256':sys.argv[3],'private_home':env['HOME'],'workspace':str(workspace),'project':str(project),'endpoint':str(endpoint)}
(epoch/'owner.launch.json').write_text(json.dumps(receipt,indent=2)+'\n')
try:
 ready=False
 for i in range(480):
  if owner.poll() is not None:raise RuntimeError('owner exited during public startup')
  if endpoint.exists():
   health=run('startup-health-'+str(i),['--passive','health'],20)
   if health['exit']==0:ready=True;break
  time.sleep(.25)
 assert ready,'owner did not become publicly reachable'
 if phase=='warm':
  run('whole-add',['add','.'])
  run('semantic-current-after-add',['semantic-versions',str(project)])
  run('whole-retry',['add','.'])
  run('semantic-current-after-retry',['semantic-versions',str(project)])
 else:run('semantic-current-cold',['semantic-versions',str(project)])
 run('packages',['packages'])
 run('search-default',['search','HTTPieArgumentParser'])
 full=run('search-full',['--detail','full','--limit','5','search','HTTPieArgumentParser'])
 run('resolve',['--limit','5','resolve','HTTPieArgumentParser'])
 coordinates=[row['identity']['coordinate'] for row in full.get('json',{}).get('records',[]) if row.get('identity',{}).get('name')=='HTTPieArgumentParser' and row.get('identity',{}).get('path')=='httpie/cli/argparser.py']
 coordinate=coordinates[0] if coordinates else None
 if coordinate:
  exact_semantic=run('resolve-exact-semantic',['resolve',coordinate]);assert exact_semantic['exit']==0 and len(exact_semantic.get('json',{}).get('records',[]))==1
  expected_id=next(row['identity']['semantic_data'] for row in full['json']['records'] if row['identity']['coordinate']==coordinate)
  assert exact_semantic['json']['records'][0]['identity']['semantic_data']==expected_id
  exact_source=run('resolve-exact-source',['resolve',str(project)+'::httpie/cli/argparser.py:138::HTTPieArgumentParser']);assert exact_source['exit']==0 and len(exact_source.get('json',{}).get('records',[]))==1
  assert exact_source['json']['records'][0]['identity']['semantic_data']==expected_id
  for label,target in [('foreign',str(project)+'-wrong::httpie/cli/argparser.py:138::HTTPieArgumentParser'),('wrong-line',str(project)+'::httpie/cli/argparser.py:139::HTTPieArgumentParser')]:
   negative=run('resolve-negative-'+label,['resolve',target]);assert negative['exit']==0 and not negative.get('json',{}).get('records',[])
  empty_leaf_targets=[str(project)+'::semantic::forged::',str(project)+'::httpie/cli/argparser.py:138::',str(project)+'::','pkg:npm/example@1.0.0::','Foo::','::']
  for at,target in enumerate(empty_leaf_targets):
   negative=run('resolve-negative-empty-leaf-'+str(at),['resolve',target]);assert negative['exit']==0 and negative['json'].get('records')==[] and not negative['json'].get('nextCursor')
  for command in ['show','source','references','graph']:
   run(command+'-default',[command,coordinate])

 # Keep one persistent actual MCP process and retain every full protocol line.
 mcp=subprocess.Popen([str(images/'backend-mcp'),'--project',str(project),'--workspace',str(workspace),'--endpoint',str(endpoint)],cwd=project,env=client_env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open(epoch/'mcp.stderr','wb'))
 wire=open(epoch/'mcp.wire.jsonl','wb');seq=0
 def rpc(method,params):
  global seq
  seq+=1;request={'jsonrpc':'2.0','id':seq,'method':method,'params':params};encoded=(json.dumps(request)+'\n').encode();wire.write(b'SEND '+encoded);wire.flush();mcp.stdin.write(encoded);mcp.stdin.flush();start=time.monotonic()
  while time.monotonic()-start<40:
   if not select.select([mcp.stdout],[],[],1)[0]:continue
   line=mcp.stdout.readline();wire.write(b'RECV '+line);wire.flush()
   if not line:raise RuntimeError('MCP stream closed')
   response=json.loads(line)
   if response.get('id')==seq:return response
  raise RuntimeError('MCP request timed out')
 try:
  rpc('initialize',{'protocolVersion':'2024-11-05','capabilities':{},'clientInfo':{'name':'httpie-public-a659-proof','version':'1'}})
  notification=(json.dumps({'jsonrpc':'2.0','method':'notifications/initialized','params':{}})+'\n').encode();wire.write(b'SEND '+notification);wire.flush();mcp.stdin.write(notification);mcp.stdin.flush()
  catalog=rpc('tools/list',{});(epoch/'mcp.tools.json').write_text(json.dumps(catalog,indent=2)+'\n')
  reads=[('backend.status',{}),('backend.semantic_versions',{'package':str(project)}),('backend.search',{'query':'HTTPieArgumentParser'}),('backend.resolve',{'query':'HTTPieArgumentParser'}),('backend.outline',{})]
  if coordinate:
   for label,target in [('semantic',coordinate),('source',str(project)+'::httpie/cli/argparser.py:138::HTTPieArgumentParser')]:
    result=rpc('tools/call',{'name':'backend.resolve','arguments':{'query':target}});(epoch/('backend.resolve-exact-'+label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    assert not result.get('error') and result['result'].get('isError') is False
    records=result['result']['structuredContent']['records'];assert len(records)==1 and records[0]['identity']['semantic_data']==expected_id
  for at,target in enumerate(empty_leaf_targets):
   negative=rpc('tools/call',{'name':'backend.resolve','arguments':{'query':target}});(epoch/('backend.resolve-negative-empty-leaf-'+str(at)+'.json')).write_text(json.dumps(negative,indent=2)+'\n')
   assert not negative.get('error') and negative['result']['isError'] is False
   assert negative['result']['structuredContent'].get('records')==[] and not negative['result']['structuredContent'].get('nextCursor')
  pages=[];seen=[];cursor=None
  for at in range(8):
   args={'query':'HTTPieArgumentParser','limit':1}
   if cursor:args['cursor']=cursor
   response=rpc('tools/call',{'name':'backend.resolve','arguments':args});(epoch/('backend.resolve-page-'+str(at)+'.json')).write_text(json.dumps(response,indent=2)+'\n')
   assert not response.get('error') and response['result'].get('isError') is False
   data=response['result']['structuredContent'];seen.extend(row['identity']['semantic_data'] for row in data['records']);pages.append(data)
   cursor=data.get('nextCursor')
   if not cursor:break
  assert len(seen)==3 and len({json.dumps(value,sort_keys=True) for value in seen})==3
  (epoch/'resolve-page-union.json').write_text(json.dumps({'pages':len(pages),'count':len(seen),'native_selectors':seen,'complete':not bool(cursor)},indent=2)+'\n')
  if coordinate:reads.extend((name,{'coordinate':coordinate}) for name in ['backend.document','backend.source','backend.references','backend.graph'])
  for name,args in reads:
   result=rpc('tools/call',{'name':name,'arguments':args});(epoch/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 finally:
  mcp.stdin.close();mcp.terminate();code=mcp.wait(timeout=15);(epoch/'mcp.retired.json').write_text(json.dumps({'pid':mcp.pid,'kernel_wait':code})+'\n');wire.close()
 run('final-health',['--passive','health'])
except Exception as exc:
 (epoch/'observer.failure.json').write_text(json.dumps({'exception':repr(exc),'owner_live':owner.poll() is None})+'\n')
 if (epoch/'needs-attention').exists():
  # Do not interrupt an accepted long-running job; retain our own lease until coordinated.
  while not (epoch/'authorized-retire').exists():time.sleep(1)
 raise
finally:
 owner.terminate();code=owner.wait(timeout=30);receipt.update(kernel_wait=code,ended=datetime.now(timezone.utc).isoformat());(epoch/'owner.retired.json').write_text(json.dumps(receipt,indent=2)+'\n');out.close();err.close()
