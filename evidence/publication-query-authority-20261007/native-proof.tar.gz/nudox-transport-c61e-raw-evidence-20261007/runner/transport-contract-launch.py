import argparse,datetime,json,pathlib,subprocess,sys,time
p=argparse.ArgumentParser();p.add_argument('--label',choices=['kernel','library','client','publication','journal'],required=True);a=p.parse_args()
python='/nix/store/llk2h8rxqzv7zh53bi413ffibjrxskxw-python3-3.14.6/bin/python3';stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');report='/private/tmp/transport-contract-'+a.label+'-'+stamp+'-fleet.json'
subprocess.run([python,'-B','/private/tmp/nudox-compiler-capacity-census-20261005-v5.py','--destination','ilo','--jobs','2','--max-age-seconds','30','--allow-local-over-cap-for-remote','--output',report],check=True,stdout=subprocess.DEVNULL)
r=json.loads(pathlib.Path(report).read_text());assert r['advisory_allowed'] and all(h['complete'] for h in r['hosts'].values()),r.get('reasons');now=datetime.datetime.now(datetime.timezone.utc)
latest=max(datetime.datetime.fromisoformat(h['resource_sampled_at_utc']) for h in r['hosts'].values());ahead=(latest-now).total_seconds();assert ahead<2
if ahead>0:time.sleep(ahead+0.05)
now=datetime.datetime.now(datetime.timezone.utc)
assert all(0<=(now-datetime.datetime.fromisoformat(h['resource_sampled_at_utc'])).total_seconds()<30 for h in r['hosts'].values())
assert r['current_fleet_compiler_group_count']<16 and r['hosts']['ilo']['compiler_group_count']<8
assert all(h['available_memory_bytes']>=8*1024**3 for h in r['hosts'].values());assert r['hosts']['ilo']['root_disk_available_bytes']>=16*1024**3
remote='/root/transport-contract-'+a.label+'-'+stamp;subprocess.run(['scp',report,'ilo:'+remote+'-fleet.json'],check=True,stdout=subprocess.DEVNULL)
print(json.dumps({'fleet_report':report,'out':remote,'fleet':r['current_fleet_compiler_group_count'],'ilo':r['hosts']['ilo']['compiler_group_count']}),flush=True)
sys.exit(subprocess.call(['ssh','ilo','/root/nudox-corpus-20261006/tool-recovery/roots/fleet-census-python3-3.14.6/bin/python3','-B','/root/transport-contract-supervisor.py','--label',a.label,'--out',remote,'--admission',remote+'-fleet.json']))
