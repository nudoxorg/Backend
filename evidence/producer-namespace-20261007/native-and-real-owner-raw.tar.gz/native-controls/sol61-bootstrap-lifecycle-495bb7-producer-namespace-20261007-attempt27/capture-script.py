import argparse, datetime, fcntl, hashlib, json, os, pathlib, re, shutil, signal, subprocess, time

p = argparse.ArgumentParser()
p.add_argument('--fleet-proof', type=pathlib.Path, required=True)
p.add_argument('--package', choices=['backend-client', 'backend-desktop', 'backend-local-service'], required=True)
p.add_argument('--filter', required=True)
p.add_argument('--attempt', required=True)
a = p.parse_args()
assert re.fullmatch(r'[a-z0-9-]+', a.attempt)
W = pathlib.Path('/Users/rmccrar6/codex-worktrees/sol-fresh-fcb-mac-build-20261006')
B = pathlib.Path('/Users/rmccrar6/nudox-functional-corpus-20261006/sol-fresh-remote-runtime')
C = '495bb765df55c7be9dd631326a9e792b10d185d8'
T = '9a0c9843bfc1cbd43d56881869737424b92d99fa'
L = 'b508bc8978b37e09e54887a76cdb7055a4188f1243770057784a08ad61560268'
R = B / ('receipts/sol61-bootstrap-' + a.attempt)
R.mkdir(mode=0o700, exist_ok=False)
permit = (B / 'coordination/sol61-bootstrap-native-slot.lock').open('a+')
fcntl.flock(permit, fcntl.LOCK_EX | fcntl.LOCK_NB)
runtime_permit = (B / 'coordination/sol61-gui-private-publication-owner.lock').open('a+')
fcntl.flock(runtime_permit, fcntl.LOCK_EX | fcntl.LOCK_NB)

def sha(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(*args):
    return subprocess.check_output(['/usr/bin/git', '-C', str(W), *args], text=True).strip()

def source():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain'), 'cargo_lock_sha256': sha(W / 'Cargo.lock')}

def resources():
    raw = subprocess.check_output(['/usr/bin/vm_stat'], text=True)
    page = int(re.search(r'page size of (\d+) bytes', raw).group(1))
    values = {k: int(v) for k, v in re.findall(r'([^\n:]+):\s+(\d+)\.', raw)}
    disk = os.statvfs(W)
    return {'utc': now(), 'available_memory_bytes': sum(values.get(k, 0) for k in
            ['Pages free', 'Pages inactive', 'Pages speculative']) * page,
            'free_disk_bytes': disk.f_bavail * disk.f_frsize}

fleet = json.loads(a.fleet_proof.read_text())
assert fleet['advisory_allowed'] and fleet['destination'] == 'h16001mac'
assert fleet['requested_cargo_jobs'] == 4
assert 0 <= time.time() - datetime.datetime.fromisoformat(fleet['sampled_at_utc']).timestamp() < 30
assert set(fleet['raw_samples']) == {'local', 'ilo', 'h16001mac'}
assert fleet['schema'] == 'compiler-capacity-admission.v5' and fleet['max_sample_age_seconds'] <= 30
for sample in fleet['raw_samples'].values():
    assert sample['transport_complete'] and sample['return_code'] == 0
    assert sample['census']['complete'] and sample['census']['resource_snapshot_complete']
    stamps = [sample['census']['sample_started_at_utc'], sample['census']['sample_finished_at_utc'], sample['census']['resource_snapshot']['sampled_at_utc']]
    assert all(-5 <= time.time() - datetime.datetime.fromisoformat(stamp).timestamp() < 30 for stamp in stamps)
before = source()
assert before == {'commit': C, 'tree': T, 'status': '', 'cargo_lock_sha256': L}
start = resources()
assert start['available_memory_bytes'] >= 8 * 1024 ** 3
assert start['free_disk_bytes'] >= 16 * 1024 ** 3
rust = pathlib.Path('/nix/store/ff5chd1i7bm0d7ki0ahkbkgwij973qvx-rust-1.97.1-with-components-2026-07-16/bin')
envfile = B / 'artifacts/fcb-native-environment.sh'
runner = W / '.local/fcb-managed-runner/cargo'

def tools():
    return {n: {'path': str(rust / n), 'sha256': sha(rust / n),
                'version': subprocess.check_output([str(rust / n), '--version'], text=True).strip()}
            for n in ['cargo', 'rustc', 'rustdoc']}

tool_before = tools()
runner_sha, env_sha = sha(runner), sha(envfile)
args = [str(runner), 'test', '--release', '--locked', '--offline', '-j4',
        '--message-format=json', '-p', a.package, '--lib', a.filter, '--', '--test-threads=1', '--nocapture']
shell = ('set -eu; source "$1"; ulimit -n 8192; '
         'export SCCACHE_DIR="$2/.local/sccache-fcb-attempt02"; unset SCCACHE_SERVER_UDS; '
         'export CARGO_BUILD_JOBS=4 NIX_BUILD_CORES=4 NUDOX_CARGO_BUILD_SLOTS=6; '
         'export CARGO_BUILD_BUILD_DIR="$2/.local/build/runtime-fcb" CARGO_TARGET_DIR="$2/.local/target"; '
         'exec "$3" "${@:4}"')
invocation = ['/bin/bash', '-c', shell, 'sol61-bootstrap-native', str(envfile), str(W), *args]
receipt = {'capture_script': {'path': __file__, 'sha256': sha(__file__)}, 'schema': 'nudox.native-bootstrap-regression.v1', 'source_before': before,
           'profile': 'release', 'target': 'native-aarch64-apple-darwin', 'command': args,
           'actual_invocation': invocation, 'tools_before': tool_before,
           'runner': {'path': str(runner), 'sha256': runner_sha},
           'environment': {'path': str(envfile), 'sha256': env_sha},
           'fleet_proof_sha256': sha(a.fleet_proof), 'supervisor_pid': os.getpid(),
           'started_utc': now(), 'exit_code': None, 'guard_reason': None,
           'gui_interaction_acceptance': False, 'test_executables': {},
           'runtime_allocation': {'scope': 'Root authorized sol61_gui_lifecycle_remote new isolated private production owner', 'lease': str(B / 'coordination/sol61-gui-private-publication-owner.lock'), 'lease_held_through_child_exit': True}}
shutil.copyfile(a.fleet_proof, R / 'fleet-proof.json')
shutil.copyfile(__file__, R / 'capture-script.py')
(R / 'test-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
with (R / 'cargo.stdout.jsonl').open('wb') as out, (R / 'cargo.stderr.log').open('wb') as err:
    child = subprocess.Popen(invocation, cwd=W, stdout=out, stderr=err, start_new_session=True)
    receipt['owned_process_group'] = child.pid
    (R / 'test-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'receipt': str(R), 'supervisor_pid': os.getpid(),
                      'owned_process_group': child.pid, 'source': C}), flush=True)
    while child.poll() is None:
        sample = resources()
        rows = subprocess.check_output(['/bin/ps', '-axo', 'pid=,ppid=,pgid=,command='], text=True).splitlines()
        owned = [line for line in rows if len(line.split(None, 3)) >= 4 and line.split(None, 3)[2] == str(child.pid)]
        pids = [line.split(None, 3)[0] for line in owned]
        sockets = subprocess.run(['/usr/sbin/lsof', '-n', '-P', '-a', '-p', ','.join(pids), '-U'], capture_output=True, text=True).stdout if pids else ''
        with (R / 'owned-runtime-observations.jsonl').open('a') as f:
            f.write(json.dumps({'utc': now(), 'processes': owned, 'unix_socket_observations': sockets}) + '\n')
        with (R / 'resources.jsonl').open('a') as f:
            f.write(json.dumps(sample) + '\n')
        if sample['available_memory_bytes'] < 8 * 1024 ** 3 or sample['free_disk_bytes'] < 16 * 1024 ** 3:
            receipt['guard_reason'] = 'owned test resource floor'
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=10)
            break
        time.sleep(5)
    receipt['exit_code'] = child.wait()
receipt['finished_utc'] = now()
receipt['source_after'] = source()
receipt['source_unchanged'] = receipt['source_after'] == before
receipt['tools_after'] = tools()
receipt['tools_unchanged'] = receipt['tools_after'] == tool_before
receipt['assets_unchanged'] = sha(runner) == runner_sha and sha(envfile) == env_sha
receipt['raw_logs'] = {n: {'bytes': (R / n).stat().st_size, 'sha256': sha(R / n)}
                       for n in ['cargo.stdout.jsonl', 'cargo.stderr.log', 'resources.jsonl']}
events = []
for line in (R / 'cargo.stdout.jsonl').read_text().splitlines():
    try:
        event = json.loads(line)
    except ValueError:
        continue
    if event.get('reason') == 'compiler-artifact' and event.get('executable') and event.get('profile', {}).get('test'):
        events.append(event)
        exe = pathlib.Path(event['executable'])
        assert exe.is_relative_to(W / '.local/target') or (exe.is_relative_to(W / '.local/build/runtime-fcb/.nudox-cargo') and exe.parent.name == 'deps' and exe.parent.parent.name == 'release' and exe.parent.parent.parent.name in {f'slot-{i}' for i in range(6)})
        frozen = R / 'frozen-test-executables'
        frozen.mkdir(mode=0o700, exist_ok=True)
        dst = frozen / exe.name
        shutil.copyfile(exe, dst)
        dst.chmod(0o555)
        assert dst.stat().st_nlink == 1 and sha(dst) == sha(exe)
        receipt['test_executables'][str(exe)] = {'sha256': sha(exe), 'bytes': exe.stat().st_size, 'frozen_copy': str(dst)}
(R / 'actual-test-artifact-events.json').write_text(json.dumps(events, indent=2) + '\n')
(R / 'test-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
(R / 'completion.json').write_text(json.dumps({'exit_code': receipt['exit_code'],
    'source_unchanged': receipt['source_unchanged'], 'receipt_sha256': sha(R / 'test-receipt.json'),
    'resources_after': resources()}, indent=2) + '\n')
print(json.dumps({'exit_code': receipt['exit_code'], 'receipt': str(R),
                  'source_unchanged': receipt['source_unchanged']}), flush=True)
raise SystemExit(receipt['exit_code'])
