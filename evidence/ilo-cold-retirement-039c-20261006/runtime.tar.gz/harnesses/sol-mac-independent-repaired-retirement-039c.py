from pathlib import Path
import os,json,time,signal,subprocess,select,concurrent.futures

namespace={'__name__':'cold_support'}
exec(compile(Path('/root/nudox-corpus-20261006/artifacts/sol-mac-independent-first-cold-039c.py').read_text(),'<frozen support>','exec'),namespace)
BASE=namespace['BASE'];IMAGES=namespace['IMAGES'];digest=namespace['digest'];tree=namespace['tree'];processes=namespace['processes'];resources=namespace['resources'];shutil=namespace['shutil']
OUT=BASE/'runs/sol-mac-independent-repaired-retirement-039c-20261006'
ORIGINAL=BASE/'runs/fresh-remote-runtime/20261006T112754Z-python-configured-0c54656f'

def proc_snapshot(pid):
    p=Path('/proc')/str(pid);r={'time':time.time(),'pid':pid,'exists':p.exists()}
    for file in ['cmdline','stat','status']:
        try:r[file]=(p/file).read_bytes().replace(b'\0',b' ').decode(errors='replace')
        except OSError:r[file]=None
    try:r['fds']={f.name:os.readlink(f) for f in (p/'fd').iterdir()}
    except OSError:r['fds']=None
    return r

def run_case(case):
    mode='kernel-pidfd'; original=ORIGINALS[case]
    lane=OUT/case;lane.mkdir(mode=0o700);state=lane/'state'; before=tree(original/'state');shutil.copytree(original/'state',state);assert before==tree(state)
    project=original/'project';source_before=tree(project);setup=json.loads((original/'setup.json').read_text());env=dict(setup['env']);home=lane/'home';home.mkdir(mode=0o700);tmp=lane/'tmp';tmp.mkdir(mode=0o700);env.update(HOME=str(home),TMPDIR=str(tmp),XDG_CONFIG_HOME=str(home/'.config'),XDG_DATA_HOME=str(home/'.local/share'),XDG_STATE_HOME=str(home/'.local/state'))
    wrapper=lane/'logged-locald';wrapper.write_text('#!/bin/sh\nexec '+str(IMAGES/'backend-locald')+' "$@" >'+str(lane/'daemon.stdout')+' 2>'+str(lane/'daemon.stderr')+'\n');wrapper.chmod(0o700);env['BACKEND_LOCALD_BIN']=str(wrapper)
    endpoint='/tmp/nudox-retirement-'+case+'-'+str(os.getpid())+'.sock';common=['--project',str(project),'--workspace',str(state),'--endpoint',endpoint];cli=[str(IMAGES/'backend-cli'),'--json','--detail','full',*common,'health'];receipt={'mode':mode,'argv':cli,'env':env,'project':str(project),'original':str(original),'events':[],'commands':[],'raw_mcp':[]};traces=[];mcp=None
    def save():(lane/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    def plain(label):
        start=time.monotonic();p=subprocess.run(cli,env=env,cwd=project,capture_output=True,timeout=90);(lane/(label+'.stdout')).write_bytes(p.stdout);(lane/(label+'.stderr')).write_bytes(p.stderr);receipt['commands'].append({'label':label,'argv':cli,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});save();return p
    def mcp_start_status(label):
        nonlocal mcp
        err=(lane/(label+'.mcp.stderr')).open('wb');mcp=subprocess.Popen([str(IMAGES/'backend-mcp'),*common],env=env,cwd=project,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,start_new_session=True)
        def rpc(value,notify=False):
            raw=json.dumps(value,separators=(',',':')).encode()+b'\n';t=time.monotonic();mcp.stdin.write(raw);mcp.stdin.flush();receipt['raw_mcp'].append({'label':label,'direction':'request','epoch':time.time(),'bytes':raw.decode()})
            if notify:return
            assert select.select([mcp.stdout],[],[],45)[0], 'MCP bounded reply deadline'
            line=mcp.stdout.readline();assert line,'MCP unexpected EOF';receipt['raw_mcp'].append({'label':label,'direction':'response','epoch':time.time(),'seconds':time.monotonic()-t,'bytes':line.decode()});reply=json.loads(line);assert reply.get('id')==value['id'];save();return reply
        rpc({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'sol-independent-cold','version':'1'}}})
        rpc({'jsonrpc':'2.0','method':'notifications/initialized'},True)
        result=rpc({'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':'backend.status','arguments':{'detail':'full'}}});receipt['events'].append({'kind':'mcp-status','label':label,'pid':mcp.pid,'result':result,'time':time.time()});mcp.stdin.close();mcp.wait(timeout=10);err.close();mcp=None;save()
    def traced_cold():
        out=(lane/'first-cold-health.stdout').open('wb');err=(lane/'first-cold-health.stderr').open('wb');path=lane/'first-cold-health.strace';start=time.monotonic();t=time.time();p=subprocess.Popen(['/run/current-system/sw/bin/strace','-f','-ttt','-yy','-s','65536','-o',str(path),'-e','trace=process,network',*cli],env=env,cwd=project,stdout=out,stderr=err,start_new_session=True);traces.append(p);pid=None;exitcode=None
        while exitcode is None:
            assert time.monotonic()-start<90
            r=resources();assert r['MemAvailable']>=16*2**30 and r['free_disk_bytes']>=16*2**30,r
            text=path.read_text(errors='replace') if path.exists() else ''
            for line in text.splitlines():
                if 'execve("'+str(IMAGES/'backend-cli')+'"' in line and pid is None:pid=int(line.split()[0])
                if pid and line.startswith(str(pid)+' ') and '+++ exited with ' in line:exitcode=int(line.split('+++ exited with ')[1].split()[0]);break
            if exitcode is None and p.poll() is not None:raise RuntimeError('tracer ended without actual CLI exit')
            if exitcode is None:time.sleep(.01)
        out.close();err.close();receipt['commands'].append({'label':'first-cold-health','argv':cli,'exit':exitcode,'epoch':t,'seconds':time.monotonic()-start,'stdout':(lane/'first-cold-health.stdout').read_text(),'stderr':(lane/'first-cold-health.stderr').read_text()});save()
    try:
        r=resources();assert r['MemAvailable']>=24*2**30 and r['free_disk_bytes']>=24*2**30 and r['host_owner_count']<=8,r
        assert plain('warm-health').returncode==0;mcp_start_status('before-retirement')
        rows=processes(endpoint);assert len(rows)==1;pid=rows[0]['pid'];receipt['events'].append({'kind':'signal-boundary','snapshot':proc_snapshot(pid),'time':time.time()});proof=retire_owned_process(pid);receipt['events'].append({'kind':'retirement-proof','proof':proof,'snapshot':proc_snapshot(pid),'time':time.time()});save();traced_cold();plain('second-cold-health');mcp_start_status('after-cold')
    finally:
        if mcp and mcp.poll() is None:mcp.terminate();mcp.wait(timeout=10)
        for row in processes(endpoint):os.kill(row['pid'],signal.SIGTERM)
        deadline=time.monotonic()+20
        while processes(endpoint) and time.monotonic()<deadline:time.sleep(.05)
        for row in processes(endpoint):os.kill(row['pid'],signal.SIGKILL)
        for p in traces:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10)
        receipt.update(remaining_owners=processes(endpoint),original_state_unchanged=before==tree(original/'state'),original_source_unchanged=source_before==tree(project),daemon_stderr=(lane/'daemon.stderr').read_text() if (lane/'daemon.stderr').exists() else None);save()
    print(case,[(c['label'],c['exit'],round(c['seconds'],3)) for c in receipt['commands']],flush=True);return {'case':case,'commands':receipt['commands'],'original_state_unchanged':receipt['original_state_unchanged'],'original_source_unchanged':receipt['original_source_unchanged'],'remaining_owners':len(receipt['remaining_owners'])}

import runpy
HELPER=BASE/'artifacts/sol-mac-kernel-exit-journey-observer.py'
retire_owned_process=runpy.run_path(str(HELPER),run_name='observer_support')['retire_owned_process']
ORIGINALS={'quart039c':ORIGINAL,'click039c':BASE/'runs/fresh-remote-runtime/20261006T113100Z-python-configured-e02a971f'}
OUT.mkdir(mode=0o700)
manifest=namespace['MANIFEST'];m=json.loads(manifest.read_text())
assert digest(manifest)=='a693977a9bcbf2e25c7b7ebb3c820d8a971ac5a190cf25708d608ee69c4c07f8'
for key,v in m['executables'].items():assert digest(IMAGES/key)==v['sha256']
(OUT/'preflight.json').write_text(json.dumps({'manifest':m,'manifest_sha256':digest(manifest),'observer_sha256':digest(HELPER),'resources':resources()},indent=2)+'\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run_case,['quart039c','click039c']))
(OUT/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
