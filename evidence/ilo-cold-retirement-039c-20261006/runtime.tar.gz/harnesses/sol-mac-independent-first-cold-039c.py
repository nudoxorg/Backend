from pathlib import Path
import os, json, subprocess, time, signal, shutil, hashlib, concurrent.futures

BASE = Path('/root/nudox-corpus-20261006')
OUT = BASE / 'runs/sol-mac-independent-cold-039c-20261006'
MANIFEST = BASE / 'receipts/dto20-039c360d28-runtime-build-20261006T111152Z-attempt03/runtime-build-manifest.json'
IMAGES = BASE / 'artifacts/images-dto20-039c360d28-20261006T111152Z'
CASES = {
    'quart039c': '20261006T112754Z-python-configured-0c54656f',
    'typing9f-state-039c-image': '20261006T112150Z-python-configured-fc243dd7',
}

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def tree(path):
    return [[str(p.relative_to(path)), p.stat().st_size, digest(p)]
            for p in sorted(path.rglob('*')) if p.is_file()]

def processes(endpoint=None):
    rows=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            exe=os.readlink(p/'exe'); cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
            if Path(exe).name != 'backend-locald' or (endpoint and endpoint not in cmd): continue
            rows.append({'pid':int(p.name),'exe':exe,'cmd':cmd,
                         'status':(p/'status').read_text(),'fds':{f.name:os.readlink(f) for f in (p/'fd').iterdir()}})
        except (OSError, ProcessLookupError): pass
    return rows

def resources():
    mem={l.split(':')[0]:int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith(('MemAvailable:','MemFree:'))}
    return {'time':time.time(),'free_disk_bytes':shutil.disk_usage(OUT.parent).free, **mem,'host_owner_count':len(processes())}

def run_case(name, suffix):
    original=BASE/'runs/fresh-remote-runtime'/suffix
    setup=json.loads((original/'setup.json').read_text())
    lane=OUT/name; lane.mkdir(mode=0o700)
    state=lane/'state'; project=original/'project'
    before=tree(original/'state'); shutil.copytree(original/'state',state)
    assert before==tree(state)
    home=lane/'home';home.mkdir(mode=0o700); tmp=lane/'tmp';tmp.mkdir(mode=0o700)
    env=dict(setup['env']);env.update(HOME=str(home),TMPDIR=str(tmp),XDG_CONFIG_HOME=str(home/'.config'),XDG_DATA_HOME=str(home/'.local/share'),XDG_STATE_HOME=str(home/'.local/state'))
    endpoint='/tmp/nudox-independent-'+name+'-'+str(os.getpid())+'.sock'
    # Only redirects logging before exec of the exact immutable daemon. The
    # CLI still performs natural detached owner startup and all real queries.
    wrapper=lane/'logged-locald';wrapper.write_text('#!/bin/sh\nexec '+str(IMAGES/'backend-locald')+' "$@" >'+str(lane/'daemon.stdout')+' 2>'+str(lane/'daemon.stderr')+'\n');wrapper.chmod(0o700)
    env['BACKEND_LOCALD_BIN']=str(wrapper)
    argv=[str(IMAGES/'backend-cli'),'--json','--detail','full','--project',str(project),'--workspace',str(state),'--endpoint',endpoint,'health']
    receipt={'scope':name,'original':str(original),'original_setup_sha256':digest(original/'setup.json'),'source_before':setup.get('runtime_manifest_content',{}).get('source'),'candidate_manifest':str(MANIFEST),'candidate_manifest_sha256':digest(MANIFEST),'project':str(project),'source_untouched':True,'state_clone_before':before,'env':env,'endpoint':endpoint,'argv':argv,'instrumentation':'natural CLI detached startup; logging-only exec wrapper; strace process/network/close tracing; no readiness sleeps or retries','samples':[],'commands':[]}
    tracing=[]
    def command(label):
        stdout=(lane/(label+'.stdout')).open('wb');stderr=(lane/(label+'.stderr')).open('wb')
        trace=lane/(label+'.strace'); cmd=['/run/current-system/sw/bin/strace','-f','-ttt','-yy','-s','65536','-o',str(trace),'-e','trace=process,network,close',*argv]
        started=time.monotonic(); start_epoch=time.time(); p=subprocess.Popen(cmd,env=env,cwd=project,stdout=stdout,stderr=stderr,start_new_session=True);tracing.append(p)
        # strace follows the detached daemon, so detect the initial real CLI's
        # exit in its trace rather than killing or waiting for the owner.
        cli_pid=None; observed=None
        deadline=started+90
        while observed is None:
            now=time.monotonic();assert now<deadline,'bounded CLI observation deadline'
            free=resources();assert free['free_disk_bytes']>=16*2**30 and free['MemAvailable']>=16*2**30,free
            rows=processes(endpoint); sock=Path(endpoint)
            receipt['samples'].append({'label':label,'time':time.time(),'elapsed':now-started,'socket_exists':sock.exists(),'socket_stat':{'inode':sock.stat().st_ino,'mode':sock.stat().st_mode,'uid':sock.stat().st_uid} if sock.exists() else None,'owners':rows,'resources':free})
            text=trace.read_text(errors='replace') if trace.exists() else ''
            for line in text.splitlines():
                if 'execve("'+str(IMAGES/'backend-cli')+'"' in line and cli_pid is None: cli_pid=int(line.split()[0])
                if cli_pid and line.startswith(str(cli_pid)+' ') and '+++ exited with ' in line:
                    observed=int(line.split('+++ exited with ')[1].split()[0]);break
            if observed is None and p.poll() is not None: raise RuntimeError('tracer ended without captured CLI exit '+str(p.returncode))
            if observed is None: time.sleep(.02)
        stdout.close();stderr.close();result={'label':label,'start_epoch':start_epoch,'seconds':time.monotonic()-started,'strace_pid':p.pid,'cli_pid':cli_pid,'cli_exit':observed,'argv':argv,'stdout':(lane/(label+'.stdout')).read_text(),'stderr':(lane/(label+'.stderr')).read_text(),'owners_after':processes(endpoint)};receipt['commands'].append(result);(lane/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(name,label,observed,round(result['seconds'],3),flush=True)
    try:
        assert resources()['MemAvailable']>=24*2**30 and resources()['free_disk_bytes']>=24*2**30
        command('first-health')
        # An explicit independent second request is evidence, never an
        # implicit retry or a substituted success for the first outcome.
        command('second-health')
    finally:
        for row in processes(endpoint):
            os.kill(row['pid'],signal.SIGTERM)
        deadline=time.monotonic()+20
        while processes(endpoint) and time.monotonic()<deadline: time.sleep(.05)
        for row in processes(endpoint): os.kill(row['pid'],signal.SIGKILL)
        for p in tracing:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10)
        receipt['remaining_owners']=processes(endpoint);receipt['original_state_unchanged']=before==tree(original/'state');receipt['daemon_stdout']=(lane/'daemon.stdout').read_text() if (lane/'daemon.stdout').exists() else None;receipt['daemon_stderr']=(lane/'daemon.stderr').read_text() if (lane/'daemon.stderr').exists() else None
        (lane/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return {'case':name,'commands':receipt['commands'],'original_state_unchanged':receipt['original_state_unchanged'],'remaining_owners':len(receipt['remaining_owners'])}

if __name__=='__main__':
    OUT.mkdir(mode=0o700)
    manifest=json.loads(MANIFEST.read_text());assert digest(MANIFEST)=='a693977a9bcbf2e25c7b7ebb3c820d8a971ac5a190cf25708d608ee69c4c07f8'
    assert manifest['source']['commit']=='039c360d286962a6cf19488fb86caabd1d8c93de'
    for key,v in manifest['executables'].items():assert digest(IMAGES/key)==v['sha256']
    baseline=resources();assert baseline['free_disk_bytes']>=24*2**30 and baseline['MemAvailable']>=24*2**30 and baseline['host_owner_count']<=8,baseline
    (OUT/'preflight.json').write_text(json.dumps({'resources':baseline,'manifest':manifest,'harness_sha256':digest(Path(__file__))},indent=2)+'\n')
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        results=list(executor.map(lambda pair:run_case(*pair),CASES.items()))
    (OUT/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
