import json,hashlib,shutil,subprocess,os
from pathlib import Path
coord=Path('/Users/rmccrar6/nudox-functional-corpus-20261006/sol61-coordination')
wt=Path('/Users/rmccrar6/codex-worktrees/sol61-index-native-test-20261006')
sha='d54f6f5908dc4a0ed4ad8d4a4c388b0e2ad39036'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip()==sha
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=wt,text=True).strip()
receipt=json.loads((coord/'document-selection-d54f-debug-trio-build.complete.json').read_text());assert receipt['exit']==0
out=coord/'images-document-selection-d54f-debug';out.mkdir(exist_ok=False)
artifacts={}
for line in (coord/'document-selection-d54f-debug-trio-build.stdout').read_text().splitlines():
 try:row=json.loads(line)
 except ValueError:continue
 if row.get('reason')!='compiler-artifact' or not row.get('executable'):continue
 name=row['target']['name']
 if name not in ['backend-cli','backend-mcp','backend-locald']:continue
 assert name not in artifacts
 source=Path(row['executable']);target=out/name;shutil.copy2(source,target);target.chmod(0o555)
 artifacts[name]={'path':str(target),'compiler_output':str(source),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'file':subprocess.check_output(['file',str(target)],text=True).strip(),'cargo_package_id':row['package_id'],'profile':row['profile'],'features':row['features']}
assert len(artifacts)==3
manifest={'schema':'nudox.runtime-build-manifest.httpie-context.v1','source_commit':sha,'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=wt,text=True).strip(),'source_clean':True,'profile':'debug','target':'aarch64-apple-darwin','managed_build_receipt':receipt,'artifacts':artifacts,'meeting_release_candidate':False}
p=coord/'document-selection-d54f-debug-runtime-build-manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'manifest':str(p),'manifest_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'artifacts':{k:v['sha256'] for k,v in artifacts.items()}},indent=2))
