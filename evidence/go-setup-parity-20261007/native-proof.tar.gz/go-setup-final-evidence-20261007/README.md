# Go/setup scoped evidence — 2026-10-07

Final frozen source17e8a0f9a57a5f9b4c4ec576479c245562759989, tree2bdfc14b13bc8c83022db157bbaebd4a452632fe. Source proof and each receipt retain exact own source; counts are not relabelled to final source.

`index.json` records unique raw gate directories, exact source/tree/lock identities, scope, verdict and SHA256 for raw merged stdout/stderr (`cargo.log`), launch and retirement receipts. The raw receipts include whole-fleet v5 admission, actual argv, owning worktree, PID and owned kernel wait. All jobs remote ILO, own graph, Cargo j2; clean source is identical before/after each gate.

The final desktop module tests compile the public alias/reexport chain and exercise closed selection reports without ambient rediscovery or eager version probes. They are local-service integration tests importing exact production desktop toolchain.rs with a scratch-base fixture seam, not actual GPUI/native GUI/renderer acceptance.

The35 host tests ran on26ab, the official Debian frontend test on0c, and33-frontier PNPM recipe test on7c. Each has its own raw receipt. No whole CLI/MCP graph, native TypeScript semantic acceptance, cold restart, matched shipping binary cohort, broad platform support, or16GiB OOM guarantee is claimed by this archive.

Pinned application/config/runtime/frontier metadata is included. Supervisor/launcher source is included for reproducibility; realization paths in that harness are fixture-only and not embedded in product source.
