import argparse, datetime, fcntl, hashlib, json, os, pathlib, re, subprocess, time
p=argparse.ArgumentParser();p.add_argument('--label',choices=['engine','desktop','engine-sdk','engine-actual','desktop-actual','desktop-composition','desktop-composition-actual','go-debian','go-layout','go-links'],required=True);p.add_argument('--admission',required=True);p.add_argument('--out',required=True);a=p.parse_args()
wt=pathlib.Path('/root/codex-worktrees/sol61-go-setup-parity-20261007');out=pathlib.Path(a.out);out.mkdir(mode=0o700)
(wt/'.local').mkdir(exist_ok=True)
lock=open(wt/'.local/setup-owner.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity():
 def git(*args):return subprocess.check_output(['git','-C',str(wt),*args],text=True).strip()
 return {'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'clean':not git('status','--porcelain'),'lock_sha256':hashlib.sha256((wt/'Cargo.lock').read_bytes()).hexdigest()}
source=identity();assert source['commit']=='17e8a0f9a57a5f9b4c4ec576479c245562759989';assert source['clean']
fleet=json.loads(pathlib.Path(a.admission).read_text());now=datetime.datetime.now(datetime.timezone.utc)
assert fleet['advisory_allowed'] and all(h['complete'] for h in fleet['hosts'].values())
assert all(0<=(now-datetime.datetime.fromisoformat(h['resource_sampled_at_utc'])).total_seconds()<30 for h in fleet['hosts'].values())
assert fleet['current_fleet_compiler_group_count']<16 and fleet['hosts']['ilo']['compiler_group_count']<8
assert all(h['available_memory_bytes']>=8*1024**3 for h in fleet['hosts'].values());assert fleet['hosts']['ilo']['root_disk_available_bytes']>=16*1024**3
rust='/nix/store/lynmg3kdpdz41r84nafwzi2n5nss50pq-rust-1.97.1-with-components-2026-07-16/bin';tools='/nix/store/n4b80fmlzlmxx0584y7acwcnikk4k071-nudox-luna-tools-shell/bin'
env=dict(os.environ);env.update(PATH=tools+':'+rust+':/nix/store/5hndr36f8c9d9z305r27z6dxkhysng95-gnumake-4.4.1/bin:/run/current-system/sw/bin',CARGO_HOME='/root/.cargo',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',NUDOX_CARGO_BUILD_SLOTS='6',NUDOX_CARGO_SLOT_WAIT_MS='0',NUDOX_CARGO_WORKTREE_WAIT_MS='0',CARGO_TARGET_DIR=str(wt/'.local/target'),CARGO_BUILD_BUILD_DIR=str(wt/'.local/owned-build-role'),RUSTC=rust+'/rustc',CC=tools+'/cc',CXX=tools+'/c++',AR=tools+'/ar',LD=tools+'/ld',PKG_CONFIG=tools+'/pkg-config',LIBRARY_PATH='',NIX_LDFLAGS='',PKG_CONFIG_PATH='')
if a.label.endswith('-actual'):
 for variable in ['NUDOX_TSC','NUDOX_TYPESCRIPT_NODE','NUDOX_TYPESCRIPT_MODULE_ROOT','BACKEND_LOCALD_COMPILER_ENVIRONMENT','BACKEND_LOCALD_DEFAULT_TSC','BACKEND_LOCALD_DEFAULT_TYPESCRIPT_NODE','BACKEND_LOCALD_BUNDLED_TYPESCRIPT_NODE']:
  env.pop(variable,None)
 corpus=pathlib.Path('/root/setup-parity-corpus-20261007')
 env.update(HOME=str(corpus/'home'),PATH=str(corpus/'home/.local/bin')+':'+env['PATH'],NUDOX_SETUP_APPLICATION_ROOT=str(corpus/'application'),NUDOX_SETUP_SOURCE_FRONTIER=str(corpus/'original-frontier.txt'),NUDOX_SETUP_EXPECTED_GLOBAL_TSC=str(corpus/'home/.local/bin/tsc'),NUDOX_SETUP_EXPECTED_NODE=str(corpus/'home/.local/bin/node'))
if a.label == 'go-debian':
 env.update(NUDOX_GO_DEBIAN_FIXTURE_ROOT='/root/go-goroot-discovery-debian-20261007/rootfs')
 assert hashlib.sha256(pathlib.Path('/root/go-goroot-discovery-debian-20261007/rootfs/usr/lib/go-1.24/bin/go').read_bytes()).hexdigest()=='8992a5c41a8fefc6bd437117566ecb3f80ac89f78c009ccbb486fa6b9ba85d01'
package,focus={'go-debian':('backend-frontend-go','debian_packaged_go_root_identity_is_admitted_and_revalidates_on_private_root'),'go-layout':('backend-frontend-go','go_toolchain_identity_accepts_only_the_paired_debian_shared_root_layout'),'go-links':('backend-platform','bounded_link_target_reads_raw_text_without_following_or_truncating'),'engine':('backend-engine','application::host::'),'engine-sdk':('backend-engine','application::typescript_host::tests::'),'desktop':('backend-desktop','host::toolchain::tests::'),'desktop-composition':('backend-local-service','toolchain::tests::'),'desktop-composition-actual':('backend-local-service','toolchain::tests::actual_default_launch_matches_standalone_installed_tool_selection'),'engine-actual':('backend-engine','application::host::capture::tests::actual_project_sdk_precedes_the_frozen_installed_global_sdk'),'desktop-actual':('backend-desktop','host::toolchain::tests::actual_default_launch_matches_standalone_installed_tool_selection')}[a.label]
target=['--test','desktop_toolchain_composition'] if a.label.startswith('desktop-composition') else ['--lib']
argv=['/root/nudox-corpus-20261006/tool-recovery/cargo-wrapped-nix6','test','--locked','--offline','--release','-j2','-p',package]+target+[focus,'--','--test-threads=1','--nocapture']
if a.label.endswith('-actual'):argv+=['--ignored','--exact']
if a.label == 'go-debian':argv+=['--ignored']
receipt={'source_before':source,'started_utc':utc(),'argv':argv,'admission':fleet,'scope':'shared host capture unit regression, not product runtime acceptance'}
with (out/'cargo.log').open('wb') as log:
 child=subprocess.Popen(argv,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);receipt['pid']=child.pid;(out/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'pid':child.pid,'out':str(out),'source':source}),flush=True)
 receipt['exit']=child.wait()
receipt.update(source_after=identity(),ended_utc=utc(),retirement='owned-child-kernel-wait');assert receipt['source_before']==receipt['source_after']
receipt['test_results']=re.findall(r'test result: (?:ok|FAILED)\. [^\n]+',(out/'cargo.log').read_text())
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'out':str(out),'exit':receipt['exit'],'test_results':receipt['test_results']}),flush=True)
raise SystemExit(receipt['exit'])
