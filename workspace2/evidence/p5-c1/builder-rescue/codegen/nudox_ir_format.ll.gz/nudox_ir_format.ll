; ModuleID = 'nudox_ir_format.ee38cb3857691817-cgu.0'
source_filename = "nudox_ir_format.ee38cb3857691817-cgu.0"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx11.0.0"

@alloc_90b0c124cbead942e81c194f9359718c = private unnamed_addr constant [34 x i8] c"crates/nudox-ir-format/src/lib.rs\00", align 1
@alloc_0611a3819f108713fa59cc7802611973 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\AD\00\00\00\09\00\00\00" }>, align 8
@alloc_62b6299ca69b0a583a529f6bb988aa1c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\AE\00\00\00\09\00\00\00" }>, align 8
@alloc_0fa07ce451cc9ac4715bf2541902e684 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\AF\00\00\00\09\00\00\00" }>, align 8
@alloc_ddeee4e4aa2d94a455292d99dfb02ab1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\B0\00\00\00\09\00\00\00" }>, align 8
@alloc_f5c7735809a7524a1ffce31e3fe22b90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\B3\00\00\00\14\00\00\00" }>, align 8
@alloc_07912206504fa53ae9562501d367c105 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\B7\00\00\00\14\00\00\00" }>, align 8

; <nudox_ir_format::PreparedFragment>::write_into
; Function Attrs: uwtable
define void @_RNvMs0_Csks33AUGQlhz_15nudox_ir_formatNtB5_16PreparedFragment10write_into(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, ptr noalias noundef nonnull %output.0, i64 noundef range(i64 0, -9223372036854775808) %output.1) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_5 = load i64, ptr %0, align 8, !noundef !2
  %_3 = icmp ult i64 %output.1, %_5
  br i1 %_3, label %bb1, label %bb10

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_5, ptr %1, align 8
  br label %bb9

bb10:                                             ; preds = %start
  %_8.not = icmp eq i64 %_5, 0
  br i1 %_8.not, label %panic, label %bb3

bb3:                                              ; preds = %bb10
  store i8 -63, ptr %output.0, align 1
  %_9.not = icmp eq i64 %_5, 1
  br i1 %_9.not, label %panic2, label %bb4

panic:                                            ; preds = %bb10
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 0, i64 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0611a3819f108713fa59cc7802611973) #4
  unreachable

bb4:                                              ; preds = %bb3
  %2 = getelementptr inbounds nuw i8, ptr %output.0, i64 1
  store i8 1, ptr %2, align 1
  %_11 = icmp samesign ugt i64 %_5, 2
  br i1 %_11, label %bb5, label %panic3

panic2:                                           ; preds = %bb3
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 1, i64 noundef 1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_62b6299ca69b0a583a529f6bb988aa1c) #4
  unreachable

bb5:                                              ; preds = %bb4
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_10 = load i8, ptr %3, align 8, !noundef !2
  %4 = getelementptr inbounds nuw i8, ptr %output.0, i64 2
  store i8 %_10, ptr %4, align 1
  %_13.not = icmp eq i64 %_5, 3
  br i1 %_13.not, label %panic4, label %bb6

panic3:                                           ; preds = %bb4
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 2, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0fa07ce451cc9ac4715bf2541902e684) #4
  unreachable

bb6:                                              ; preds = %bb5
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 41
  %_12 = load i8, ptr %5, align 1, !noundef !2
  %6 = getelementptr inbounds nuw i8, ptr %output.0, i64 3
  store i8 %_12, ptr %6, align 1
  %_16.0 = load ptr, ptr %self, align 8, !nonnull !2, !align !3, !noundef !2
  %7 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_16.1 = load i64, ptr %7, align 8, !noundef !2
  %_52.idx = shl nuw nsw i64 %_16.1, 2
  %_52 = getelementptr inbounds nuw i8, ptr %_16.0, i64 %_52.idx
  %_5913 = icmp eq i64 %_16.1, 0
  br i1 %_5913, label %bb14, label %bb15

panic4:                                           ; preds = %bb5
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 3, i64 noundef 3, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ddeee4e4aa2d94a455292d99dfb02ab1) #4
  unreachable

bb15:                                             ; preds = %bb6, %bb16
  %cursor.sroa.0.015 = phi i64 [ %_22, %bb16 ], [ 4, %bb6 ]
  %iter.sroa.0.014 = phi ptr [ %_65, %bb16 ], [ %_16.0, %bb6 ]
  %_22 = add i64 %cursor.sroa.0.015, 4
  %8 = or disjoint i64 %cursor.sroa.0.015, 3
  %or.cond.not = icmp ult i64 %8, %_5
  br i1 %or.cond.not, label %bb16, label %bb17, !prof !4

bb14:                                             ; preds = %bb16, %bb6
  %cursor.sroa.0.0.lcssa = phi i64 [ 4, %bb6 ], [ %_22, %bb16 ]
  %9 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_29.0 = load ptr, ptr %9, align 8, !nonnull !2, !align !3, !noundef !2
  %10 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %_29.1 = load i64, ptr %10, align 8, !noundef !2
  %_79.idx = shl nuw nsw i64 %_29.1, 2
  %_79 = getelementptr inbounds nuw i8, ptr %_29.0, i64 %_79.idx
  %_8616 = icmp eq i64 %_29.1, 0
  br i1 %_8616, label %bb21, label %bb22

bb17:                                             ; preds = %bb15
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef %cursor.sroa.0.015, i64 noundef %_22, i64 noundef %_5, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f5c7735809a7524a1ffce31e3fe22b90) #4
  unreachable

bb16:                                             ; preds = %bb15
  %_65 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.014, i64 4
  %_74 = getelementptr inbounds nuw i8, ptr %output.0, i64 %cursor.sroa.0.015
  %_27 = load i32, ptr %iter.sroa.0.014, align 4, !noundef !2
  store i32 %_27, ptr %_74, align 1, !alias.scope !5
  %_59 = icmp eq ptr %_65, %_52
  br i1 %_59, label %bb14, label %bb15

bb22:                                             ; preds = %bb14, %bb23
  %cursor.sroa.0.118 = phi i64 [ %_35, %bb23 ], [ %cursor.sroa.0.0.lcssa, %bb14 ]
  %iter1.sroa.0.017 = phi ptr [ %_92, %bb23 ], [ %_29.0, %bb14 ]
  %_35 = add i64 %cursor.sroa.0.118, 4
  %11 = or disjoint i64 %cursor.sroa.0.118, 3
  %or.cond10.not = icmp ult i64 %11, %_5
  br i1 %or.cond10.not, label %bb23, label %bb24, !prof !4

bb21:                                             ; preds = %bb23, %bb14
  %12 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %output.0, ptr %12, align 8
  br label %bb9

bb24:                                             ; preds = %bb22
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef %cursor.sroa.0.118, i64 noundef %_35, i64 noundef %_5, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_07912206504fa53ae9562501d367c105) #4
  unreachable

bb23:                                             ; preds = %bb22
  %_92 = getelementptr inbounds nuw i8, ptr %iter1.sroa.0.017, i64 4
  %_101 = getelementptr inbounds nuw i8, ptr %output.0, i64 %cursor.sroa.0.118
  %_40 = load i32, ptr %iter1.sroa.0.017, align 4, !noundef !2
  store i32 %_40, ptr %_101, align 1, !alias.scope !8
  %_86 = icmp eq ptr %_92, %_79
  br i1 %_86, label %bb21, label %bb22

bb9:                                              ; preds = %bb1, %bb21
  %output.1.sink = phi i64 [ %output.1, %bb1 ], [ %_5, %bb21 ]
  %storemerge = phi i64 [ 1, %bb1 ], [ 0, %bb21 ]
  %13 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %output.1.sink, ptr %13, align 8
  store i64 %storemerge, ptr %_0, align 8
  ret void
}

; <nudox_ir_format::FragmentView>::validate
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define void @_RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) initializes((0, 9)) %_0, ptr noalias noundef nonnull readonly captures(address, read_provenance) %envelope.0, i64 noundef range(i64 0, -9223372036854775808) %envelope.1) unnamed_addr #1 {
start:
  %_2 = icmp samesign ult i64 %envelope.1, 4
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_5 = load i8, ptr %envelope.0, align 1, !noundef !2
  %0 = icmp eq i8 %_5, -63
  br i1 %0, label %bb7, label %bb5

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 0, ptr %1, align 8
  %_4.sroa.46.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %envelope.1, ptr %_4.sroa.46.0..sroa_idx, align 8
  store ptr null, ptr %_0, align 8
  br label %bb21

bb7:                                              ; preds = %bb2
  %2 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 1
  %_8 = load i8, ptr %2, align 1, !noundef !2
  %3 = icmp eq i8 %_8, 1
  br i1 %3, label %bb11, label %bb9

bb11:                                             ; preds = %bb7
  %4 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 2
  %entity_count = load i8, ptr %4, align 1, !noundef !2
  %_13 = icmp ugt i8 %entity_count, 2
  br i1 %_13, label %bb12, label %bb14

bb12:                                             ; preds = %bb11
  %5 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 3, ptr %5, align 8
  %_14.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 %entity_count, ptr %_14.sroa.4.0..sroa_idx, align 1
  store ptr null, ptr %_0, align 8
  br label %bb21

bb14:                                             ; preds = %bb11
  %6 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 3
  %type_count = load i8, ptr %6, align 1, !noundef !2
  %_17 = icmp ugt i8 %type_count, 2
  br i1 %_17, label %bb15, label %bb16

bb16:                                             ; preds = %bb14
  %7 = shl nuw nsw i8 %entity_count, 2
  %_20 = zext nneg i8 %7 to i64
  %entity_end = add nuw nsw i64 %_20, 4
  %8 = shl nuw nsw i8 %type_count, 2
  %_23 = zext nneg i8 %8 to i64
  %expected = add nuw nsw i64 %entity_end, %_23
  %_25.not = icmp eq i64 %envelope.1, %expected
  br i1 %_25.not, label %bb22, label %bb17

bb15:                                             ; preds = %bb14
  %9 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 4, ptr %9, align 8
  %_18.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 %type_count, ptr %_18.sroa.4.0..sroa_idx, align 1
  store ptr null, ptr %_0, align 8
  br label %bb21

bb17:                                             ; preds = %bb16
  %10 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 5, ptr %10, align 8
  %_26.sroa.47.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %expected, ptr %_26.sroa.47.0..sroa_idx, align 8
  %_26.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %envelope.1, ptr %_26.sroa.5.0..sroa_idx, align 8
  store ptr null, ptr %_0, align 8
  br label %bb21

bb22:                                             ; preds = %bb16
  %_37 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 4
  %_40 = sub nuw nsw i64 %envelope.1, %entity_end
  %_44 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 %entity_end
  store ptr %envelope.0, ptr %_0, align 8
  %_27.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %envelope.1, ptr %_27.sroa.4.0._0.sroa_idx, align 8
  %_27.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store ptr %_37, ptr %_27.sroa.5.0._0.sroa_idx, align 8
  %_27.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %_20, ptr %_27.sroa.6.0._0.sroa_idx, align 8
  %_27.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store ptr %_44, ptr %_27.sroa.7.0._0.sroa_idx, align 8
  %_27.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40
  store i64 %_40, ptr %_27.sroa.8.0._0.sroa_idx, align 8
  br label %bb21

bb21:                                             ; preds = %bb12, %bb15, %bb17, %bb1, %bb5, %bb9, %bb22
  ret void

bb9:                                              ; preds = %bb7
  %11 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 2, ptr %11, align 8
  %_10.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 %_8, ptr %_10.sroa.4.0..sroa_idx, align 1
  store ptr null, ptr %_0, align 8
  br label %bb21

bb5:                                              ; preds = %bb2
  %12 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 1, ptr %12, align 8
  %_7.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 %_5, ptr %_7.sroa.4.0..sroa_idx, align 1
  store ptr null, ptr %_0, align 8
  br label %bb21
}

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #2

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef, i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #3

attributes #0 = { uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #2 = { cold minsize noinline noreturn optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #3 = { cold noinline noreturn uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{!"rustc version 1.97.1 (8bab26f4f 2026-07-14)"}
!2 = !{}
!3 = !{i64 4}
!4 = !{!"branch_weights", i32 4000000, i32 4001}
!5 = !{!6}
!6 = distinct !{!6, !7, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECsks33AUGQlhz_15nudox_ir_format: %dest.0"}
!7 = distinct !{!7, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECsks33AUGQlhz_15nudox_ir_format"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECsks33AUGQlhz_15nudox_ir_format: %dest.0"}
!10 = distinct !{!10, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECsks33AUGQlhz_15nudox_ir_format"}
