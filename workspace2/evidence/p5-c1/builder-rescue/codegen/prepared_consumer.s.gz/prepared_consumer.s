	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	stp	x22, x21, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x20, x19, [sp, #16]
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	sub	x10, x5, #1
	ldr	x16, [x1, #32]
	add	x9, x10, x16
	cmp	x9, x3
	b.hs	LBB0_18
	ldr	x11, [x1]
	ldp	x13, x12, [x1, #16]
	ldr	x15, [x1, #48]
	neg	x14, x11
	b	LBB0_4
LBB0_2:
	str	x9, [x1, #48]
	mov	x15, x9
LBB0_3:
	add	x9, x10, x8
	cmp	x9, x3
	mov	x16, x8
	b.hs	LBB0_18
LBB0_4:
	ldrb	w8, [x2, x9]
	lsr	x8, x12, x8
	tbz	w8, #0, LBB0_10
	cmp	x15, x11
	csel	x8, x15, x11, hi
	cmp	w6, #0
	csel	x9, x11, x8, ne
	add	x17, x9, x16
	add	x8, x17, x14
	add	x7, x4, x9
	subs	x19, x5, x9
	csel	x19, xzr, x19, lo
LBB0_6:
	cbz	x19, LBB0_12
	cmp	x17, x3
	b.hs	LBB0_23
	ldrb	w20, [x7], #1
	ldrb	w21, [x2, x17]
	add	x8, x8, #1
	add	x17, x17, #1
	sub	x19, x19, #1
	cmp	w20, w21
	b.eq	LBB0_6
	str	x8, [x1, #32]
	tbnz	w6, #0, LBB0_3
	b	LBB0_11
LBB0_10:
	add	x8, x16, x5
	str	x8, [x1, #32]
	tbnz	w6, #0, LBB0_3
LBB0_11:
	mov	x9, #0
	b	LBB0_2
LBB0_12:
	cmp	w6, #0
	csel	x17, xzr, x15, ne
	mov	x8, x11
LBB0_13:
	cmp	x17, x8
	b.hs	LBB0_19
	sub	x8, x8, #1
	cmp	x8, x5
	b.hs	LBB0_25
	add	x9, x8, x16
	cmp	x9, x3
	b.hs	LBB0_24
	ldrb	w7, [x4, x8]
	ldrb	w9, [x2, x9]
	cmp	w7, w9
	b.eq	LBB0_13
	add	x8, x13, x16
	str	x8, [x1, #32]
	sub	x9, x5, x13
	tbz	w6, #0, LBB0_2
	b	LBB0_3
LBB0_18:
	mov	x8, #0
	str	x3, [x1, #32]
	b	LBB0_22
LBB0_19:
	add	x8, x16, x5
	str	x8, [x1, #32]
	tbnz	w6, #0, LBB0_21
	str	xzr, [x1, #48]
LBB0_21:
	stp	x16, x8, [x0, #8]
	mov	w8, #1
LBB0_22:
	str	x8, [x0]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB0_23:
	.cfi_restore_state
	add	x8, x9, x16
	cmp	x3, x8
	csel	x0, x3, x8, hi
Lloh0:
	adrp	x2, l_alloc_8ae9795802ad53c9398ce2776784dbc3@PAGE
Lloh1:
	add	x2, x2, l_alloc_8ae9795802ad53c9398ce2776784dbc3@PAGEOFF
	mov	x1, x3
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB0_24:
Lloh2:
	adrp	x2, l_alloc_8deac4fa778727f9c004a28bc20bcda6@PAGE
Lloh3:
	add	x2, x2, l_alloc_8deac4fa778727f9c004a28bc20bcda6@PAGEOFF
	mov	x0, x9
	mov	x1, x3
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB0_25:
Lloh4:
	adrp	x2, l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2@PAGE
Lloh5:
	add	x2, x2, l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2@PAGEOFF
	mov	x0, x8
	mov	x1, x5
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc

	.private_extern	__RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs21ATSyVuzIl_17prepared_consumer
	.globl	__RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs21ATSyVuzIl_17prepared_consumer
	.p2align	2
__RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x4, x3
	mov	x3, x2
	mov	x2, x1
	str	x0, [sp, #8]
Lloh6:
	adrp	x1, l_vtable.1@PAGE
Lloh7:
	add	x1, x1, l_vtable.1@PAGEOFF
	add	x0, sp, #8
	bl	__RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc

	.p2align	2
__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedAhj17_BL_ECs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	x0, x1, [sp]
Lloh8:
	adrp	x2, l_vtable.2@PAGE
Lloh9:
	add	x2, x2, l_vtable.2@PAGEOFF
Lloh10:
	adrp	x7, l_alloc_cb00222c11a9560fc2db0458e2b363a2@PAGE
Lloh11:
	add	x7, x7, l_alloc_cb00222c11a9560fc2db0458e2b363a2@PAGEOFF
	bl	_OUTLINED_FUNCTION_0
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc

	.p2align	2
__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedINtNtB4_6result6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorEBL_EB1a_:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	x0, x1, [sp]
Lloh12:
	adrp	x2, l_vtable.3@PAGE
Lloh13:
	add	x2, x2, l_vtable.3@PAGEOFF
Lloh14:
	adrp	x7, l_alloc_16613a034bc3772cbb719c5113a258a5@PAGE
Lloh15:
	add	x7, x7, l_alloc_16613a034bc3772cbb719c5113a258a5@PAGEOFF
	bl	_OUTLINED_FUNCTION_0
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc

	.p2align	2
__RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	blr	x0
	; InlineAsm Start
	; InlineAsm End
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs21ATSyVuzIl_17prepared_consumer
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs21ATSyVuzIl_17prepared_consumer
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent:
	.cfi_startproc
	sub	sp, sp, #160
	.cfi_def_cfa_offset 160
	stp	x24, x23, [sp, #96]
	stp	x22, x21, [sp, #112]
	stp	x20, x19, [sp, #128]
	stp	x29, x30, [sp, #144]
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x19, x4
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x23, x0
	mov	x8, #4919131752989213764
	eor	x8, x8, #0xe1e1e1e1e1e1e1e1
	stur	x8, [sp, #15]
	stp	x8, x8, [sp]
	stur	x8, [sp, #39]
	stp	x8, x8, [sp, #24]
	stp	x0, x1, [sp, #72]
	add	x8, sp, #72
	; InlineAsm Start
	; InlineAsm End
	ldp	x1, x2, [sp, #72]
	stp	x21, x3, [sp, #72]
	add	x8, sp, #72
	; InlineAsm Start
	; InlineAsm End
	ldp	x3, x4, [sp, #72]
	mov	x8, sp
	stp	x8, x19, [sp, #72]
	add	x8, sp, #72
	; InlineAsm Start
	; InlineAsm End
	ldp	x5, x6, [sp, #72]
	add	x0, sp, #48
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer23prepared_whole_consumer
	stp	x23, x22, [sp, #72]
	add	x8, sp, #72
	; InlineAsm Start
	; InlineAsm End
	ldp	x1, x2, [sp, #72]
	stp	x21, x20, [sp, #72]
	add	x8, sp, #72
	; InlineAsm Start
	; InlineAsm End
	ldp	x3, x4, [sp, #72]
	add	x8, sp, #24
	stp	x8, x19, [sp, #72]
	add	x8, sp, #72
	; InlineAsm Start
	; InlineAsm End
	ldp	x5, x6, [sp, #72]
	add	x0, sp, #72
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer26manual_single_pass_control
	ldrb	w8, [sp, #48]
	cmp	w8, #255
	cset	w10, ne
	ldrb	w9, [sp, #72]
	cmp	w9, #255
	cset	w11, eq
	cmp	w10, w11
	b.eq	LBB7_17
	cmp	w8, #255
	b.eq	LBB7_11
	sub	w10, w8, #6
	mov	w11, #2
	cmp	w8, #5
	csel	w10, w10, w11, hi
	and	w12, w10, #0xff
	sub	w13, w9, #6
	cmp	w9, #5
	csel	w11, w13, w11, hi
	cmp	w12, w11, uxtb
	b.ne	LBB7_17
	ands	w10, w10, #0xff
	b.eq	LBB7_5
	cmp	w10, #1
	b.ne	LBB7_7
LBB7_5:
	ldr	x8, [sp, #56]
	ldr	x9, [sp, #80]
	cmp	x8, x9
	b.ne	LBB7_17
	ldr	x8, [sp, #64]
	ldr	x9, [sp, #88]
	cmp	x8, x9
	b.eq	LBB7_12
	b	LBB7_17
LBB7_7:
	cmp	w8, w9
	b.ne	LBB7_17
	cmp	w8, #2
	b.gt	LBB7_14
	cbz	w8, LBB7_11
	cmp	w8, #1
	b	LBB7_16
LBB7_11:
	ldr	x8, [sp, #56]
	ldr	x9, [sp, #80]
	cmp	x8, x9
	b.ne	LBB7_17
LBB7_12:
	ldp	x8, x9, [sp]
	ldp	x10, x11, [sp, #24]
	ldur	x12, [sp, #15]
	ldur	x13, [sp, #39]
	cmp	x8, x10
	ccmp	x9, x11, #0, eq
	ccmp	x12, x13, #0, eq
	b.ne	LBB7_18
	.cfi_def_cfa wsp, 160
	ldp	x29, x30, [sp, #144]
	ldp	x20, x19, [sp, #128]
	ldp	x22, x21, [sp, #112]
	ldp	x24, x23, [sp, #96]
	add	sp, sp, #160
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB7_14:
	.cfi_restore_state
	cmp	w8, #3
	b.eq	LBB7_16
	cmp	w8, #4
	b.ne	LBB7_5
LBB7_16:
	ldrb	w8, [sp, #49]
	ldrb	w9, [sp, #73]
	cmp	w8, w9
	b.eq	LBB7_12
LBB7_17:
	add	x0, sp, #48
	add	x1, sp, #72
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedINtNtB4_6result6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorEBL_EB1a_
LBB7_18:
	mov	x0, sp
	add	x1, sp, #24
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedAhj17_BL_ECs21ATSyVuzIl_17prepared_consumer
	.cfi_endproc

	.p2align	2
__RNvCs21ATSyVuzIl_17prepared_consumer23prepared_whole_consumer:
	.cfi_startproc
	cmp	x2, #255
	b.ls	LBB8_2
	mov	x8, #0
	mov	w9, #6
	strb	w9, [x0]
	stp	x8, x2, [x0, #8]
	ret
LBB8_2:
	cmp	x2, #2
	b.ls	LBB8_4
	mov	x8, #0
	mov	w9, #6
	strb	w9, [x0]
	stp	x8, x2, [x0, #8]
	ret
LBB8_4:
	cmp	x4, #3
	b.lo	LBB8_6
	mov	w8, #1
	mov	w9, #6
	strb	w9, [x0]
	stp	x8, x4, [x0, #8]
	ret
LBB8_6:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x20, x19, [sp, #96]
	stp	x29, x30, [sp, #112]
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x8, x4, x2
	lsl	x8, x8, #2
	add	x8, x8, #4
	stp	x1, x2, [sp]
	stp	x3, x4, [sp, #16]
	str	x8, [sp, #32]
	strb	w2, [sp, #40]
	strb	w4, [sp, #41]
	add	x8, sp, #48
	mov	x0, sp
	mov	x1, x5
	mov	x2, x6
	bl	__RNvMs0_Csks33AUGQlhz_15nudox_ir_formatNtB5_16PreparedFragment10write_into
	ldr	x8, [sp, #48]
	ldr	x1, [sp, #64]
	cmp	x8, #1
	b.ne	LBB8_8
	ldr	x8, [sp, #56]
	mov	w9, #7
	strb	w9, [x19]
	stp	x8, x1, [x19, #8]
	b	LBB8_11
LBB8_8:
	ldr	x0, [sp, #56]
	add	x8, sp, #48
	bl	__RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate
	ldr	x8, [sp, #48]
	cbz	x8, LBB8_10
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #88]
	sub	x10, x8, #4
	lsr	x10, x10, #2
	cmp	x8, #3
	csinc	x8, xzr, x10, ls
	sub	x10, x9, #4
	lsr	x10, x10, #2
	cmp	x9, #3
	csinc	x9, xzr, x10, ls
	add	x8, x9, x8
	str	x8, [x19, #8]
	mov	w8, #255
	strb	w8, [x19]
	b	LBB8_11
LBB8_10:
	ldur	q0, [sp, #56]
	str	q0, [x19]
	ldr	x8, [sp, #72]
	str	x8, [x19, #16]
LBB8_11:
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]
	ldp	x20, x19, [sp, #96]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.cfi_endproc

	.p2align	2
__RNvCs21ATSyVuzIl_17prepared_consumer26manual_single_pass_control:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	cmp	x2, #255
	b.hi	LBB9_2
	cmp	x2, #2
	b.ls	LBB9_4
LBB9_2:
	mov	w8, #6
	strb	w8, [x0]
	stp	xzr, x2, [x0, #8]
LBB9_3:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
LBB9_4:
	.cfi_restore_state
	cmp	x4, #255
	b.hi	LBB9_6
	cmp	x4, #2
	b.ls	LBB9_7
LBB9_6:
	mov	w8, #6
	strb	w8, [x0]
	mov	w8, #1
	stp	x8, x4, [x0, #8]
	b	LBB9_3
LBB9_7:
	mov	x8, x1
	add	x9, x4, x2
	lsl	x10, x9, #2
	add	x1, x10, #4
	cmp	x6, x1
	b.hs	LBB9_9
	mov	w8, #7
	strb	w8, [x0]
	stp	x1, x6, [x0, #8]
	b	LBB9_3
LBB9_9:
	mov	w10, #449
	strh	w10, [x5]
	strb	w2, [x5, #2]
	strb	w4, [x5, #3]
	cbz	x2, LBB9_12
	ldr	w10, [x8]
	str	w10, [x5, #4]
	cmp	x2, #1
	b.ne	LBB9_13
	mov	w11, #8
	b	LBB9_15
LBB9_12:
	mov	w11, #4
	b	LBB9_15
LBB9_13:
	cmp	x9, #2
	b.lo	LBB9_27
	ldr	w8, [x8, #4]
	str	w8, [x5, #8]
	mov	w11, #12
LBB9_15:
	cbz	x4, LBB9_23
	lsl	x10, x4, #2
	add	x8, x11, #3
	cmp	x1, x8
	csel	x8, x1, x8, hi
	sub	x8, x8, x11
	lsr	x8, x8, #2
	sub	x9, x10, #4
	lsr	x9, x9, #2
	cmp	x8, x9
	csel	x12, x8, x9, lo
	cmp	x12, #15
	b.hi	LBB9_18
	mov	x9, x3
	mov	x8, x11
	b	LBB9_20
LBB9_18:
	add	x8, x12, #1
	ands	x9, x8, #0xf
	mov	w13, #16
	csel	x13, x13, x9, eq
	sub	x8, x8, x13
	lsl	x8, x8, #2
	add	x9, x3, x8
	add	x8, x11, x8
	mvn	x12, x12
	add	x12, x12, x13
	add	x13, x3, #32
	add	x11, x11, x5
	add	x11, x11, #32
LBB9_19:
	ldp	q0, q1, [x13, #-32]
	ldp	q2, q3, [x13], #64
	stp	q0, q1, [x11, #-32]
	stp	q2, q3, [x11], #64
	adds	x12, x12, #16
	b.ne	LBB9_19
LBB9_20:
	add	x10, x3, x10
LBB9_21:
	add	x11, x8, #3
	cmp	x11, x1
	b.hs	LBB9_26
	ldr	w11, [x9], #4
	str	w11, [x5, x8]
	add	x8, x8, #4
	cmp	x9, x10
	b.ne	LBB9_21
LBB9_23:
	mov	x19, x0
	mov	x8, sp
	mov	x0, x5
	bl	__RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate
	ldr	x8, [sp]
	cbz	x8, LBB9_25
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #40]
	sub	x10, x8, #4
	lsr	x10, x10, #2
	cmp	x8, #3
	csinc	x8, xzr, x10, ls
	sub	x10, x9, #4
	lsr	x10, x10, #2
	cmp	x9, #3
	csinc	x9, xzr, x10, ls
	add	x8, x9, x8
	str	x8, [x19, #8]
	mov	w8, #255
	strb	w8, [x19]
	b	LBB9_3
LBB9_25:
	ldur	q0, [sp, #8]
	str	q0, [x19]
	ldr	x8, [sp, #24]
	str	x8, [x19, #16]
	b	LBB9_3
LBB9_26:
Lloh16:
	adrp	x3, l_alloc_0d19906a6b3022c81c70f9413c97b8e2@PAGE
Lloh17:
	add	x3, x3, l_alloc_0d19906a6b3022c81c70f9413c97b8e2@PAGEOFF
	mov	x2, x1
	add	x1, x8, #4
	mov	x0, x8
	bl	__RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail
LBB9_27:
Lloh18:
	adrp	x3, l_alloc_d3c0ed059c64d66bf64704809ec4db02@PAGE
Lloh19:
	add	x3, x3, l_alloc_d3c0ed059c64d66bf64704809ec4db02@PAGEOFF
	mov	w0, #8
	mov	x2, x1
	mov	w1, #12
	bl	__RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.cfi_endproc

	.private_extern	__RNvCs21ATSyVuzIl_17prepared_consumer4main
	.globl	__RNvCs21ATSyVuzIl_17prepared_consumer4main
	.p2align	2
__RNvCs21ATSyVuzIl_17prepared_consumer4main:
	.cfi_startproc
Lloh20:
	adrp	x0, l_alloc_e68e146f22cb2d0b878fb86e4e6fa8ea@PAGE
Lloh21:
	add	x0, x0, l_alloc_e68e146f22cb2d0b878fb86e4e6fa8ea@PAGEOFF
	mov	w1, #1
	b	__RNvCs3O4ZRUMviTO_4test16test_main_static
	.loh AdrpAdd	Lloh20, Lloh21
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRAhj17_NtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x20, x19, [sp, #32]
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x20, [x0]
	add	x8, sp, #8
	mov	x0, x1
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter10debug_list
	str	x20, [sp, #24]
Lloh22:
	adrp	x19, l_vtable.0@PAGE
Lloh23:
	add	x19, x19, l_vtable.0@PAGEOFF
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #1
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #2
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #3
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #4
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #5
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #6
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #7
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #8
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #9
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #10
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #11
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #12
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #13
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #14
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #15
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #16
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #17
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #18
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #19
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #20
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #21
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #22
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x0, sp, #8
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList6finish
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.loh AdrpAdd	Lloh22, Lloh23
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6result6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtB6_5Debug3fmtBU_:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w10, [x9]
	cmp	w10, #255
	b.eq	LBB12_2
	str	x9, [sp, #8]
Lloh24:
	adrp	x1, l_alloc_bf301217d548e4f1fd13189dd935c554@PAGE
Lloh25:
	add	x1, x1, l_alloc_bf301217d548e4f1fd13189dd935c554@PAGEOFF
Lloh26:
	adrp	x4, l_vtable.9@PAGE
Lloh27:
	add	x4, x4, l_vtable.9@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #3
	b	LBB12_3
LBB12_2:
	add	x9, x9, #8
	str	x9, [sp, #8]
Lloh28:
	adrp	x1, l_alloc_c73d17da7498663a071b898ac2218935@PAGE
Lloh29:
	add	x1, x1, l_alloc_c73d17da7498663a071b898ac2218935@PAGEOFF
Lloh30:
	adrp	x4, l_vtable.7@PAGE
Lloh31:
	add	x4, x4, l_vtable.7@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #2
LBB12_3:
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh28, Lloh29
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorNtB6_5Debug3fmtBx_:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w10, [x9]
	sub	w11, w10, #6
	mov	w12, #2
	cmp	w10, #5
	csel	w10, w11, w12, hi
	ands	w10, w10, #0xff
	b.eq	LBB13_3
	cmp	w10, #1
	b.ne	LBB13_4
	add	x9, x9, #8
	str	x9, [sp, #8]
Lloh32:
	adrp	x1, l_alloc_6b7483292c41e5f1002b8b441a63be1a@PAGE
Lloh33:
	add	x1, x1, l_alloc_6b7483292c41e5f1002b8b441a63be1a@PAGEOFF
Lloh34:
	adrp	x4, l_vtable.5@PAGE
Lloh35:
	add	x4, x4, l_vtable.5@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #5
	b	LBB13_5
LBB13_3:
	add	x9, x9, #8
	str	x9, [sp, #8]
Lloh36:
	adrp	x1, l_alloc_ff99525767786baa5dc7e956e06d005e@PAGE
Lloh37:
	add	x1, x1, l_alloc_ff99525767786baa5dc7e956e06d005e@PAGEOFF
Lloh38:
	adrp	x4, l_vtable.4@PAGE
Lloh39:
	add	x4, x4, l_vtable.4@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #7
	b	LBB13_5
LBB13_4:
	str	x9, [sp, #8]
Lloh40:
	adrp	x1, l_alloc_9734c9124d3f60537957ec8c47f6ebf4@PAGE
Lloh41:
	add	x1, x1, l_alloc_9734c9124d3f60537957ec8c47f6ebf4@PAGEOFF
Lloh42:
	adrp	x4, l_vtable.6@PAGE
Lloh43:
	add	x4, x4, l_vtable.6@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #8
LBB13_5:
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh40, Lloh41
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format10WriteErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x5, [x0]
	add	x9, x5, #8
	stur	x9, [x29, #-8]
Lloh44:
	adrp	x9, l_vtable.7@PAGE
Lloh45:
	add	x11, x9, l_vtable.7@PAGEOFF
	sub	x9, x29, #8
	mov	w10, #9
	stp	x9, x11, [sp, #8]
	str	x10, [sp]
Lloh46:
	adrp	x1, l_alloc_5ab5ad54a633166dad8479b7b463c0d3@PAGE
Lloh47:
	add	x1, x1, l_alloc_5ab5ad54a633166dad8479b7b463c0d3@PAGEOFF
Lloh48:
	adrp	x3, l_alloc_715ad17152b7a3dfcbb2abff840befeb@PAGE
Lloh49:
	add	x3, x3, l_alloc_715ad17152b7a3dfcbb2abff840befeb@PAGEOFF
Lloh50:
	adrp	x6, l_vtable.8@PAGE
Lloh51:
	add	x6, x6, l_vtable.8@PAGEOFF
Lloh52:
	adrp	x7, l_alloc_700d5d683c25860e3d40207214c9c99c@PAGE
Lloh53:
	add	x7, x7, l_alloc_700d5d683c25860e3d40207214c9c99c@PAGEOFF
	mov	x0, x8
	mov	w2, #14
	mov	w4, #8
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh44, Lloh45
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format12PrepareErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x9, [x0]
	ldr	x10, [x9], #8
	cmp	x10, #1
	b.ne	LBB15_2
	str	x9, [sp, #8]
Lloh54:
	adrp	x1, l_alloc_b5a34892e83b03f9728fdba51e681f6f@PAGE
Lloh55:
	add	x1, x1, l_alloc_b5a34892e83b03f9728fdba51e681f6f@PAGEOFF
Lloh56:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh57:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh58:
	adrp	x6, l_vtable.7@PAGE
Lloh59:
	add	x6, x6, l_vtable.7@PAGEOFF
	add	x5, sp, #8
	mov	x0, x8
	mov	w2, #9
	b	LBB15_3
LBB15_2:
	str	x9, [sp, #8]
Lloh60:
	adrp	x1, l_alloc_c904b8fe89a4f835804b02bd44018d9c@PAGE
Lloh61:
	add	x1, x1, l_alloc_c904b8fe89a4f835804b02bd44018d9c@PAGEOFF
Lloh62:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh63:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh64:
	adrp	x6, l_vtable.7@PAGE
Lloh65:
	add	x6, x6, l_vtable.7@PAGEOFF
	add	x5, sp, #8
	mov	x0, x8
	mov	w2, #11
LBB15_3:
	mov	w4, #6
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh60, Lloh61
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format13FragmentErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w10, [x9]
	cmp	w10, #2
	b.gt	LBB16_4
	cbz	w10, LBB16_7
	add	x9, x9, #1
	cmp	w10, #1
	b.ne	LBB16_9
	stur	x9, [x29, #-8]
Lloh66:
	adrp	x1, l_alloc_d7b9b6c1829de9592f5bc6e83c4fc424@PAGE
Lloh67:
	add	x1, x1, l_alloc_d7b9b6c1829de9592f5bc6e83c4fc424@PAGEOFF
Lloh68:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh69:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh70:
	adrp	x6, l_vtable.0@PAGE
Lloh71:
	add	x6, x6, l_vtable.0@PAGEOFF
	sub	x5, x29, #8
	mov	x0, x8
	mov	w2, #5
	b	LBB16_10
LBB16_4:
	cmp	w10, #3
	b.eq	LBB16_8
	cmp	w10, #4
	b.ne	LBB16_12
	add	x9, x9, #1
	stur	x9, [x29, #-8]
Lloh72:
	adrp	x1, l_alloc_b5a34892e83b03f9728fdba51e681f6f@PAGE
Lloh73:
	add	x1, x1, l_alloc_b5a34892e83b03f9728fdba51e681f6f@PAGEOFF
Lloh74:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh75:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh76:
	adrp	x6, l_vtable.0@PAGE
Lloh77:
	add	x6, x6, l_vtable.0@PAGEOFF
	sub	x5, x29, #8
	mov	x0, x8
	mov	w2, #9
	b	LBB16_10
LBB16_7:
	add	x9, x9, #8
	stur	x9, [x29, #-8]
Lloh78:
	adrp	x1, l_alloc_ea8e8baf0be5855bbef17ce48226036b@PAGE
Lloh79:
	add	x1, x1, l_alloc_ea8e8baf0be5855bbef17ce48226036b@PAGEOFF
Lloh80:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh81:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh82:
	adrp	x6, l_vtable.7@PAGE
Lloh83:
	add	x6, x6, l_vtable.7@PAGEOFF
	sub	x5, x29, #8
	mov	x0, x8
	mov	w2, #17
	b	LBB16_10
LBB16_8:
	add	x9, x9, #1
	stur	x9, [x29, #-8]
Lloh84:
	adrp	x1, l_alloc_c904b8fe89a4f835804b02bd44018d9c@PAGE
Lloh85:
	add	x1, x1, l_alloc_c904b8fe89a4f835804b02bd44018d9c@PAGEOFF
Lloh86:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh87:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh88:
	adrp	x6, l_vtable.0@PAGE
Lloh89:
	add	x6, x6, l_vtable.0@PAGEOFF
	sub	x5, x29, #8
	mov	x0, x8
	mov	w2, #11
	b	LBB16_10
LBB16_9:
	stur	x9, [x29, #-8]
Lloh90:
	adrp	x1, l_alloc_d102eb289abff9d0655d27bf114c0746@PAGE
Lloh91:
	add	x1, x1, l_alloc_d102eb289abff9d0655d27bf114c0746@PAGEOFF
Lloh92:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh93:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh94:
	adrp	x6, l_vtable.0@PAGE
Lloh95:
	add	x6, x6, l_vtable.0@PAGEOFF
	sub	x5, x29, #8
	mov	x0, x8
	mov	w2, #6
LBB16_10:
	mov	w4, #6
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish
LBB16_11:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB16_12:
	.cfi_restore_state
	add	x10, x9, #16
	stur	x10, [x29, #-8]
Lloh96:
	adrp	x10, l_vtable.7@PAGE
Lloh97:
	add	x10, x10, l_vtable.7@PAGEOFF
	str	x10, [sp, #16]
	sub	x10, x29, #8
	mov	w11, #6
	stp	x11, x10, [sp]
Lloh98:
	adrp	x1, l_alloc_4d3c10a7785e3cacd7635396354c2688@PAGE
Lloh99:
	add	x1, x1, l_alloc_4d3c10a7785e3cacd7635396354c2688@PAGEOFF
Lloh100:
	adrp	x3, l_alloc_bebfed686e6a6f31c99c69b171066b8a@PAGE
Lloh101:
	add	x3, x3, l_alloc_bebfed686e6a6f31c99c69b171066b8a@PAGEOFF
Lloh102:
	adrp	x6, l_vtable.8@PAGE
Lloh103:
	add	x6, x6, l_vtable.8@PAGEOFF
	add	x5, x9, #8
Lloh104:
	adrp	x7, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh105:
	add	x7, x7, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
	mov	x0, x8
	mov	w2, #8
	mov	w4, #8
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish
	b	LBB16_11
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh100, Lloh101
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdd	Lloh96, Lloh97
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRhNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB17_3
	tbnz	w8, #26, LBB17_4
	b	__RNvXNtNtNtCsgtPOCBgevO_4core3fmt3num3imphNtB6_7Display3fmt
LBB17_3:
	b	__RNvXse_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8LowerHex3fmt
LBB17_4:
	b	__RNvXsg_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRjNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB18_3
	tbnz	w8, #26, LBB18_4
	b	__RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt
LBB18_3:
	b	__RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt
LBB18_4:
	b	__RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt:
	.cfi_startproc
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB19_3
	tbnz	w8, #26, LBB19_4
	b	__RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt
LBB19_3:
	b	__RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt
LBB19_4:
	b	__RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match:
	.cfi_startproc
	mov	x9, x1
	ldr	w8, [x9], #8
	tbz	w8, #0, LBB20_3
	ldr	x8, [x1, #56]
	ldp	x2, x3, [x1, #72]
	ldp	x4, x5, [x1, #88]
	mov	x1, x9
	cmn	x8, #1
	b.eq	LBB20_8
	mov	w6, #0
	b	__RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer
LBB20_3:
	ldrb	w8, [x1, #26]
	tbz	w8, #0, LBB20_5
	str	xzr, [x0]
	ret
LBB20_5:
	ldr	x2, [x1, #8]
	ldp	x8, x3, [x1, #72]
	ldrb	w10, [x1, #24]
	cbz	x2, LBB20_10
	cmp	x2, x3
	b.hs	LBB20_9
	ldrsb	w11, [x8, x2]
	cmn	w11, #64
	b.ge	LBB20_10
	b	LBB20_28
LBB20_8:
	mov	w6, #1
	b	__RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer
LBB20_9:
	b.ne	LBB20_28
LBB20_10:
	cmp	x2, x3
	b.ne	LBB20_13
	mov	w9, #1
	bic	w8, w9, w10
	strb	w8, [x1, #24]
	tbnz	w10, #0, LBB20_35
	strb	w9, [x1, #26]
	str	xzr, [x0]
	ret
LBB20_13:
	add	x12, x8, x2
	ldrsb	w13, [x12]
	and	w11, w13, #0xff
	tbz	w13, #31, LBB20_18
	ldrb	w13, [x12, #1]
	and	w14, w13, #0x3f
	cmp	w11, #224
	b.lo	LBB20_17
	and	w13, w11, #0x1f
	ldrb	w15, [x12, #2]
	and	w15, w15, #0x3f
	orr	w14, w15, w14, lsl #6
	cmp	w11, #240
	b.lo	LBB20_36
	ldrb	w11, [x12, #3]
	and	w11, w11, #0x3f
	orr	w11, w11, w14, lsl #6
	bfi	w11, w13, #18, #3
	tbz	w10, #0, LBB20_19
	b	LBB20_34
LBB20_17:
	bfi	w14, w11, #6, #5
	mov	x11, x14
LBB20_18:
	tbnz	w10, #0, LBB20_34
LBB20_19:
	cmp	w11, #128
	b.hs	LBB20_21
	mov	w10, #1
	b	LBB20_24
LBB20_21:
	cmp	w11, #2048
	b.hs	LBB20_23
	mov	w10, #2
	b	LBB20_24
LBB20_23:
	cmp	w11, #16, lsl #12
	mov	w10, #3
	cinc	x10, x10, hs
LBB20_24:
	adds	x11, x10, x2
	str	x11, [x9]
	b.eq	LBB20_30
	cmp	x11, x3
	b.hs	LBB20_29
	ldrsb	w9, [x8, x11]
	cmn	w9, #64
	b.ge	LBB20_30
LBB20_27:
	mov	w10, #1
	mov	x2, x11
LBB20_28:
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w9, #1
	bic	w9, w9, w10
	strb	w9, [x1, #24]
Lloh106:
	adrp	x4, l_alloc_de5e2f1dd01253ae804bfe6ba3503da0@PAGE
Lloh107:
	add	x4, x4, l_alloc_de5e2f1dd01253ae804bfe6ba3503da0@PAGEOFF
	mov	x0, x8
	mov	x1, x3
	bl	__RNvNtCsgtPOCBgevO_4core3str16slice_error_fail
LBB20_29:
	.cfi_def_cfa wsp, 0
	.cfi_same_value w30
	.cfi_same_value w29
	b.ne	LBB20_27
LBB20_30:
	mov	x2, x3
	cmp	x11, x3
	b.eq	LBB20_34
	ldrsb	w8, [x8, x11]
	tbz	w8, #31, LBB20_33
	and	w8, w8, #0xff
	cmp	w8, #224
LBB20_33:
	mov	x2, x11
LBB20_34:
	strb	wzr, [x1, #24]
	mov	x3, x2
LBB20_35:
	stp	x3, x3, [x0, #8]
	mov	w8, #1
	str	x8, [x0]
	ret
LBB20_36:
	orr	w11, w14, w13, lsl #12
	tbz	w10, #0, LBB20_19
	b	LBB20_34
	.loh AdrpAdd	Lloh106, Lloh107
	.cfi_endproc

	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI21_0:
	.long	16909060
	.long	84281096
lCPI21_1:
	.long	2695938256
	.long	270544960
lCPI21_2:
	.long	1
	.long	2
lCPI21_3:
	.long	4
	.long	5
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvYNCNvCs21ATSyVuzIl_17prepared_consumer50prepared_and_manual_whole_consumers_are_equivalent0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_:
	.cfi_startproc
	sub	sp, sp, #336
	.cfi_def_cfa_offset 336
	stp	x28, x27, [sp, #240]
	stp	x26, x25, [sp, #256]
	stp	x24, x23, [sp, #272]
	stp	x22, x21, [sp, #288]
	stp	x20, x19, [sp, #304]
	stp	x29, x30, [sp, #320]
	add	x29, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	str	x8, [sp]
Lloh108:
	adrp	x8, lCPI21_0@PAGE
Lloh109:
	ldr	d1, [x8, lCPI21_0@PAGEOFF]
Lloh110:
	adrp	x8, lCPI21_1@PAGE
Lloh111:
	ldr	d0, [x8, lCPI21_1@PAGEOFF]
	stp	d1, d0, [sp, #8]
Lloh112:
	adrp	x8, lCPI21_2@PAGE
Lloh113:
	ldr	d0, [x8, lCPI21_2@PAGEOFF]
	str	d0, [sp, #24]
	mov	w8, #3
	str	w8, [sp, #32]
Lloh114:
	adrp	x8, lCPI21_3@PAGE
Lloh115:
	ldr	d0, [x8, lCPI21_3@PAGEOFF]
	str	d0, [sp, #40]
	mov	w8, #6
	str	w8, [sp, #48]
	mov	w0, #4
	mov	x1, #0
	mov	w2, #4
	mov	x3, #0
	mov	w4, #4
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #1
	mov	w3, #1
	mov	w4, #12
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #20
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	mov	w1, #1
	mov	w2, #4
	mov	x3, #0
	mov	w4, #8
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x2, sp, #16
	mov	w0, #4
	mov	x1, #0
	mov	w3, #1
	mov	w4, #8
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	mov	w1, #2
	mov	w2, #4
	mov	x3, #0
	mov	w4, #12
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x2, sp, #16
	mov	w0, #4
	mov	x1, #0
	mov	w3, #2
	mov	w4, #12
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #1
	mov	w3, #2
	mov	w4, #16
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #1
	mov	w4, #16
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	mov	w1, #2
	mov	w2, #4
	mov	x3, #0
	mov	x4, #0
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x2, sp, #16
	mov	w0, #4
	mov	x1, #0
	mov	w3, #2
	mov	x4, #0
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	x4, #0
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #24
	mov	w1, #3
	mov	w2, #4
	mov	x3, #0
	mov	x4, #0
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x2, sp, #40
	mov	w0, #4
	mov	x1, #0
	mov	w3, #3
	mov	x4, #0
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #24
	add	x2, sp, #40
	mov	w1, #3
	mov	w3, #3
	mov	x4, #0
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	x4, #0
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #1
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #2
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #3
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #4
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #5
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #6
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #7
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #8
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #9
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #10
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #11
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #12
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #13
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #14
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #15
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #16
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #17
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #18
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	add	x0, sp, #8
	add	x2, sp, #16
	mov	w1, #2
	mov	w3, #2
	mov	w4, #19
	bl	__RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent
	mov	w8, #0
	mov	x9, #0
	add	x10, sp, #56
	add	x26, x10, #16
Lloh116:
	adrp	x10, l_alloc_d91c9f80f2e5baff61980d0c7830d0e8@PAGE
Lloh117:
	add	x10, x10, l_alloc_d91c9f80f2e5baff61980d0c7830d0e8@PAGEOFF
	mov	w11, #26
	stp	x10, x11, [sp, #72]
Lloh118:
	adrp	x10, l_alloc_28eec9e12bbc407b8589cbde87c7f667@PAGE
Lloh119:
	add	x10, x10, l_alloc_28eec9e12bbc407b8589cbde87c7f667@PAGEOFF
	mov	w11, #29
Lloh120:
	adrp	x20, l_alloc_26763173fa2e792d564fcfb08dcb11cd@PAGE
Lloh121:
	add	x20, x20, l_alloc_26763173fa2e792d564fcfb08dcb11cd@PAGEOFF
	stp	x10, x11, [sp, #88]
	mov	w27, #5687
Lloh122:
	adrp	x21, l_alloc_e89cb6afc643eac20b05a0b577b5e8bc@PAGE
Lloh123:
	add	x21, x21, l_alloc_e89cb6afc643eac20b05a0b577b5e8bc@PAGEOFF
Lloh124:
	adrp	x22, l_alloc_7a807194ba7bcc2f917ecb6ee3f0af2a@PAGE
Lloh125:
	add	x22, x22, l_alloc_7a807194ba7bcc2f917ecb6ee3f0af2a@PAGEOFF
LBB21_1:
	mov	x28, x8
	add	x8, x26, x9, lsl #4
	ldp	x2, x3, [x8]
	add	x8, sp, #128
	mov	x0, x20
	mov	w1, #5687
	bl	__RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new
	add	x0, sp, #104
	add	x1, sp, #128
	bl	__RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match
	ldr	x8, [sp, #104]
	cmp	x8, #1
	b.ne	LBB21_100
	ldr	x2, [sp, #112]
	cbz	x2, LBB21_6
	cmp	x2, x27
	b.hs	LBB21_5
	ldrsb	w8, [x20, x2]
	cmn	w8, #65
	b.gt	LBB21_6
	b	LBB21_111
LBB21_5:
	cmp	x2, x27
	b.ne	LBB21_111
LBB21_6:
	sub	x24, x27, x2
	add	x23, x20, x2
	add	x8, sp, #128
	mov	x0, x23
	mov	x1, x24
	mov	x2, x21
	mov	w3, #3
	bl	__RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new
	add	x0, sp, #104
	add	x1, sp, #128
	bl	__RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match
	ldr	w8, [sp, #104]
	tbz	w8, #0, LBB21_101
	ldr	x3, [sp, #112]
	cbz	x3, LBB21_11
	cmp	x3, x24
	b.hs	LBB21_10
	ldrsb	w8, [x23, x3]
	cmn	w8, #65
	b.gt	LBB21_11
	b	LBB21_112
LBB21_10:
	b.ne	LBB21_112
LBB21_11:
	add	x8, sp, #128
	mov	x0, x23
	mov	x1, x3
	mov	x2, x22
	mov	w3, #22
	bl	__RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new
	ldp	x8, x2, [sp, #128]
	ldr	x13, [sp, #152]
	ldp	x0, x1, [sp, #200]
	cmp	x8, #1
	b.ne	LBB21_47
	mov	x12, #0
	ldp	x14, x6, [sp, #160]
	ldr	x7, [sp, #184]
	ldp	x15, x8, [sp, #216]
	sub	x16, x8, #1
	sub	x9, x2, #1
	cmp	x9, x8
	cset	w17, lo
	neg	x3, x2
	subs	x10, x8, x2
	csel	x4, xzr, x10, lo
	sub	x5, x15, #1
	b	LBB21_15
LBB21_13:
	mov	x7, #0
LBB21_14:
	add	x6, x6, x8
	add	x12, x12, #1
LBB21_15:
	add	x11, x6, x16
	cmn	x7, #1
	b.eq	LBB21_32
	cmp	x11, x1
	b.lo	LBB21_19
	b	LBB21_96
LBB21_17:
	mov	x7, #0
	add	x10, x6, x8
LBB21_18:
	add	x11, x10, x16
	cmp	x11, x1
	mov	x6, x10
	b.hs	LBB21_96
LBB21_19:
	ldrb	w10, [x0, x11]
	lsr	x10, x14, x10
	tbz	w10, #0, LBB21_17
	cmp	x7, x2
	csel	x11, x7, x2, hi
	add	x23, x6, x11
	add	x10, x23, x3
	add	x24, x15, x11
	subs	x30, x8, x11
	csel	x30, xzr, x30, lo
LBB21_21:
	cbz	x30, LBB21_25
	cmp	x23, x1
	b.hs	LBB21_102
	ldrb	w19, [x24], #1
	ldrb	w25, [x0, x23]
	add	x10, x10, #1
	add	x23, x23, #1
	sub	x30, x30, #1
	cmp	w19, w25
	b.eq	LBB21_21
	mov	x7, #0
	b	LBB21_18
LBB21_25:
	mov	x10, x2
LBB21_26:
	cmp	x7, x10
	b.hs	LBB21_13
	sub	x10, x10, #1
	cmp	x10, x8
	b.hs	LBB21_105
	add	x11, x10, x6
	cmp	x11, x1
	b.hs	LBB21_104
	ldrb	w19, [x15, x10]
	ldrb	w11, [x0, x11]
	cmp	w19, w11
	b.eq	LBB21_26
	add	x10, x6, x13
	sub	x7, x8, x13
	b	LBB21_18
LBB21_31:
	add	x6, x6, x8
	add	x11, x6, x16
LBB21_32:
	cmp	x11, x1
	b.hs	LBB21_96
	ldrb	w10, [x0, x11]
	lsr	x10, x14, x10
	tbz	w10, #0, LBB21_31
	neg	x10, x6
	add	x11, x2, x6
	mov	x7, x4
	add	x23, x15, x2
LBB21_35:
	cbz	x7, LBB21_39
	cmp	x11, x1
	b.hs	LBB21_103
	ldrb	w19, [x23], #1
	ldrb	w24, [x0, x11]
	sub	x10, x10, #1
	add	x11, x11, #1
	sub	x7, x7, #1
	cmp	w19, w24
	b.eq	LBB21_35
	neg	x6, x10
	add	x11, x6, x16
	b	LBB21_32
LBB21_39:
	cbz	w17, LBB21_45
	add	x11, x0, x6
	mov	x7, x2
LBB21_41:
	cbz	x7, LBB21_46
	add	x10, x6, x7
	sub	x10, x10, #1
	cmp	x10, x1
	b.hs	LBB21_106
	ldrb	w10, [x5, x7]
	add	x19, x11, x7
	ldurb	w19, [x19, #-1]
	sub	x7, x7, #1
	cmp	w10, w19
	b.eq	LBB21_41
	add	x6, x6, x13
	add	x11, x6, x16
	b	LBB21_32
LBB21_45:
	cbnz	x2, LBB21_113
LBB21_46:
	mov	x7, #-1
	b	LBB21_14
LBB21_47:
	tbnz	w13, #16, LBB21_109
	cbz	x2, LBB21_52
	cmp	x2, x1
	b.hs	LBB21_51
	ldrsb	w8, [x0, x2]
	cmn	w8, #64
	b.ge	LBB21_52
	b	LBB21_108
LBB21_51:
	b.ne	LBB21_108
LBB21_52:
	cmp	x2, x1
	b.ne	LBB21_54
	tbnz	w13, #0, LBB21_72
	b	LBB21_109
LBB21_54:
	add	x9, x0, x2
	ldrsb	w10, [x9]
	and	w8, w10, #0xff
	tbnz	w10, #31, LBB21_58
	tbnz	w13, #0, LBB21_72
LBB21_56:
	cmp	w8, #128
	b.hs	LBB21_61
	mov	w8, #1
	adds	x8, x8, x2
	b.ne	LBB21_65
	b	LBB21_68
LBB21_58:
	ldrb	w10, [x9, #1]
	and	w11, w10, #0x3f
	cmp	w8, #224
	b.lo	LBB21_63
	and	w10, w8, #0x1f
	ldrb	w12, [x9, #2]
	and	w12, w12, #0x3f
	orr	w11, w12, w11, lsl #6
	cmp	w8, #240
	b.lo	LBB21_98
	ldrb	w8, [x9, #3]
	and	w8, w8, #0x3f
	orr	w8, w8, w11, lsl #6
	bfi	w8, w10, #18, #3
	tbz	w13, #0, LBB21_56
	b	LBB21_72
LBB21_61:
	cmp	w8, #2048
	b.hs	LBB21_64
	mov	w8, #2
	adds	x8, x8, x2
	b.ne	LBB21_65
	b	LBB21_68
LBB21_63:
	bfi	w11, w8, #6, #5
	mov	x8, x11
	tbnz	w13, #0, LBB21_72
	b	LBB21_56
LBB21_64:
	cmp	w8, #16, lsl #12
	mov	w8, #3
	cinc	x8, x8, hs
	adds	x8, x8, x2
	b.eq	LBB21_68
LBB21_65:
	cmp	x8, x1
	b.hs	LBB21_67
	ldrsb	w9, [x0, x8]
	cmn	w9, #64
	b.ge	LBB21_68
	b	LBB21_107
LBB21_67:
	b.ne	LBB21_107
LBB21_68:
	mov	x2, x1
	cmp	x8, x1
	b.eq	LBB21_72
	ldrsb	w9, [x0, x8]
	tbz	w9, #31, LBB21_71
	and	w9, w9, #0xff
	cmp	w9, #224
LBB21_71:
	mov	x2, x8
LBB21_72:
	mov	w12, #1
	b	LBB21_75
LBB21_73:
	mov	x2, x8
LBB21_74:
	add	x12, x12, #1
LBB21_75:
	cbz	x2, LBB21_79
	cmp	x2, x1
	b.hs	LBB21_78
	ldrsb	w8, [x0, x2]
	cmn	w8, #64
	b.ge	LBB21_79
	b	LBB21_108
LBB21_78:
	b.ne	LBB21_108
LBB21_79:
	cmp	x2, x1
	b.eq	LBB21_96
	add	x9, x0, x2
	ldrsb	w8, [x9]
	tbnz	w8, #31, LBB21_84
LBB21_81:
	mov	w8, #1
	adds	x8, x8, x2
	b.eq	LBB21_88
LBB21_82:
	cmp	x8, x1
	b.hs	LBB21_87
	ldrsb	w9, [x0, x8]
	cmn	w9, #64
	b.ge	LBB21_88
	b	LBB21_107
LBB21_84:
	and	w10, w8, #0xff
	ldrb	w8, [x9, #1]
	and	w8, w8, #0x3f
	cmp	w10, #224
	b.lo	LBB21_91
	and	w11, w10, #0x1f
	ldrb	w13, [x9, #2]
	and	w13, w13, #0x3f
	orr	w8, w13, w8, lsl #6
	cmp	w10, #240
	b.lo	LBB21_92
	ldrb	w9, [x9, #3]
	and	w9, w9, #0x3f
	orr	w8, w9, w8, lsl #6
	bfi	w8, w11, #18, #3
	cmp	w8, #128
	b.lo	LBB21_81
	b	LBB21_93
LBB21_87:
	b.ne	LBB21_107
LBB21_88:
	mov	x2, x1
	cmp	x8, x1
	b.eq	LBB21_74
	ldrsb	w9, [x0, x8]
	tbz	w9, #31, LBB21_73
	and	w9, w9, #0xff
	cmp	w9, #224
	b	LBB21_73
LBB21_91:
	bfi	w8, w10, #6, #5
	cmp	w8, #128
	b.lo	LBB21_81
	b	LBB21_93
LBB21_92:
	orr	w8, w8, w11, lsl #12
	cmp	w8, #128
	b.lo	LBB21_81
LBB21_93:
	cmp	w8, #2048
	b.hs	LBB21_95
	mov	w8, #2
	adds	x8, x8, x2
	b.ne	LBB21_82
	b	LBB21_88
LBB21_95:
	cmp	w8, #16, lsl #12
	mov	w8, #3
	cinc	x8, x8, hs
	adds	x8, x8, x2
	b.ne	LBB21_82
	b	LBB21_88
LBB21_96:
	str	x12, [sp, #128]
	cmp	x12, #1
	b.ne	LBB21_110
	mov	w8, #1
	mov	w9, #1
	tbz	w28, #0, LBB21_1
	b	LBB21_99
LBB21_98:
	orr	w8, w11, w10, lsl #12
	tbz	w13, #0, LBB21_56
	b	LBB21_72
LBB21_99:
	mov	x8, #-1
	ldr	x9, [sp]
	str	x8, [x9]
	.cfi_def_cfa wsp, 336
	ldp	x29, x30, [sp, #320]
	ldp	x20, x19, [sp, #304]
	ldp	x22, x21, [sp, #288]
	ldp	x24, x23, [sp, #272]
	ldp	x26, x25, [sp, #256]
	ldp	x28, x27, [sp, #240]
	add	sp, sp, #336
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB21_100:
	.cfi_restore_state
Lloh126:
	adrp	x0, l_alloc_56105bc765d39b007aae1d24445a5f7d@PAGE
Lloh127:
	add	x0, x0, l_alloc_56105bc765d39b007aae1d24445a5f7d@PAGEOFF
Lloh128:
	adrp	x2, l_alloc_0eb7e310050072805af9487b58c4035d@PAGE
Lloh129:
	add	x2, x2, l_alloc_0eb7e310050072805af9487b58c4035d@PAGEOFF
	mov	w1, #47
	bl	__RNvNtCsgtPOCBgevO_4core9panicking9panic_fmt
LBB21_101:
Lloh130:
	adrp	x0, l_alloc_6b25b981d6dcb0f81ae5433ae5833550@PAGE
Lloh131:
	add	x0, x0, l_alloc_6b25b981d6dcb0f81ae5433ae5833550@PAGEOFF
Lloh132:
	adrp	x2, l_alloc_3f1972d8ea19ee8686ea812b9669179e@PAGE
Lloh133:
	add	x2, x2, l_alloc_3f1972d8ea19ee8686ea812b9669179e@PAGEOFF
	mov	w1, #75
	bl	__RNvNtCsgtPOCBgevO_4core9panicking9panic_fmt
LBB21_102:
	add	x8, x6, x11
	cmp	x1, x8
	csel	x0, x1, x8, hi
Lloh134:
	adrp	x2, l_alloc_8ae9795802ad53c9398ce2776784dbc3@PAGE
Lloh135:
	add	x2, x2, l_alloc_8ae9795802ad53c9398ce2776784dbc3@PAGEOFF
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB21_103:
	add	x8, x6, x2
	cmp	x1, x8
	csel	x0, x1, x8, hi
Lloh136:
	adrp	x2, l_alloc_8ae9795802ad53c9398ce2776784dbc3@PAGE
Lloh137:
	add	x2, x2, l_alloc_8ae9795802ad53c9398ce2776784dbc3@PAGEOFF
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB21_104:
Lloh138:
	adrp	x2, l_alloc_8deac4fa778727f9c004a28bc20bcda6@PAGE
Lloh139:
	add	x2, x2, l_alloc_8deac4fa778727f9c004a28bc20bcda6@PAGEOFF
	mov	x0, x11
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB21_105:
Lloh140:
	adrp	x2, l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2@PAGE
Lloh141:
	add	x2, x2, l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2@PAGEOFF
	mov	x0, x10
	mov	x1, x8
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB21_106:
Lloh142:
	adrp	x2, l_alloc_8deac4fa778727f9c004a28bc20bcda6@PAGE
Lloh143:
	add	x2, x2, l_alloc_8deac4fa778727f9c004a28bc20bcda6@PAGEOFF
	mov	x0, x10
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB21_107:
	mov	x2, x8
LBB21_108:
Lloh144:
	adrp	x4, l_alloc_de5e2f1dd01253ae804bfe6ba3503da0@PAGE
Lloh145:
	add	x4, x4, l_alloc_de5e2f1dd01253ae804bfe6ba3503da0@PAGEOFF
	mov	x3, x1
	bl	__RNvNtCsgtPOCBgevO_4core3str16slice_error_fail
LBB21_109:
	str	xzr, [sp, #128]
LBB21_110:
Lloh146:
	adrp	x2, l_alloc_edb3ed16ed07237eac14eb16826c52e0@PAGE
Lloh147:
	add	x2, x2, l_alloc_edb3ed16ed07237eac14eb16826c52e0@PAGEOFF
Lloh148:
	adrp	x5, l_alloc_7b2885fbf347689c42120fce9d13749d@PAGE
Lloh149:
	add	x5, x5, l_alloc_7b2885fbf347689c42120fce9d13749d@PAGEOFF
	add	x1, sp, #128
	mov	w0, #0
	mov	x3, #0
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_
LBB21_111:
Lloh150:
	adrp	x0, l_alloc_26763173fa2e792d564fcfb08dcb11cd@PAGE
Lloh151:
	add	x0, x0, l_alloc_26763173fa2e792d564fcfb08dcb11cd@PAGEOFF
Lloh152:
	adrp	x4, l_alloc_24028a94044fca6d4a8bfbb1fadd3876@PAGE
Lloh153:
	add	x4, x4, l_alloc_24028a94044fca6d4a8bfbb1fadd3876@PAGEOFF
	mov	w1, #5687
	mov	w3, #5687
	bl	__RNvNtCsgtPOCBgevO_4core3str16slice_error_fail
LBB21_112:
Lloh154:
	adrp	x4, l_alloc_4c92989ea71fda7e0c89e82a9cab1489@PAGE
Lloh155:
	add	x4, x4, l_alloc_4c92989ea71fda7e0c89e82a9cab1489@PAGEOFF
	mov	x0, x23
	mov	x1, x24
	mov	x2, #0
	bl	__RNvNtCsgtPOCBgevO_4core3str16slice_error_fail
LBB21_113:
Lloh156:
	adrp	x2, l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2@PAGE
Lloh157:
	add	x2, x2, l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2@PAGEOFF
	mov	x0, x9
	mov	x1, x8
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh120, Lloh121
	.loh AdrpAdd	Lloh118, Lloh119
	.loh AdrpAdd	Lloh116, Lloh117
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpAdrp	Lloh110, Lloh112
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdrp	Lloh108, Lloh110
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdd	Lloh126, Lloh127
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh140, Lloh141
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh156, Lloh157
	.cfi_endproc

	.globl	_main
	.p2align	2
_main:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x3, x1
	sxtw	x2, w0
Lloh158:
	adrp	x8, __RNvCs21ATSyVuzIl_17prepared_consumer4main@PAGE
Lloh159:
	add	x8, x8, __RNvCs21ATSyVuzIl_17prepared_consumer4main@PAGEOFF
	str	x8, [sp, #8]
Lloh160:
	adrp	x1, l_vtable.1@PAGE
Lloh161:
	add	x1, x1, l_vtable.1@PAGEOFF
	add	x0, sp, #8
	mov	w4, #0
	bl	__RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdd	Lloh158, Lloh159
	.cfi_endproc

	.p2align	2
_OUTLINED_FUNCTION_0:
	.cfi_startproc
	mov	x1, sp
	add	x3, sp, #8
	mov	w0, #0
	mov	x4, x2
	mov	x5, #0
	b	__RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner
	.cfi_endproc

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRhNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer

	.section	__TEXT,__cstring,cstring_literals
l_alloc_ee38938c8929eed18faaff5d8f37cd9b:
	.asciz	"/nix/store/p5s0g9nqgaf3024n3g2ib80f3si3bn9s-rust-mixed/lib/rustlib/src/rust/library/core/src/str/pattern.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2:
	.quad	l_alloc_ee38938c8929eed18faaff5d8f37cd9b
	.asciz	"k\000\000\000\000\000\000\000\347\005\000\000\024\000\000"

	.p2align	3, 0x0
l_alloc_8deac4fa778727f9c004a28bc20bcda6:
	.quad	l_alloc_ee38938c8929eed18faaff5d8f37cd9b
	.asciz	"k\000\000\000\000\000\000\000\347\005\000\000!\000\000"

	.p2align	3, 0x0
l_alloc_8ae9795802ad53c9398ce2776784dbc3:
	.quad	l_alloc_ee38938c8929eed18faaff5d8f37cd9b
	.asciz	"k\000\000\000\000\000\000\000\333\005\000\000!\000\000"

	.p2align	3, 0x0
l_vtable.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs21ATSyVuzIl_17prepared_consumer
	.quad	__RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs21ATSyVuzIl_17prepared_consumer
	.quad	__RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs21ATSyVuzIl_17prepared_consumer

	.p2align	3, 0x0
l_vtable.2:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRAhj17_NtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer

	.p2align	3, 0x0
l_vtable.3:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6result6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtB6_5Debug3fmtBU_

	.section	__TEXT,__cstring,cstring_literals
l_alloc_63c269227ccc4ad1eb0f705675a3abbe:
	.asciz	"crates/nudox-ir-format/tests/prepared_consumer.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_16613a034bc3772cbb719c5113a258a5:
	.quad	l_alloc_63c269227ccc4ad1eb0f705675a3abbe
	.asciz	"1\000\000\000\000\000\000\000v\000\000\000\005\000\000"

	.p2align	3, 0x0
l_alloc_cb00222c11a9560fc2db0458e2b363a2:
	.quad	l_alloc_63c269227ccc4ad1eb0f705675a3abbe
	.asciz	"1\000\000\000\000\000\000\000w\000\000\000\005\000\000"

	.p2align	3, 0x0
l_alloc_d3c0ed059c64d66bf64704809ec4db02:
	.quad	l_alloc_63c269227ccc4ad1eb0f705675a3abbe
	.asciz	"1\000\000\000\000\000\000\000Y\000\000\000\017\000\000"

	.p2align	3, 0x0
l_alloc_0d19906a6b3022c81c70f9413c97b8e2:
	.quad	l_alloc_63c269227ccc4ad1eb0f705675a3abbe
	.asciz	"1\000\000\000\000\000\000\000]\000\000\000\017\000\000"

	.section	__TEXT,__const
l_alloc_df6b3d8045eb4043c58a494fb8deea1f:
	.ascii	"prepared_and_manual_whole_consumers_are_equivalent"

l_alloc_27b07c5770fd6e4fc4a9c4f1589bd131:
	.ascii	"crates/nudox-ir-format/tests/prepared_consumer.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_aef0b2eeb4aad7015e0c32e103483ee4:
	.space	8
	.space	16
	.ascii	"\000\000\000\000\000\000\000\200"
	.quad	l_alloc_df6b3d8045eb4043c58a494fb8deea1f
	.asciz	"2\000\000\000\000\000\000"
	.space	8
	.quad	l_alloc_27b07c5770fd6e4fc4a9c4f1589bd131
	.asciz	"1\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.space	8
	.ascii	"{\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000{\000\000\000\000\000\000\0006\000\000\000\000\000\000\000\000\000\000\001"
	.space	4
	.space	8
	.quad	__RNvYNCNvCs21ATSyVuzIl_17prepared_consumer50prepared_and_manual_whole_consumers_are_equivalent0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_
	.space	8

	.p2align	3, 0x0
l_alloc_e68e146f22cb2d0b878fb86e4e6fa8ea:
	.quad	l_alloc_aef0b2eeb4aad7015e0c32e103483ee4

	.section	__TEXT,__const
l_alloc_d91c9f80f2e5baff61980d0c7830d0e8:
	.ascii	"fn prepared_whole_consumer"

l_alloc_28eec9e12bbc407b8589cbde87c7f667:
	.ascii	"fn manual_single_pass_control"

l_alloc_26763173fa2e792d564fcfb08dcb11cd:
	.ascii	"use core::hint::black_box;\nuse nudox_ir_format::{\n    ENTITY_BYTES, FragmentError, FragmentView, HEADER_BYTES, MAGIC, MAX_LANE_ITEMS, PrepareError,\n    PreparedFragment, SCHEMA, TYPE_BYTES, WriteError,\n};\nuse nudox_ir_vocab::{EntityId, TypeId};\n\nconst MAGIC_OFFSET: usize = 0;\nconst SCHEMA_OFFSET: usize = 1;\nconst ENTITY_COUNT_OFFSET: usize = 2;\nconst TYPE_COUNT_OFFSET: usize = 3;\n\n#[derive(Clone, Copy, Debug, Eq, PartialEq)]\nenum ConsumerError {\n    Prepare(PrepareError),\n    Write(WriteError),\n    Validate(FragmentError),\n}\n\n#[inline(never)]\nfn prepared_whole_consumer(\n    entities: &[EntityId],\n    types: &[TypeId],\n    output: &mut [u8],\n) -> Result<usize, ConsumerError> {\n    let prepared = match PreparedFragment::prepare(entities, types) {\n        Ok(prepared) => prepared,\n        Err(error) => return Err(ConsumerError::Prepare(error)),\n    };\n    let prefix = match prepared.write_into(output) {\n        Ok(prefix) => prefix,\n        Err(error) => return Err(ConsumerError::Write(error)),\n    };\n    let view = match FragmentView::validate(prefix) {\n        Ok(view) => view,\n        Err(error) => return Err(ConsumerError::Validate(error)),\n    };\n    let entities = view.entity_ids().count();\n    let types = view.type_ids().count();\n    Ok(entities + types)\n}\n\n#[inline(never)]\nfn manual_single_pass_control(\n    entities: &[EntityId],\n    types: &[TypeId],\n    output: &mut [u8],\n) -> Result<usize, ConsumerError> {\n    let entity_count = match u8::try_from(entities.len()) {\n        Ok(count) => count,\n        Err(_) => {\n            return Err(ConsumerError::Prepare(PrepareError::EntityCount {\n                actual: entities.len(),\n            }));\n        }\n    };\n    if entity_count > MAX_LANE_ITEMS {\n        return Err(ConsumerError::Prepare(PrepareError::EntityCount {\n            actual: entities.len(),\n        }));\n    }\n    let type_count = match u8::try_from(types.len()) {\n        Ok(count) => count,\n        Err(_) => {\n            return Err(ConsumerError::Prepare(PrepareError::TypeCount {\n                actual: types.len(),\n            }));\n        }\n    };\n    if type_count > MAX_LANE_ITEMS {\n        return Err(ConsumerError::Prepare(PrepareError::TypeCount {\n            actual: types.len(),\n        }));\n    }\n    let required = HEADER_BYTES + entities.len() * ENTITY_BYTES + types.len() * TYPE_BYTES;\n    if output.len() < required {\n        return Err(ConsumerError::Write(WriteError::OutputTooSmall {\n            required,\n            available: output.len(),\n        }));\n    }\n    let prefix = &mut output[..required];\n    prefix[MAGIC_OFFSET] = MAGIC;\n    prefix[SCHEMA_OFFSET] = SCHEMA;\n    prefix[ENTITY_COUNT_OFFSET] = entity_count;\n    prefix[TYPE_COUNT_OFFSET] = type_count;\n    let mut cursor = HEADER_BYTES;\n    for entity in entities {\n        prefix[cursor..cursor + ENTITY_BYTES].copy_from_slice(&entity.raw.to_le_bytes());\n        cursor += ENTITY_BYTES;\n    }\n    for ty in types {\n        prefix[cursor..cursor + TYPE_BYTES].copy_from_slice(&ty.raw.to_le_bytes());\n        cursor += TYPE_BYTES;\n    }\n    let view = match FragmentView::validate(prefix) {\n        Ok(view) => view,\n        Err(error) => return Err(ConsumerError::Validate(error)),\n    };\n    let entities = view.entity_ids().count();\n    let types = view.type_ids().count();\n    Ok(entities + types)\n}\n\nfn assert_equivalent(entities: &[EntityId], types: &[TypeId], available: usize) {\n    let mut prepared_output = [0xa5; 23];\n    let mut manual_output = [0xa5; 23];\n    let prepared_result = prepared_whole_consumer(\n        black_box(entities),\n        black_box(types),\n        black_box(&mut prepared_output[..available]),\n    );\n    let manual_result = manual_single_pass_control(\n        black_box(entities),\n        black_box(types),\n        black_box(&mut manual_output[..available]),\n    );\n    assert_eq!(prepared_result, manual_result);\n    assert_eq!(prepared_output, manual_output);\n}\n\n#[test]\nfn prepared_and_manual_whole_consumers_are_equivalent() {\n    let entities = [EntityId::new(0x0102_0304), EntityId::new(0x0506_0708)];\n    let types = [TypeId::new(0xa0b0_c0d0), TypeId::new(0x1020_3040)];\n    let three_entities = [EntityId::new(1), EntityId::new(2), EntityId::new(3)];\n    let three_types = [TypeId::new(4), TypeId::new(5), TypeId::new(6)];\n    assert_equivalent(&[], &[], 4);\n    assert_equivalent(&entities[..1], &types[..1], 12);\n    assert_equivalent(&entities, &types, 20);\n    assert_equivalent(&entities[..1], &[], 8);\n    assert_equivalent(&[], &types[..1], 8);\n    assert_equivalent(&entities, &[], 12);\n    assert_equivalent(&[], &types, 12);\n    assert_equivalent(&entities[..1], &types, 16);\n    assert_equivalent(&entities, &types[..1], 16);\n    assert_equivalent(&entities[..], &[], 0);\n    assert_equivalent(&[], &types[..], 0);\n    assert_equivalent(&entities[..], &types[..], 0);\n    assert_equivalent(&three_entities, &[], 0);\n    assert_equivalent(&[], &three_types, 0);\n    assert_equivalent(&three_entities, &three_types, 0);\n    for available in 0..20 {\n        assert_equivalent(&entities, &types, available);\n    }\n    let source = include_str!(\"prepared_consumer.rs\");\n    for marker in [\n        \"fn prepared_whole_consumer\",\n        \"fn manual_single_pass_control\",\n    ] {\n        let start = match source.find(marker) {\n            Some(start) => start,\n            None => panic!(\"callable source missing\"),\n        };\n        let body = &source[start..];\n        let end = match body.find(\"\\n}\\n\") {\n            Some(end) => end,\n            None => panic!(\"callable source closing brace missing\"),\n        };\n        assert_eq!(body[..end].matches(\"FragmentView::validate\").count(), 1);\n    }\n}\n"

l_alloc_56105bc765d39b007aae1d24445a5f7d:
	.ascii	"callable source missing"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_0eb7e310050072805af9487b58c4035d:
	.quad	l_alloc_63c269227ccc4ad1eb0f705675a3abbe
	.asciz	"1\000\000\000\000\000\000\000\231\000\000\000\025\000\000"

	.p2align	3, 0x0
l_alloc_24028a94044fca6d4a8bfbb1fadd3876:
	.quad	l_alloc_63c269227ccc4ad1eb0f705675a3abbe
	.asciz	"1\000\000\000\000\000\000\000\233\000\000\000\033\000\000"

	.section	__TEXT,__const
l_alloc_e89cb6afc643eac20b05a0b577b5e8bc:
	.ascii	"\n}\n"

l_alloc_6b25b981d6dcb0f81ae5433ae5833550:
	.ascii	"callable source closing brace missing"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_3f1972d8ea19ee8686ea812b9669179e:
	.quad	l_alloc_63c269227ccc4ad1eb0f705675a3abbe
	.asciz	"1\000\000\000\000\000\000\000\236\000\000\000\025\000\000"

	.p2align	3, 0x0
l_alloc_4c92989ea71fda7e0c89e82a9cab1489:
	.quad	l_alloc_63c269227ccc4ad1eb0f705675a3abbe
	.asciz	"1\000\000\000\000\000\000\000\240\000\000\000\030\000\000"

	.section	__TEXT,__const
l_alloc_7a807194ba7bcc2f917ecb6ee3f0af2a:
	.ascii	"FragmentView::validate"

	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
l_alloc_edb3ed16ed07237eac14eb16826c52e0:
	.asciz	"\001\000\000\000\000\000\000"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_7b2885fbf347689c42120fce9d13749d:
	.quad	l_alloc_63c269227ccc4ad1eb0f705675a3abbe
	.asciz	"1\000\000\000\000\000\000\000\240\000\000\000\t\000\000"

	.p2align	3, 0x0
l_vtable.4:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format12PrepareErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer

	.section	__TEXT,__const
l_alloc_ff99525767786baa5dc7e956e06d005e:
	.ascii	"Prepare"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.5:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format10WriteErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer

	.section	__TEXT,__const
l_alloc_6b7483292c41e5f1002b8b441a63be1a:
	.ascii	"Write"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.6:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format13FragmentErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer

	.section	__TEXT,__literal8,8byte_literals
l_alloc_9734c9124d3f60537957ec8c47f6ebf4:
	.ascii	"Validate"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.7:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRjNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer

	.section	__TEXT,__const
l_alloc_ea8e8baf0be5855bbef17ce48226036b:
	.ascii	"TruncatedEnvelope"

l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc:
	.ascii	"actual"

l_alloc_d7b9b6c1829de9592f5bc6e83c4fc424:
	.ascii	"Magic"

l_alloc_d102eb289abff9d0655d27bf114c0746:
	.ascii	"Schema"

l_alloc_c904b8fe89a4f835804b02bd44018d9c:
	.ascii	"EntityCount"

l_alloc_b5a34892e83b03f9728fdba51e681f6f:
	.ascii	"TypeCount"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.8:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt

	.section	__TEXT,__literal8,8byte_literals
l_alloc_4d3c10a7785e3cacd7635396354c2688:
	.ascii	"Geometry"

l_alloc_bebfed686e6a6f31c99c69b171066b8a:
	.ascii	"expected"

	.section	__TEXT,__const
l_alloc_5ab5ad54a633166dad8479b7b463c0d3:
	.ascii	"OutputTooSmall"

	.section	__TEXT,__literal8,8byte_literals
l_alloc_715ad17152b7a3dfcbb2abff840befeb:
	.ascii	"required"

	.section	__TEXT,__const
l_alloc_700d5d683c25860e3d40207214c9c99c:
	.ascii	"available"

l_alloc_c73d17da7498663a071b898ac2218935:
	.ascii	"Ok"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.9:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorNtB6_5Debug3fmtBx_

	.section	__TEXT,__const
l_alloc_bf301217d548e4f1fd13189dd935c554:
	.ascii	"Err"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_de5e2f1dd01253ae804bfe6ba3503da0:
	.quad	l_alloc_ee38938c8929eed18faaff5d8f37cd9b
	.asciz	"k\000\000\000\000\000\000\000k\004\000\000$\000\000"

.subsections_via_symbols
