; ModuleID = 'prepared_consumer.17984c639fc1dcab-cgu.0'
source_filename = "prepared_consumer.17984c639fc1dcab-cgu.0"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx11.0.0"

%"core::mem::maybe_uninit::MaybeUninit<&str>" = type { [2 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRhNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer }>, align 8
@alloc_ee38938c8929eed18faaff5d8f37cd9b = private unnamed_addr constant [108 x i8] c"/nix/store/p5s0g9nqgaf3024n3g2ib80f3si3bn9s-rust-mixed/lib/rustlib/src/rust/library/core/src/str/pattern.rs\00", align 1
@alloc_68bb27fa7fd7af0b8edb2570ef014cd2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ee38938c8929eed18faaff5d8f37cd9b, [16 x i8] c"k\00\00\00\00\00\00\00\E7\05\00\00\14\00\00\00" }>, align 8
@alloc_8deac4fa778727f9c004a28bc20bcda6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ee38938c8929eed18faaff5d8f37cd9b, [16 x i8] c"k\00\00\00\00\00\00\00\E7\05\00\00!\00\00\00" }>, align 8
@alloc_8ae9795802ad53c9398ce2776784dbc3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ee38938c8929eed18faaff5d8f37cd9b, [16 x i8] c"k\00\00\00\00\00\00\00\DB\05\00\00!\00\00\00" }>, align 8
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs21ATSyVuzIl_17prepared_consumer, ptr @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs21ATSyVuzIl_17prepared_consumer, ptr @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs21ATSyVuzIl_17prepared_consumer }>, align 8
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRAhj17_NtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer }>, align 8
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6result6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtB6_5Debug3fmtBU_ }>, align 8
@alloc_63c269227ccc4ad1eb0f705675a3abbe = private unnamed_addr constant [50 x i8] c"crates/nudox-ir-format/tests/prepared_consumer.rs\00", align 1
@alloc_16613a034bc3772cbb719c5113a258a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_63c269227ccc4ad1eb0f705675a3abbe, [16 x i8] c"1\00\00\00\00\00\00\00v\00\00\00\05\00\00\00" }>, align 8
@alloc_cb00222c11a9560fc2db0458e2b363a2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_63c269227ccc4ad1eb0f705675a3abbe, [16 x i8] c"1\00\00\00\00\00\00\00w\00\00\00\05\00\00\00" }>, align 8
@alloc_d3c0ed059c64d66bf64704809ec4db02 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_63c269227ccc4ad1eb0f705675a3abbe, [16 x i8] c"1\00\00\00\00\00\00\00Y\00\00\00\0F\00\00\00" }>, align 8
@alloc_0d19906a6b3022c81c70f9413c97b8e2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_63c269227ccc4ad1eb0f705675a3abbe, [16 x i8] c"1\00\00\00\00\00\00\00]\00\00\00\0F\00\00\00" }>, align 8
@alloc_df6b3d8045eb4043c58a494fb8deea1f = private unnamed_addr constant [50 x i8] c"prepared_and_manual_whole_consumers_are_equivalent", align 1
@alloc_27b07c5770fd6e4fc4a9c4f1589bd131 = private unnamed_addr constant [49 x i8] c"crates/nudox-ir-format/tests/prepared_consumer.rs", align 1
@alloc_aef0b2eeb4aad7015e0c32e103483ee4 = private unnamed_addr constant <{ [8 x i8], [16 x i8], [8 x i8], ptr, [8 x i8], [8 x i8], ptr, [16 x i8], [8 x i8], [36 x i8], [4 x i8], [8 x i8], ptr, [8 x i8] }> <{ [8 x i8] zeroinitializer, [16 x i8] undef, [8 x i8] c"\00\00\00\00\00\00\00\80", ptr @alloc_df6b3d8045eb4043c58a494fb8deea1f, [8 x i8] c"2\00\00\00\00\00\00\00", [8 x i8] undef, ptr @alloc_27b07c5770fd6e4fc4a9c4f1589bd131, [16 x i8] c"1\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", [8 x i8] undef, [36 x i8] c"{\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00{\00\00\00\00\00\00\006\00\00\00\00\00\00\00\00\00\00\01", [4 x i8] undef, [8 x i8] zeroinitializer, ptr @_RNvYNCNvCs21ATSyVuzIl_17prepared_consumer50prepared_and_manual_whole_consumers_are_equivalent0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_, [8 x i8] undef }>, align 8
@alloc_e68e146f22cb2d0b878fb86e4e6fa8ea = private unnamed_addr constant ptr @alloc_aef0b2eeb4aad7015e0c32e103483ee4, align 8
@alloc_d91c9f80f2e5baff61980d0c7830d0e8 = private unnamed_addr constant [26 x i8] c"fn prepared_whole_consumer", align 1
@alloc_28eec9e12bbc407b8589cbde87c7f667 = private unnamed_addr constant [29 x i8] c"fn manual_single_pass_control", align 1
@alloc_26763173fa2e792d564fcfb08dcb11cd = private unnamed_addr constant [5687 x i8] c"use core::hint::black_box;\0Ause nudox_ir_format::{\0A    ENTITY_BYTES, FragmentError, FragmentView, HEADER_BYTES, MAGIC, MAX_LANE_ITEMS, PrepareError,\0A    PreparedFragment, SCHEMA, TYPE_BYTES, WriteError,\0A};\0Ause nudox_ir_vocab::{EntityId, TypeId};\0A\0Aconst MAGIC_OFFSET: usize = 0;\0Aconst SCHEMA_OFFSET: usize = 1;\0Aconst ENTITY_COUNT_OFFSET: usize = 2;\0Aconst TYPE_COUNT_OFFSET: usize = 3;\0A\0A#[derive(Clone, Copy, Debug, Eq, PartialEq)]\0Aenum ConsumerError {\0A    Prepare(PrepareError),\0A    Write(WriteError),\0A    Validate(FragmentError),\0A}\0A\0A#[inline(never)]\0Afn prepared_whole_consumer(\0A    entities: &[EntityId],\0A    types: &[TypeId],\0A    output: &mut [u8],\0A) -> Result<usize, ConsumerError> {\0A    let prepared = match PreparedFragment::prepare(entities, types) {\0A        Ok(prepared) => prepared,\0A        Err(error) => return Err(ConsumerError::Prepare(error)),\0A    };\0A    let prefix = match prepared.write_into(output) {\0A        Ok(prefix) => prefix,\0A        Err(error) => return Err(ConsumerError::Write(error)),\0A    };\0A    let view = match FragmentView::validate(prefix) {\0A        Ok(view) => view,\0A        Err(error) => return Err(ConsumerError::Validate(error)),\0A    };\0A    let entities = view.entity_ids().count();\0A    let types = view.type_ids().count();\0A    Ok(entities + types)\0A}\0A\0A#[inline(never)]\0Afn manual_single_pass_control(\0A    entities: &[EntityId],\0A    types: &[TypeId],\0A    output: &mut [u8],\0A) -> Result<usize, ConsumerError> {\0A    let entity_count = match u8::try_from(entities.len()) {\0A        Ok(count) => count,\0A        Err(_) => {\0A            return Err(ConsumerError::Prepare(PrepareError::EntityCount {\0A                actual: entities.len(),\0A            }));\0A        }\0A    };\0A    if entity_count > MAX_LANE_ITEMS {\0A        return Err(ConsumerError::Prepare(PrepareError::EntityCount {\0A            actual: entities.len(),\0A        }));\0A    }\0A    let type_count = match u8::try_from(types.len()) {\0A        Ok(count) => count,\0A        Err(_) => {\0A            return Err(ConsumerError::Prepare(PrepareError::TypeCount {\0A                actual: types.len(),\0A            }));\0A        }\0A    };\0A    if type_count > MAX_LANE_ITEMS {\0A        return Err(ConsumerError::Prepare(PrepareError::TypeCount {\0A            actual: types.len(),\0A        }));\0A    }\0A    let required = HEADER_BYTES + entities.len() * ENTITY_BYTES + types.len() * TYPE_BYTES;\0A    if output.len() < required {\0A        return Err(ConsumerError::Write(WriteError::OutputTooSmall {\0A            required,\0A            available: output.len(),\0A        }));\0A    }\0A    let prefix = &mut output[..required];\0A    prefix[MAGIC_OFFSET] = MAGIC;\0A    prefix[SCHEMA_OFFSET] = SCHEMA;\0A    prefix[ENTITY_COUNT_OFFSET] = entity_count;\0A    prefix[TYPE_COUNT_OFFSET] = type_count;\0A    let mut cursor = HEADER_BYTES;\0A    for entity in entities {\0A        prefix[cursor..cursor + ENTITY_BYTES].copy_from_slice(&entity.raw.to_le_bytes());\0A        cursor += ENTITY_BYTES;\0A    }\0A    for ty in types {\0A        prefix[cursor..cursor + TYPE_BYTES].copy_from_slice(&ty.raw.to_le_bytes());\0A        cursor += TYPE_BYTES;\0A    }\0A    let view = match FragmentView::validate(prefix) {\0A        Ok(view) => view,\0A        Err(error) => return Err(ConsumerError::Validate(error)),\0A    };\0A    let entities = view.entity_ids().count();\0A    let types = view.type_ids().count();\0A    Ok(entities + types)\0A}\0A\0Afn assert_equivalent(entities: &[EntityId], types: &[TypeId], available: usize) {\0A    let mut prepared_output = [0xa5; 23];\0A    let mut manual_output = [0xa5; 23];\0A    let prepared_result = prepared_whole_consumer(\0A        black_box(entities),\0A        black_box(types),\0A        black_box(&mut prepared_output[..available]),\0A    );\0A    let manual_result = manual_single_pass_control(\0A        black_box(entities),\0A        black_box(types),\0A        black_box(&mut manual_output[..available]),\0A    );\0A    assert_eq!(prepared_result, manual_result);\0A    assert_eq!(prepared_output, manual_output);\0A}\0A\0A#[test]\0Afn prepared_and_manual_whole_consumers_are_equivalent() {\0A    let entities = [EntityId::new(0x0102_0304), EntityId::new(0x0506_0708)];\0A    let types = [TypeId::new(0xa0b0_c0d0), TypeId::new(0x1020_3040)];\0A    let three_entities = [EntityId::new(1), EntityId::new(2), EntityId::new(3)];\0A    let three_types = [TypeId::new(4), TypeId::new(5), TypeId::new(6)];\0A    assert_equivalent(&[], &[], 4);\0A    assert_equivalent(&entities[..1], &types[..1], 12);\0A    assert_equivalent(&entities, &types, 20);\0A    assert_equivalent(&entities[..1], &[], 8);\0A    assert_equivalent(&[], &types[..1], 8);\0A    assert_equivalent(&entities, &[], 12);\0A    assert_equivalent(&[], &types, 12);\0A    assert_equivalent(&entities[..1], &types, 16);\0A    assert_equivalent(&entities, &types[..1], 16);\0A    assert_equivalent(&entities[..], &[], 0);\0A    assert_equivalent(&[], &types[..], 0);\0A    assert_equivalent(&entities[..], &types[..], 0);\0A    assert_equivalent(&three_entities, &[], 0);\0A    assert_equivalent(&[], &three_types, 0);\0A    assert_equivalent(&three_entities, &three_types, 0);\0A    for available in 0..20 {\0A        assert_equivalent(&entities, &types, available);\0A    }\0A    let source = include_str!(\22prepared_consumer.rs\22);\0A    for marker in [\0A        \22fn prepared_whole_consumer\22,\0A        \22fn manual_single_pass_control\22,\0A    ] {\0A        let start = match source.find(marker) {\0A            Some(start) => start,\0A            None => panic!(\22callable source missing\22),\0A        };\0A        let body = &source[start..];\0A        let end = match body.find(\22\\n}\\n\22) {\0A            Some(end) => end,\0A            None => panic!(\22callable source closing brace missing\22),\0A        };\0A        assert_eq!(body[..end].matches(\22FragmentView::validate\22).count(), 1);\0A    }\0A}\0A", align 1
@alloc_56105bc765d39b007aae1d24445a5f7d = private unnamed_addr constant [23 x i8] c"callable source missing", align 1
@alloc_0eb7e310050072805af9487b58c4035d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_63c269227ccc4ad1eb0f705675a3abbe, [16 x i8] c"1\00\00\00\00\00\00\00\99\00\00\00\15\00\00\00" }>, align 8
@alloc_24028a94044fca6d4a8bfbb1fadd3876 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_63c269227ccc4ad1eb0f705675a3abbe, [16 x i8] c"1\00\00\00\00\00\00\00\9B\00\00\00\1B\00\00\00" }>, align 8
@alloc_e89cb6afc643eac20b05a0b577b5e8bc = private unnamed_addr constant [3 x i8] c"\0A}\0A", align 1
@alloc_6b25b981d6dcb0f81ae5433ae5833550 = private unnamed_addr constant [37 x i8] c"callable source closing brace missing", align 1
@alloc_3f1972d8ea19ee8686ea812b9669179e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_63c269227ccc4ad1eb0f705675a3abbe, [16 x i8] c"1\00\00\00\00\00\00\00\9E\00\00\00\15\00\00\00" }>, align 8
@alloc_4c92989ea71fda7e0c89e82a9cab1489 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_63c269227ccc4ad1eb0f705675a3abbe, [16 x i8] c"1\00\00\00\00\00\00\00\A0\00\00\00\18\00\00\00" }>, align 8
@alloc_7a807194ba7bcc2f917ecb6ee3f0af2a = private unnamed_addr constant [22 x i8] c"FragmentView::validate", align 1
@alloc_edb3ed16ed07237eac14eb16826c52e0 = private unnamed_addr constant [8 x i8] c"\01\00\00\00\00\00\00\00", align 8
@alloc_7b2885fbf347689c42120fce9d13749d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_63c269227ccc4ad1eb0f705675a3abbe, [16 x i8] c"1\00\00\00\00\00\00\00\A0\00\00\00\09\00\00\00" }>, align 8
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format12PrepareErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer }>, align 8
@alloc_ff99525767786baa5dc7e956e06d005e = private unnamed_addr constant [7 x i8] c"Prepare", align 1
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format10WriteErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer }>, align 8
@alloc_6b7483292c41e5f1002b8b441a63be1a = private unnamed_addr constant [5 x i8] c"Write", align 1
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format13FragmentErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer }>, align 8
@alloc_9734c9124d3f60537957ec8c47f6ebf4 = private unnamed_addr constant [8 x i8] c"Validate", align 1
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRjNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer }>, align 8
@alloc_ea8e8baf0be5855bbef17ce48226036b = private unnamed_addr constant [17 x i8] c"TruncatedEnvelope", align 1
@alloc_b31c6c8dca3d1da07e1eee656fa2f5cc = private unnamed_addr constant [6 x i8] c"actual", align 1
@alloc_d7b9b6c1829de9592f5bc6e83c4fc424 = private unnamed_addr constant [5 x i8] c"Magic", align 1
@alloc_d102eb289abff9d0655d27bf114c0746 = private unnamed_addr constant [6 x i8] c"Schema", align 1
@alloc_c904b8fe89a4f835804b02bd44018d9c = private unnamed_addr constant [11 x i8] c"EntityCount", align 1
@alloc_b5a34892e83b03f9728fdba51e681f6f = private unnamed_addr constant [9 x i8] c"TypeCount", align 1
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt }>, align 8
@alloc_4d3c10a7785e3cacd7635396354c2688 = private unnamed_addr constant [8 x i8] c"Geometry", align 1
@alloc_bebfed686e6a6f31c99c69b171066b8a = private unnamed_addr constant [8 x i8] c"expected", align 1
@alloc_5ab5ad54a633166dad8479b7b463c0d3 = private unnamed_addr constant [14 x i8] c"OutputTooSmall", align 1
@alloc_715ad17152b7a3dfcbb2abff840befeb = private unnamed_addr constant [8 x i8] c"required", align 1
@alloc_700d5d683c25860e3d40207214c9c99c = private unnamed_addr constant [9 x i8] c"available", align 1
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1
@vtable.9 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorNtB6_5Debug3fmtBx_ }>, align 8
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1
@alloc_de5e2f1dd01253ae804bfe6ba3503da0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ee38938c8929eed18faaff5d8f37cd9b, [16 x i8] c"k\00\00\00\00\00\00\00k\04\00\00$\00\00\00" }>, align 8

; <core::str::pattern::TwoWaySearcher>::next::<core::str::pattern::MatchOnly>
; Function Attrs: inlinehint uwtable
define internal fastcc void @_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef nonnull align 8 captures(none) dereferenceable(64) %self, ptr noalias noundef nonnull readonly captures(none) %haystack.0, i64 noundef range(i64 0, -9223372036854775808) %haystack.1, ptr noalias noundef nonnull readonly captures(none) %needle.0, i64 noundef range(i64 0, -9223372036854775808) %needle.1, i1 noundef zeroext %long_period) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %needle_last = add nsw i64 %needle.1, -1
  %.promoted = load i64, ptr %0, align 8
  %index24 = add i64 %needle_last, %.promoted
  %_5325 = icmp ult i64 %index24, %haystack.1
  br i1 %_5325, label %bb39.lr.ph, label %bb40

bb39.lr.ph:                                       ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %_58 = load i64, ptr %1, align 8, !noundef !3
  %v1 = load i64, ptr %self, align 8
  %2 = getelementptr inbounds nuw i8, ptr %self, i64 48
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_48 = load i64, ptr %3, align 8
  %4 = sub i64 %needle.1, %_48
  %.promoted27 = load i64, ptr %2, align 8
  br label %bb39

bb40:                                             ; preds = %bb37, %start
  store i64 %haystack.1, ptr %0, align 8
  br label %bb38

bb39:                                             ; preds = %bb39.lr.ph, %bb37
  %v229 = phi i64 [ %.promoted27, %bb39.lr.ph ], [ %v228, %bb37 ]
  %index26 = phi i64 [ %index24, %bb39.lr.ph ], [ %index, %bb37 ]
  %5 = phi i64 [ %.promoted, %bb39.lr.ph ], [ %10, %bb37 ]
  %_55 = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %index26
  %tail_byte = load i8, ptr %_55, align 1, !noundef !3
  %_60 = and i8 %tail_byte, 63
  %_59 = zext nneg i8 %_60 to i64
  %6 = shl nuw i64 1, %_59
  %7 = and i64 %6, %_58
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %bb10, label %bb9

bb38:                                             ; preds = %bb34, %bb40
  %storemerge = phi i64 [ 0, %bb40 ], [ 1, %bb34 ]
  store i64 %storemerge, ptr %_0, align 8
  ret void

bb10:                                             ; preds = %bb39
  %9 = add i64 %5, %needle.1
  store i64 %9, ptr %0, align 8
  br i1 %long_period, label %bb37, label %bb37.sink.split

bb9:                                              ; preds = %bb39
  %_0.sroa.0.0.i = tail call i64 @llvm.umax.i64(i64 %v229, i64 %v1)
  %start1.sroa.0.0 = select i1 %long_period, i64 %v1, i64 %_0.sroa.0.0.i
  %umax40 = tail call i64 @llvm.umax.i64(i64 %start1.sroa.0.0, i64 %needle.1)
  br label %bb16

bb37.sink.split:                                  ; preds = %bb10, %bb19, %bb29
  %.sink = phi i64 [ %4, %bb29 ], [ 0, %bb19 ], [ 0, %bb10 ]
  %.ph = phi i64 [ %16, %bb29 ], [ %20, %bb19 ], [ %9, %bb10 ]
  store i64 %.sink, ptr %2, align 8
  br label %bb37

bb37:                                             ; preds = %bb37.sink.split, %bb19, %bb29, %bb10
  %v228 = phi i64 [ %v229, %bb19 ], [ %v229, %bb10 ], [ %v229, %bb29 ], [ %.sink, %bb37.sink.split ]
  %10 = phi i64 [ %20, %bb19 ], [ %9, %bb10 ], [ %16, %bb29 ], [ %.ph, %bb37.sink.split ]
  %index = add i64 %needle_last, %10
  %_53 = icmp ult i64 %index, %haystack.1
  br i1 %_53, label %bb39, label %bb40

bb16:                                             ; preds = %bb18, %bb9
  %iter.sroa.0.0 = phi i64 [ %start1.sroa.0.0, %bb9 ], [ %_65, %bb18 ]
  %exitcond.not = icmp eq i64 %iter.sroa.0.0, %umax40
  br i1 %exitcond.not, label %bb43, label %bb42

bb43:                                             ; preds = %bb16
  %start2.sroa.0.0 = select i1 %long_period, i64 0, i64 %v229
  br label %bb26

bb42:                                             ; preds = %bb16
  %_28 = add i64 %iter.sroa.0.0, %5
  %_30 = icmp ult i64 %_28, %haystack.1
  br i1 %_30, label %bb18, label %panic8

bb26:                                             ; preds = %bb28, %bb43
  %iter3.sroa.2.0 = phi i64 [ %v1, %bb43 ], [ %_73, %bb28 ]
  %_70 = icmp ult i64 %start2.sroa.0.0, %iter3.sroa.2.0
  br i1 %_70, label %bb46, label %bb47

bb47:                                             ; preds = %bb26
  %11 = add i64 %5, %needle.1
  store i64 %11, ptr %0, align 8
  br i1 %long_period, label %bb34, label %bb33

bb46:                                             ; preds = %bb26
  %_73 = add i64 %iter3.sroa.2.0, -1
  %_43 = icmp ult i64 %_73, %needle.1
  br i1 %_43, label %bb27, label %panic

bb33:                                             ; preds = %bb47
  store i64 0, ptr %2, align 8
  br label %bb34

bb34:                                             ; preds = %bb33, %bb47
  %12 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %5, ptr %12, align 8, !alias.scope !4
  %13 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %11, ptr %13, align 8, !alias.scope !4
  br label %bb38

bb27:                                             ; preds = %bb46
  %_45 = add i64 %_73, %5
  %_47 = icmp ult i64 %_45, %haystack.1
  br i1 %_47, label %bb28, label %panic5

panic:                                            ; preds = %bb46
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %_73, i64 noundef %needle.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_68bb27fa7fd7af0b8edb2570ef014cd2) #14
  unreachable

bb28:                                             ; preds = %bb27
  %14 = getelementptr inbounds nuw i8, ptr %needle.0, i64 %_73
  %_42 = load i8, ptr %14, align 1, !noundef !3
  %15 = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %_45
  %_44 = load i8, ptr %15, align 1, !noundef !3
  %_41.not = icmp eq i8 %_42, %_44
  br i1 %_41.not, label %bb26, label %bb29

panic5:                                           ; preds = %bb27
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %_45, i64 noundef %haystack.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8deac4fa778727f9c004a28bc20bcda6) #14
  unreachable

bb29:                                             ; preds = %bb28
  %16 = add i64 %_48, %5
  store i64 %16, ptr %0, align 8
  br i1 %long_period, label %bb37, label %bb37.sink.split

bb18:                                             ; preds = %bb42
  %_65 = add i64 %iter.sroa.0.0, 1
  %17 = getelementptr inbounds nuw i8, ptr %needle.0, i64 %iter.sroa.0.0
  %_25 = load i8, ptr %17, align 1, !noundef !3
  %18 = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %_28
  %_27 = load i8, ptr %18, align 1, !noundef !3
  %_24.not = icmp eq i8 %_25, %_27
  br i1 %_24.not, label %bb16, label %bb19

panic8:                                           ; preds = %bb42
  %19 = add i64 %start1.sroa.0.0, %5
  %umax = tail call i64 @llvm.umax.i64(i64 %haystack.1, i64 %19)
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %umax, i64 noundef %haystack.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8ae9795802ad53c9398ce2776784dbc3) #14
  unreachable

bb19:                                             ; preds = %bb18
  %_32 = add i64 %5, 1
  %_31 = add i64 %_32, %iter.sroa.0.0
  %20 = sub i64 %_31, %v1
  store i64 %20, ptr %0, align 8
  br i1 %long_period, label %bb37, label %bb37.sink.split
}

; std::rt::lang_start::<()>
; Function Attrs: uwtable
define hidden noundef i64 @_RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs21ATSyVuzIl_17prepared_consumer(ptr noundef nonnull %main, i64 noundef %argc, ptr noundef %argv, i8 noundef %sigpipe) unnamed_addr #1 {
start:
  %_7 = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_7)
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call noundef i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr noundef nonnull %_7, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48) @vtable.1, i64 noundef %argc, ptr noundef %argv, i8 noundef %sigpipe)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7)
  ret i64 %_0
}

; core::panicking::assert_failed::<[u8; 23], [u8; 23]>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
define internal fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedAhj17_BL_ECs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef nonnull readonly captures(address, read_provenance) dereferenceable(23) %0, ptr noalias noundef nonnull readonly captures(address, read_provenance) dereferenceable(23) %1) unnamed_addr #2 {
start:
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  store ptr %0, ptr %left, align 8
  store ptr %1, ptr %right, align 8
; call core::panicking::assert_failed_inner
  call void @_RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner(i8 noundef 0, ptr noundef nonnull %left, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.2, ptr noundef nonnull %right, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.2, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_cb00222c11a9560fc2db0458e2b363a2) #14
  unreachable
}

; core::panicking::assert_failed::<core::result::Result<usize, prepared_consumer::ConsumerError>, core::result::Result<usize, prepared_consumer::ConsumerError>>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
define internal fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedINtNtB4_6result6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorEBL_EB1a_(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) %0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) %1) unnamed_addr #2 {
start:
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  store ptr %0, ptr %left, align 8
  store ptr %1, ptr %right, align 8
; call core::panicking::assert_failed_inner
  call void @_RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner(i8 noundef 0, ptr noundef nonnull %left, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.3, ptr noundef nonnull %right, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.3, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_16613a034bc3772cbb719c5113a258a5) #14
  unreachable
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline uwtable
define internal fastcc void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs21ATSyVuzIl_17prepared_consumer(ptr noundef nonnull readonly captures(none) %f) unnamed_addr #3 {
start:
  tail call void %f()
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !7
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint uwtable
define internal noundef i32 @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %_1) unnamed_addr #0 {
start:
  %_4 = load ptr, ptr %_1, align 8, !nonnull !3, !noundef !3
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  tail call fastcc void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs21ATSyVuzIl_17prepared_consumer(ptr noundef nonnull %_4)
  ret i32 0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint uwtable
define internal noundef i32 @_RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs21ATSyVuzIl_17prepared_consumer(ptr noundef readonly captures(none) %_1) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = load ptr, ptr %_1, align 8, !nonnull !3, !noundef !3
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  tail call fastcc void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs21ATSyVuzIl_17prepared_consumer(ptr noundef nonnull readonly %0), !noalias !8
  ret i32 0
}

; prepared_consumer::assert_equivalent
; Function Attrs: uwtable
define internal fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.0, i64 noundef range(i64 0, 4) %entities.1, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.0, i64 noundef range(i64 0, 4) %types.1, i64 noundef range(i64 0, 21) %available) unnamed_addr #1 {
start:
  %0 = alloca [16 x i8], align 8
  %1 = alloca [16 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %3 = alloca [16 x i8], align 8
  %4 = alloca [16 x i8], align 8
  %5 = alloca [16 x i8], align 8
  %manual_result = alloca [24 x i8], align 8
  %prepared_result = alloca [24 x i8], align 8
  %manual_output = alloca [23 x i8], align 1
  %prepared_output = alloca [23 x i8], align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %prepared_output)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %prepared_output, i8 -91, i64 23, i1 false)
  call void @llvm.lifetime.start.p0(ptr nonnull %manual_output)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %manual_output, i8 -91, i64 23, i1 false)
  call void @llvm.lifetime.start.p0(ptr nonnull %prepared_result)
  call void @llvm.lifetime.start.p0(ptr nonnull %5)
  store ptr %entities.0, ptr %5, align 8
  %6 = getelementptr inbounds nuw i8, ptr %5, i64 8
  store i64 %entities.1, ptr %6, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %5) #15, !srcloc !7
  %_7.0 = load ptr, ptr %5, align 8, !nonnull !3, !align !11, !noundef !3
  %_7.1 = load i64, ptr %6, align 8, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %5)
  call void @llvm.lifetime.start.p0(ptr nonnull %4)
  store ptr %types.0, ptr %4, align 8
  %7 = getelementptr inbounds nuw i8, ptr %4, i64 8
  store i64 %types.1, ptr %7, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %4) #15, !srcloc !7
  %_8.0 = load ptr, ptr %4, align 8, !nonnull !3, !align !11, !noundef !3
  %_8.1 = load i64, ptr %7, align 8, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %4)
  call void @llvm.lifetime.start.p0(ptr nonnull %3)
  store ptr %prepared_output, ptr %3, align 8
  %8 = getelementptr inbounds nuw i8, ptr %3, i64 8
  store i64 %available, ptr %8, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %3) #15, !srcloc !7
  %_9.0 = load ptr, ptr %3, align 8, !nonnull !3, !noundef !3
  %_9.1 = load i64, ptr %8, align 8, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %3)
; call prepared_consumer::prepared_whole_consumer
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer23prepared_whole_consumer(ptr noalias noundef align 8 captures(none) dereferenceable(24) %prepared_result, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %_7.0, i64 noundef %_7.1, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %_8.0, i64 noundef %_8.1, ptr noalias noundef nonnull %_9.0, i64 noundef %_9.1)
  call void @llvm.lifetime.start.p0(ptr nonnull %manual_result)
  call void @llvm.lifetime.start.p0(ptr nonnull %2)
  store ptr %entities.0, ptr %2, align 8
  %9 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i64 %entities.1, ptr %9, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %2) #15, !srcloc !7
  %_13.0 = load ptr, ptr %2, align 8, !nonnull !3, !align !11, !noundef !3
  %_13.1 = load i64, ptr %9, align 8, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %2)
  call void @llvm.lifetime.start.p0(ptr nonnull %1)
  store ptr %types.0, ptr %1, align 8
  %10 = getelementptr inbounds nuw i8, ptr %1, i64 8
  store i64 %types.1, ptr %10, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %1) #15, !srcloc !7
  %_14.0 = load ptr, ptr %1, align 8, !nonnull !3, !align !11, !noundef !3
  %_14.1 = load i64, ptr %10, align 8, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %1)
  call void @llvm.lifetime.start.p0(ptr nonnull %0)
  store ptr %manual_output, ptr %0, align 8
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 8
  store i64 %available, ptr %11, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %0) #15, !srcloc !7
  %_15.0 = load ptr, ptr %0, align 8, !nonnull !3, !noundef !3
  %_15.1 = load i64, ptr %11, align 8, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %0)
; call prepared_consumer::manual_single_pass_control
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer26manual_single_pass_control(ptr noalias noundef align 8 captures(none) dereferenceable(24) %manual_result, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %_13.0, i64 noundef %_13.1, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %_14.0, i64 noundef %_14.1, ptr noalias noundef nonnull %_15.0, i64 noundef %_15.1)
  call void @llvm.experimental.noalias.scope.decl(metadata !12)
  call void @llvm.experimental.noalias.scope.decl(metadata !15)
  %12 = load i8, ptr %prepared_result, align 8, !range !17, !alias.scope !12, !noalias !15, !noundef !3
  %13 = icmp ne i8 %12, -1
  %14 = load i8, ptr %manual_result, align 8, !range !17, !alias.scope !15, !noalias !12, !noundef !3
  %15 = icmp eq i8 %14, -1
  %not..i = xor i1 %15, true
  %_5.i = xor i1 %13, %15
  br i1 %_5.i, label %bb1.i, label %bb5, !prof !18

bb1.i:                                            ; preds = %start
  br i1 %13, label %bb4.i, label %_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3cmp9PartialEq2eqBM_.exit

bb4.i:                                            ; preds = %bb1.i
  call void @llvm.assume(i1 %not..i)
  call void @llvm.experimental.noalias.scope.decl(metadata !19)
  call void @llvm.experimental.noalias.scope.decl(metadata !22)
  %16 = add nsw i8 %12, -6
  %17 = icmp samesign ugt i8 %12, 5
  %narrow.i.i = select i1 %17, i8 %16, i8 2
  %18 = add nsw i8 %14, -6
  %19 = icmp samesign ugt i8 %14, 5
  %narrow1.i.i = select i1 %19, i8 %18, i8 2
  %_5.i.i = icmp eq i8 %narrow.i.i, %narrow1.i.i
  br i1 %_5.i.i, label %bb1.i.i, label %bb5, !prof !18

bb1.i.i:                                          ; preds = %bb4.i
  switch i8 %narrow.i.i, label %bb16.i.i [
    i8 0, label %bb3.i.i
    i8 1, label %bb4.i.i
    i8 2, label %bb5.i.i
  ]

bb16.i.i:                                         ; preds = %bb1.i.i
  unreachable

bb3.i.i:                                          ; preds = %bb1.i.i
  %20 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 8
  %_17.i.i = load i64, ptr %20, align 8, !range !24, !alias.scope !25, !noalias !26, !noundef !3
  %21 = getelementptr inbounds nuw i8, ptr %manual_result, i64 8
  %_18.i.i = load i64, ptr %21, align 8, !range !24, !alias.scope !26, !noalias !25, !noundef !3
  %_19.i.i = icmp eq i64 %_17.i.i, %_18.i.i
  br i1 %_19.i.i, label %bb11.i.i, label %bb5, !prof !18

bb4.i.i:                                          ; preds = %bb1.i.i
  %22 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 8
  %_13.i.i = load i64, ptr %22, align 8, !alias.scope !25, !noalias !26, !noundef !3
  %23 = getelementptr inbounds nuw i8, ptr %manual_result, i64 8
  %_14.i.i = load i64, ptr %23, align 8, !alias.scope !26, !noalias !25, !noundef !3
  %_12.i.i = icmp eq i64 %_13.i.i, %_14.i.i
  br i1 %_12.i.i, label %bb8.i.i, label %bb5, !prof !18

bb5.i.i:                                          ; preds = %bb1.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !27)
  call void @llvm.experimental.noalias.scope.decl(metadata !30)
  %_5.i.i.i = icmp eq i8 %12, %14
  br i1 %_5.i.i.i, label %bb1.i.i.i, label %bb5, !prof !18

bb1.i.i.i:                                        ; preds = %bb5.i.i
  switch i8 %12, label %default.unreachable1.i.i.i [
    i8 0, label %bb3.i.i.i
    i8 1, label %bb4.i.i.i
    i8 2, label %bb5.i.i.i
    i8 3, label %bb6.i.i.i
    i8 4, label %bb7.i.i.i
    i8 5, label %bb8.i.i.i
  ]

default.unreachable1.i.i.i:                       ; preds = %bb1.i.i.i
  unreachable

bb3.i.i.i:                                        ; preds = %bb1.i.i.i
  %24 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 8
  %_31.i.i.i = load i64, ptr %24, align 8, !alias.scope !32, !noalias !33, !noundef !3
  %25 = getelementptr inbounds nuw i8, ptr %manual_result, i64 8
  %_32.i.i.i = load i64, ptr %25, align 8, !alias.scope !33, !noalias !32, !noundef !3
  %26 = icmp eq i64 %_31.i.i.i, %_32.i.i.i
  br i1 %26, label %bb4, label %bb5, !prof !34

bb4.i.i.i:                                        ; preds = %bb1.i.i.i
  %27 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 1
  %_29.i.i.i = load i8, ptr %27, align 1, !alias.scope !32, !noalias !33, !noundef !3
  %28 = getelementptr inbounds nuw i8, ptr %manual_result, i64 1
  %_30.i.i.i = load i8, ptr %28, align 1, !alias.scope !33, !noalias !32, !noundef !3
  %29 = icmp eq i8 %_29.i.i.i, %_30.i.i.i
  br i1 %29, label %bb4, label %bb5, !prof !34

bb5.i.i.i:                                        ; preds = %bb1.i.i.i
  %30 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 1
  %_27.i.i.i = load i8, ptr %30, align 1, !alias.scope !32, !noalias !33, !noundef !3
  %31 = getelementptr inbounds nuw i8, ptr %manual_result, i64 1
  %_28.i.i.i = load i8, ptr %31, align 1, !alias.scope !33, !noalias !32, !noundef !3
  %32 = icmp eq i8 %_27.i.i.i, %_28.i.i.i
  br i1 %32, label %bb4, label %bb5, !prof !34

bb6.i.i.i:                                        ; preds = %bb1.i.i.i
  %33 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 1
  %_25.i.i.i = load i8, ptr %33, align 1, !alias.scope !32, !noalias !33, !noundef !3
  %34 = getelementptr inbounds nuw i8, ptr %manual_result, i64 1
  %_26.i.i.i = load i8, ptr %34, align 1, !alias.scope !33, !noalias !32, !noundef !3
  %35 = icmp eq i8 %_25.i.i.i, %_26.i.i.i
  br i1 %35, label %bb4, label %bb5, !prof !34

bb7.i.i.i:                                        ; preds = %bb1.i.i.i
  %36 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 1
  %_23.i.i.i = load i8, ptr %36, align 1, !alias.scope !32, !noalias !33, !noundef !3
  %37 = getelementptr inbounds nuw i8, ptr %manual_result, i64 1
  %_24.i.i.i = load i8, ptr %37, align 1, !alias.scope !33, !noalias !32, !noundef !3
  %38 = icmp eq i8 %_23.i.i.i, %_24.i.i.i
  br i1 %38, label %bb4, label %bb5, !prof !34

bb8.i.i.i:                                        ; preds = %bb1.i.i.i
  %39 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 8
  %_21.i.i.i = load i64, ptr %39, align 8, !alias.scope !32, !noalias !33, !noundef !3
  %40 = getelementptr inbounds nuw i8, ptr %manual_result, i64 8
  %_22.i.i.i = load i64, ptr %40, align 8, !alias.scope !33, !noalias !32, !noundef !3
  %_20.i.i.i = icmp eq i64 %_21.i.i.i, %_22.i.i.i
  br i1 %_20.i.i.i, label %bb9.i.i.i, label %bb5, !prof !18

bb9.i.i.i:                                        ; preds = %bb8.i.i.i
  %41 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 16
  %_33.i.i.i = load i64, ptr %41, align 8, !alias.scope !32, !noalias !33, !noundef !3
  %42 = getelementptr inbounds nuw i8, ptr %manual_result, i64 16
  %_34.i.i.i = load i64, ptr %42, align 8, !alias.scope !33, !noalias !32, !noundef !3
  %43 = icmp eq i64 %_33.i.i.i, %_34.i.i.i
  br i1 %43, label %bb4, label %bb5, !prof !34

bb11.i.i:                                         ; preds = %bb3.i.i
  %44 = getelementptr inbounds nuw i8, ptr %manual_result, i64 16
  %45 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 16
  %_20.i.i = load i64, ptr %45, align 8, !alias.scope !25, !noalias !26, !noundef !3
  %_21.i.i = load i64, ptr %44, align 8, !alias.scope !26, !noalias !25, !noundef !3
  %46 = icmp eq i64 %_20.i.i, %_21.i.i
  br i1 %46, label %bb4, label %bb5, !prof !34

bb8.i.i:                                          ; preds = %bb4.i.i
  %47 = getelementptr inbounds nuw i8, ptr %prepared_result, i64 16
  %_15.i.i = load i64, ptr %47, align 8, !alias.scope !25, !noalias !26, !noundef !3
  %48 = getelementptr inbounds nuw i8, ptr %manual_result, i64 16
  %_16.i.i = load i64, ptr %48, align 8, !alias.scope !26, !noalias !25, !noundef !3
  %49 = icmp eq i64 %_15.i.i, %_16.i.i
  br i1 %49, label %bb4, label %bb5, !prof !34

_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3cmp9PartialEq2eqBM_.exit: ; preds = %bb1.i
  call void @llvm.assume(i1 %15)
  %__self_0.i = getelementptr inbounds nuw i8, ptr %prepared_result, i64 8
  %__arg1_0.i = getelementptr inbounds nuw i8, ptr %manual_result, i64 8
  %__self_0.val.i = load i64, ptr %__self_0.i, align 8, !alias.scope !12, !noalias !15, !noundef !3
  %__arg1_0.val.i = load i64, ptr %__arg1_0.i, align 8, !alias.scope !15, !noalias !12, !noundef !3
  %_0.i.i = icmp eq i64 %__self_0.val.i, %__arg1_0.val.i
  br i1 %_0.i.i, label %bb4, label %bb5, !prof !34

bb5:                                              ; preds = %bb5.i.i, %bb4.i.i, %bb3.i.i, %bb4.i, %bb8.i.i.i, %start, %bb11.i.i, %bb5.i.i.i, %bb6.i.i.i, %bb8.i.i, %bb7.i.i.i, %bb9.i.i.i, %bb3.i.i.i, %bb4.i.i.i, %_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3cmp9PartialEq2eqBM_.exit
; call core::panicking::assert_failed::<core::result::Result<usize, prepared_consumer::ConsumerError>, core::result::Result<usize, prepared_consumer::ConsumerError>>
  call fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedINtNtB4_6result6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorEBL_EB1a_(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) %prepared_result, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) %manual_result) #14
  unreachable

bb4:                                              ; preds = %bb11.i.i, %bb5.i.i.i, %bb6.i.i.i, %bb8.i.i, %bb7.i.i.i, %bb9.i.i.i, %bb3.i.i.i, %bb4.i.i.i, %_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3cmp9PartialEq2eqBM_.exit
  %50 = call i32 @memcmp(ptr noundef nonnull dereferenceable(23) %prepared_output, ptr noundef nonnull dereferenceable(23) %manual_output, i64 23)
  %51 = icmp eq i32 %50, 0
  br i1 %51, label %bb6, label %bb7, !prof !35

bb7:                                              ; preds = %bb4
; call core::panicking::assert_failed::<[u8; 23], [u8; 23]>
  call fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedAhj17_BL_ECs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef readonly captures(address, read_provenance) dereferenceable(23) %prepared_output, ptr noalias noundef readonly captures(address, read_provenance) dereferenceable(23) %manual_output) #14
  unreachable

bb6:                                              ; preds = %bb4
  call void @llvm.lifetime.end.p0(ptr nonnull %manual_result)
  call void @llvm.lifetime.end.p0(ptr nonnull %prepared_result)
  call void @llvm.lifetime.end.p0(ptr nonnull %manual_output)
  call void @llvm.lifetime.end.p0(ptr nonnull %prepared_output)
  ret void
}

; prepared_consumer::prepared_whole_consumer
; Function Attrs: noinline uwtable
define internal fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer23prepared_whole_consumer(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) initializes((0, 1), (8, 16)) %_0, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.0, i64 noundef range(i64 0, 2305843009213693952) %entities.1, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.0, i64 noundef range(i64 0, 2305843009213693952) %types.1, ptr noalias noundef nonnull %output.0, i64 noundef range(i64 0, -9223372036854775808) %output.1) unnamed_addr #3 personality ptr @rust_eh_personality {
start:
  %_14 = alloca [48 x i8], align 8
  %_9 = alloca [24 x i8], align 8
  %prepared = alloca [48 x i8], align 8
  %_20.i = icmp samesign ugt i64 %entities.1, 255
  br i1 %_20.i, label %bb3, label %bb9.i

bb9.i:                                            ; preds = %start
  %_21.i = trunc nuw i64 %entities.1 to i8
  %_7.i = icmp samesign ugt i64 %entities.1, 2
  br i1 %_7.i, label %bb3, label %bb2.i

bb2.i:                                            ; preds = %bb9.i
  %or.cond = icmp samesign ugt i64 %types.1, 2
  br i1 %or.cond, label %bb3, label %bb4

bb3:                                              ; preds = %start, %bb9.i, %bb2.i
  %_4.sroa.16.0.ph = phi i64 [ %entities.1, %start ], [ %types.1, %bb2.i ], [ %entities.1, %bb9.i ]
  %_4.sroa.10.0.ph = phi i64 [ 0, %start ], [ 1, %bb2.i ], [ 0, %bb9.i ]
  store i8 6, ptr %_0, align 8
  %_8.sroa.47.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_4.sroa.10.0.ph, ptr %_8.sroa.47.0._0.sroa_idx, align 8
  %_8.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_4.sroa.16.0.ph, ptr %_8.sroa.5.0._0.sroa_idx, align 8
  br label %bb12

bb4:                                              ; preds = %bb2.i
  %_23.i = trunc nuw nsw i64 %types.1 to i8
  %0 = add nuw nsw i64 %types.1, %entities.1
  %1 = shl nuw nsw i64 %0, 2
  %output_len.i = add nuw nsw i64 %1, 4
  %2 = ptrtoint ptr %types.0 to i64
  store ptr %entities.0, ptr %prepared, align 8
  %_4.sroa.10.0.prepared.sroa_idx = getelementptr inbounds nuw i8, ptr %prepared, i64 8
  store i64 %entities.1, ptr %_4.sroa.10.0.prepared.sroa_idx, align 8
  %_4.sroa.16.0.prepared.sroa_idx = getelementptr inbounds nuw i8, ptr %prepared, i64 16
  store i64 %2, ptr %_4.sroa.16.0.prepared.sroa_idx, align 8
  %_4.sroa.22.0.prepared.sroa_idx = getelementptr inbounds nuw i8, ptr %prepared, i64 24
  store i64 %types.1, ptr %_4.sroa.22.0.prepared.sroa_idx, align 8
  %_4.sroa.23.0.prepared.sroa_idx = getelementptr inbounds nuw i8, ptr %prepared, i64 32
  store i64 %output_len.i, ptr %_4.sroa.23.0.prepared.sroa_idx, align 8
  %_4.sroa.24.0.prepared.sroa_idx = getelementptr inbounds nuw i8, ptr %prepared, i64 40
  store i8 %_21.i, ptr %_4.sroa.24.0.prepared.sroa_idx, align 8
  %_4.sroa.25.0.prepared.sroa_idx = getelementptr inbounds nuw i8, ptr %prepared, i64 41
  store i8 %_23.i, ptr %_4.sroa.25.0.prepared.sroa_idx, align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %_9)
; call <nudox_ir_format::PreparedFragment>::write_into
  call void @_RNvMs0_Csks33AUGQlhz_15nudox_ir_formatNtB5_16PreparedFragment10write_into(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_9, ptr noalias noundef nonnull readonly align 8 captures(none) dereferenceable(48) %prepared, ptr noalias noundef nonnull %output.0, i64 noundef %output.1)
  %_10 = load i64, ptr %_9, align 8, !range !24, !noundef !3
  %3 = trunc nuw i64 %_10 to i1
  %4 = getelementptr inbounds nuw i8, ptr %_9, i64 8
  %5 = getelementptr inbounds nuw i8, ptr %_9, i64 16
  %error.1 = load i64, ptr %5, align 8, !noundef !3
  br i1 %3, label %bb6, label %bb7

bb6:                                              ; preds = %bb4
  %error.0 = load i64, ptr %4, align 8, !noundef !3
  store i8 7, ptr %_0, align 8
  %_13.sroa.48.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %error.0, ptr %_13.sroa.48.0._0.sroa_idx, align 8
  %_13.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %error.1, ptr %_13.sroa.5.0._0.sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_9)
  br label %bb12

bb7:                                              ; preds = %bb4
  %prefix.0 = load ptr, ptr %4, align 8, !nonnull !3, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %_9)
  call void @llvm.lifetime.start.p0(ptr nonnull %_14)
; call <nudox_ir_format::FragmentView>::validate
  call void @_RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate(ptr noalias noundef nonnull sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_14, ptr noalias noundef nonnull readonly captures(address, read_provenance) %prefix.0, i64 noundef %error.1)
  %6 = load ptr, ptr %_14, align 8, !noundef !3
  %7 = icmp eq ptr %6, null
  br i1 %7, label %bb9, label %bb10

bb9:                                              ; preds = %bb7
  %8 = getelementptr inbounds nuw i8, ptr %_14, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %8, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_14)
  br label %bb12

bb10:                                             ; preds = %bb7
  %9 = getelementptr inbounds nuw i8, ptr %_14, i64 24
  %view.12 = load i64, ptr %9, align 8, !noundef !3
  %10 = getelementptr inbounds nuw i8, ptr %_14, i64 40
  %view.14 = load i64, ptr %10, align 8, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %_14)
  %_12.i9.i = icmp ugt i64 %view.12, 3
  %11 = add i64 %view.12, -4
  %12 = lshr i64 %11, 2
  %13 = add nuw nsw i64 %12, 1
  %accum.sroa.0.0.lcssa.i = select i1 %_12.i9.i, i64 %13, i64 0
  %_12.i9.i9 = icmp ugt i64 %view.14, 3
  %14 = add i64 %view.14, -4
  %15 = lshr i64 %14, 2
  %16 = add nuw nsw i64 %15, 1
  %accum.sroa.0.0.lcssa.i10 = select i1 %_12.i9.i9, i64 %16, i64 0
  %_22 = add nuw i64 %accum.sroa.0.0.lcssa.i10, %accum.sroa.0.0.lcssa.i
  %17 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_22, ptr %17, align 8
  store i8 -1, ptr %_0, align 8
  br label %bb12

bb12:                                             ; preds = %bb9, %bb6, %bb3, %bb10
  ret void
}

; prepared_consumer::manual_single_pass_control
; Function Attrs: noinline uwtable
define internal fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer26manual_single_pass_control(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef nonnull readonly align 4 captures(address) %entities.0, i64 noundef range(i64 0, 2305843009213693952) %entities.1, ptr noalias noundef nonnull readonly align 4 captures(address) %types.0, i64 noundef range(i64 0, 2305843009213693952) %types.1, ptr noalias noundef nonnull captures(address, read_provenance) %output.0, i64 noundef range(i64 0, -9223372036854775808) %output.1) unnamed_addr #3 personality ptr @rust_eh_personality {
start:
  %_58 = alloca [48 x i8], align 8
  %_68 = icmp samesign ugt i64 %entities.1, 255
  br i1 %_68, label %bb21, label %bb22

bb22:                                             ; preds = %start
  %_69 = trunc nuw i64 %entities.1 to i8
  %_9 = icmp samesign ugt i64 %entities.1, 2
  br i1 %_9, label %bb2, label %bb3

bb21:                                             ; preds = %start
  store i8 6, ptr %_0, align 8
  %_7.sroa.49.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 0, ptr %_7.sroa.49.0._0.sroa_idx, align 8
  %_7.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %entities.1, ptr %_7.sroa.5.0._0.sroa_idx, align 8
  br label %bb20

bb3:                                              ; preds = %bb22
  %_70 = icmp samesign ugt i64 %types.1, 255
  br i1 %_70, label %bb23, label %bb24

bb2:                                              ; preds = %bb22
  store i8 6, ptr %_0, align 8
  %_10.sroa.410.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 0, ptr %_10.sroa.410.0._0.sroa_idx, align 8
  %_10.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %entities.1, ptr %_10.sroa.5.0._0.sroa_idx, align 8
  br label %bb20

bb24:                                             ; preds = %bb3
  %_71 = trunc nuw i64 %types.1 to i8
  %_17 = icmp samesign ugt i64 %types.1, 2
  br i1 %_17, label %bb4, label %bb5

bb23:                                             ; preds = %bb3
  store i8 6, ptr %_0, align 8
  %_15.sroa.411.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 1, ptr %_15.sroa.411.0._0.sroa_idx, align 8
  %_15.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %types.1, ptr %_15.sroa.5.0._0.sroa_idx, align 8
  br label %bb20

bb5:                                              ; preds = %bb24
  %0 = add nuw nsw i64 %types.1, %entities.1
  %1 = shl nuw nsw i64 %0, 2
  %required = add nuw nsw i64 %1, 4
  %_24 = icmp samesign ult i64 %output.1, %required
  br i1 %_24, label %bb6, label %bb8

bb4:                                              ; preds = %bb24
  store i8 6, ptr %_0, align 8
  %_18.sroa.412.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 1, ptr %_18.sroa.412.0._0.sroa_idx, align 8
  %_18.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %types.1, ptr %_18.sroa.5.0._0.sroa_idx, align 8
  br label %bb20

bb6:                                              ; preds = %bb5
  store i8 7, ptr %_0, align 8
  %_26.sroa.413.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %required, ptr %_26.sroa.413.0._0.sroa_idx, align 8
  %_26.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %output.1, ptr %_26.sroa.5.0._0.sroa_idx, align 8
  br label %bb20

bb8:                                              ; preds = %bb5
  store i8 -63, ptr %output.0, align 1
  %2 = getelementptr inbounds nuw i8, ptr %output.0, i64 1
  store i8 1, ptr %2, align 1
  %3 = getelementptr inbounds nuw i8, ptr %output.0, i64 2
  store i8 %_69, ptr %3, align 1
  %4 = getelementptr inbounds nuw i8, ptr %output.0, i64 3
  store i8 %_71, ptr %4, align 1
  %_8824 = icmp eq i64 %entities.1, 0
  br i1 %_8824, label %bb29, label %bb31

bb29:                                             ; preds = %bb31, %bb31.1, %bb8
  %cursor.sroa.0.0.lcssa = phi i64 [ 4, %bb8 ], [ 8, %bb31 ], [ 12, %bb31.1 ]
  %_107.idx = shl nuw nsw i64 %types.1, 2
  %_107 = getelementptr inbounds nuw i8, ptr %types.0, i64 %_107.idx
  %_11427 = icmp eq i64 %types.1, 0
  br i1 %_11427, label %bb36, label %bb37.preheader

bb37.preheader:                                   ; preds = %bb29
  %5 = add nuw nsw i64 %cursor.sroa.0.0.lcssa, 3
  %umax = tail call i64 @llvm.umax.i64(i64 %required, i64 %5)
  %6 = sub i64 %umax, %cursor.sroa.0.0.lcssa
  %7 = lshr i64 %6, 2
  %8 = add nsw i64 %_107.idx, -4
  %9 = lshr exact i64 %8, 2
  %umin = tail call i64 @llvm.umin.i64(i64 %7, i64 %9)
  %min.iters.check = icmp samesign ult i64 %umin, 16
  br i1 %min.iters.check, label %bb37.preheader47, label %vector.ph

bb37.preheader47:                                 ; preds = %vector.body, %bb37.preheader
  %iter1.sroa.0.029.ph = phi ptr [ %types.0, %bb37.preheader ], [ %14, %vector.body ]
  %cursor.sroa.0.128.ph = phi i64 [ %cursor.sroa.0.0.lcssa, %bb37.preheader ], [ %16, %vector.body ]
  br label %bb37

vector.ph:                                        ; preds = %bb37.preheader
  %10 = add nuw nsw i64 %umin, 1
  %n.mod.vf = and i64 %10, 15
  %11 = icmp eq i64 %n.mod.vf, 0
  %12 = select i1 %11, i64 16, i64 %n.mod.vf
  %n.vec = sub nsw i64 %10, %12
  %13 = shl i64 %n.vec, 2
  %14 = getelementptr i8, ptr %types.0, i64 %13
  %15 = shl i64 %n.vec, 2
  %16 = add i64 %cursor.sroa.0.0.lcssa, %15
  %17 = getelementptr i8, ptr %output.0, i64 %cursor.sroa.0.0.lcssa
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %offset.idx = shl i64 %index, 2
  %next.gep = getelementptr i8, ptr %types.0, i64 %offset.idx
  %18 = shl i64 %index, 2
  %19 = getelementptr i8, ptr %17, i64 %18
  %20 = getelementptr i8, ptr %next.gep, i64 16
  %21 = getelementptr i8, ptr %next.gep, i64 32
  %22 = getelementptr i8, ptr %next.gep, i64 48
  %wide.load = load <4 x i32>, ptr %next.gep, align 4
  %wide.load43 = load <4 x i32>, ptr %20, align 4
  %wide.load44 = load <4 x i32>, ptr %21, align 4
  %wide.load45 = load <4 x i32>, ptr %22, align 4
  %23 = getelementptr inbounds nuw i8, ptr %19, i64 16
  %24 = getelementptr inbounds nuw i8, ptr %19, i64 32
  %25 = getelementptr inbounds nuw i8, ptr %19, i64 48
  store <4 x i32> %wide.load, ptr %19, align 1, !alias.scope !36
  store <4 x i32> %wide.load43, ptr %23, align 1, !alias.scope !36
  store <4 x i32> %wide.load44, ptr %24, align 1, !alias.scope !36
  store <4 x i32> %wide.load45, ptr %25, align 1, !alias.scope !36
  %index.next = add nuw i64 %index, 16
  %26 = icmp eq i64 %index.next, %n.vec
  br i1 %26, label %bb37.preheader47, label %vector.body, !llvm.loop !39

bb32:                                             ; preds = %bb30.1
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef 8, i64 noundef 12, i64 noundef %required, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d3c0ed059c64d66bf64704809ec4db02) #14
  unreachable

bb31:                                             ; preds = %bb8
  %_94 = getelementptr inbounds nuw i8, ptr %entities.0, i64 4
  %_103 = getelementptr inbounds nuw i8, ptr %output.0, i64 4
  %_45 = load i32, ptr %entities.0, align 4, !noundef !3
  store i32 %_45, ptr %_103, align 1, !alias.scope !42
  %_88 = icmp eq i64 %entities.1, 1
  br i1 %_88, label %bb29, label %bb30.1

bb30.1:                                           ; preds = %bb31
  %or.cond.not.1 = icmp samesign ugt i64 %0, 1
  br i1 %or.cond.not.1, label %bb31.1, label %bb32, !prof !45

bb31.1:                                           ; preds = %bb30.1
  %_103.1 = getelementptr inbounds nuw i8, ptr %output.0, i64 8
  %_45.1 = load i32, ptr %_94, align 4, !noundef !3
  store i32 %_45.1, ptr %_103.1, align 1, !alias.scope !42
  br label %bb29

bb37:                                             ; preds = %bb37.preheader47, %bb38
  %iter1.sroa.0.029 = phi ptr [ %_120, %bb38 ], [ %iter1.sroa.0.029.ph, %bb37.preheader47 ]
  %cursor.sroa.0.128 = phi i64 [ %_52, %bb38 ], [ %cursor.sroa.0.128.ph, %bb37.preheader47 ]
  %_52 = add nuw i64 %cursor.sroa.0.128, 4
  %27 = or disjoint i64 %cursor.sroa.0.128, 3
  %or.cond19.not = icmp ult i64 %27, %required
  br i1 %or.cond19.not, label %bb38, label %bb39, !prof !45

bb36:                                             ; preds = %bb38, %bb29
  call void @llvm.lifetime.start.p0(ptr nonnull %_58)
; call <nudox_ir_format::FragmentView>::validate
  call void @_RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate(ptr noalias noundef nonnull sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_58, ptr noalias noundef nonnull readonly captures(address, read_provenance) %output.0, i64 noundef %required)
  %28 = load ptr, ptr %_58, align 8, !noundef !3
  %29 = icmp eq ptr %28, null
  br i1 %29, label %bb15, label %bb16

bb39:                                             ; preds = %bb37
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef %cursor.sroa.0.128, i64 noundef %_52, i64 noundef %required, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0d19906a6b3022c81c70f9413c97b8e2) #14
  unreachable

bb38:                                             ; preds = %bb37
  %_120 = getelementptr inbounds nuw i8, ptr %iter1.sroa.0.029, i64 4
  %_129 = getelementptr inbounds nuw i8, ptr %output.0, i64 %cursor.sroa.0.128
  %_57 = load i32, ptr %iter1.sroa.0.029, align 4, !noundef !3
  store i32 %_57, ptr %_129, align 1, !alias.scope !36
  %_114 = icmp eq ptr %_120, %_107
  br i1 %_114, label %bb36, label %bb37, !llvm.loop !46

bb15:                                             ; preds = %bb36
  %30 = getelementptr inbounds nuw i8, ptr %_58, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %30, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_58)
  br label %bb20

bb16:                                             ; preds = %bb36
  %31 = getelementptr inbounds nuw i8, ptr %_58, i64 24
  %view.16 = load i64, ptr %31, align 8, !noundef !3
  %32 = getelementptr inbounds nuw i8, ptr %_58, i64 40
  %view.18 = load i64, ptr %32, align 8, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %_58)
  %_12.i9.i = icmp ugt i64 %view.16, 3
  %33 = add i64 %view.16, -4
  %34 = lshr i64 %33, 2
  %35 = add nuw nsw i64 %34, 1
  %accum.sroa.0.0.lcssa.i = select i1 %_12.i9.i, i64 %35, i64 0
  %_12.i9.i20 = icmp ugt i64 %view.18, 3
  %36 = add i64 %view.18, -4
  %37 = lshr i64 %36, 2
  %38 = add nuw nsw i64 %37, 1
  %accum.sroa.0.0.lcssa.i21 = select i1 %_12.i9.i20, i64 %38, i64 0
  %_67 = add nuw i64 %accum.sroa.0.0.lcssa.i21, %accum.sroa.0.0.lcssa.i
  %39 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_67, ptr %39, align 8
  store i8 -1, ptr %_0, align 8
  br label %bb20

bb20:                                             ; preds = %bb2, %bb21, %bb15, %bb6, %bb23, %bb4, %bb16
  ret void
}

; prepared_consumer::main
; Function Attrs: uwtable
define hidden void @_RNvCs21ATSyVuzIl_17prepared_consumer4main() unnamed_addr #1 {
start:
; call test::test_main_static
  tail call void @_RNvCs3O4ZRUMviTO_4test16test_main_static(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) @alloc_e68e146f22cb2d0b878fb86e4e6fa8ea, i64 noundef 1)
  ret void
}

; <&[u8; 23] as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRAhj17_NtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %entry.i.i.i = alloca [8 x i8], align 8
  %_5.i.i = alloca [16 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !noundef !3
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i), !noalias !47
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter10debug_list(ptr noalias noundef nonnull sret([16 x i8]) align 8 captures(address) dereferenceable(16) %_5.i.i, ptr noalias noundef nonnull align 8 dereferenceable(24) %f), !noalias !54
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %_3, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.1.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 1
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.1.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.1.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.2.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 2
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.2.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.2.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.3.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 3
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.3.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.3.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.4.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 4
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.4.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.4.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.5.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 5
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.5.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.5.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.6.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 6
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.6.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.6.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.7.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 7
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.7.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.7.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.8.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.8.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.8.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.9.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 9
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.9.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.9.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.10.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 10
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.10.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.10.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.11.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 11
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.11.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.11.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.12.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 12
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.12.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.12.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.13.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 13
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.13.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.13.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.14.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 14
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.14.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.14.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.15.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 15
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.15.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.15.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.16.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 16
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.16.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.16.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.17.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 17
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.17.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.17.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.18.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 18
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.18.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.18.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.19.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 19
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.19.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.19.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.20.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 20
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.20.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.20.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.21.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 21
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.21.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.21.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
  %iter.sroa.0.08.i.ptr.22.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 22
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !55
  store ptr %iter.sroa.0.08.i.ptr.22.i.i, ptr %entry.i.i.i, align 8, !noalias !55
; call <core::fmt::builders::DebugList>::entry
  %_9.i.22.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !55
; call <core::fmt::builders::DebugList>::finish
  %_0.i.i = call noundef zeroext i1 @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList6finish(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i), !noalias !47
  ret i1 %_0.i.i
}

; <&core::result::Result<usize, prepared_consumer::ConsumerError> as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6result6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtB6_5Debug3fmtBU_(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_01.i = alloca [8 x i8], align 8
  %__self_0.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !58, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !59)
  %0 = load i8, ptr %_3, align 8, !range !17, !alias.scope !59, !noalias !62, !noundef !3
  %.not.i = icmp eq i8 %0, -1
  br i1 %.not.i, label %bb3.i, label %bb2.i

bb2.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01.i), !noalias !64
  store ptr %_3, ptr %__self_01.i, align 8, !noalias !64
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %1 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_bf301217d548e4f1fd13189dd935c554, i64 noundef 3, ptr noundef nonnull %__self_01.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.9)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01.i), !noalias !64
  br label %_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3fmt5Debug3fmtBM_.exit

bb3.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0.i), !noalias !64
  %2 = getelementptr inbounds nuw i8, ptr %_3, i64 8
  store ptr %2, ptr %__self_0.i, align 8, !noalias !64
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_c73d17da7498663a071b898ac2218935, i64 noundef 2, ptr noundef nonnull %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.7)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0.i), !noalias !64
  br label %_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3fmt5Debug3fmtBM_.exit

_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3fmt5Debug3fmtBM_.exit: ; preds = %bb2.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %1, %bb2.i ], [ %3, %bb3.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&prepared_consumer::ConsumerError as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorNtB6_5Debug3fmtBx_(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_02.i = alloca [8 x i8], align 8
  %__self_01.i = alloca [8 x i8], align 8
  %__self_0.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !58, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !65)
  %0 = load i8, ptr %_3, align 8, !range !68, !alias.scope !65, !noalias !69, !noundef !3
  %1 = add nsw i8 %0, -6
  %2 = icmp samesign ugt i8 %0, 5
  %narrow.i = select i1 %2, i8 %1, i8 2
  switch i8 %narrow.i, label %bb1.i [
    i8 0, label %bb4.i
    i8 1, label %bb3.i
    i8 2, label %bb2.i
  ]

bb1.i:                                            ; preds = %start
  unreachable

bb4.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0.i), !noalias !71
  %3 = getelementptr inbounds nuw i8, ptr %_3, i64 8
  store ptr %3, ptr %__self_0.i, align 8, !noalias !71
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_ff99525767786baa5dc7e956e06d005e, i64 noundef 7, ptr noundef nonnull %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.4)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0.i), !noalias !71
  br label %_RNvXs1_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb3.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01.i), !noalias !71
  %5 = getelementptr inbounds nuw i8, ptr %_3, i64 8
  store ptr %5, ptr %__self_01.i, align 8, !noalias !71
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_6b7483292c41e5f1002b8b441a63be1a, i64 noundef 5, ptr noundef nonnull %__self_01.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.5)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01.i), !noalias !71
  br label %_RNvXs1_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb2.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_02.i), !noalias !71
  store ptr %_3, ptr %__self_02.i, align 8, !noalias !71
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_9734c9124d3f60537957ec8c47f6ebf4, i64 noundef 8, ptr noundef nonnull %__self_02.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.6)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_02.i), !noalias !71
  br label %_RNvXs1_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

_RNvXs1_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit: ; preds = %bb4.i, %bb3.i, %bb2.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %6, %bb3.i ], [ %7, %bb2.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&nudox_ir_format::WriteError as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format10WriteErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_1.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !58, !noundef !3
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_1.i), !noalias !72
  %0 = getelementptr inbounds nuw i8, ptr %_3, i64 8
  store ptr %0, ptr %__self_1.i, align 8, !noalias !72
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %_0.i = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_5ab5ad54a633166dad8479b7b463c0d3, i64 noundef 14, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_715ad17152b7a3dfcbb2abff840befeb, i64 noundef 8, ptr noundef nonnull readonly align 8 dereferenceable(16) %_3, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.8, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_700d5d683c25860e3d40207214c9c99c, i64 noundef 9, ptr noundef nonnull %__self_1.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.7)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_1.i), !noalias !72
  ret i1 %_0.i
}

; <&nudox_ir_format::PrepareError as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format12PrepareErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_01.i = alloca [8 x i8], align 8
  %__self_0.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !58, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !76)
  %_3.i = load i64, ptr %_3, align 8, !range !24, !alias.scope !76, !noalias !79, !noundef !3
  %0 = getelementptr inbounds nuw i8, ptr %_3, i64 8
  %1 = trunc nuw i64 %_3.i to i1
  br i1 %1, label %bb2.i, label %bb3.i

bb2.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01.i), !noalias !81
  store ptr %0, ptr %__self_01.i, align 8, !noalias !81
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %2 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b5a34892e83b03f9728fdba51e681f6f, i64 noundef 9, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_01.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.7)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01.i), !noalias !81
  br label %_RNvXsh_Csks33AUGQlhz_15nudox_ir_formatNtB5_12PrepareErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb3.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0.i), !noalias !81
  store ptr %0, ptr %__self_0.i, align 8, !noalias !81
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %3 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_c904b8fe89a4f835804b02bd44018d9c, i64 noundef 11, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.7)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0.i), !noalias !81
  br label %_RNvXsh_Csks33AUGQlhz_15nudox_ir_formatNtB5_12PrepareErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

_RNvXsh_Csks33AUGQlhz_15nudox_ir_formatNtB5_12PrepareErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit: ; preds = %bb2.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %2, %bb2.i ], [ %3, %bb3.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&nudox_ir_format::FragmentError as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtCsks33AUGQlhz_15nudox_ir_format13FragmentErrorNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_1.i = alloca [8 x i8], align 8
  %__self_04.i = alloca [8 x i8], align 8
  %__self_03.i = alloca [8 x i8], align 8
  %__self_02.i = alloca [8 x i8], align 8
  %__self_01.i = alloca [8 x i8], align 8
  %__self_0.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !58, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !82)
  %0 = load i8, ptr %_3, align 8, !range !85, !alias.scope !82, !noalias !86, !noundef !3
  switch i8 %0, label %default.unreachable [
    i8 0, label %bb7.i
    i8 1, label %bb6.i
    i8 2, label %bb5.i
    i8 3, label %bb4.i
    i8 4, label %bb3.i
    i8 5, label %bb2.i
  ]

default.unreachable:                              ; preds = %start
  unreachable

bb7.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0.i), !noalias !88
  %1 = getelementptr inbounds nuw i8, ptr %_3, i64 8
  store ptr %1, ptr %__self_0.i, align 8, !noalias !88
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %2 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_ea8e8baf0be5855bbef17ce48226036b, i64 noundef 17, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.7)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0.i), !noalias !88
  br label %_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb6.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01.i), !noalias !88
  %3 = getelementptr inbounds nuw i8, ptr %_3, i64 1
  store ptr %3, ptr %__self_01.i, align 8, !noalias !88
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %4 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_d7b9b6c1829de9592f5bc6e83c4fc424, i64 noundef 5, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_01.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01.i), !noalias !88
  br label %_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb5.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_02.i), !noalias !88
  %5 = getelementptr inbounds nuw i8, ptr %_3, i64 1
  store ptr %5, ptr %__self_02.i, align 8, !noalias !88
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %6 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_d102eb289abff9d0655d27bf114c0746, i64 noundef 6, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_02.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_02.i), !noalias !88
  br label %_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb4.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_03.i), !noalias !88
  %7 = getelementptr inbounds nuw i8, ptr %_3, i64 1
  store ptr %7, ptr %__self_03.i, align 8, !noalias !88
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %8 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_c904b8fe89a4f835804b02bd44018d9c, i64 noundef 11, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_03.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_03.i), !noalias !88
  br label %_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb3.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_04.i), !noalias !88
  %9 = getelementptr inbounds nuw i8, ptr %_3, i64 1
  store ptr %9, ptr %__self_04.i, align 8, !noalias !88
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %10 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b5a34892e83b03f9728fdba51e681f6f, i64 noundef 9, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_04.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_04.i), !noalias !88
  br label %_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb2.i:                                            ; preds = %start
  %__self_05.i = getelementptr inbounds nuw i8, ptr %_3, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_1.i), !noalias !88
  %11 = getelementptr inbounds nuw i8, ptr %_3, i64 16
  store ptr %11, ptr %__self_1.i, align 8, !noalias !88
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %12 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_4d3c10a7785e3cacd7635396354c2688, i64 noundef 8, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_bebfed686e6a6f31c99c69b171066b8a, i64 noundef 8, ptr noundef nonnull readonly %__self_05.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.8, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_1.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.7)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_1.i), !noalias !88
  br label %_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit: ; preds = %bb7.i, %bb6.i, %bb5.i, %bb4.i, %bb3.i, %bb2.i
  %_0.sroa.0.0.in.i = phi i1 [ %2, %bb7.i ], [ %4, %bb6.i ], [ %6, %bb5.i ], [ %8, %bb4.i ], [ %10, %bb3.i ], [ %12, %bb2.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRhNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !noundef !3
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4.i = load i32, ptr %0, align 8, !alias.scope !89, !noalias !92, !noundef !3
  %_3.i = and i32 %_4.i, 33554432
  %1 = icmp eq i32 %_3.i, 0
  br i1 %1, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %start
  %_5.i = and i32 %_4.i, 67108864
  %2 = icmp eq i32 %_5.i, 0
  br i1 %2, label %bb4.i, label %bb3.i

bb1.i:                                            ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXse_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance) dereferenceable(1) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt.exit

bb4.i:                                            ; preds = %bb2.i
; call <u8 as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXNtNtNtCsgtPOCBgevO_4core3fmt3num3imphNtB6_7Display3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance) dereferenceable(1) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt.exit

bb3.i:                                            ; preds = %bb2.i
; call <u8 as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXsg_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance) dereferenceable(1) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt.exit

_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt.exit: ; preds = %bb1.i, %bb4.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %5, %bb3.i ], [ %3, %bb1.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&usize as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRjNtB6_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !58, !noundef !3
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4.i = load i32, ptr %0, align 8, !alias.scope !94, !noalias !97, !noundef !3
  %_3.i = and i32 %_4.i, 33554432
  %1 = icmp eq i32 %_3.i, 0
  br i1 %1, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %start
  %_5.i = and i32 %_4.i, 67108864
  %2 = icmp eq i32 %_5.i, 0
  br i1 %2, label %bb4.i, label %bb3.i

bb1.i:                                            ; preds = %start
; call <usize as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt.exit

bb4.i:                                            ; preds = %bb2.i
; call <usize as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt.exit

bb3.i:                                            ; preds = %bb2.i
; call <usize as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt.exit

_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt.exit: ; preds = %bb1.i, %bb4.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %5, %bb3.i ], [ %3, %bb1.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <usize as core::fmt::Debug>::fmt
; Function Attrs: inlinehint uwtable
define internal noundef zeroext i1 @_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4 = load i32, ptr %0, align 8, !noundef !3
  %_3 = and i32 %_4, 33554432
  %1 = icmp eq i32 %_3, 0
  br i1 %1, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %_5 = and i32 %_4, 67108864
  %2 = icmp eq i32 %_5, 0
  br i1 %2, label %bb4, label %bb3

bb1:                                              ; preds = %start
; call <usize as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %bb6

bb4:                                              ; preds = %bb2
; call <usize as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %bb6

bb3:                                              ; preds = %bb2
; call <usize as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3, %bb1
  %_0.sroa.0.0.in = phi i1 [ %4, %bb4 ], [ %5, %bb3 ], [ %3, %bb1 ]
  ret i1 %_0.sroa.0.0.in
}

; <core::str::pattern::StrSearcher as core::str::pattern::Searcher>::next_match
; Function Attrs: inlinehint uwtable
define internal fastcc void @_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef nonnull align 8 captures(none) dereferenceable(104) %self) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %_2 = load i64, ptr %self, align 8, !range !24, !noundef !3
  %0 = trunc nuw i64 %_2 to i1
  %searcher = getelementptr inbounds nuw i8, ptr %self, i64 8
  br i1 %0, label %bb2, label %bb3.preheader

bb3.preheader:                                    ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 26
  %2 = load i8, ptr %1, align 2, !range !99, !alias.scope !100, !noalias !103, !noundef !3
  %_4.i = trunc nuw i8 %2 to i1
  br i1 %_4.i, label %bb13, label %bb5.i.lr.ph

bb5.i.lr.ph:                                      ; preds = %bb3.preheader
  %.promoted = load i64, ptr %searcher, align 8
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %4 = getelementptr inbounds nuw i8, ptr %self, i64 72
  %self.0.i = load ptr, ptr %4, align 8, !alias.scope !100, !noalias !103, !nonnull !3, !noundef !3
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 80
  %self.1.i = load i64, ptr %5, align 8, !alias.scope !100, !noalias !103, !noundef !3
  %.promoted29 = load i8, ptr %3, align 8, !alias.scope !100, !noalias !103
  %extract.t = trunc i8 %.promoted29 to i1
  tail call void @llvm.experimental.noalias.scope.decl(metadata !105)
  %6 = icmp eq i64 %.promoted, 0
  br i1 %6, label %bb20.i.peel, label %bb5.i.i.peel

bb5.i.i.peel:                                     ; preds = %bb5.i.lr.ph
  %_8.not.i.i.peel = icmp ult i64 %.promoted, %self.1.i
  br i1 %_8.not.i.i.peel, label %bb9.i.i.peel, label %bb6.i.i.peel

bb6.i.i.peel:                                     ; preds = %bb5.i.i.peel
  %7 = icmp eq i64 %.promoted, %self.1.i
  br i1 %7, label %bb20.i.peel, label %bb19.i

bb9.i.i.peel:                                     ; preds = %bb5.i.i.peel
  %8 = getelementptr inbounds nuw i8, ptr %self.0.i, i64 %.promoted
  %self1.i.i.peel = load i8, ptr %8, align 1, !alias.scope !107, !noalias !110, !noundef !3
  %9 = icmp sgt i8 %self1.i.i.peel, -65
  br i1 %9, label %bb20.i.peel, label %bb19.i

bb20.i.peel:                                      ; preds = %bb9.i.i.peel, %bb6.i.i.peel, %bb5.i.lr.ph
  %data.i.i.peel = getelementptr inbounds nuw i8, ptr %self.0.i, i64 %.promoted
  %_6.i.i.i.peel = icmp samesign eq i64 %.promoted, %self.1.i
  br i1 %_6.i.i.i.peel, label %bb22.i, label %bb15.i.i.peel

bb15.i.i.peel:                                    ; preds = %bb20.i.peel
  %x.i.i.peel = load i8, ptr %data.i.i.peel, align 1, !noalias !111, !noundef !3
  %_7.i.i.peel = icmp sgt i8 %x.i.i.peel, -1
  br i1 %_7.i.i.peel, label %bb3.i.i.peel, label %bb4.i.i.peel

bb4.i.i.peel:                                     ; preds = %bb15.i.i.peel
  %_16.i.i.i.peel = getelementptr inbounds nuw i8, ptr %data.i.i.peel, i64 1
  %_33.i.i.peel = and i8 %x.i.i.peel, 31
  %init.i.i.peel = zext nneg i8 %_33.i.i.peel to i32
  %10 = add nuw nsw i64 %.promoted, 1
  %_6.i10.i.i.peel = icmp samesign ne i64 %10, %self.1.i
  tail call void @llvm.assume(i1 %_6.i10.i.i.peel)
  %y.i.i.peel = load i8, ptr %_16.i.i.i.peel, align 1, !noalias !111, !noundef !3
  %_36.i.i.peel = shl nuw nsw i32 %init.i.i.peel, 6
  %_38.i.i.peel = and i8 %y.i.i.peel, 63
  %_37.i.i.peel = zext nneg i8 %_38.i.i.peel to i32
  %11 = or disjoint i32 %_36.i.i.peel, %_37.i.i.peel
  %_14.i.i.peel = icmp samesign ugt i8 %x.i.i.peel, -33
  br i1 %_14.i.i.peel, label %bb6.i21.i.peel, label %bb23.i.peel

bb6.i21.i.peel:                                   ; preds = %bb4.i.i.peel
  %_16.i12.i.i.peel = getelementptr inbounds nuw i8, ptr %data.i.i.peel, i64 2
  %12 = add nuw nsw i64 %.promoted, 2
  %_6.i17.i.i.peel = icmp samesign ne i64 %12, %self.1.i
  tail call void @llvm.assume(i1 %_6.i17.i.i.peel)
  %z.i.i.peel = load i8, ptr %_16.i12.i.i.peel, align 1, !noalias !111, !noundef !3
  %_41.i.i.peel = shl nuw nsw i32 %_37.i.i.peel, 6
  %_43.i.i.peel = and i8 %z.i.i.peel, 63
  %_42.i.i.peel = zext nneg i8 %_43.i.i.peel to i32
  %y_z.i.i.peel = or disjoint i32 %_41.i.i.peel, %_42.i.i.peel
  %_21.i.i.peel = shl nuw nsw i32 %init.i.i.peel, 12
  %13 = or disjoint i32 %y_z.i.i.peel, %_21.i.i.peel
  %_22.i.i.peel = icmp samesign ugt i8 %x.i.i.peel, -17
  br i1 %_22.i.i.peel, label %bb8.i.i.peel, label %bb23.i.peel

bb8.i.i.peel:                                     ; preds = %bb6.i21.i.peel
  %_16.i19.i.i.peel = getelementptr inbounds nuw i8, ptr %data.i.i.peel, i64 3
  %14 = add nuw nsw i64 %.promoted, 3
  %_6.i24.i.i.peel = icmp samesign ne i64 %14, %self.1.i
  tail call void @llvm.assume(i1 %_6.i24.i.i.peel)
  %w.i.i.peel = load i8, ptr %_16.i19.i.i.peel, align 1, !noalias !111, !noundef !3
  %_27.i.i.peel = shl nuw nsw i32 %init.i.i.peel, 18
  %_26.i.i.peel = and i32 %_27.i.i.peel, 1835008
  %_46.i.i.peel = shl nuw nsw i32 %y_z.i.i.peel, 6
  %_48.i.i.peel = and i8 %w.i.i.peel, 63
  %_47.i.i.peel = zext nneg i8 %_48.i.i.peel to i32
  %_28.i.i.peel = or disjoint i32 %_46.i.i.peel, %_47.i.i.peel
  %15 = or disjoint i32 %_28.i.i.peel, %_26.i.i.peel
  br label %bb23.i.peel

bb3.i.i.peel:                                     ; preds = %bb15.i.i.peel
  %_8.i.i.peel = zext nneg i8 %x.i.i.peel to i32
  br label %bb23.i.peel

bb23.i.peel:                                      ; preds = %bb3.i.i.peel, %bb8.i.i.peel, %bb6.i21.i.peel, %bb4.i.i.peel
  %_0.sroa.4.0.i.ph.i.peel = phi i32 [ %13, %bb6.i21.i.peel ], [ %15, %bb8.i.i.peel ], [ %11, %bb4.i.i.peel ], [ %_8.i.i.peel, %bb3.i.i.peel ]
  %16 = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.peel, 1114112
  tail call void @llvm.assume(i1 %16)
  br i1 %extract.t, label %bb7.loopexit, label %bb40.i.peel

bb40.i.peel:                                      ; preds = %bb23.i.peel
  %_61.i.peel = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.peel, 128
  br i1 %_61.i.peel, label %bb26.i.peel, label %bb27.i.peel

bb27.i.peel:                                      ; preds = %bb40.i.peel
  %_62.i.peel = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.peel, 2048
  br i1 %_62.i.peel, label %bb26.i.peel, label %bb28.i.peel

bb28.i.peel:                                      ; preds = %bb27.i.peel
  %_63.i.peel = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.peel, 65536
  %..i.peel = select i1 %_63.i.peel, i64 3, i64 4
  br label %bb26.i.peel

bb26.i.peel:                                      ; preds = %bb28.i.peel, %bb27.i.peel, %bb40.i.peel
  %_14.sroa.0.0.i.peel = phi i64 [ 2, %bb27.i.peel ], [ %..i.peel, %bb28.i.peel ], [ 1, %bb40.i.peel ]
  %17 = add i64 %_14.sroa.0.0.i.peel, %.promoted
  store i64 %17, ptr %searcher, align 8, !alias.scope !105, !noalias !103
  %18 = icmp eq i64 %17, 0
  %_8.not.i.i = icmp ult i64 %17, %self.1.i
  %19 = icmp eq i64 %17, %self.1.i
  %20 = getelementptr inbounds nuw i8, ptr %self.0.i, i64 %17
  %data.i.i = getelementptr inbounds nuw i8, ptr %self.0.i, i64 %17
  %_6.i.i.i = icmp samesign eq i64 %17, %self.1.i
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %data.i.i, i64 1
  %21 = add nuw nsw i64 %17, 1
  %_6.i10.i.i = icmp samesign ne i64 %21, %self.1.i
  %_16.i12.i.i = getelementptr inbounds nuw i8, ptr %data.i.i, i64 2
  %22 = add nuw nsw i64 %17, 2
  %_6.i17.i.i = icmp samesign ne i64 %22, %self.1.i
  %_16.i19.i.i = getelementptr inbounds nuw i8, ptr %data.i.i, i64 3
  %23 = add nuw nsw i64 %17, 3
  %_6.i24.i.i = icmp samesign ne i64 %23, %self.1.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !100)
  br i1 %18, label %bb20.i, label %bb5.i.i

bb2:                                              ; preds = %start
  %24 = getelementptr inbounds nuw i8, ptr %self, i64 56
  %_10 = load i64, ptr %24, align 8, !noundef !3
  %25 = icmp eq i64 %_10, -1
  %26 = getelementptr inbounds nuw i8, ptr %self, i64 72
  %self.0 = load ptr, ptr %26, align 8, !nonnull !3, !noundef !3
  %27 = getelementptr inbounds nuw i8, ptr %self, i64 80
  %self.1 = load i64, ptr %27, align 8, !noundef !3
  %28 = getelementptr inbounds nuw i8, ptr %self, i64 88
  %self.01 = load ptr, ptr %28, align 8, !nonnull !3, !noundef !3
  %29 = getelementptr inbounds nuw i8, ptr %self, i64 96
  %self.12 = load i64, ptr %29, align 8, !noundef !3
  br i1 %25, label %bb8, label %bb10

bb5.i.i:                                          ; preds = %bb26.i.peel
  br i1 %_8.not.i.i, label %bb9.i.i, label %bb6.i.i

bb6.i.i:                                          ; preds = %bb5.i.i
  br i1 %19, label %bb20.i, label %bb19.i

bb9.i.i:                                          ; preds = %bb5.i.i
  %self1.i.i = load i8, ptr %20, align 1, !alias.scope !107, !noalias !114, !noundef !3
  %30 = icmp sgt i8 %self1.i.i, -65
  br i1 %30, label %bb20.i, label %bb19.i

bb20.i:                                           ; preds = %bb9.i.i, %bb6.i.i, %bb26.i.peel
  br i1 %_6.i.i.i, label %bb7.critedge, label %bb15.i.i

bb15.i.i:                                         ; preds = %bb20.i
  %x.i.i = load i8, ptr %data.i.i, align 1, !noalias !115, !noundef !3
  %_7.i.i = icmp sgt i8 %x.i.i, -1
  br i1 %_7.i.i, label %bb3.i.i, label %bb4.i.i

bb4.i.i:                                          ; preds = %bb15.i.i
  %_33.i.i = and i8 %x.i.i, 31
  %init.i.i = zext nneg i8 %_33.i.i to i32
  tail call void @llvm.assume(i1 %_6.i10.i.i)
  %y.i.i = load i8, ptr %_16.i.i.i, align 1, !noalias !115, !noundef !3
  %_36.i.i = shl nuw nsw i32 %init.i.i, 6
  %_38.i.i = and i8 %y.i.i, 63
  %_37.i.i = zext nneg i8 %_38.i.i to i32
  %31 = or disjoint i32 %_36.i.i, %_37.i.i
  %_14.i.i = icmp samesign ugt i8 %x.i.i, -33
  br i1 %_14.i.i, label %bb6.i21.i, label %bb23.i

bb3.i.i:                                          ; preds = %bb15.i.i
  %_8.i.i = zext nneg i8 %x.i.i to i32
  br label %bb23.i

bb6.i21.i:                                        ; preds = %bb4.i.i
  tail call void @llvm.assume(i1 %_6.i17.i.i)
  %z.i.i = load i8, ptr %_16.i12.i.i, align 1, !noalias !115, !noundef !3
  %_41.i.i = shl nuw nsw i32 %_37.i.i, 6
  %_43.i.i = and i8 %z.i.i, 63
  %_42.i.i = zext nneg i8 %_43.i.i to i32
  %y_z.i.i = or disjoint i32 %_41.i.i, %_42.i.i
  %_21.i.i = shl nuw nsw i32 %init.i.i, 12
  %32 = or disjoint i32 %y_z.i.i, %_21.i.i
  %_22.i.i = icmp samesign ugt i8 %x.i.i, -17
  br i1 %_22.i.i, label %bb8.i.i, label %bb23.i

bb8.i.i:                                          ; preds = %bb6.i21.i
  tail call void @llvm.assume(i1 %_6.i24.i.i)
  %w.i.i = load i8, ptr %_16.i19.i.i, align 1, !noalias !115, !noundef !3
  %_27.i.i = shl nuw nsw i32 %init.i.i, 18
  %_26.i.i = and i32 %_27.i.i, 1835008
  %_46.i.i = shl nuw nsw i32 %y_z.i.i, 6
  %_48.i.i = and i8 %w.i.i, 63
  %_47.i.i = zext nneg i8 %_48.i.i to i32
  %_28.i.i = or disjoint i32 %_46.i.i, %_47.i.i
  %33 = or disjoint i32 %_28.i.i, %_26.i.i
  br label %bb23.i

bb19.i:                                           ; preds = %bb9.i.i, %bb6.i.i, %bb9.i.i.peel, %bb6.i.i.peel
  %.off0.lcssa = phi i1 [ %extract.t, %bb6.i.i.peel ], [ %extract.t, %bb9.i.i.peel ], [ true, %bb6.i.i ], [ true, %bb9.i.i ]
  %.lcssa = phi i64 [ %.promoted, %bb6.i.i.peel ], [ %.promoted, %bb9.i.i.peel ], [ %17, %bb6.i.i ], [ %17, %bb9.i.i ]
  %34 = xor i1 %.off0.lcssa, true
  %35 = zext i1 %34 to i8
  store i8 %35, ptr %3, align 8, !alias.scope !100, !noalias !103
; call core::str::slice_error_fail
  tail call void @_RNvNtCsgtPOCBgevO_4core3str16slice_error_fail(ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.0.i, i64 noundef %self.1.i, i64 noundef %.lcssa, i64 noundef %self.1.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_de5e2f1dd01253ae804bfe6ba3503da0) #14, !noalias !114
  unreachable

bb23.i:                                           ; preds = %bb8.i.i, %bb6.i21.i, %bb3.i.i, %bb4.i.i
  %_0.sroa.4.0.i.ph.i = phi i32 [ %32, %bb6.i21.i ], [ %33, %bb8.i.i ], [ %31, %bb4.i.i ], [ %_8.i.i, %bb3.i.i ]
  %36 = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i, 1114112
  tail call void @llvm.assume(i1 %36)
  br label %bb7.loopexit

bb22.i:                                           ; preds = %bb20.i.peel
  %37 = xor i1 %extract.t, true
  %38 = zext i1 %37 to i8
  store i8 %38, ptr %3, align 8, !alias.scope !100, !noalias !103
  br i1 %extract.t, label %bb7, label %bb41.i

bb41.i:                                           ; preds = %bb22.i
  store i8 1, ptr %1, align 2, !alias.scope !100, !noalias !103
  br label %bb13

bb7.loopexit:                                     ; preds = %bb23.i, %bb23.i.peel
  %.lcssa62 = phi i64 [ %.promoted, %bb23.i.peel ], [ %17, %bb23.i ]
  store i8 0, ptr %3, align 8, !alias.scope !100, !noalias !103
  br label %bb7

bb7.critedge:                                     ; preds = %bb20.i
  store i8 0, ptr %3, align 8, !alias.scope !100, !noalias !103
  br label %bb7

bb7:                                              ; preds = %bb7.critedge, %bb7.loopexit, %bb22.i
  %39 = phi i64 [ %.lcssa62, %bb7.loopexit ], [ %self.1.i, %bb22.i ], [ %self.1.i, %bb7.critedge ]
  %40 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %39, ptr %40, align 8
  %41 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %39, ptr %41, align 8
  br label %bb13

bb13:                                             ; preds = %bb3.preheader, %bb41.i, %bb7
  %storemerge = phi i64 [ 1, %bb7 ], [ 0, %bb41.i ], [ 0, %bb3.preheader ]
  store i64 %storemerge, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb8, %bb10, %bb13
  ret void

bb8:                                              ; preds = %bb2
; call <core::str::pattern::TwoWaySearcher>::next::<core::str::pattern::MatchOnly>
  tail call fastcc void @_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_0, ptr noalias noundef align 8 dereferenceable(64) %searcher, ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.0, i64 noundef %self.1, ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.01, i64 noundef %self.12, i1 noundef zeroext true)
  br label %bb14

bb10:                                             ; preds = %bb2
; call <core::str::pattern::TwoWaySearcher>::next::<core::str::pattern::MatchOnly>
  tail call fastcc void @_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_0, ptr noalias noundef align 8 dereferenceable(64) %searcher, ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.0, i64 noundef %self.1, ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.01, i64 noundef %self.12, i1 noundef zeroext false)
  br label %bb14
}

; <prepared_consumer::prepared_and_manual_whole_consumers_are_equivalent::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint uwtable
define internal void @_RNvYNCNvCs21ATSyVuzIl_17prepared_consumer50prepared_and_manual_whole_consumers_are_equivalent0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %_5.i15.i.i = alloca [104 x i8], align 8
  %self.i16.i.i = alloca [24 x i8], align 8
  %_5.i.i.i = alloca [104 x i8], align 8
  %self.i.i.i = alloca [24 x i8], align 8
  %_163.i.i = alloca [104 x i8], align 8
  %_92.i.i = alloca [8 x i8], align 8
  %iter.i.i = alloca [48 x i8], align 8
  %three_types.i.i = alloca [12 x i8], align 8
  %three_entities.i.i = alloca [12 x i8], align 8
  %types.i.i = alloca [8 x i8], align 8
  %entities.i.i = alloca [8 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !116)
  call void @llvm.lifetime.start.p0(ptr nonnull %entities.i.i), !noalias !116
  store <2 x i32> <i32 16909060, i32 84281096>, ptr %entities.i.i, align 8, !noalias !116
  call void @llvm.lifetime.start.p0(ptr nonnull %types.i.i), !noalias !116
  store <2 x i32> <i32 -1599029040, i32 270544960>, ptr %types.i.i, align 8, !noalias !116
  call void @llvm.lifetime.start.p0(ptr nonnull %three_entities.i.i), !noalias !116
  store <2 x i32> <i32 1, i32 2>, ptr %three_entities.i.i, align 8, !noalias !116
  %0 = getelementptr inbounds nuw i8, ptr %three_entities.i.i, i64 8
  store i32 3, ptr %0, align 8, !noalias !116
  call void @llvm.lifetime.start.p0(ptr nonnull %three_types.i.i), !noalias !116
  store <2 x i32> <i32 4, i32 5>, ptr %three_types.i.i, align 8, !noalias !116
  %1 = getelementptr inbounds nuw i8, ptr %three_types.i.i, i64 8
  store i32 6, ptr %1, align 8, !noalias !116
; call prepared_consumer::assert_equivalent
  tail call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, i64 noundef 4), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 1, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 1, i64 noundef 12), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 20), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 1, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, i64 noundef 8), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 1, i64 noundef 8), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, i64 noundef 12), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 12), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 1, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 16), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 1, i64 noundef 16), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, i64 noundef 0), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 0), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 0), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %three_entities.i.i, i64 noundef 3, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, i64 noundef 0), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) inttoptr (i64 4 to ptr), i64 noundef 0, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %three_types.i.i, i64 noundef 3, i64 noundef 0), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %three_entities.i.i, i64 noundef 3, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %three_types.i.i, i64 noundef 3, i64 noundef 0), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 0), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 1), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 2), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 3), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 4), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 5), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 6), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 7), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 8), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 9), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 10), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 11), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 12), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 13), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 14), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 15), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 16), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 17), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 18), !noalias !116
; call prepared_consumer::assert_equivalent
  call fastcc void @_RNvCs21ATSyVuzIl_17prepared_consumer17assert_equivalent(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %entities.i.i, i64 noundef 2, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) %types.i.i, i64 noundef 2, i64 noundef 19), !noalias !116
  call void @llvm.lifetime.start.p0(ptr nonnull %iter.i.i), !noalias !116
  %_73.sroa.5.0.iter.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %iter.i.i, i64 16
  store ptr @alloc_d91c9f80f2e5baff61980d0c7830d0e8, ptr %_73.sroa.5.0.iter.sroa_idx.i.i, align 8, !noalias !116
  %_73.sroa.6.0.iter.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %iter.i.i, i64 24
  store i64 26, ptr %_73.sroa.6.0.iter.sroa_idx.i.i, align 8, !noalias !116
  %_73.sroa.7.0.iter.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %iter.i.i, i64 32
  store ptr @alloc_28eec9e12bbc407b8589cbde87c7f667, ptr %_73.sroa.7.0.iter.sroa_idx.i.i, align 8, !noalias !116
  %_73.sroa.8.0.iter.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %iter.i.i, i64 40
  store i64 29, ptr %_73.sroa.8.0.iter.sroa_idx.i.i, align 8, !noalias !116
  %2 = getelementptr inbounds nuw i8, ptr %self.i.i.i, i64 8
  %3 = getelementptr inbounds nuw i8, ptr %self.i16.i.i, i64 8
  %_162.sroa.4.0._163.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_163.i.i, i64 8
  %_162.sroa.6.0._163.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_163.i.i, i64 24
  %_162.sroa.7.0._163.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_163.i.i, i64 32
  %_162.sroa.8.0._163.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_163.i.i, i64 40
  %_162.sroa.10.0._163.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_163.i.i, i64 56
  %_162.sroa.12.0._163.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_163.i.i, i64 72
  %_162.sroa.13.0._163.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_163.i.i, i64 80
  %_162.sroa.14.0._163.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_163.i.i, i64 88
  %_162.sroa.15.0._163.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_163.i.i, i64 96
  br label %bb20.i.i

bb20.i.i:                                         ; preds = %bb28.i.i, %start
  %_5.not.i.i.i = phi i1 [ false, %start ], [ true, %bb28.i.i ]
  %4 = phi i64 [ 0, %start ], [ 1, %bb28.i.i ]
  %self3.i.i.i = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<&str>", ptr %_73.sroa.5.0.iter.sroa_idx.i.i, i64 %4
  %_14.0.i.i.i = load ptr, ptr %self3.i.i.i, align 8, !alias.scope !119, !noalias !116, !nonnull !3, !noundef !3
  %5 = getelementptr inbounds nuw i8, ptr %self3.i.i.i, i64 8
  %_14.1.i.i.i = load i64, ptr %5, align 8, !alias.scope !119, !noalias !116, !noundef !3
  call void @llvm.lifetime.start.p0(ptr nonnull %self.i.i.i), !noalias !122
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i.i), !noalias !122
; call <core::str::pattern::StrSearcher>::new
  call void @_RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new(ptr noalias noundef nonnull sret([104 x i8]) align 8 captures(none) dereferenceable(104) %_5.i.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_26763173fa2e792d564fcfb08dcb11cd, i64 noundef 5687, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_14.0.i.i.i, i64 noundef %_14.1.i.i.i), !noalias !116
; call <core::str::pattern::StrSearcher as core::str::pattern::Searcher>::next_match
  call fastcc void @_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match(ptr noalias noundef align 8 captures(address) dereferenceable(24) %self.i.i.i, ptr noalias noundef align 8 dereferenceable(104) %_5.i.i.i), !noalias !116
  %_6.i.i.i = load i64, ptr %self.i.i.i, align 8, !range !24, !noalias !122, !noundef !3
  %6 = trunc nuw i64 %_6.i.i.i to i1
  %x.i.i.i = load i64, ptr %2, align 8, !noalias !122
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i.i), !noalias !122
  call void @llvm.lifetime.end.p0(ptr nonnull %self.i.i.i), !noalias !122
  br i1 %6, label %bb24.i.i, label %bb23.i.i, !prof !35

bb24.i.i:                                         ; preds = %bb20.i.i
  %7 = icmp eq i64 %x.i.i.i, 0
  br i1 %7, label %bb38.i.i, label %bb5.i.i.i

bb5.i.i.i:                                        ; preds = %bb24.i.i
  %_8.not.i.i.i = icmp ult i64 %x.i.i.i, 5687
  br i1 %_8.not.i.i.i, label %bb9.i.i.i, label %bb6.i.i.i

bb6.i.i.i:                                        ; preds = %bb5.i.i.i
  %8 = icmp eq i64 %x.i.i.i, 5687
  br i1 %8, label %bb38.i.i, label %bb37.i.i

bb9.i.i.i:                                        ; preds = %bb5.i.i.i
  %9 = getelementptr inbounds nuw i8, ptr @alloc_26763173fa2e792d564fcfb08dcb11cd, i64 %x.i.i.i
  %self1.i.i.i = load i8, ptr %9, align 1, !alias.scope !126, !noalias !116, !noundef !3
  %10 = icmp sgt i8 %self1.i.i.i, -65
  br i1 %10, label %bb38.i.i, label %bb37.i.i

bb23.i.i:                                         ; preds = %bb20.i.i
; call core::panicking::panic_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking9panic_fmt(ptr noundef nonnull @alloc_56105bc765d39b007aae1d24445a5f7d, ptr noundef nonnull inttoptr (i64 47 to ptr), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0eb7e310050072805af9487b58c4035d) #14, !noalias !116
  unreachable

bb38.i.i:                                         ; preds = %bb9.i.i.i, %bb6.i.i.i, %bb24.i.i
  %new_len.i.i.i = sub nuw nsw i64 5687, %x.i.i.i
  %data.i.i.i = getelementptr inbounds nuw i8, ptr @alloc_26763173fa2e792d564fcfb08dcb11cd, i64 %x.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %self.i16.i.i), !noalias !129
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i15.i.i), !noalias !129
; call <core::str::pattern::StrSearcher>::new
  call void @_RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new(ptr noalias noundef nonnull sret([104 x i8]) align 8 captures(none) dereferenceable(104) %_5.i15.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %data.i.i.i, i64 noundef %new_len.i.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_e89cb6afc643eac20b05a0b577b5e8bc, i64 noundef 3), !noalias !116
; call <core::str::pattern::StrSearcher as core::str::pattern::Searcher>::next_match
  call fastcc void @_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match(ptr noalias noundef align 8 captures(address) dereferenceable(24) %self.i16.i.i, ptr noalias noundef align 8 dereferenceable(104) %_5.i15.i.i), !noalias !116
  %_6.i17.i.i = load i64, ptr %self.i16.i.i, align 8, !range !24, !noalias !129, !noundef !3
  %11 = trunc nuw i64 %_6.i17.i.i to i1
  %x.i18.i.i = load i64, ptr %3, align 8, !noalias !129
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i15.i.i), !noalias !129
  call void @llvm.lifetime.end.p0(ptr nonnull %self.i16.i.i), !noalias !129
  br i1 %11, label %bb27.i.i, label %bb26.i.i, !prof !35

bb37.i.i:                                         ; preds = %bb9.i.i.i, %bb6.i.i.i
; call core::str::slice_error_fail
  call void @_RNvNtCsgtPOCBgevO_4core3str16slice_error_fail(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_26763173fa2e792d564fcfb08dcb11cd, i64 noundef 5687, i64 noundef %x.i.i.i, i64 noundef 5687, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_24028a94044fca6d4a8bfbb1fadd3876) #14, !noalias !116
  unreachable

bb27.i.i:                                         ; preds = %bb38.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_92.i.i), !noalias !116
  %12 = icmp eq i64 %x.i18.i.i, 0
  br i1 %12, label %bb41.i.i, label %bb5.i23.i.i

bb5.i23.i.i:                                      ; preds = %bb27.i.i
  %_8.not.i24.i.i = icmp ult i64 %x.i18.i.i, %new_len.i.i.i
  br i1 %_8.not.i24.i.i, label %bb9.i27.i.i, label %bb6.i25.i.i

bb6.i25.i.i:                                      ; preds = %bb5.i23.i.i
  %13 = icmp eq i64 %x.i18.i.i, %new_len.i.i.i
  br i1 %13, label %bb41.i.i, label %bb40.i.i

bb9.i27.i.i:                                      ; preds = %bb5.i23.i.i
  %14 = getelementptr inbounds nuw i8, ptr %data.i.i.i, i64 %x.i18.i.i
  %self1.i28.i.i = load i8, ptr %14, align 1, !alias.scope !133, !noalias !116, !noundef !3
  %15 = icmp sgt i8 %self1.i28.i.i, -65
  br i1 %15, label %bb41.i.i, label %bb40.i.i

bb26.i.i:                                         ; preds = %bb38.i.i
; call core::panicking::panic_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking9panic_fmt(ptr noundef nonnull @alloc_6b25b981d6dcb0f81ae5433ae5833550, ptr noundef nonnull inttoptr (i64 75 to ptr), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3f1972d8ea19ee8686ea812b9669179e) #14, !noalias !116
  unreachable

bb41.i.i:                                         ; preds = %bb9.i27.i.i, %bb6.i25.i.i, %bb27.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_163.i.i), !noalias !116
; call <core::str::pattern::StrSearcher>::new
  call void @_RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new(ptr noalias noundef nonnull sret([104 x i8]) align 8 captures(none) dereferenceable(104) %_163.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %data.i.i.i, i64 noundef %x.i18.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_7a807194ba7bcc2f917ecb6ee3f0af2a, i64 noundef 22), !noalias !116
  %_162.sroa.0.0.copyload.i.i = load i64, ptr %_163.i.i, align 8, !noalias !116
  %_162.sroa.4.0.copyload.i.i = load i64, ptr %_162.sroa.4.0._163.sroa_idx.i.i, align 8, !noalias !116
  %_162.sroa.6.0.copyload.i.i = load i64, ptr %_162.sroa.6.0._163.sroa_idx.i.i, align 8, !noalias !116
  %_162.sroa.7.0.copyload.i.i = load i64, ptr %_162.sroa.7.0._163.sroa_idx.i.i, align 8, !noalias !116
  %_162.sroa.8.0.copyload.i.i = load i64, ptr %_162.sroa.8.0._163.sroa_idx.i.i, align 8, !noalias !116
  %_162.sroa.10.0.copyload.i.i = load i64, ptr %_162.sroa.10.0._163.sroa_idx.i.i, align 8, !noalias !116
  %_162.sroa.12.0.copyload.i.i = load ptr, ptr %_162.sroa.12.0._163.sroa_idx.i.i, align 8, !noalias !116
  %_162.sroa.13.0.copyload.i.i = load i64, ptr %_162.sroa.13.0._163.sroa_idx.i.i, align 8, !noalias !116
  %_162.sroa.14.0.copyload.i.i = load ptr, ptr %_162.sroa.14.0._163.sroa_idx.i.i, align 8, !noalias !116
  %_162.sroa.15.0.copyload.i.i = load i64, ptr %_162.sroa.15.0._163.sroa_idx.i.i, align 8, !noalias !116
  call void @llvm.lifetime.end.p0(ptr nonnull %_163.i.i), !noalias !116
  %16 = trunc nuw i64 %_162.sroa.0.0.copyload.i.i to i1
  %17 = icmp ne ptr %_162.sroa.12.0.copyload.i.i, null
  %18 = icmp ne ptr %_162.sroa.14.0.copyload.i.i, null
  %needle_last.i.i.i = add nsw i64 %_162.sroa.15.0.copyload.i.i, -1
  br i1 %16, label %bb41.split.us.i.i, label %bb41.split.i.i

bb41.split.us.i.i:                                ; preds = %bb41.i.i
  call void @llvm.assume(i1 %17)
  call void @llvm.assume(i1 %18)
  %19 = sub i64 %_162.sroa.15.0.copyload.i.i, %_162.sroa.6.0.copyload.i.i
  %umax40.i64.us.i.i = call i64 @llvm.umax.i64(i64 %_162.sroa.4.0.copyload.i.i, i64 range(i64 0, -9223372036854775808) %_162.sroa.15.0.copyload.i.i)
  %20 = add i64 %_162.sroa.4.0.copyload.i.i, -1
  %_43.i90.us.first_iter.i.i = icmp ult i64 %20, %_162.sroa.15.0.copyload.i.i
  %_43.i90.us.first_iter.i.fr.i = freeze i1 %_43.i90.us.first_iter.i.i
  %_70.i86.not.us.i.i = icmp eq i64 %_162.sroa.4.0.copyload.i.i, 0
  br label %bb1.i29.us.i.i

bb1.i29.us.i.i:                                   ; preds = %.noexc31.us.i.i, %bb41.split.us.i.i
  %_93.sroa.30108.0.us.i.i = phi i64 [ %_162.sroa.10.0.copyload.i.i, %bb41.split.us.i.i ], [ %_93.sroa.30108.1.us.i.i, %.noexc31.us.i.i ]
  %_93.sroa.18.0.us.i.i = phi i64 [ %_162.sroa.8.0.copyload.i.i, %bb41.split.us.i.i ], [ %_93.sroa.18.1.us.i.i, %.noexc31.us.i.i ]
  %accum.sroa.0.0.i.us.i.i = phi i64 [ 0, %bb41.split.us.i.i ], [ %_4.0.i.i.us.i.i, %.noexc31.us.i.i ]
  %21 = icmp eq i64 %_93.sroa.30108.0.us.i.i, -1
  %index24.i46.us.i.i = add i64 %_93.sroa.18.0.us.i.i, %needle_last.i.i.i
  %_5325.i47.us.i.i = icmp ult i64 %index24.i46.us.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %21, label %bb8.i.us.i.i, label %bb10.i.us.i.i

bb10.i.us.i.i:                                    ; preds = %bb1.i29.us.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !136)
  call void @llvm.experimental.noalias.scope.decl(metadata !139)
  br i1 %_5325.i47.us.i.i, label %bb39.i.us.i.i, label %bb43.i.i

bb39.i.us.i.i:                                    ; preds = %bb10.i.us.i.i, %bb37.sink.split.i.us.i.i
  %v229.i.us.i.i = phi i64 [ %.sink.i.us.i.i, %bb37.sink.split.i.us.i.i ], [ %_93.sroa.30108.0.us.i.i, %bb10.i.us.i.i ]
  %index26.i.us.i.i = phi i64 [ %index.i.us.i.i, %bb37.sink.split.i.us.i.i ], [ %index24.i46.us.i.i, %bb10.i.us.i.i ]
  %22 = phi i64 [ %.ph.i.us.i.i, %bb37.sink.split.i.us.i.i ], [ %_93.sroa.18.0.us.i.i, %bb10.i.us.i.i ]
  %_55.i.us.i.i = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %index26.i.us.i.i
  %tail_byte.i.us.i.i = load i8, ptr %_55.i.us.i.i, align 1, !alias.scope !136, !noalias !141, !noundef !3
  %_60.i.us.i.i = and i8 %tail_byte.i.us.i.i, 63
  %_59.i.us.i.i = zext nneg i8 %_60.i.us.i.i to i64
  %23 = shl nuw i64 1, %_59.i.us.i.i
  %24 = and i64 %23, %_162.sroa.7.0.copyload.i.i
  %25 = icmp eq i64 %24, 0
  br i1 %25, label %bb10.i40.us.i.i, label %bb9.i39.us.i.i

bb9.i39.us.i.i:                                   ; preds = %bb39.i.us.i.i
  %_0.sroa.0.0.i.i.us.i.i = call i64 @llvm.umax.i64(i64 %v229.i.us.i.i, i64 %_162.sroa.4.0.copyload.i.i)
  %umax40.i.us.i.i = call i64 @llvm.umax.i64(i64 %_0.sroa.0.0.i.i.us.i.i, i64 range(i64 0, -9223372036854775808) %_162.sroa.15.0.copyload.i.i)
  br label %bb16.i.us.i.i

bb16.i.us.i.i:                                    ; preds = %bb18.i.us.i.i, %bb9.i39.us.i.i
  %iter.sroa.0.0.i.us.i.i = phi i64 [ %_0.sroa.0.0.i.i.us.i.i, %bb9.i39.us.i.i ], [ %_65.i.us.i.i, %bb18.i.us.i.i ]
  %exitcond.not.i.us.i.i = icmp eq i64 %iter.sroa.0.0.i.us.i.i, %umax40.i.us.i.i
  br i1 %exitcond.not.i.us.i.i, label %bb26.i.us.i.i, label %bb42.i.us.i.i

bb42.i.us.i.i:                                    ; preds = %bb16.i.us.i.i
  %_28.i.us.i.i = add i64 %iter.sroa.0.0.i.us.i.i, %22
  %_30.i.us.i.i = icmp ult i64 %_28.i.us.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_30.i.us.i.i, label %bb18.i.us.i.i, label %panic8.i.split.us.i.i

bb18.i.us.i.i:                                    ; preds = %bb42.i.us.i.i
  %_65.i.us.i.i = add i64 %iter.sroa.0.0.i.us.i.i, 1
  %26 = getelementptr inbounds nuw i8, ptr %_162.sroa.14.0.copyload.i.i, i64 %iter.sroa.0.0.i.us.i.i
  %_25.i.us.i.i = load i8, ptr %26, align 1, !alias.scope !139, !noalias !144, !noundef !3
  %27 = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %_28.i.us.i.i
  %_27.i.us.i.i = load i8, ptr %27, align 1, !alias.scope !136, !noalias !141, !noundef !3
  %_24.not.i.us.i.i = icmp eq i8 %_25.i.us.i.i, %_27.i.us.i.i
  br i1 %_24.not.i.us.i.i, label %bb16.i.us.i.i, label %bb19.i.us.i.i

bb19.i.us.i.i:                                    ; preds = %bb18.i.us.i.i
  %reass.sub = sub i64 %22, %_162.sroa.4.0.copyload.i.i
  %_31.i.us.i.i = add i64 %reass.sub, 1
  %28 = add i64 %_31.i.us.i.i, %iter.sroa.0.0.i.us.i.i
  br label %bb37.sink.split.i.us.i.i

bb26.i.us.i.i:                                    ; preds = %bb16.i.us.i.i, %bb28.i.us.i.i
  %iter3.sroa.2.0.i.us.i.i = phi i64 [ %_73.i.us.i.i, %bb28.i.us.i.i ], [ %_162.sroa.4.0.copyload.i.i, %bb16.i.us.i.i ]
  %_70.i.us.i.i = icmp ult i64 %v229.i.us.i.i, %iter3.sroa.2.0.i.us.i.i
  br i1 %_70.i.us.i.i, label %bb46.i.us.i.i, label %.noexc31.us.i.i

bb46.i.us.i.i:                                    ; preds = %bb26.i.us.i.i
  %_73.i.us.i.i = add i64 %iter3.sroa.2.0.i.us.i.i, -1
  %_43.i.us.i.i = icmp ult i64 %_73.i.us.i.i, %_162.sroa.15.0.copyload.i.i
  br i1 %_43.i.us.i.i, label %bb27.i.us.i.i, label %panic.i.split.us.i.i

bb27.i.us.i.i:                                    ; preds = %bb46.i.us.i.i
  %_45.i.us.i.i = add i64 %_73.i.us.i.i, %22
  %_47.i.us.i.i = icmp ult i64 %_45.i.us.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_47.i.us.i.i, label %bb28.i.us.i.i, label %panic5.i.split.us.i.i

bb28.i.us.i.i:                                    ; preds = %bb27.i.us.i.i
  %29 = getelementptr inbounds nuw i8, ptr %_162.sroa.14.0.copyload.i.i, i64 %_73.i.us.i.i
  %_42.i.us.i.i = load i8, ptr %29, align 1, !alias.scope !139, !noalias !144, !noundef !3
  %30 = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %_45.i.us.i.i
  %_44.i.us.i.i = load i8, ptr %30, align 1, !alias.scope !136, !noalias !141, !noundef !3
  %_41.not.i.us.i.i = icmp eq i8 %_42.i.us.i.i, %_44.i.us.i.i
  br i1 %_41.not.i.us.i.i, label %bb26.i.us.i.i, label %bb29.i.us.i.i

bb29.i.us.i.i:                                    ; preds = %bb28.i.us.i.i
  %31 = add i64 %22, %_162.sroa.6.0.copyload.i.i
  br label %bb37.sink.split.i.us.i.i

bb10.i40.us.i.i:                                  ; preds = %bb39.i.us.i.i
  %32 = add i64 %22, %_162.sroa.15.0.copyload.i.i
  br label %bb37.sink.split.i.us.i.i

bb37.sink.split.i.us.i.i:                         ; preds = %bb10.i40.us.i.i, %bb29.i.us.i.i, %bb19.i.us.i.i
  %.sink.i.us.i.i = phi i64 [ %19, %bb29.i.us.i.i ], [ 0, %bb19.i.us.i.i ], [ 0, %bb10.i40.us.i.i ]
  %.ph.i.us.i.i = phi i64 [ %31, %bb29.i.us.i.i ], [ %28, %bb19.i.us.i.i ], [ %32, %bb10.i40.us.i.i ]
  %index.i.us.i.i = add i64 %.ph.i.us.i.i, %needle_last.i.i.i
  %_53.i.us.i.i = icmp ult i64 %index.i.us.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_53.i.us.i.i, label %bb39.i.us.i.i, label %bb43.i.i

bb8.i.us.i.i:                                     ; preds = %bb1.i29.us.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !145)
  call void @llvm.experimental.noalias.scope.decl(metadata !148)
  br i1 %_5325.i47.us.i.i, label %bb39.i55.us.i.i, label %bb43.i.i

bb39.i55.us.i.i:                                  ; preds = %bb8.i.us.i.i, %bb37.i.us.i.i
  %index26.i57.us.i.i = phi i64 [ %index.i81.us.i.i, %bb37.i.us.i.i ], [ %index24.i46.us.i.i, %bb8.i.us.i.i ]
  %33 = phi i64 [ %44, %bb37.i.us.i.i ], [ %_93.sroa.18.0.us.i.i, %bb8.i.us.i.i ]
  %_55.i58.us.i.i = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %index26.i57.us.i.i
  %tail_byte.i59.us.i.i = load i8, ptr %_55.i58.us.i.i, align 1, !alias.scope !145, !noalias !150, !noundef !3
  %_60.i60.us.i.i = and i8 %tail_byte.i59.us.i.i, 63
  %_59.i61.us.i.i = zext nneg i8 %_60.i60.us.i.i to i64
  %34 = shl nuw i64 1, %_59.i61.us.i.i
  %35 = and i64 %34, %_162.sroa.7.0.copyload.i.i
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %bb10.i101.us.i.i, label %bb16.i65.us.i.i

bb16.i65.us.i.i:                                  ; preds = %bb39.i55.us.i.i, %bb18.i73.us.i.i
  %iter.sroa.0.0.i66.us.i.i = phi i64 [ %_65.i74.us.i.i, %bb18.i73.us.i.i ], [ %_162.sroa.4.0.copyload.i.i, %bb39.i55.us.i.i ]
  %exitcond.not.i67.us.i.i = icmp eq i64 %iter.sroa.0.0.i66.us.i.i, %umax40.i64.us.i.i
  br i1 %exitcond.not.i67.us.i.i, label %bb26.i84.us.i.preheader.i, label %bb42.i68.us.i.i

bb26.i84.us.i.preheader.i:                        ; preds = %bb16.i65.us.i.i
  br i1 %_43.i90.us.first_iter.i.fr.i, label %bb26.i84.us.i.us.i, label %bb26.i84.us.i.preheader.split.i

bb26.i84.us.i.us.i:                               ; preds = %bb26.i84.us.i.preheader.i, %bb28.i96.us.i.us.i
  %iter3.sroa.2.0.i85.us.i.us.i = phi i64 [ %_73.i89.us.i.us.i, %bb28.i96.us.i.us.i ], [ %_162.sroa.4.0.copyload.i.i, %bb26.i84.us.i.preheader.i ]
  %_70.i86.not.us.i.us.i = icmp eq i64 %iter3.sroa.2.0.i85.us.i.us.i, 0
  br i1 %_70.i86.not.us.i.us.i, label %.noexc31.us.i.i, label %bb46.i88.us.i.us.i

bb46.i88.us.i.us.i:                               ; preds = %bb26.i84.us.i.us.i
  %_73.i89.us.i.us.i = add i64 %iter3.sroa.2.0.i85.us.i.us.i, -1
  %_45.i93.us.i.us.i = add i64 %_73.i89.us.i.us.i, %33
  %_47.i94.us.i.us.i = icmp ult i64 %_45.i93.us.i.us.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_47.i94.us.i.us.i, label %bb28.i96.us.i.us.i, label %panic5.i95.split.us.i.i

bb28.i96.us.i.us.i:                               ; preds = %bb46.i88.us.i.us.i
  %37 = getelementptr inbounds nuw i8, ptr %_162.sroa.14.0.copyload.i.i, i64 %_73.i89.us.i.us.i
  %_42.i97.us.i.us.i = load i8, ptr %37, align 1, !alias.scope !148, !noalias !153, !noundef !3
  %38 = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %_45.i93.us.i.us.i
  %_44.i98.us.i.us.i = load i8, ptr %38, align 1, !alias.scope !145, !noalias !150, !noundef !3
  %_41.not.i99.us.i.us.i = icmp eq i8 %_42.i97.us.i.us.i, %_44.i98.us.i.us.i
  br i1 %_41.not.i99.us.i.us.i, label %bb26.i84.us.i.us.i, label %bb29.i100.us.i.split.us.i

bb29.i100.us.i.split.us.i:                        ; preds = %bb28.i96.us.i.us.i
  %39 = add i64 %33, %_162.sroa.6.0.copyload.i.i
  br label %bb37.i.us.i.i

bb26.i84.us.i.preheader.split.i:                  ; preds = %bb26.i84.us.i.preheader.i
  br i1 %_70.i86.not.us.i.i, label %.noexc31.us.i.i, label %bb46.i88.us.i.i

bb42.i68.us.i.i:                                  ; preds = %bb16.i65.us.i.i
  %_28.i69.us.i.i = add i64 %iter.sroa.0.0.i66.us.i.i, %33
  %_30.i70.us.i.i = icmp ult i64 %_28.i69.us.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_30.i70.us.i.i, label %bb18.i73.us.i.i, label %panic8.i71.split.us.i.i

bb18.i73.us.i.i:                                  ; preds = %bb42.i68.us.i.i
  %_65.i74.us.i.i = add i64 %iter.sroa.0.0.i66.us.i.i, 1
  %40 = getelementptr inbounds nuw i8, ptr %_162.sroa.14.0.copyload.i.i, i64 %iter.sroa.0.0.i66.us.i.i
  %_25.i75.us.i.i = load i8, ptr %40, align 1, !alias.scope !148, !noalias !153, !noundef !3
  %41 = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %_28.i69.us.i.i
  %_27.i76.us.i.i = load i8, ptr %41, align 1, !alias.scope !145, !noalias !150, !noundef !3
  %_24.not.i77.us.i.i = icmp eq i8 %_25.i75.us.i.i, %_27.i76.us.i.i
  br i1 %_24.not.i77.us.i.i, label %bb16.i65.us.i.i, label %bb19.i78.us.i.i

bb19.i78.us.i.i:                                  ; preds = %bb18.i73.us.i.i
  %reass.sub134 = sub i64 %33, %_162.sroa.4.0.copyload.i.i
  %_31.i80.us.i.i = add i64 %reass.sub134, 1
  %42 = add i64 %_31.i80.us.i.i, %iter.sroa.0.0.i66.us.i.i
  br label %bb37.i.us.i.i

bb46.i88.us.i.i:                                  ; preds = %bb26.i84.us.i.preheader.split.i
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %20, i64 noundef range(i64 0, -9223372036854775808) %_162.sroa.15.0.copyload.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_68bb27fa7fd7af0b8edb2570ef014cd2) #14, !noalias !116
  unreachable

.noexc31.us.i.i:                                  ; preds = %bb26.i.us.i.i, %bb26.i84.us.i.us.i, %bb26.i84.us.i.preheader.split.i
  %_93.sroa.30108.1.us.i.i = phi i64 [ -1, %bb26.i84.us.i.us.i ], [ -1, %bb26.i84.us.i.preheader.split.i ], [ 0, %bb26.i.us.i.i ]
  %.pn.i.i = phi i64 [ %33, %bb26.i84.us.i.us.i ], [ %33, %bb26.i84.us.i.preheader.split.i ], [ %22, %bb26.i.us.i.i ]
  %_93.sroa.18.1.us.i.i = add i64 %.pn.i.i, %_162.sroa.15.0.copyload.i.i
  %_4.0.i.i.us.i.i = add i64 %accum.sroa.0.0.i.us.i.i, 1
  br label %bb1.i29.us.i.i

bb10.i101.us.i.i:                                 ; preds = %bb39.i55.us.i.i
  %43 = add i64 %33, %_162.sroa.15.0.copyload.i.i
  br label %bb37.i.us.i.i

bb37.i.us.i.i:                                    ; preds = %bb10.i101.us.i.i, %bb19.i78.us.i.i, %bb29.i100.us.i.split.us.i
  %44 = phi i64 [ %42, %bb19.i78.us.i.i ], [ %43, %bb10.i101.us.i.i ], [ %39, %bb29.i100.us.i.split.us.i ]
  %index.i81.us.i.i = add i64 %44, %needle_last.i.i.i
  %_53.i82.us.i.i = icmp ult i64 %index.i81.us.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_53.i82.us.i.i, label %bb39.i55.us.i.i, label %bb43.i.i

panic8.i.split.us.i.i:                            ; preds = %bb42.i.us.i.i
  %45 = add i64 %22, %_0.sroa.0.0.i.i.us.i.i
  %umax.i.i.i = call i64 @llvm.umax.i64(i64 range(i64 0, -9223372036854775808) %_162.sroa.13.0.copyload.i.i, i64 %45)
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %umax.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %_162.sroa.13.0.copyload.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8ae9795802ad53c9398ce2776784dbc3) #14, !noalias !116
  unreachable

panic.i.split.us.i.i:                             ; preds = %bb46.i.us.i.i
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %_73.i.us.i.i, i64 noundef range(i64 0, -9223372036854775808) %_162.sroa.15.0.copyload.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_68bb27fa7fd7af0b8edb2570ef014cd2) #14, !noalias !116
  unreachable

panic5.i.split.us.i.i:                            ; preds = %bb27.i.us.i.i
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %_45.i.us.i.i, i64 noundef range(i64 0, -9223372036854775808) %_162.sroa.13.0.copyload.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8deac4fa778727f9c004a28bc20bcda6) #14, !noalias !116
  unreachable

panic8.i71.split.us.i.i:                          ; preds = %bb42.i68.us.i.i
  %46 = add i64 %33, %_162.sroa.4.0.copyload.i.i
  %umax.i72.i.i = call i64 @llvm.umax.i64(i64 range(i64 0, -9223372036854775808) %_162.sroa.13.0.copyload.i.i, i64 %46)
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %umax.i72.i.i, i64 noundef range(i64 0, -9223372036854775808) %_162.sroa.13.0.copyload.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8ae9795802ad53c9398ce2776784dbc3) #14, !noalias !116
  unreachable

panic5.i95.split.us.i.i:                          ; preds = %bb46.i88.us.i.us.i
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %_45.i93.us.i.us.i, i64 noundef range(i64 0, -9223372036854775808) %_162.sroa.13.0.copyload.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8deac4fa778727f9c004a28bc20bcda6) #14, !noalias !116
  unreachable

bb41.split.i.i:                                   ; preds = %bb41.i.i
  %47 = and i64 %_162.sroa.6.0.copyload.i.i, 65536
  %_4.i.i.not.i.i = icmp eq i64 %47, 0
  br i1 %_4.i.i.not.i.i, label %bb5.i.lr.ph.i.lr.ph.i.i, label %bb29.i.sink.split.i

bb5.i.lr.ph.i.lr.ph.i.i:                          ; preds = %bb41.split.i.i
  call void @llvm.assume(i1 %17)
  %extract.t.i.i = trunc i64 %_162.sroa.6.0.copyload.i.i to i1
  %48 = icmp eq i64 %_162.sroa.4.0.copyload.i.i, 0
  br i1 %48, label %bb20.i.i.peel.i.peel.i, label %bb5.i.i.i.peel.i.peel.i

bb5.i.i.i.peel.i.peel.i:                          ; preds = %bb5.i.lr.ph.i.lr.ph.i.i
  %_8.not.i.i.i.peel.i.peel.i = icmp ult i64 %_162.sroa.4.0.copyload.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_8.not.i.i.i.peel.i.peel.i, label %bb9.i.i.i.peel.i.peel.i, label %bb6.i.i.i.peel.i.peel.i

bb6.i.i.i.peel.i.peel.i:                          ; preds = %bb5.i.i.i.peel.i.peel.i
  %49 = icmp eq i64 %_162.sroa.4.0.copyload.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %49, label %bb20.i.i.peel.i.peel.i, label %bb19.i.i.i.i

bb9.i.i.i.peel.i.peel.i:                          ; preds = %bb5.i.i.i.peel.i.peel.i
  %50 = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %_162.sroa.4.0.copyload.i.i
  %self1.i.i.i32.peel.i.peel.i = load i8, ptr %50, align 1, !alias.scope !154, !noalias !157, !noundef !3
  %51 = icmp sgt i8 %self1.i.i.i32.peel.i.peel.i, -65
  br i1 %51, label %bb20.i.i.peel.i.peel.i, label %bb19.i.i.i.i

bb20.i.i.peel.i.peel.i:                           ; preds = %bb9.i.i.i.peel.i.peel.i, %bb6.i.i.i.peel.i.peel.i, %bb5.i.lr.ph.i.lr.ph.i.i
  %data.i.i.i.peel.i.peel.i = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %_162.sroa.4.0.copyload.i.i
  %_6.i.i.i.i.peel.i.peel.i = icmp samesign eq i64 %_162.sroa.4.0.copyload.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_6.i.i.i.i.peel.i.peel.i, label %bb22.i.i.i.peel.i, label %bb15.i.i.i.peel.i.peel.i

bb15.i.i.i.peel.i.peel.i:                         ; preds = %bb20.i.i.peel.i.peel.i
  %x.i.i.i.peel.i.peel.i = load i8, ptr %data.i.i.i.peel.i.peel.i, align 1, !noalias !164, !noundef !3
  %_7.i.i.i.peel.i.peel.i = icmp sgt i8 %x.i.i.i.peel.i.peel.i, -1
  br i1 %_7.i.i.i.peel.i.peel.i, label %bb3.i.i.i.peel.i.peel.i, label %bb4.i.i.i.peel.i.peel.i

bb4.i.i.i.peel.i.peel.i:                          ; preds = %bb15.i.i.i.peel.i.peel.i
  %_16.i.i.i.i.peel.i.peel.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.peel.i.peel.i, i64 1
  %_33.i.i.i.peel.i.peel.i = and i8 %x.i.i.i.peel.i.peel.i, 31
  %init.i.i.i.peel.i.peel.i = zext nneg i8 %_33.i.i.i.peel.i.peel.i to i32
  %52 = add nuw nsw i64 %_162.sroa.4.0.copyload.i.i, 1
  %_6.i10.i.i.i.peel.i.peel.i = icmp samesign ne i64 %52, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i10.i.i.i.peel.i.peel.i)
  %y.i.i.i.peel.i.peel.i = load i8, ptr %_16.i.i.i.i.peel.i.peel.i, align 1, !noalias !164, !noundef !3
  %_36.i.i.i.peel.i.peel.i = shl nuw nsw i32 %init.i.i.i.peel.i.peel.i, 6
  %_38.i.i.i.peel.i.peel.i = and i8 %y.i.i.i.peel.i.peel.i, 63
  %_37.i.i.i.peel.i.peel.i = zext nneg i8 %_38.i.i.i.peel.i.peel.i to i32
  %53 = or disjoint i32 %_36.i.i.i.peel.i.peel.i, %_37.i.i.i.peel.i.peel.i
  %_14.i.i.i.peel.i.peel.i = icmp samesign ugt i8 %x.i.i.i.peel.i.peel.i, -33
  br i1 %_14.i.i.i.peel.i.peel.i, label %bb6.i21.i.i.peel.i.peel.i, label %bb23.i.i.peel.i.peel.i

bb6.i21.i.i.peel.i.peel.i:                        ; preds = %bb4.i.i.i.peel.i.peel.i
  %_16.i12.i.i.i.peel.i.peel.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.peel.i.peel.i, i64 2
  %54 = add nuw nsw i64 %_162.sroa.4.0.copyload.i.i, 2
  %_6.i17.i.i.i.peel.i.peel.i = icmp samesign ne i64 %54, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i17.i.i.i.peel.i.peel.i)
  %z.i.i.i.peel.i.peel.i = load i8, ptr %_16.i12.i.i.i.peel.i.peel.i, align 1, !noalias !164, !noundef !3
  %_41.i.i.i.peel.i.peel.i = shl nuw nsw i32 %_37.i.i.i.peel.i.peel.i, 6
  %_43.i.i.i.peel.i.peel.i = and i8 %z.i.i.i.peel.i.peel.i, 63
  %_42.i.i.i.peel.i.peel.i = zext nneg i8 %_43.i.i.i.peel.i.peel.i to i32
  %y_z.i.i.i.peel.i.peel.i = or disjoint i32 %_41.i.i.i.peel.i.peel.i, %_42.i.i.i.peel.i.peel.i
  %_21.i.i.i.peel.i.peel.i = shl nuw nsw i32 %init.i.i.i.peel.i.peel.i, 12
  %55 = or disjoint i32 %y_z.i.i.i.peel.i.peel.i, %_21.i.i.i.peel.i.peel.i
  %_22.i.i.i.peel.i.peel.i = icmp samesign ugt i8 %x.i.i.i.peel.i.peel.i, -17
  br i1 %_22.i.i.i.peel.i.peel.i, label %bb8.i.i.i.peel.i.peel.i, label %bb23.i.i.peel.i.peel.i

bb8.i.i.i.peel.i.peel.i:                          ; preds = %bb6.i21.i.i.peel.i.peel.i
  %_16.i19.i.i.i.peel.i.peel.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.peel.i.peel.i, i64 3
  %56 = add nuw nsw i64 %_162.sroa.4.0.copyload.i.i, 3
  %_6.i24.i.i.i.peel.i.peel.i = icmp samesign ne i64 %56, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i24.i.i.i.peel.i.peel.i)
  %w.i.i.i.peel.i.peel.i = load i8, ptr %_16.i19.i.i.i.peel.i.peel.i, align 1, !noalias !164, !noundef !3
  %_27.i.i.i.peel.i.peel.i = shl nuw nsw i32 %init.i.i.i.peel.i.peel.i, 18
  %_26.i.i.i.peel.i.peel.i = and i32 %_27.i.i.i.peel.i.peel.i, 1835008
  %_46.i.i.i.peel.i.peel.i = shl nuw nsw i32 %y_z.i.i.i.peel.i.peel.i, 6
  %_48.i.i.i.peel.i.peel.i = and i8 %w.i.i.i.peel.i.peel.i, 63
  %_47.i.i.i.peel.i.peel.i = zext nneg i8 %_48.i.i.i.peel.i.peel.i to i32
  %_28.i.i.i.peel.i.peel.i = or disjoint i32 %_46.i.i.i.peel.i.peel.i, %_47.i.i.i.peel.i.peel.i
  %57 = or disjoint i32 %_28.i.i.i.peel.i.peel.i, %_26.i.i.i.peel.i.peel.i
  br label %bb23.i.i.peel.i.peel.i

bb3.i.i.i.peel.i.peel.i:                          ; preds = %bb15.i.i.i.peel.i.peel.i
  %_8.i.i.i.peel.i.peel.i = zext nneg i8 %x.i.i.i.peel.i.peel.i to i32
  br label %bb23.i.i.peel.i.peel.i

bb23.i.i.peel.i.peel.i:                           ; preds = %bb3.i.i.i.peel.i.peel.i, %bb8.i.i.i.peel.i.peel.i, %bb6.i21.i.i.peel.i.peel.i, %bb4.i.i.i.peel.i.peel.i
  %_0.sroa.4.0.i.ph.i.i.peel.i.peel.i = phi i32 [ %55, %bb6.i21.i.i.peel.i.peel.i ], [ %57, %bb8.i.i.i.peel.i.peel.i ], [ %53, %bb4.i.i.i.peel.i.peel.i ], [ %_8.i.i.i.peel.i.peel.i, %bb3.i.i.i.peel.i.peel.i ]
  %58 = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.i.peel.i.peel.i, 1114112
  call void @llvm.assume(i1 %58)
  br i1 %extract.t.i.i, label %bb5.i.lr.ph.i.i.i.preheader, label %bb40.i.i.peel.i.peel.i

bb5.i.lr.ph.i.i.i.preheader:                      ; preds = %bb4.i.i.i.i.peel.i, %bb6.i21.i.i.i.peel.i, %bb8.i.i.i.i.peel.i, %bb15.i.i.i.i.peel.i, %bb22.i.i.i.peel.i, %bb20.i.i.i.peel.i, %bb23.i.i.peel.i.peel.i
  %_93.sroa.4.0271.i.i.ph = phi i64 [ %_162.sroa.4.0.copyload.i.i, %bb23.i.i.peel.i.peel.i ], [ %_162.sroa.13.0.copyload.i.i, %bb20.i.i.i.peel.i ], [ %_162.sroa.4.0.copyload.i.i, %bb22.i.i.i.peel.i ], [ %59, %bb15.i.i.i.i.peel.i ], [ %59, %bb8.i.i.i.i.peel.i ], [ %59, %bb6.i21.i.i.i.peel.i ], [ %59, %bb4.i.i.i.i.peel.i ]
  br label %bb5.i.lr.ph.i.i.i

bb40.i.i.peel.i.peel.i:                           ; preds = %bb23.i.i.peel.i.peel.i
  %_61.i.i.peel.i.peel.i = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.i.peel.i.peel.i, 128
  br i1 %_61.i.i.peel.i.peel.i, label %bb5.i.i.i.peel.i, label %bb27.i.i.peel.i.peel.i

bb27.i.i.peel.i.peel.i:                           ; preds = %bb40.i.i.peel.i.peel.i
  %_62.i.i.peel.i.peel.i = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.i.peel.i.peel.i, 2048
  br i1 %_62.i.i.peel.i.peel.i, label %bb5.i.i.i.peel.i, label %bb28.i.i.peel.i.peel.i

bb28.i.i.peel.i.peel.i:                           ; preds = %bb27.i.i.peel.i.peel.i
  %_63.i.i.peel.i.peel.i = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.i.peel.i.peel.i, 65536
  %..i.i.peel.i.peel.i = select i1 %_63.i.i.peel.i.peel.i, i64 3, i64 4
  br label %bb5.i.i.i.peel.i

bb5.i.i.i.peel.i:                                 ; preds = %bb28.i.i.peel.i.peel.i, %bb27.i.i.peel.i.peel.i, %bb40.i.i.peel.i.peel.i
  %_14.sroa.0.0.i.i.peel.i.peel.i = phi i64 [ 2, %bb27.i.i.peel.i.peel.i ], [ %..i.i.peel.i.peel.i, %bb28.i.i.peel.i.peel.i ], [ 1, %bb40.i.i.peel.i.peel.i ]
  %59 = add i64 %_14.sroa.0.0.i.i.peel.i.peel.i, %_162.sroa.4.0.copyload.i.i
  %60 = icmp eq i64 %59, 0
  br i1 %60, label %bb20.i.i.i.peel.i, label %bb5.i.i.i.i.peel.i

bb5.i.i.i.i.peel.i:                               ; preds = %bb5.i.i.i.peel.i
  %_8.not.i.i.i.i.peel.i = icmp ult i64 %59, %_162.sroa.13.0.copyload.i.i
  br i1 %_8.not.i.i.i.i.peel.i, label %bb9.i.i.i.i.peel.i, label %bb6.i.i.i.i.peel.i

bb6.i.i.i.i.peel.i:                               ; preds = %bb5.i.i.i.i.peel.i
  %61 = icmp eq i64 %59, %_162.sroa.13.0.copyload.i.i
  br i1 %61, label %bb20.i.i.i.peel.i, label %bb19.i.i.i.i

bb9.i.i.i.i.peel.i:                               ; preds = %bb5.i.i.i.i.peel.i
  %62 = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %59
  %self1.i.i.i32.i.peel.i = load i8, ptr %62, align 1, !alias.scope !154, !noalias !157, !noundef !3
  %63 = icmp sgt i8 %self1.i.i.i32.i.peel.i, -65
  br i1 %63, label %bb20.i.i.i.peel.i, label %bb19.i.i.i.i

bb20.i.i.i.peel.i:                                ; preds = %bb9.i.i.i.i.peel.i, %bb6.i.i.i.i.peel.i, %bb5.i.i.i.peel.i
  %_6.i.i.i.i.i.peel.i = icmp samesign eq i64 %59, %_162.sroa.13.0.copyload.i.i
  br i1 %_6.i.i.i.i.i.peel.i, label %bb5.i.lr.ph.i.i.i.preheader, label %bb15.i.i.i.i.peel.i

bb15.i.i.i.i.peel.i:                              ; preds = %bb20.i.i.i.peel.i
  %data.i.i.i.i.peel.i = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %59
  %x.i.i.i.i.peel.i = load i8, ptr %data.i.i.i.i.peel.i, align 1, !noalias !164, !noundef !3
  %_7.i.i.i.i.peel.i = icmp sgt i8 %x.i.i.i.i.peel.i, -1
  br i1 %_7.i.i.i.i.peel.i, label %bb5.i.lr.ph.i.i.i.preheader, label %bb4.i.i.i.i.peel.i

bb4.i.i.i.i.peel.i:                               ; preds = %bb15.i.i.i.i.peel.i
  %64 = add nuw nsw i64 %59, 1
  %_6.i10.i.i.i.i.peel.i = icmp samesign ne i64 %64, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i10.i.i.i.i.peel.i)
  %_14.i.i.i.i.peel.i = icmp samesign ugt i8 %x.i.i.i.i.peel.i, -33
  br i1 %_14.i.i.i.i.peel.i, label %bb6.i21.i.i.i.peel.i, label %bb5.i.lr.ph.i.i.i.preheader

bb6.i21.i.i.i.peel.i:                             ; preds = %bb4.i.i.i.i.peel.i
  %65 = add nuw nsw i64 %59, 2
  %_6.i17.i.i.i.i.peel.i = icmp samesign ne i64 %65, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i17.i.i.i.i.peel.i)
  %_22.i.i.i.i.peel.i = icmp samesign ugt i8 %x.i.i.i.i.peel.i, -17
  br i1 %_22.i.i.i.i.peel.i, label %bb8.i.i.i.i.peel.i, label %bb5.i.lr.ph.i.i.i.preheader

bb8.i.i.i.i.peel.i:                               ; preds = %bb6.i21.i.i.i.peel.i
  %66 = add nuw nsw i64 %59, 3
  %_6.i24.i.i.i.i.peel.i = icmp samesign ne i64 %66, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i24.i.i.i.i.peel.i)
  br label %bb5.i.lr.ph.i.i.i.preheader

bb22.i.i.i.peel.i:                                ; preds = %bb20.i.i.peel.i.peel.i
  br i1 %extract.t.i.i, label %bb5.i.lr.ph.i.i.i.preheader, label %bb29.i.sink.split.i

bb40.i.i:                                         ; preds = %bb9.i27.i.i, %bb6.i25.i.i
; call core::str::slice_error_fail
  call void @_RNvNtCsgtPOCBgevO_4core3str16slice_error_fail(ptr noalias noundef nonnull readonly captures(address, read_provenance) %data.i.i.i, i64 noundef %new_len.i.i.i, i64 noundef 0, i64 noundef %x.i18.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4c92989ea71fda7e0c89e82a9cab1489) #14, !noalias !116
  unreachable

bb5.i.lr.ph.i.i.i:                                ; preds = %bb5.i.lr.ph.i.i.i.preheader, %.noexc31.i.i
  %accum.sroa.0.0.i272.i.i = phi i64 [ %_4.0.i.i.i.i, %.noexc31.i.i ], [ 1, %bb5.i.lr.ph.i.i.i.preheader ]
  %_93.sroa.4.0271.i.i = phi i64 [ %_93.sroa.4.1294.i.i, %.noexc31.i.i ], [ %_93.sroa.4.0271.i.i.ph, %bb5.i.lr.ph.i.i.i.preheader ]
  %67 = icmp eq i64 %_93.sroa.4.0271.i.i, 0
  br i1 %67, label %bb20.i.i.peel.i.i, label %bb5.i.i.i.peel.i.i

bb5.i.i.i.peel.i.i:                               ; preds = %bb5.i.lr.ph.i.i.i
  %_8.not.i.i.i.peel.i.i = icmp ult i64 %_93.sroa.4.0271.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_8.not.i.i.i.peel.i.i, label %bb9.i.i.i.peel.i.i, label %bb6.i.i.i.peel.i.i

bb6.i.i.i.peel.i.i:                               ; preds = %bb5.i.i.i.peel.i.i
  %68 = icmp eq i64 %_93.sroa.4.0271.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %68, label %bb20.i.i.peel.i.i, label %bb19.i.i.i.i

bb9.i.i.i.peel.i.i:                               ; preds = %bb5.i.i.i.peel.i.i
  %69 = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %_93.sroa.4.0271.i.i
  %self1.i.i.i32.peel.i.i = load i8, ptr %69, align 1, !alias.scope !154, !noalias !157, !noundef !3
  %70 = icmp sgt i8 %self1.i.i.i32.peel.i.i, -65
  br i1 %70, label %bb20.i.i.peel.i.i, label %bb19.i.i.i.i

bb20.i.i.peel.i.i:                                ; preds = %bb9.i.i.i.peel.i.i, %bb6.i.i.i.peel.i.i, %bb5.i.lr.ph.i.i.i
  %data.i.i.i.peel.i.i = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %_93.sroa.4.0271.i.i
  %_6.i.i.i.i.peel.i.i = icmp samesign eq i64 %_93.sroa.4.0271.i.i, %_162.sroa.13.0.copyload.i.i
  br i1 %_6.i.i.i.i.peel.i.i, label %bb43.i.i, label %bb15.i.i.i.peel.i.i

bb15.i.i.i.peel.i.i:                              ; preds = %bb20.i.i.peel.i.i
  %x.i.i.i.peel.i.i = load i8, ptr %data.i.i.i.peel.i.i, align 1, !noalias !164, !noundef !3
  %_7.i.i.i.peel.i.i = icmp sgt i8 %x.i.i.i.peel.i.i, -1
  br i1 %_7.i.i.i.peel.i.i, label %bb5.i.i.i.i, label %bb4.i.i.i.peel.i.i

bb4.i.i.i.peel.i.i:                               ; preds = %bb15.i.i.i.peel.i.i
  %_16.i.i.i.i.peel.i.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.peel.i.i, i64 1
  %_33.i.i.i.peel.i.i = and i8 %x.i.i.i.peel.i.i, 31
  %init.i.i.i.peel.i.i = zext nneg i8 %_33.i.i.i.peel.i.i to i32
  %71 = add nuw nsw i64 %_93.sroa.4.0271.i.i, 1
  %_6.i10.i.i.i.peel.i.i = icmp samesign ne i64 %71, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i10.i.i.i.peel.i.i)
  %y.i.i.i.peel.i.i = load i8, ptr %_16.i.i.i.i.peel.i.i, align 1, !noalias !164, !noundef !3
  %_36.i.i.i.peel.i.i = shl nuw nsw i32 %init.i.i.i.peel.i.i, 6
  %_38.i.i.i.peel.i.i = and i8 %y.i.i.i.peel.i.i, 63
  %_37.i.i.i.peel.i.i = zext nneg i8 %_38.i.i.i.peel.i.i to i32
  %72 = or disjoint i32 %_36.i.i.i.peel.i.i, %_37.i.i.i.peel.i.i
  %_14.i.i.i.peel.i.i = icmp samesign ugt i8 %x.i.i.i.peel.i.i, -33
  br i1 %_14.i.i.i.peel.i.i, label %bb6.i21.i.i.peel.i.i, label %bb40.i.i.peel.i.i

bb6.i21.i.i.peel.i.i:                             ; preds = %bb4.i.i.i.peel.i.i
  %_16.i12.i.i.i.peel.i.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.peel.i.i, i64 2
  %73 = add nuw nsw i64 %_93.sroa.4.0271.i.i, 2
  %_6.i17.i.i.i.peel.i.i = icmp samesign ne i64 %73, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i17.i.i.i.peel.i.i)
  %z.i.i.i.peel.i.i = load i8, ptr %_16.i12.i.i.i.peel.i.i, align 1, !noalias !164, !noundef !3
  %_41.i.i.i.peel.i.i = shl nuw nsw i32 %_37.i.i.i.peel.i.i, 6
  %_43.i.i.i.peel.i.i = and i8 %z.i.i.i.peel.i.i, 63
  %_42.i.i.i.peel.i.i = zext nneg i8 %_43.i.i.i.peel.i.i to i32
  %y_z.i.i.i.peel.i.i = or disjoint i32 %_41.i.i.i.peel.i.i, %_42.i.i.i.peel.i.i
  %_21.i.i.i.peel.i.i = shl nuw nsw i32 %init.i.i.i.peel.i.i, 12
  %74 = or disjoint i32 %y_z.i.i.i.peel.i.i, %_21.i.i.i.peel.i.i
  %_22.i.i.i.peel.i.i = icmp samesign ugt i8 %x.i.i.i.peel.i.i, -17
  br i1 %_22.i.i.i.peel.i.i, label %bb8.i.i.i.peel.i.i, label %bb40.i.i.peel.i.i

bb8.i.i.i.peel.i.i:                               ; preds = %bb6.i21.i.i.peel.i.i
  %_16.i19.i.i.i.peel.i.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.peel.i.i, i64 3
  %75 = add nuw nsw i64 %_93.sroa.4.0271.i.i, 3
  %_6.i24.i.i.i.peel.i.i = icmp samesign ne i64 %75, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i24.i.i.i.peel.i.i)
  %w.i.i.i.peel.i.i = load i8, ptr %_16.i19.i.i.i.peel.i.i, align 1, !noalias !164, !noundef !3
  %_27.i.i.i.peel.i.i = shl nuw nsw i32 %init.i.i.i.peel.i.i, 18
  %_26.i.i.i.peel.i.i = and i32 %_27.i.i.i.peel.i.i, 1835008
  %_46.i.i.i.peel.i.i = shl nuw nsw i32 %y_z.i.i.i.peel.i.i, 6
  %_48.i.i.i.peel.i.i = and i8 %w.i.i.i.peel.i.i, 63
  %_47.i.i.i.peel.i.i = zext nneg i8 %_48.i.i.i.peel.i.i to i32
  %_28.i.i.i.peel.i.i = or disjoint i32 %_46.i.i.i.peel.i.i, %_47.i.i.i.peel.i.i
  %76 = or disjoint i32 %_28.i.i.i.peel.i.i, %_26.i.i.i.peel.i.i
  br label %bb40.i.i.peel.i.i

bb40.i.i.peel.i.i:                                ; preds = %bb8.i.i.i.peel.i.i, %bb6.i21.i.i.peel.i.i, %bb4.i.i.i.peel.i.i
  %_0.sroa.4.0.i.ph.i.i.peel.i.i = phi i32 [ %74, %bb6.i21.i.i.peel.i.i ], [ %76, %bb8.i.i.i.peel.i.i ], [ %72, %bb4.i.i.i.peel.i.i ]
  %77 = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.i.peel.i.i, 1114112
  call void @llvm.assume(i1 %77)
  %_61.i.i.peel.i.i = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.i.peel.i.i, 128
  br i1 %_61.i.i.peel.i.i, label %bb5.i.i.i.i, label %bb27.i.i.peel.i.i

bb27.i.i.peel.i.i:                                ; preds = %bb40.i.i.peel.i.i
  %_62.i.i.peel.i.i = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.i.peel.i.i, 2048
  br i1 %_62.i.i.peel.i.i, label %bb5.i.i.i.i, label %bb28.i.i.peel.i.i

bb28.i.i.peel.i.i:                                ; preds = %bb27.i.i.peel.i.i
  %_63.i.i.peel.i.i = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.i.peel.i.i, 65536
  %..i.i.peel.i.i = select i1 %_63.i.i.peel.i.i, i64 3, i64 4
  br label %bb5.i.i.i.i

bb5.i.i.i.i:                                      ; preds = %bb28.i.i.peel.i.i, %bb27.i.i.peel.i.i, %bb40.i.i.peel.i.i, %bb15.i.i.i.peel.i.i
  %_14.sroa.0.0.i.i.peel.i.i = phi i64 [ 2, %bb27.i.i.peel.i.i ], [ %..i.i.peel.i.i, %bb28.i.i.peel.i.i ], [ 1, %bb40.i.i.peel.i.i ], [ 1, %bb15.i.i.i.peel.i.i ]
  %78 = add i64 %_14.sroa.0.0.i.i.peel.i.i, %_93.sroa.4.0271.i.i
  %79 = icmp eq i64 %78, 0
  br i1 %79, label %bb20.i.i.i.i, label %bb5.i.i.i.i.i

bb5.i.i.i.i.i:                                    ; preds = %bb5.i.i.i.i
  %_8.not.i.i.i.i.i = icmp ult i64 %78, %_162.sroa.13.0.copyload.i.i
  br i1 %_8.not.i.i.i.i.i, label %bb9.i.i.i.i.i, label %bb6.i.i.i.i.i

bb6.i.i.i.i.i:                                    ; preds = %bb5.i.i.i.i.i
  %80 = icmp eq i64 %78, %_162.sroa.13.0.copyload.i.i
  br i1 %80, label %bb20.i.i.i.i, label %bb19.i.i.i.i

bb9.i.i.i.i.i:                                    ; preds = %bb5.i.i.i.i.i
  %81 = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %78
  %self1.i.i.i32.i.i = load i8, ptr %81, align 1, !alias.scope !154, !noalias !157, !noundef !3
  %82 = icmp sgt i8 %self1.i.i.i32.i.i, -65
  br i1 %82, label %bb20.i.i.i.i, label %bb19.i.i.i.i

bb20.i.i.i.i:                                     ; preds = %bb9.i.i.i.i.i, %bb6.i.i.i.i.i, %bb5.i.i.i.i
  %_6.i.i.i.i.i.i = icmp samesign eq i64 %78, %_162.sroa.13.0.copyload.i.i
  br i1 %_6.i.i.i.i.i.i, label %.noexc31.i.i, label %bb15.i.i.i.i.i

bb15.i.i.i.i.i:                                   ; preds = %bb20.i.i.i.i
  %data.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_162.sroa.12.0.copyload.i.i, i64 %78
  %x.i.i.i.i.i = load i8, ptr %data.i.i.i.i.i, align 1, !noalias !164, !noundef !3
  %_7.i.i.i.i.i = icmp sgt i8 %x.i.i.i.i.i, -1
  br i1 %_7.i.i.i.i.i, label %.noexc31.i.i, label %bb4.i.i.i.i.i

bb4.i.i.i.i.i:                                    ; preds = %bb15.i.i.i.i.i
  %83 = add nuw nsw i64 %78, 1
  %_6.i10.i.i.i.i.i = icmp samesign ne i64 %83, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i10.i.i.i.i.i)
  %_14.i.i.i.i.i = icmp samesign ugt i8 %x.i.i.i.i.i, -33
  br i1 %_14.i.i.i.i.i, label %bb6.i21.i.i.i.i, label %.noexc31.i.i

bb6.i21.i.i.i.i:                                  ; preds = %bb4.i.i.i.i.i
  %84 = add nuw nsw i64 %78, 2
  %_6.i17.i.i.i.i.i = icmp samesign ne i64 %84, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i17.i.i.i.i.i)
  %_22.i.i.i.i.i = icmp samesign ugt i8 %x.i.i.i.i.i, -17
  br i1 %_22.i.i.i.i.i, label %bb8.i.i.i.i.i, label %.noexc31.i.i

bb8.i.i.i.i.i:                                    ; preds = %bb6.i21.i.i.i.i
  %85 = add nuw nsw i64 %78, 3
  %_6.i24.i.i.i.i.i = icmp samesign ne i64 %85, %_162.sroa.13.0.copyload.i.i
  call void @llvm.assume(i1 %_6.i24.i.i.i.i.i)
  br label %.noexc31.i.i

bb19.i.i.i.i:                                     ; preds = %bb9.i.i.i.i.peel.i, %bb6.i.i.i.i.peel.i, %bb9.i.i.i.peel.i.peel.i, %bb6.i.i.i.peel.i.peel.i, %bb9.i.i.i.i.i, %bb6.i.i.i.i.i, %bb9.i.i.i.peel.i.i, %bb6.i.i.i.peel.i.i
  %_93.sroa.4.1.lcssa.i.i = phi i64 [ %78, %bb9.i.i.i.i.i ], [ %_93.sroa.4.0271.i.i, %bb9.i.i.i.peel.i.i ], [ %_93.sroa.4.0271.i.i, %bb6.i.i.i.peel.i.i ], [ %78, %bb6.i.i.i.i.i ], [ %59, %bb9.i.i.i.i.peel.i ], [ %59, %bb6.i.i.i.i.peel.i ], [ %_162.sroa.4.0.copyload.i.i, %bb9.i.i.i.peel.i.peel.i ], [ %_162.sroa.4.0.copyload.i.i, %bb6.i.i.i.peel.i.peel.i ]
; call core::str::slice_error_fail
  call void @_RNvNtCsgtPOCBgevO_4core3str16slice_error_fail(ptr noalias noundef nonnull readonly captures(address, read_provenance) %_162.sroa.12.0.copyload.i.i, i64 noundef %_162.sroa.13.0.copyload.i.i, i64 noundef %_93.sroa.4.1.lcssa.i.i, i64 noundef %_162.sroa.13.0.copyload.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_de5e2f1dd01253ae804bfe6ba3503da0) #14, !noalias !116
  unreachable

.noexc31.i.i:                                     ; preds = %bb4.i.i.i.i.i, %bb6.i21.i.i.i.i, %bb8.i.i.i.i.i, %bb15.i.i.i.i.i, %bb20.i.i.i.i
  %_93.sroa.4.1294.i.i = phi i64 [ %_162.sroa.13.0.copyload.i.i, %bb20.i.i.i.i ], [ %78, %bb15.i.i.i.i.i ], [ %78, %bb8.i.i.i.i.i ], [ %78, %bb6.i21.i.i.i.i ], [ %78, %bb4.i.i.i.i.i ]
  %_4.0.i.i.i.i = add i64 %accum.sroa.0.0.i272.i.i, 1
  br label %bb5.i.lr.ph.i.i.i, !llvm.loop !167

bb43.i.i:                                         ; preds = %bb20.i.i.peel.i.i, %bb8.i.us.i.i, %bb10.i.us.i.i, %bb37.sink.split.i.us.i.i, %bb37.i.us.i.i
  %accum.sroa.0.0.i183.i.i = phi i64 [ %accum.sroa.0.0.i.us.i.i, %bb37.i.us.i.i ], [ %accum.sroa.0.0.i.us.i.i, %bb8.i.us.i.i ], [ %accum.sroa.0.0.i.us.i.i, %bb37.sink.split.i.us.i.i ], [ %accum.sroa.0.0.i.us.i.i, %bb10.i.us.i.i ], [ %accum.sroa.0.0.i272.i.i, %bb20.i.i.peel.i.i ]
  store i64 %accum.sroa.0.0.i183.i.i, ptr %_92.i.i, align 8, !noalias !116
  %86 = icmp eq i64 %accum.sroa.0.0.i183.i.i, 1
  br i1 %86, label %bb28.i.i, label %bb29.i.i, !prof !34

bb28.i.i:                                         ; preds = %bb43.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_92.i.i), !noalias !116
  br i1 %_5.not.i.i.i, label %_RNCNvCs21ATSyVuzIl_17prepared_consumer50prepared_and_manual_whole_consumers_are_equivalent0B3_.exit, label %bb20.i.i

bb29.i.sink.split.i:                              ; preds = %bb22.i.i.i.peel.i, %bb41.split.i.i
  store i64 0, ptr %_92.i.i, align 8, !noalias !116
  br label %bb29.i.i

bb29.i.i:                                         ; preds = %bb43.i.i, %bb29.i.sink.split.i
; call core::panicking::assert_failed::<usize, usize>
  call void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_(i8 noundef 0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_92.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) @alloc_edb3ed16ed07237eac14eb16826c52e0, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_7b2885fbf347689c42120fce9d13749d) #14, !noalias !116
  unreachable

_RNCNvCs21ATSyVuzIl_17prepared_consumer50prepared_and_manual_whole_consumers_are_equivalent0B3_.exit: ; preds = %bb28.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %iter.i.i), !noalias !116
  call void @llvm.lifetime.end.p0(ptr nonnull %three_types.i.i), !noalias !116
  call void @llvm.lifetime.end.p0(ptr nonnull %three_entities.i.i), !noalias !116
  call void @llvm.lifetime.end.p0(ptr nonnull %types.i.i), !noalias !116
  call void @llvm.lifetime.end.p0(ptr nonnull %entities.i.i), !noalias !116
  store i64 -1, ptr %_0, align 8, !alias.scope !169
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #5

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #4

; Function Attrs: nounwind uwtable
declare noundef range(i32 0, 10) i32 @rust_eh_personality(i32 noundef, i32 noundef, i64 noundef, ptr noundef, ptr noundef) unnamed_addr #7

; <core::fmt::builders::DebugList>::entry
; Function Attrs: uwtable
declare noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef align 8 dereferenceable(16), ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #2

; std::rt::lang_start_internal
; Function Attrs: uwtable
declare noundef i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48), i64 noundef, ptr noundef, i8 noundef) unnamed_addr #1

; core::panicking::assert_failed_inner
; Function Attrs: cold minsize noinline noreturn optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner(i8 noundef range(i8 0, 3), ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noundef, ptr, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #8

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: read)
declare i32 @memcmp(ptr captures(none), ptr captures(none), i64) local_unnamed_addr #9

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef, i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #10

; <nudox_ir_format::PreparedFragment>::write_into
; Function Attrs: uwtable
declare void @_RNvMs0_Csks33AUGQlhz_15nudox_ir_formatNtB5_16PreparedFragment10write_into(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24), ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(48), ptr noalias noundef nonnull, i64 noundef range(i64 0, -9223372036854775808)) unnamed_addr #1

; <nudox_ir_format::FragmentView>::validate
; Function Attrs: uwtable
declare void @_RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate(ptr dead_on_unwind noalias noundef writable sret([48 x i8]) align 8 captures(none) dereferenceable(48), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808)) unnamed_addr #1

; test::test_main_static
; Function Attrs: uwtable
declare void @_RNvCs3O4ZRUMviTO_4test16test_main_static(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance), i64 noundef range(i64 0, 1152921504606846976)) unnamed_addr #1

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking9panic_fmt(ptr noundef nonnull, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #10

; core::str::slice_error_fail
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtCsgtPOCBgevO_4core3str16slice_error_fail(ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #10

; <core::str::pattern::StrSearcher>::new
; Function Attrs: uwtable
declare void @_RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new(ptr dead_on_unwind noalias noundef writable sret([104 x i8]) align 8 captures(none) dereferenceable(104), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef) unnamed_addr #1

; core::panicking::assert_failed::<usize, usize>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
declare void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_(i8 noundef range(i8 0, 3), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noundef, ptr, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #2

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXNtNtNtCsgtPOCBgevO_4core3fmt3num3imphNtB6_7Display3fmt(ptr noalias noundef readonly captures(address, read_provenance) dereferenceable(1), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXsg_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8UpperHex3fmt(ptr noalias noundef readonly captures(address, read_provenance) dereferenceable(1), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXse_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8LowerHex3fmt(ptr noalias noundef readonly captures(address, read_provenance) dereferenceable(1), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <usize as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <usize as core::fmt::UpperHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <usize as core::fmt::LowerHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field2_finish
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: uwtable
declare void @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter10debug_list(ptr dead_on_unwind noalias noundef writable sret([16 x i8]) align 8 captures(address) dereferenceable(16), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <core::fmt::builders::DebugList>::finish
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList6finish(ptr noalias noundef align 8 dereferenceable(16)) unnamed_addr #1

define noundef i32 @main(i32 %0, ptr %1) unnamed_addr #11 {
top:
  %_7.i = alloca [8 x i8], align 8
  %2 = sext i32 %0 to i64
  call void @llvm.lifetime.start.p0(ptr nonnull %_7.i)
  store ptr @_RNvCs21ATSyVuzIl_17prepared_consumer4main, ptr %_7.i, align 8
; call std::rt::lang_start_internal
  %_0.i = call noundef i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr noundef nonnull %_7.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48) @vtable.1, i64 noundef %2, ptr noundef %1, i8 noundef 0)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i)
  %3 = trunc i64 %_0.i to i32
  ret i32 %3
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #13

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #13

attributes #0 = { inlinehint uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #1 = { uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #2 = { cold minsize noinline noreturn optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #3 = { noinline uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #6 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #8 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #9 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: read) }
attributes #10 = { cold noinline noreturn uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #11 = { "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #13 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #14 = { noreturn }
attributes #15 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{!"rustc version 1.97.1 (8bab26f4f 2026-07-14)"}
!3 = !{}
!4 = !{!5}
!5 = distinct !{!5, !6, !"_RNvXsy_NtNtCsgtPOCBgevO_4core3str7patternNtB5_9MatchOnlyNtB5_14TwoWayStrategy8matching: %_0"}
!6 = distinct !{!6, !"_RNvXsy_NtNtCsgtPOCBgevO_4core3str7patternNtB5_9MatchOnlyNtB5_14TwoWayStrategy8matching"}
!7 = !{i64 1950761261395474}
!8 = !{!9}
!9 = distinct !{!9, !10, !"_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs21ATSyVuzIl_17prepared_consumer: %_1"}
!10 = distinct !{!10, !"_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs21ATSyVuzIl_17prepared_consumer"}
!11 = !{i64 4}
!12 = !{!13}
!13 = distinct !{!13, !14, !"_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3cmp9PartialEq2eqBM_: %self"}
!14 = distinct !{!14, !"_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3cmp9PartialEq2eqBM_"}
!15 = !{!16}
!16 = distinct !{!16, !14, !"_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3cmp9PartialEq2eqBM_: %other"}
!17 = !{i8 -1, i8 8}
!18 = !{!"branch_weights", i32 2146410443, i32 1073205}
!19 = !{!20}
!20 = distinct !{!20, !21, !"_RNvXs4_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %self"}
!21 = distinct !{!21, !"_RNvXs4_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq"}
!22 = !{!23}
!23 = distinct !{!23, !21, !"_RNvXs4_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %other"}
!24 = !{i64 0, i64 2}
!25 = !{!20, !13}
!26 = !{!23, !16}
!27 = !{!28}
!28 = distinct !{!28, !29, !"_RNvXsd_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %self"}
!29 = distinct !{!29, !"_RNvXsd_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq"}
!30 = !{!31}
!31 = distinct !{!31, !29, !"_RNvXsd_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %other"}
!32 = !{!28, !20, !13}
!33 = !{!31, !23, !16}
!34 = !{!"branch_weights", !"expected", i32 -2147483648, i32 0}
!35 = !{!"branch_weights", !"expected", i32 2000, i32 1}
!36 = !{!37}
!37 = distinct !{!37, !38, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECs21ATSyVuzIl_17prepared_consumer: %dest.0"}
!38 = distinct !{!38, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECs21ATSyVuzIl_17prepared_consumer"}
!39 = distinct !{!39, !40, !41}
!40 = !{!"llvm.loop.isvectorized", i32 1}
!41 = !{!"llvm.loop.unroll.runtime.disable"}
!42 = !{!43}
!43 = distinct !{!43, !44, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECs21ATSyVuzIl_17prepared_consumer: %dest.0"}
!44 = distinct !{!44, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECs21ATSyVuzIl_17prepared_consumer"}
!45 = !{!"branch_weights", i32 4000000, i32 4001}
!46 = distinct !{!46, !41, !40}
!47 = !{!48, !50, !51, !53}
!48 = distinct !{!48, !49, !"_RNvXsr_NtCsgtPOCBgevO_4core3fmtShNtB5_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer: %self.0"}
!49 = distinct !{!49, !"_RNvXsr_NtCsgtPOCBgevO_4core3fmtShNtB5_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer"}
!50 = distinct !{!50, !49, !"_RNvXsr_NtCsgtPOCBgevO_4core3fmtShNtB5_5Debug3fmtCs21ATSyVuzIl_17prepared_consumer: %f"}
!51 = distinct !{!51, !52, !"_RNvXsa_NtCsgtPOCBgevO_4core5arrayAhj17_NtNtB7_3fmt5Debug3fmtCs21ATSyVuzIl_17prepared_consumer: %self"}
!52 = distinct !{!52, !"_RNvXsa_NtCsgtPOCBgevO_4core5arrayAhj17_NtNtB7_3fmt5Debug3fmtCs21ATSyVuzIl_17prepared_consumer"}
!53 = distinct !{!53, !52, !"_RNvXsa_NtCsgtPOCBgevO_4core5arrayAhj17_NtNtB7_3fmt5Debug3fmtCs21ATSyVuzIl_17prepared_consumer: %f"}
!54 = !{!48, !51}
!55 = !{!56, !48, !50, !51, !53}
!56 = distinct !{!56, !57, !"_RINvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB6_9DebugList7entriesRhINtNtNtBa_5slice4iter4IterhEECs21ATSyVuzIl_17prepared_consumer: %self"}
!57 = distinct !{!57, !"_RINvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB6_9DebugList7entriesRhINtNtNtBa_5slice4iter4IterhEECs21ATSyVuzIl_17prepared_consumer"}
!58 = !{i64 8}
!59 = !{!60}
!60 = distinct !{!60, !61, !"_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3fmt5Debug3fmtBM_: %self"}
!61 = distinct !{!61, !"_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3fmt5Debug3fmtBM_"}
!62 = !{!63}
!63 = distinct !{!63, !61, !"_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultjNtCs21ATSyVuzIl_17prepared_consumer13ConsumerErrorENtNtB7_3fmt5Debug3fmtBM_: %f"}
!64 = !{!60, !63}
!65 = !{!66}
!66 = distinct !{!66, !67, !"_RNvXs1_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %self"}
!67 = distinct !{!67, !"_RNvXs1_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt"}
!68 = !{i8 0, i8 8}
!69 = !{!70}
!70 = distinct !{!70, !67, !"_RNvXs1_Cs21ATSyVuzIl_17prepared_consumerNtB5_13ConsumerErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %f"}
!71 = !{!66, !70}
!72 = !{!73, !75}
!73 = distinct !{!73, !74, !"_RNvXso_Csks33AUGQlhz_15nudox_ir_formatNtB5_10WriteErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %self"}
!74 = distinct !{!74, !"_RNvXso_Csks33AUGQlhz_15nudox_ir_formatNtB5_10WriteErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt"}
!75 = distinct !{!75, !74, !"_RNvXso_Csks33AUGQlhz_15nudox_ir_formatNtB5_10WriteErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %f"}
!76 = !{!77}
!77 = distinct !{!77, !78, !"_RNvXsh_Csks33AUGQlhz_15nudox_ir_formatNtB5_12PrepareErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %self"}
!78 = distinct !{!78, !"_RNvXsh_Csks33AUGQlhz_15nudox_ir_formatNtB5_12PrepareErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt"}
!79 = !{!80}
!80 = distinct !{!80, !78, !"_RNvXsh_Csks33AUGQlhz_15nudox_ir_formatNtB5_12PrepareErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %f"}
!81 = !{!77, !80}
!82 = !{!83}
!83 = distinct !{!83, !84, !"_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %self"}
!84 = distinct !{!84, !"_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt"}
!85 = !{i8 0, i8 6}
!86 = !{!87}
!87 = distinct !{!87, !84, !"_RNvXsa_Csks33AUGQlhz_15nudox_ir_formatNtB5_13FragmentErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %f"}
!88 = !{!83, !87}
!89 = !{!90}
!90 = distinct !{!90, !91, !"_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt: %f"}
!91 = distinct !{!91, !"_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt"}
!92 = !{!93}
!93 = distinct !{!93, !91, !"_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt: %self"}
!94 = !{!95}
!95 = distinct !{!95, !96, !"_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt: %f"}
!96 = distinct !{!96, !"_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt"}
!97 = !{!98}
!98 = distinct !{!98, !96, !"_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt: %self"}
!99 = !{i8 0, i8 2}
!100 = !{!101}
!101 = distinct !{!101, !102, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next: %self"}
!102 = distinct !{!102, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next"}
!103 = !{!104}
!104 = distinct !{!104, !102, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next: %otherwise"}
!105 = !{!106}
!106 = distinct !{!106, !102, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next: %self:Peel0"}
!107 = !{!108}
!108 = distinct !{!108, !109, !"_RNvXs9_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE3get: %slice.0"}
!109 = distinct !{!109, !"_RNvXs9_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE3get"}
!110 = !{!104, !106}
!111 = !{!112, !104, !106}
!112 = distinct !{!112, !113, !"_RINvNtNtCsgtPOCBgevO_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs21ATSyVuzIl_17prepared_consumer: %bytes"}
!113 = distinct !{!113, !"_RINvNtNtCsgtPOCBgevO_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs21ATSyVuzIl_17prepared_consumer"}
!114 = !{!104, !101}
!115 = !{!112, !104, !101}
!116 = !{!117}
!117 = distinct !{!117, !118, !"_RNCNvCs21ATSyVuzIl_17prepared_consumer50prepared_and_manual_whole_consumers_are_equivalent0B3_: %_0"}
!118 = distinct !{!118, !"_RNCNvCs21ATSyVuzIl_17prepared_consumer50prepared_and_manual_whole_consumers_are_equivalent0B3_"}
!119 = !{!120}
!120 = distinct !{!120, !121, !"_RNvMs6_NtNtNtCsgtPOCBgevO_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEE4nextCs21ATSyVuzIl_17prepared_consumer: %self.0"}
!121 = distinct !{!121, !"_RNvMs6_NtNtNtCsgtPOCBgevO_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEE4nextCs21ATSyVuzIl_17prepared_consumer"}
!122 = !{!123, !125, !117}
!123 = distinct !{!123, !124, !"_RINvMNtCsgtPOCBgevO_4core3stre4findReECs21ATSyVuzIl_17prepared_consumer: %self.0"}
!124 = distinct !{!124, !"_RINvMNtCsgtPOCBgevO_4core3stre4findReECs21ATSyVuzIl_17prepared_consumer"}
!125 = distinct !{!125, !124, !"_RINvMNtCsgtPOCBgevO_4core3stre4findReECs21ATSyVuzIl_17prepared_consumer: %pat.0"}
!126 = !{!127}
!127 = distinct !{!127, !128, !"_RNvXs9_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE3get: %slice.0"}
!128 = distinct !{!128, !"_RNvXs9_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE3get"}
!129 = !{!130, !132, !117}
!130 = distinct !{!130, !131, !"_RINvMNtCsgtPOCBgevO_4core3stre4findReECs21ATSyVuzIl_17prepared_consumer: %self.0"}
!131 = distinct !{!131, !"_RINvMNtCsgtPOCBgevO_4core3stre4findReECs21ATSyVuzIl_17prepared_consumer"}
!132 = distinct !{!132, !131, !"_RINvMNtCsgtPOCBgevO_4core3stre4findReECs21ATSyVuzIl_17prepared_consumer: %pat.0"}
!133 = !{!134}
!134 = distinct !{!134, !135, !"_RNvXs8_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range7RangeTojEINtNtNtB9_5slice5index10SliceIndexeE3get: %slice.0"}
!135 = distinct !{!135, !"_RNvXs8_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range7RangeTojEINtNtNtB9_5slice5index10SliceIndexeE3get"}
!136 = !{!137}
!137 = distinct !{!137, !138, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer: %haystack.0"}
!138 = distinct !{!138, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer"}
!139 = !{!140}
!140 = distinct !{!140, !138, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer: %needle.0"}
!141 = !{!142, !143, !140, !117}
!142 = distinct !{!142, !138, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer: %_0"}
!143 = distinct !{!143, !138, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer: %self"}
!144 = !{!142, !143, !137, !117}
!145 = !{!146}
!146 = distinct !{!146, !147, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer: %haystack.0"}
!147 = distinct !{!147, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer"}
!148 = !{!149}
!149 = distinct !{!149, !147, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer: %needle.0"}
!150 = !{!151, !152, !149, !117}
!151 = distinct !{!151, !147, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer: %_0"}
!152 = distinct !{!152, !147, !"_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs21ATSyVuzIl_17prepared_consumer: %self"}
!153 = !{!151, !152, !146, !117}
!154 = !{!155}
!155 = distinct !{!155, !156, !"_RNvXs9_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE3get: %slice.0"}
!156 = distinct !{!156, !"_RNvXs9_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE3get"}
!157 = !{!158, !160, !161, !163, !117}
!158 = distinct !{!158, !159, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next: %otherwise"}
!159 = distinct !{!159, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next"}
!160 = distinct !{!160, !159, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next: %self"}
!161 = distinct !{!161, !162, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match: %_0"}
!162 = distinct !{!162, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match"}
!163 = distinct !{!163, !162, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match: %self"}
!164 = !{!165, !158, !160, !161, !163, !117}
!165 = distinct !{!165, !166, !"_RINvNtNtCsgtPOCBgevO_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs21ATSyVuzIl_17prepared_consumer: %bytes"}
!166 = distinct !{!166, !"_RINvNtNtCsgtPOCBgevO_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs21ATSyVuzIl_17prepared_consumer"}
!167 = distinct !{!167, !168}
!168 = !{!"llvm.loop.peeled.count", i32 1}
!169 = !{!170, !117}
!170 = distinct !{!170, !171, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultuECs21ATSyVuzIl_17prepared_consumer: %_0"}
!171 = distinct !{!171, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultuECs21ATSyVuzIl_17prepared_consumer"}
