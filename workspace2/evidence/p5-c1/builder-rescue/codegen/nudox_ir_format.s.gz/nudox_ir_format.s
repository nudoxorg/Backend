	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvMs0_Csks33AUGQlhz_15nudox_ir_formatNtB5_16PreparedFragment10write_into
	.p2align	2
__RNvMs0_Csks33AUGQlhz_15nudox_ir_formatNtB5_16PreparedFragment10write_into:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	mov	x9, x2
	ldr	x2, [x0, #32]
	cmp	x9, x2
	b.hs	LBB0_2
	str	x2, [x8, #8]
	mov	w10, #1
	mov	x2, x9
	b	LBB0_16
LBB0_2:
	cbz	x2, LBB0_19
	mov	w9, #193
	strb	w9, [x1]
	cmp	x2, #1
	b.eq	LBB0_20
	mov	w9, #1
	strb	w9, [x1, #1]
	cmp	x2, #2
	b.ls	LBB0_21
	ldrb	w9, [x0, #40]
	strb	w9, [x1, #2]
	cmp	x2, #3
	b.eq	LBB0_22
	ldrb	w9, [x0, #41]
	strb	w9, [x1, #3]
	ldr	x11, [x0, #8]
	cbz	x11, LBB0_11
	mov	x9, #0
	ldr	x10, [x0]
	lsl	x11, x11, #2
	add	x12, x1, #4
LBB0_8:
	add	x13, x9, #7
	cmp	x13, x2
	b.hs	LBB0_17
	ldr	w13, [x10, x9]
	str	w13, [x12, x9]
	add	x9, x9, #4
	cmp	x11, x9
	b.ne	LBB0_8
	add	x9, x9, #4
	ldr	x11, [x0, #24]
	cbnz	x11, LBB0_12
	b	LBB0_15
LBB0_11:
	mov	w9, #4
	ldr	x11, [x0, #24]
	cbz	x11, LBB0_15
LBB0_12:
	ldr	x10, [x0, #16]
	lsl	x11, x11, #2
LBB0_13:
	add	x12, x9, #3
	cmp	x12, x2
	b.hs	LBB0_18
	ldr	w12, [x10], #4
	str	w12, [x1, x9]
	add	x9, x9, #4
	subs	x11, x11, #4
	b.ne	LBB0_13
LBB0_15:
	mov	x10, #0
	str	x1, [x8, #8]
LBB0_16:
	str	x2, [x8, #16]
	str	x10, [x8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB0_17:
	.cfi_restore_state
Lloh0:
	adrp	x3, l_alloc_f5c7735809a7524a1ffce31e3fe22b90@PAGE
Lloh1:
	add	x3, x3, l_alloc_f5c7735809a7524a1ffce31e3fe22b90@PAGEOFF
	add	x0, x9, #4
	add	x1, x9, #8
	bl	__RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail
LBB0_18:
Lloh2:
	adrp	x3, l_alloc_07912206504fa53ae9562501d367c105@PAGE
Lloh3:
	add	x3, x3, l_alloc_07912206504fa53ae9562501d367c105@PAGEOFF
	add	x1, x9, #4
	mov	x0, x9
	bl	__RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail
LBB0_19:
Lloh4:
	adrp	x2, l_alloc_0611a3819f108713fa59cc7802611973@PAGE
Lloh5:
	add	x2, x2, l_alloc_0611a3819f108713fa59cc7802611973@PAGEOFF
	mov	x0, #0
	mov	x1, #0
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB0_20:
Lloh6:
	adrp	x2, l_alloc_62b6299ca69b0a583a529f6bb988aa1c@PAGE
Lloh7:
	add	x2, x2, l_alloc_62b6299ca69b0a583a529f6bb988aa1c@PAGEOFF
	mov	w0, #1
	mov	w1, #1
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB0_21:
Lloh8:
	adrp	x2, l_alloc_0fa07ce451cc9ac4715bf2541902e684@PAGE
Lloh9:
	add	x2, x2, l_alloc_0fa07ce451cc9ac4715bf2541902e684@PAGEOFF
	mov	w0, #2
	mov	w1, #2
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB0_22:
Lloh10:
	adrp	x2, l_alloc_ddeee4e4aa2d94a455292d99dfb02ab1@PAGE
Lloh11:
	add	x2, x2, l_alloc_ddeee4e4aa2d94a455292d99dfb02ab1@PAGEOFF
	mov	w0, #3
	mov	w1, #3
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc

	.globl	__RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate
	.p2align	2
__RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate:
	.cfi_startproc
	cmp	x1, #4
	b.hs	LBB1_2
	strb	wzr, [x8, #8]
	str	x1, [x8, #16]
	str	xzr, [x8]
	ret
LBB1_2:
	ldrb	w9, [x0]
	cmp	w9, #193
	b.ne	LBB1_6
	ldrb	w9, [x0, #1]
	cmp	w9, #1
	b.ne	LBB1_7
	ldrb	w9, [x0, #2]
	cmp	w9, #3
	b.lo	LBB1_8
	mov	w10, #3
	strb	w10, [x8, #8]
	strb	w9, [x8, #9]
	str	xzr, [x8]
	ret
LBB1_6:
	mov	w10, #1
	strb	w10, [x8, #8]
	strb	w9, [x8, #9]
	str	xzr, [x8]
	ret
LBB1_7:
	mov	w10, #2
	strb	w10, [x8, #8]
	strb	w9, [x8, #9]
	str	xzr, [x8]
	ret
LBB1_8:
	ldrb	w10, [x0, #3]
	cmp	w10, #2
	b.ls	LBB1_10
	mov	w9, #4
	strb	w9, [x8, #8]
	strb	w10, [x8, #9]
	str	xzr, [x8]
	ret
LBB1_10:
	lsl	x9, x9, #2
	add	x11, x9, #4
	add	x10, x11, x10, lsl #2
	cmp	x1, x10
	b.ne	LBB1_12
	add	x10, x0, #4
	sub	x12, x1, x11
	add	x11, x0, x11
	stp	x0, x1, [x8]
	stp	x10, x9, [x8, #16]
	stp	x11, x12, [x8, #32]
	ret
LBB1_12:
	mov	w9, #5
	strb	w9, [x8, #8]
	stp	x10, x1, [x8, #16]
	str	xzr, [x8]
	ret
	.cfi_endproc

	.section	__TEXT,__cstring,cstring_literals
l_alloc_90b0c124cbead942e81c194f9359718c:
	.asciz	"crates/nudox-ir-format/src/lib.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_0611a3819f108713fa59cc7802611973:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\255\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_62b6299ca69b0a583a529f6bb988aa1c:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\256\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_0fa07ce451cc9ac4715bf2541902e684:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\257\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_ddeee4e4aa2d94a455292d99dfb02ab1:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\260\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_f5c7735809a7524a1ffce31e3fe22b90:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\263\000\000\000\024\000\000"

	.p2align	3, 0x0
l_alloc_07912206504fa53ae9562501d367c105:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\267\000\000\000\024\000\000"

.subsections_via_symbols
