; ModuleID = 'type_dag.4b6a513f2e16ecf9-cgu.0'
source_filename = "type_dag.4b6a513f2e16ecf9-cgu.0"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx11.0.0"

@alloc_9e22aeedee7de67b6dbb357f0a3915a8 = private unnamed_addr constant [98 x i8] c"Cthe test returned a termination value with a non-zero status code (\C0\1B) which indicates a failure\00", align 1
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRhNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_ee38938c8929eed18faaff5d8f37cd9b = private unnamed_addr constant [108 x i8] c"/nix/store/p5s0g9nqgaf3024n3g2ib80f3si3bn9s-rust-mixed/lib/rustlib/src/rust/library/core/src/str/pattern.rs\00", align 1
@alloc_68bb27fa7fd7af0b8edb2570ef014cd2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ee38938c8929eed18faaff5d8f37cd9b, [16 x i8] c"k\00\00\00\00\00\00\00\E7\05\00\00\14\00\00\00" }>, align 8
@alloc_8deac4fa778727f9c004a28bc20bcda6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ee38938c8929eed18faaff5d8f37cd9b, [16 x i8] c"k\00\00\00\00\00\00\00\E7\05\00\00!\00\00\00" }>, align 8
@alloc_8ae9795802ad53c9398ce2776784dbc3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ee38938c8929eed18faaff5d8f37cd9b, [16 x i8] c"k\00\00\00\00\00\00\00\DB\05\00\00!\00\00\00" }>, align 8
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs6tqTQJNM79Z_8type_dag, ptr @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs6tqTQJNM79Z_8type_dag, ptr @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs6tqTQJNM79Z_8type_dag }>, align 8
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_NtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6result6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRRShNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_fc59cbe87b130fa4fa1d3a2e82d342fe = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ee38938c8929eed18faaff5d8f37cd9b, [16 x i8] c"k\00\00\00\00\00\00\00\15\07\00\00I\00\00\00" }>, align 8
@alloc_cbf4874b1b147cfd09d259bc70f502f8 = private unnamed_addr constant <{ [2 x i8], [6 x i8] }> <{ [2 x i8] c"\00\01", [6 x i8] undef }>, align 4
@alloc_ad7306ae0224e62badd99f32f4d8d58c = private unnamed_addr constant [41 x i8] c"crates/nudox-ir-format/tests/type_dag.rs\00", align 1
@alloc_0cbc87dd977768d531eddd3dcebd568b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\000\00\00\00\05\00\00\00" }>, align 8
@alloc_7fe41e4be0c7245e8ff7e83adb85e94f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\001\00\00\00\05\00\00\00" }>, align 8
@alloc_7404500edb0ae603b6d675589f316978 = private unnamed_addr constant [66 x i8] c"type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused", align 1
@alloc_be81d0a65128fe8aa6f6d55c0b15d059 = private unnamed_addr constant [40 x i8] c"crates/nudox-ir-format/tests/type_dag.rs", align 1
@alloc_6b19a81fd0d9220b3b120a9b4bc1899a = private unnamed_addr constant <{ [8 x i8], [16 x i8], [8 x i8], ptr, [8 x i8], [8 x i8], ptr, [16 x i8], [8 x i8], [36 x i8], [4 x i8], [8 x i8], ptr, [8 x i8] }> <{ [8 x i8] zeroinitializer, [16 x i8] undef, [8 x i8] c"\00\00\00\00\00\00\00\80", ptr @alloc_7404500edb0ae603b6d675589f316978, [8 x i8] c"B\00\00\00\00\00\00\00", [8 x i8] undef, ptr @alloc_be81d0a65128fe8aa6f6d55c0b15d059, [16 x i8] c"(\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", [8 x i8] undef, [36 x i8] c"E\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00E\00\00\00\00\00\00\00F\00\00\00\00\00\00\00\00\00\00\01", [4 x i8] undef, [8 x i8] zeroinitializer, ptr @_RNvYNCNvCs6tqTQJNM79Z_8type_dag66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_, [8 x i8] undef }>, align 8
@alloc_cdb6725c7915b088e5aa36e528c366c6 = private unnamed_addr constant [64 x i8] c"type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic", align 1
@alloc_4aa485b89b48004fc7817892989be4c4 = private unnamed_addr constant <{ [8 x i8], [16 x i8], [8 x i8], ptr, [8 x i8], [8 x i8], ptr, [16 x i8], [8 x i8], [36 x i8], [4 x i8], [8 x i8], ptr, [8 x i8] }> <{ [8 x i8] zeroinitializer, [16 x i8] undef, [8 x i8] c"\00\00\00\00\00\00\00\80", ptr @alloc_cdb6725c7915b088e5aa36e528c366c6, [8 x i8] c"@\00\00\00\00\00\00\00", [8 x i8] undef, ptr @alloc_be81d0a65128fe8aa6f6d55c0b15d059, [16 x i8] c"(\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", [8 x i8] undef, [36 x i8] c"\80\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\80\00\00\00\00\00\00\00D\00\00\00\00\00\00\00\00\00\00\01", [4 x i8] undef, [8 x i8] zeroinitializer, ptr @_RNvYNCNvCs6tqTQJNM79Z_8type_dag64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_, [8 x i8] undef }>, align 8
@alloc_6062f6044dd9f7474ceb5fda6361d69e = private unnamed_addr constant [59 x i8] c"type_dag_layout_and_cursor_source_are_observed_on_this_host", align 1
@alloc_88ca7db97edc20dc7f24542e26d80fb2 = private unnamed_addr constant <{ [8 x i8], [16 x i8], [8 x i8], ptr, [8 x i8], [8 x i8], ptr, [16 x i8], [8 x i8], [36 x i8], [4 x i8], [8 x i8], ptr, [8 x i8] }> <{ [8 x i8] zeroinitializer, [16 x i8] undef, [8 x i8] c"\00\00\00\00\00\00\00\80", ptr @alloc_6062f6044dd9f7474ceb5fda6361d69e, [8 x i8] c";\00\00\00\00\00\00\00", [8 x i8] undef, ptr @alloc_be81d0a65128fe8aa6f6d55c0b15d059, [16 x i8] c"(\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", [8 x i8] undef, [36 x i8] c"\EA\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\EA\00\00\00\00\00\00\00?\00\00\00\00\00\00\00\00\00\00\01", [4 x i8] undef, [8 x i8] zeroinitializer, ptr @_RNvYNCNvCs6tqTQJNM79Z_8type_dag59type_dag_layout_and_cursor_source_are_observed_on_this_host0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_, [8 x i8] undef }>, align 8
@alloc_cb3e15bf75992dca2db71edf954b0c16 = private unnamed_addr constant [60 x i8] c"type_dag_node_mutations_retain_ordinal_operands_and_priority", align 1
@alloc_8f0759b75afaab4655dc6fac252fd0c3 = private unnamed_addr constant <{ [8 x i8], [16 x i8], [8 x i8], ptr, [8 x i8], [8 x i8], ptr, [16 x i8], [8 x i8], [36 x i8], [4 x i8], [8 x i8], ptr, [8 x i8] }> <{ [8 x i8] zeroinitializer, [16 x i8] undef, [8 x i8] c"\00\00\00\00\00\00\00\80", ptr @alloc_cb3e15bf75992dca2db71edf954b0c16, [8 x i8] c"<\00\00\00\00\00\00\00", [8 x i8] undef, ptr @alloc_be81d0a65128fe8aa6f6d55c0b15d059, [16 x i8] c"(\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", [8 x i8] undef, [36 x i8] c"\AC\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\AC\00\00\00\00\00\00\00@\00\00\00\00\00\00\00\00\00\00\01", [4 x i8] undef, [8 x i8] zeroinitializer, ptr @_RNvYNCNvCs6tqTQJNM79Z_8type_dag60type_dag_node_mutations_retain_ordinal_operands_and_priority0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_, [8 x i8] undef }>, align 8
@alloc_4776006e0a43248bf4954eb5625408e7 = private unnamed_addr constant <{ ptr, ptr, ptr, ptr }> <{ ptr @alloc_6b19a81fd0d9220b3b120a9b4bc1899a, ptr @alloc_4aa485b89b48004fc7817892989be4c4, ptr @alloc_88ca7db97edc20dc7f24542e26d80fb2, ptr @alloc_8f0759b75afaab4655dc6fac252fd0c3 }>, align 8
@alloc_a15ed431d12b61b552a8b4f468521cb1 = private unnamed_addr constant [6203 x i8] c"use nudox_ir_vocab::TypeId;\0A\0Apub const TYPE_DAG_HEADER_BYTES: usize = 4;\0Apub const TYPE_DAG_MAGIC: u8 = 0xc2;\0Apub const TYPE_DAG_SCHEMA: u8 = 1;\0Apub const MAX_TYPE_DAG_NODES: u8 = 2;\0A\0A#[derive(Clone, Copy)]\0Aenum RecordKind {\0A    Primitive,\0A    Reference,\0A}\0A\0A#[derive(Clone, Copy, Debug, Eq, PartialEq)]\0Apub enum PrimitiveType {\0A    Bool,\0A    I32,\0A}\0A\0A#[derive(Clone, Copy, Debug, Eq, PartialEq)]\0Apub enum TypeNode {\0A    Primitive(PrimitiveType),\0A    Reference(TypeId),\0A}\0A\0A#[derive(Clone, Copy, Debug, Eq, PartialEq)]\0Apub enum TypeDagHeaderError {\0A    Magic { actual: u8 },\0A    Schema { actual: u8 },\0A    NodeCount { actual: u8 },\0A}\0A\0A#[derive(Clone, Copy, Debug, Eq, PartialEq)]\0Apub enum TypeNodeFault {\0A    Truncated { required: usize, actual: usize },\0A    Tag { actual: u8 },\0A    Primitive { actual: u8 },\0A    Edge { target: TypeId, node_count: u8 },\0A}\0A\0A#[derive(Clone, Copy, Debug, Eq, PartialEq)]\0Apub enum TypeDagError {\0A    TruncatedEnvelope {\0A        actual: usize,\0A    },\0A    Header(TypeDagHeaderError),\0A    Geometry {\0A        expected: usize,\0A        actual: usize,\0A    },\0A    ScratchTooSmall {\0A        required: usize,\0A        available: usize,\0A    },\0A    Node {\0A        ordinal: TypeId,\0A        fault: TypeNodeFault,\0A    },\0A    NodeBytes {\0A        expected: usize,\0A        actual: usize,\0A    },\0A}\0A\0Apub struct TypeDagView<'bytes, 'scratch> {\0A    bytes: &'bytes [u8],\0A    proof: &'scratch [TypeNode],\0A}\0A\0Aimpl<'bytes, 'scratch> TypeDagView<'bytes, 'scratch> {\0A    pub fn validate(\0A        bytes: &'bytes [u8],\0A        scratch: &'scratch mut [TypeNode],\0A    ) -> Result<Self, TypeDagError> {\0A        if bytes.len() < TYPE_DAG_HEADER_BYTES {\0A            return Err(TypeDagError::TruncatedEnvelope {\0A                actual: bytes.len(),\0A            });\0A        }\0A        if bytes[0] != TYPE_DAG_MAGIC {\0A            return Err(TypeDagError::Header(TypeDagHeaderError::Magic {\0A                actual: bytes[0],\0A            }));\0A        }\0A        if bytes[1] != TYPE_DAG_SCHEMA {\0A            return Err(TypeDagError::Header(TypeDagHeaderError::Schema {\0A                actual: bytes[1],\0A            }));\0A        }\0A        let node_count = bytes[2];\0A        if node_count > MAX_TYPE_DAG_NODES {\0A            return Err(TypeDagError::Header(TypeDagHeaderError::NodeCount {\0A                actual: node_count,\0A            }));\0A        }\0A        let expected = TYPE_DAG_HEADER_BYTES + usize::from(bytes[3]);\0A        if bytes.len() != expected {\0A            return Err(TypeDagError::Geometry {\0A                expected,\0A                actual: bytes.len(),\0A            });\0A        }\0A        let required = usize::from(node_count);\0A        if scratch.len() < required {\0A            return Err(TypeDagError::ScratchTooSmall {\0A                required,\0A                available: scratch.len(),\0A            });\0A        }\0A\0A        let mut decoded = [TypeNode::Primitive(PrimitiveType::Bool); MAX_TYPE_DAG_NODES as usize];\0A        let body = &bytes[TYPE_DAG_HEADER_BYTES..];\0A        let mut cursor = 0;\0A        for ordinal in 0..node_count {\0A            let source = TypeId::new(u32::from(ordinal));\0A            let available = body.len() - cursor;\0A            if available == 0 {\0A                return Err(node_error(\0A                    source,\0A                    TypeNodeFault::Truncated {\0A                        required: 1,\0A                        actual: 0,\0A                    },\0A                ));\0A            }\0A            let kind = match body[cursor] {\0A                0 => RecordKind::Primitive,\0A                1 => RecordKind::Reference,\0A                actual => return Err(node_error(source, TypeNodeFault::Tag { actual })),\0A            };\0A            if available < 2 {\0A                return Err(node_error(\0A                    source,\0A                    TypeNodeFault::Truncated {\0A                        required: 2,\0A                        actual: available,\0A                    },\0A                ));\0A            }\0A            decoded[usize::from(ordinal)] = kind.decode(body[cursor + 1], source, node_count)?;\0A            cursor += 2;\0A        }\0A        if cursor != body.len() {\0A            return Err(TypeDagError::NodeBytes {\0A                expected: cursor,\0A                actual: body.len(),\0A            });\0A        }\0A        scratch[..required].copy_from_slice(&decoded[..required]);\0A        Ok(Self {\0A            bytes,\0A            proof: &scratch[..required],\0A        })\0A    }\0A\0A    pub fn nodes(&self) -> TypeNodeCursor<'scratch> {\0A        TypeNodeCursor {\0A            remaining: self.proof,\0A        }\0A    }\0A\0A    pub fn input_len(&self) -> usize {\0A        self.bytes.len()\0A    }\0A}\0A\0Aimpl AsRef<[u8]> for TypeDagView<'_, '_> {\0A    fn as_ref(&self) -> &[u8] {\0A        self.bytes\0A    }\0A}\0A\0Apub struct TypeNodeCursor<'scratch> {\0A    remaining: &'scratch [TypeNode],\0A}\0A\0Aimpl<'scratch> Iterator for TypeNodeCursor<'scratch> {\0A    type Item = &'scratch TypeNode;\0A\0A    fn next(&mut self) -> Option<Self::Item> {\0A        let (node, remaining) = self.remaining.split_first()?;\0A        self.remaining = remaining;\0A        Some(node)\0A    }\0A\0A    fn size_hint(&self) -> (usize, Option<usize>) {\0A        (self.remaining.len(), Some(self.remaining.len()))\0A    }\0A}\0A\0Aimpl ExactSizeIterator for TypeNodeCursor<'_> {}\0Aimpl core::iter::FusedIterator for TypeNodeCursor<'_> {}\0A\0Aimpl RecordKind {\0A    fn decode(self, raw: u8, source: TypeId, node_count: u8) -> Result<TypeNode, TypeDagError> {\0A        match self {\0A            Self::Primitive => match raw {\0A                0 => Ok(TypeNode::Primitive(PrimitiveType::Bool)),\0A                1 => Ok(TypeNode::Primitive(PrimitiveType::I32)),\0A                actual => Err(node_error(source, TypeNodeFault::Primitive { actual })),\0A            },\0A            Self::Reference if raw < node_count => {\0A                Ok(TypeNode::Reference(TypeId::new(u32::from(raw))))\0A            }\0A            Self::Reference => Err(node_error(\0A                source,\0A                TypeNodeFault::Edge {\0A                    target: TypeId::new(u32::from(raw)),\0A                    node_count,\0A                },\0A            )),\0A        }\0A    }\0A}\0A\0Aconst fn node_error(ordinal: TypeId, fault: TypeNodeFault) -> TypeDagError {\0A    TypeDagError::Node { ordinal, fault }\0A}\0A", align 1
@alloc_caf81f150f8e2a3f46956011ce18ea9a = private unnamed_addr constant [23 x i8] c"impl<'scratch> Iterator", align 1
@alloc_81d08f51e9b46a96808970faccda49a8 = private unnamed_addr constant [22 x i8] c"impl ExactSizeIterator", align 1
@alloc_c2dcc5662ba056ecce14533279e4b160 = private unnamed_addr constant [15 x i8] c"cursor boundary", align 1
@alloc_c8234fd665543c28765ba1c6e15e759c = private unnamed_addr constant [11 x i8] c"split_first", align 1
@alloc_cd7c7f7dce8f9b264694ca2526c37516 = private unnamed_addr constant [46 x i8] c"assertion failed: body.contains(\22split_first\22)", align 1
@alloc_6e2e0c0ec38458ba4fdfb65ea05a2eb2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00\FA\00\00\00\05\00\00\00" }>, align 8
@alloc_dd4ffb6a82fadbcfa53fa009063078f4 = private unnamed_addr constant [5 x i8] c"bytes", align 1
@alloc_f4e8947ab4017184eb7a640b452ba22d = private unnamed_addr constant [11 x i8] c"TypeId::new", align 1
@alloc_700d8946133bd552962b15338de36ae6 = private unnamed_addr constant [9 x i8] c"match raw", align 1
@alloc_9b7e1a584d08fa8ad7c1a56b7ce8a44f = private unnamed_addr constant [6 x i8] c"unwrap", align 1
@alloc_872ed60f4e9cc5929cf39c60b855d9ea = private unnamed_addr constant [6 x i8] c"expect", align 1
@alloc_b3a99f180af7a4a365370845f4d61ecc = private unnamed_addr constant [43 x i8] c"assertion failed: !body.contains(forbidden)", align 1
@alloc_b8d0ec36c0eead905460459f2e09257b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00\FC\00\00\00\09\00\00\00" }>, align 8
@alloc_54bb4d60df512e09680a75e9c196c327 = private unnamed_addr constant [21 x i8] c"cursor implementation", align 1
@alloc_d0ef803f235cc9da4d2f68db2ae7eecd = private unnamed_addr constant [4 x i8] c"\C2\01\01\00", align 1
@alloc_84e44d17547bb16feba7510e5887a46e = private unnamed_addr constant [5 x i8] c"\C2\01\01\01\00", align 1
@alloc_dfa58342adb1b61c9b339d03997d4468 = private unnamed_addr constant [6 x i8] c"\C2\01\01\02\07\00", align 1
@alloc_2deb6346c8c31952b5e510cfc673852c = private unnamed_addr constant [6 x i8] c"\C2\01\01\02\00\07", align 1
@alloc_ac5a6c5e09adc7e44b9ec58eff44f5a6 = private unnamed_addr constant [6 x i8] c"\C2\01\01\02\01\01", align 1
@alloc_c1242df8626b9cf6c60c92fd6d618193 = private unnamed_addr constant [7 x i8] c"\C2\01\01\03\00\00\00", align 1
@alloc_f6f7b3569446eafb281a38f3be526f22 = private unnamed_addr constant [4 x i8] c"\00\01\00\00", align 1
@alloc_29797342d601d1e047d79ddaf9206dc7 = private unnamed_addr constant [4 x i8] c"\C2\00\00\00", align 1
@alloc_060289bc9efbbf6030aff056af069676 = private unnamed_addr constant [4 x i8] c"\C2\01\03\00", align 1
@alloc_7884c94991f6216c5ebb8eda5460e4b8 = private unnamed_addr constant [5 x i8] c"\C2\01\01\02\00", align 1
@alloc_40eaf789987e2da79c4d5f3f8e4e709a = private unnamed_addr constant [6 x i8] c"\C2\01\01\02\00\00", align 1
@alloc_c1b96e55b45c7736d2483852531d6cfa = private unnamed_addr constant [4 x i8] c"\C2\01\00\00", align 1
@alloc_a4fec9de8264c27b2449b411fe17eeb0 = private unnamed_addr constant <{ [2 x i8], [6 x i8] }> <{ [2 x i8] zeroinitializer, [6 x i8] undef }>, align 4
@alloc_68d4241588b373d3827583e8b7e560bc = private unnamed_addr constant [6 x i8] c"\C2\01\01\02\00\01", align 1
@alloc_fa61d42cbf53437402fcbcb23f6b9f14 = private unnamed_addr constant [6 x i8] c"\C2\01\01\02\01\00", align 1
@alloc_8e580bd0a57c3d4e874ce5e1d1608074 = private unnamed_addr constant [8 x i8] c"\C2\01\02\04\01\01\01\00", align 1
@alloc_366a20069fba01ea1b12f1ee9bd96211 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00d\00\00\00\09\00\00\00" }>, align 8
@alloc_800cf2779c59941b383445baad70eeb8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00e\00\00\00\09\00\00\00" }>, align 8
@alloc_98a68c254d2f16f24a30ac2be7568bfa = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00h\00\00\00\09\00\00\00" }>, align 8
@alloc_41adb055745d596a22069a43cc6b96f0 = private unnamed_addr constant [47 x i8] c"assertion failed: scratch_start <= node_address", align 1
@alloc_787cc3db1ede27825734bc2f561a73e1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00o\00\00\00\0D\00\00\00" }>, align 8
@alloc_ef0d0704052a8e970d69179d3ab3ec5d = private unnamed_addr constant [96 x i8] c"assertion failed: node_address + size_of::<TypeNode>() <= scratch_start + size_of_val(*expected)", align 1
@alloc_bed34f8f916518f97094735f53f0071b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00p\00\00\00\0D\00\00\00" }>, align 8
@alloc_345a3daa91d0eb883779457fc7280ed5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00q\00\00\00\0D\00\00\00" }>, align 8
@alloc_53973d2fe29b4adba8bb7390b5678745 = private unnamed_addr constant [8 x i8] zeroinitializer, align 8
@alloc_8a3150ea8ce92a0b4c407d9443666eec = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00s\00\00\00\09\00\00\00" }>, align 8
@alloc_f11587fcc5df25a2c968fb538524ab02 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00`\00\00\00C\00\00\00" }>, align 8
@alloc_20850533bf96e06227afa83f2bc9aa63 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ad7306ae0224e62badd99f32f4d8d58c, [16 x i8] c"(\00\00\00\00\00\00\00x\00\00\00\05\00\00\00" }>, align 8
@alloc_200ebb91f49df6906629ddcf737a98f2 = private unnamed_addr constant [25 x i8] c"invalid type DAG accepted", align 1
@alloc_205495696f58003a123a312f976ed7c8 = private unnamed_addr constant [15 x i8] c"golden rejected", align 1
@vtable.9 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00 \00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsC_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt }>, align 8
@alloc_c9012ddda9c7d3e0809e5ad487d5dbaf = private unnamed_addr constant [26 x i8] c"validated cursor shortened", align 1
@alloc_37eecd02b27b2a803515d9677500278a = private unnamed_addr constant [14 x i8] c"missing source", align 1
@vtable.a = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtReNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_26978532d6004174455ea2130c477035 = private unnamed_addr constant [12 x i8] c"\07Error: \C0\01\0A\00", align 1
@vtable.b = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRjNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_ea8e8baf0be5855bbef17ce48226036b = private unnamed_addr constant [17 x i8] c"TruncatedEnvelope", align 1
@alloc_b31c6c8dca3d1da07e1eee656fa2f5cc = private unnamed_addr constant [6 x i8] c"actual", align 1
@vtable.c = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag18TypeDagHeaderErrorNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_b2243a0a9fd6f5181b6e5ba2b6488d3a = private unnamed_addr constant [6 x i8] c"Header", align 1
@vtable.d = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt }>, align 8
@alloc_4d3c10a7785e3cacd7635396354c2688 = private unnamed_addr constant [8 x i8] c"Geometry", align 1
@alloc_bebfed686e6a6f31c99c69b171066b8a = private unnamed_addr constant [8 x i8] c"expected", align 1
@alloc_5c9910a63c1c5173176bd3aa76a8ac20 = private unnamed_addr constant [15 x i8] c"ScratchTooSmall", align 1
@alloc_715ad17152b7a3dfcbb2abff840befeb = private unnamed_addr constant [8 x i8] c"required", align 1
@alloc_700d5d683c25860e3d40207214c9c99c = private unnamed_addr constant [9 x i8] c"available", align 1
@vtable.e = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @_RNvXsf_Csjj9WfcXSjwO_14nudox_ir_vocabINtB5_7DenseIdNtB5_4TypeENtNtCsgtPOCBgevO_4core3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@vtable.f = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag13TypeNodeFaultNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_1e2d27e83e9b70f610a2d8f4ab61fc2e = private unnamed_addr constant [4 x i8] c"Node", align 1
@alloc_d466f777e26b5a6c15c5498a3130191d = private unnamed_addr constant [7 x i8] c"ordinal", align 1
@alloc_652e7c9d7b77be2ac6e01717f701606a = private unnamed_addr constant [5 x i8] c"fault", align 1
@alloc_d7a7f078b751cfeba410ab5cc24bfa07 = private unnamed_addr constant [9 x i8] c"NodeBytes", align 1
@alloc_b94f1f40ebe2eb842bd4cc55034553f1 = private unnamed_addr constant [4 x i8] c"Bool", align 1
@alloc_e4fa82a2878eb5612d513befd6fc8a36 = private unnamed_addr constant [3 x i8] c"I32", align 1
@vtable.g = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @_RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt }>, align 8
@vtable.h = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6marker11PhantomDataFENtCsjj9WfcXSjwO_14nudox_ir_vocab4TypeENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_1ab8f3bcfc18061e9d6f0217059b41f5 = private unnamed_addr constant [7 x i8] c"DenseId", align 1
@alloc_005de03493e3aaea3890cf93afea4072 = private unnamed_addr constant [3 x i8] c"raw", align 1
@alloc_8cc6661f3cf091aca5a7bc91c52031fe = private unnamed_addr constant [5 x i8] c"owner", align 1
@vtable.i = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag13PrimitiveTypeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_2a28b803340a522af1d6fe0d14a5f8e5 = private unnamed_addr constant [9 x i8] c"Primitive", align 1
@vtable.j = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtCsjj9WfcXSjwO_14nudox_ir_vocab7DenseIdNtBy_4TypeENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_a67487da2e66b342314634b825542faf = private unnamed_addr constant [9 x i8] c"Reference", align 1
@alloc_d7b9b6c1829de9592f5bc6e83c4fc424 = private unnamed_addr constant [5 x i8] c"Magic", align 1
@alloc_d102eb289abff9d0655d27bf114c0746 = private unnamed_addr constant [6 x i8] c"Schema", align 1
@alloc_830cc47b3e97457eae2b6eb6d050e986 = private unnamed_addr constant [9 x i8] c"NodeCount", align 1
@alloc_f281a46e9987443bf5658c5f394cb876 = private unnamed_addr constant [28 x i8] c"fn() -> nudox_ir_vocab::Type", align 1
@alloc_ccb3afc2d9f98e5ced738fc09e93fead = private unnamed_addr constant [17 x i8] c"\0CPhantomData<\C0\01>\00", align 1
@vtable.k = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRmNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag }>, align 8
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1
@alloc_eb66dd8df2025c3378e51480905e26b5 = private unnamed_addr constant [9 x i8] c"Truncated", align 1
@alloc_cdb9aa4db1ff8f1d481eca6e672fb6b0 = private unnamed_addr constant [3 x i8] c"Tag", align 1
@alloc_2af43630e845fc262d2a6f3b2fa9b1c0 = private unnamed_addr constant [4 x i8] c"Edge", align 1
@alloc_5de5b778237022f7dfbd4b14eca9b832 = private unnamed_addr constant [6 x i8] c"target", align 1
@alloc_c662412d9acfc8d757cfe16257349ca3 = private unnamed_addr constant [10 x i8] c"node_count", align 1
@alloc_de5e2f1dd01253ae804bfe6ba3503da0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ee38938c8929eed18faaff5d8f37cd9b, [16 x i8] c"k\00\00\00\00\00\00\00k\04\00\00$\00\00\00" }>, align 8

; <core::str::pattern::TwoWaySearcher>::next::<core::str::pattern::MatchOnly>
; Function Attrs: inlinehint uwtable
define internal fastcc void @_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs6tqTQJNM79Z_8type_dag(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef nonnull align 8 captures(none) dereferenceable(64) %self, ptr noalias noundef nonnull readonly captures(none) %haystack.0, i64 noundef range(i64 0, -9223372036854775808) %haystack.1, ptr noalias noundef nonnull readonly captures(none) %needle.0, i64 noundef range(i64 0, -9223372036854775808) %needle.1, i1 noundef zeroext %long_period) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %needle_last = add nsw i64 %needle.1, -1
  %.promoted = load i64, ptr %0, align 8
  %index24 = add i64 %needle_last, %.promoted
  %_5325 = icmp ult i64 %index24, %haystack.1
  br i1 %_5325, label %bb39.lr.ph, label %bb40

bb39.lr.ph:                                       ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %_58 = load i64, ptr %1, align 8, !noundef !3
  %v1 = load i64, ptr %self, align 8
  %2 = getelementptr inbounds nuw i8, ptr %self, i64 48
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_48 = load i64, ptr %3, align 8
  %4 = sub i64 %needle.1, %_48
  %.promoted27 = load i64, ptr %2, align 8
  br label %bb39

bb40:                                             ; preds = %bb37, %start
  store i64 %haystack.1, ptr %0, align 8
  br label %bb38

bb39:                                             ; preds = %bb39.lr.ph, %bb37
  %v229 = phi i64 [ %.promoted27, %bb39.lr.ph ], [ %v228, %bb37 ]
  %index26 = phi i64 [ %index24, %bb39.lr.ph ], [ %index, %bb37 ]
  %5 = phi i64 [ %.promoted, %bb39.lr.ph ], [ %10, %bb37 ]
  %_55 = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %index26
  %tail_byte = load i8, ptr %_55, align 1, !noundef !3
  %_60 = and i8 %tail_byte, 63
  %_59 = zext nneg i8 %_60 to i64
  %6 = shl nuw i64 1, %_59
  %7 = and i64 %6, %_58
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %bb10, label %bb9

bb38:                                             ; preds = %bb34, %bb40
  %storemerge = phi i64 [ 0, %bb40 ], [ 1, %bb34 ]
  store i64 %storemerge, ptr %_0, align 8
  ret void

bb10:                                             ; preds = %bb39
  %9 = add i64 %5, %needle.1
  store i64 %9, ptr %0, align 8
  br i1 %long_period, label %bb37, label %bb37.sink.split

bb9:                                              ; preds = %bb39
  %_0.sroa.0.0.i = tail call i64 @llvm.umax.i64(i64 %v229, i64 %v1)
  %start1.sroa.0.0 = select i1 %long_period, i64 %v1, i64 %_0.sroa.0.0.i
  %umax40 = tail call i64 @llvm.umax.i64(i64 %start1.sroa.0.0, i64 %needle.1)
  br label %bb16

bb37.sink.split:                                  ; preds = %bb10, %bb19, %bb29
  %.sink = phi i64 [ %4, %bb29 ], [ 0, %bb19 ], [ 0, %bb10 ]
  %.ph = phi i64 [ %16, %bb29 ], [ %20, %bb19 ], [ %9, %bb10 ]
  store i64 %.sink, ptr %2, align 8
  br label %bb37

bb37:                                             ; preds = %bb37.sink.split, %bb19, %bb29, %bb10
  %v228 = phi i64 [ %v229, %bb19 ], [ %v229, %bb10 ], [ %v229, %bb29 ], [ %.sink, %bb37.sink.split ]
  %10 = phi i64 [ %20, %bb19 ], [ %9, %bb10 ], [ %16, %bb29 ], [ %.ph, %bb37.sink.split ]
  %index = add i64 %needle_last, %10
  %_53 = icmp ult i64 %index, %haystack.1
  br i1 %_53, label %bb39, label %bb40

bb16:                                             ; preds = %bb18, %bb9
  %iter.sroa.0.0 = phi i64 [ %start1.sroa.0.0, %bb9 ], [ %_65, %bb18 ]
  %exitcond.not = icmp eq i64 %iter.sroa.0.0, %umax40
  br i1 %exitcond.not, label %bb43, label %bb42

bb43:                                             ; preds = %bb16
  %start2.sroa.0.0 = select i1 %long_period, i64 0, i64 %v229
  br label %bb26

bb42:                                             ; preds = %bb16
  %_28 = add i64 %iter.sroa.0.0, %5
  %_30 = icmp ult i64 %_28, %haystack.1
  br i1 %_30, label %bb18, label %panic8

bb26:                                             ; preds = %bb28, %bb43
  %iter3.sroa.2.0 = phi i64 [ %v1, %bb43 ], [ %_73, %bb28 ]
  %_70 = icmp ult i64 %start2.sroa.0.0, %iter3.sroa.2.0
  br i1 %_70, label %bb46, label %bb47

bb47:                                             ; preds = %bb26
  %11 = add i64 %5, %needle.1
  store i64 %11, ptr %0, align 8
  br i1 %long_period, label %bb34, label %bb33

bb46:                                             ; preds = %bb26
  %_73 = add i64 %iter3.sroa.2.0, -1
  %_43 = icmp ult i64 %_73, %needle.1
  br i1 %_43, label %bb27, label %panic

bb33:                                             ; preds = %bb47
  store i64 0, ptr %2, align 8
  br label %bb34

bb34:                                             ; preds = %bb33, %bb47
  %12 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %5, ptr %12, align 8, !alias.scope !4
  %13 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %11, ptr %13, align 8, !alias.scope !4
  br label %bb38

bb27:                                             ; preds = %bb46
  %_45 = add i64 %_73, %5
  %_47 = icmp ult i64 %_45, %haystack.1
  br i1 %_47, label %bb28, label %panic5

panic:                                            ; preds = %bb46
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %_73, i64 noundef %needle.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_68bb27fa7fd7af0b8edb2570ef014cd2) #18
  unreachable

bb28:                                             ; preds = %bb27
  %14 = getelementptr inbounds nuw i8, ptr %needle.0, i64 %_73
  %_42 = load i8, ptr %14, align 1, !noundef !3
  %15 = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %_45
  %_44 = load i8, ptr %15, align 1, !noundef !3
  %_41.not = icmp eq i8 %_42, %_44
  br i1 %_41.not, label %bb26, label %bb29

panic5:                                           ; preds = %bb27
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %_45, i64 noundef %haystack.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8deac4fa778727f9c004a28bc20bcda6) #18
  unreachable

bb29:                                             ; preds = %bb28
  %16 = add i64 %_48, %5
  store i64 %16, ptr %0, align 8
  br i1 %long_period, label %bb37, label %bb37.sink.split

bb18:                                             ; preds = %bb42
  %_65 = add i64 %iter.sroa.0.0, 1
  %17 = getelementptr inbounds nuw i8, ptr %needle.0, i64 %iter.sroa.0.0
  %_25 = load i8, ptr %17, align 1, !noundef !3
  %18 = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %_28
  %_27 = load i8, ptr %18, align 1, !noundef !3
  %_24.not = icmp eq i8 %_25, %_27
  br i1 %_24.not, label %bb16, label %bb19

panic8:                                           ; preds = %bb42
  %19 = add i64 %start1.sroa.0.0, %5
  %umax = tail call i64 @llvm.umax.i64(i64 %haystack.1, i64 %19)
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %umax, i64 noundef %haystack.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8ae9795802ad53c9398ce2776784dbc3) #18
  unreachable

bb19:                                             ; preds = %bb18
  %_32 = add i64 %5, 1
  %_31 = add i64 %_32, %iter.sroa.0.0
  %20 = sub i64 %_31, %v1
  store i64 %20, ptr %0, align 8
  br i1 %long_period, label %bb37, label %bb37.sink.split
}

; std::rt::lang_start::<()>
; Function Attrs: uwtable
define hidden noundef i64 @_RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs6tqTQJNM79Z_8type_dag(ptr noundef nonnull %main, i64 noundef %argc, ptr noundef %argv, i8 noundef %sigpipe) unnamed_addr #1 {
start:
  %_7 = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_7)
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call noundef i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr noundef nonnull %_7, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48) @vtable.2, i64 noundef %argc, ptr noundef %argv, i8 noundef %sigpipe)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7)
  ret i64 %_0
}

; core::panicking::assert_failed::<[nudox_ir_format::type_dag::TypeNode; 2], [nudox_ir_format::type_dag::TypeNode; 2]>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
define internal fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_BL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(16) %0, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(16) %1) unnamed_addr #2 {
start:
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  store ptr %0, ptr %left, align 8
  store ptr %1, ptr %right, align 8
; call core::panicking::assert_failed_inner
  call void @_RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner(i8 noundef 0, ptr noundef nonnull %left, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.3, ptr noundef nonnull %right, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.3, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_7fe41e4be0c7245e8ff7e83adb85e94f) #18
  unreachable
}

; core::panicking::assert_failed::<core::result::Result<u32, nudox_ir_format::type_dag::TypeDagError>, core::result::Result<u32, nudox_ir_format::type_dag::TypeDagError>>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
define internal fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedINtNtB4_6result6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorEBL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(32) %0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(32) %1) unnamed_addr #2 {
start:
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  store ptr %0, ptr %left, align 8
  store ptr %1, ptr %right, align 8
; call core::panicking::assert_failed_inner
  call void @_RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner(i8 noundef 1, ptr noundef nonnull %left, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.5, ptr noundef nonnull %right, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.5, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_20850533bf96e06227afa83f2bc9aa63) #18
  unreachable
}

; core::panicking::assert_failed::<nudox_ir_format::type_dag::TypeDagError, nudox_ir_format::type_dag::TypeDagError>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
define internal fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorBL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(32) %0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(32) %1) unnamed_addr #2 {
start:
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  store ptr %0, ptr %left, align 8
  store ptr %1, ptr %right, align 8
; call core::panicking::assert_failed_inner
  call void @_RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner(i8 noundef 0, ptr noundef nonnull %left, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.6, ptr noundef nonnull %right, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.6, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0cbc87dd977768d531eddd3dcebd568b) #18
  unreachable
}

; core::panicking::assert_failed::<&nudox_ir_format::type_dag::TypeNode, &nudox_ir_format::type_dag::TypeNode>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
define internal fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeBL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %1) unnamed_addr #2 {
start:
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  store ptr %0, ptr %left, align 8
  store ptr %1, ptr %right, align 8
; call core::panicking::assert_failed_inner
  call void @_RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner(i8 noundef 0, ptr noundef nonnull %left, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.7, ptr noundef nonnull %right, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.7, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_345a3daa91d0eb883779457fc7280ed5) #18
  unreachable
}

; core::panicking::assert_failed::<&[u8], &[u8]>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
define internal fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedRShBL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(16) %0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(16) %1) unnamed_addr #2 {
start:
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  store ptr %0, ptr %left, align 8
  store ptr %1, ptr %right, align 8
; call core::panicking::assert_failed_inner
  call void @_RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner(i8 noundef 0, ptr noundef nonnull %left, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.8, ptr noundef nonnull %right, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.8, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_366a20069fba01ea1b12f1ee9bd96211) #18
  unreachable
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline uwtable
define internal fastcc void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6tqTQJNM79Z_8type_dag(ptr noundef nonnull readonly captures(none) %f) unnamed_addr #3 {
start:
  tail call void %f()
  tail call void asm sideeffect "", "~{memory}"() #19, !srcloc !7
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint uwtable
define internal noundef i32 @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %_1) unnamed_addr #0 {
start:
  %_4 = load ptr, ptr %_1, align 8, !nonnull !3, !noundef !3
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  tail call fastcc void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6tqTQJNM79Z_8type_dag(ptr noundef nonnull %_4)
  ret i32 0
}

; core::str::pattern::simd_contains::{closure#2}
; Function Attrs: cold inlinehint nofree norecurse nosync nounwind memory(read, inaccessiblemem: readwrite, target_mem0: none, target_mem1: none) uwtable
define internal fastcc noundef zeroext i1 @_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag(ptr noalias noundef nonnull readonly align 8 captures(none) dereferenceable(32) %_1, i64 noundef %idx, i16 noundef range(i16 1, 0) %0, i1 noundef zeroext %skip) unnamed_addr #4 personality ptr @rust_eh_personality {
start:
  br i1 %skip, label %bb9, label %bb3.preheader

bb3.preheader:                                    ; preds = %start
  %self.0 = load ptr, ptr %_1, align 8, !nonnull !3, !noundef !3
  %1 = getelementptr i8, ptr %self.0, i64 %idx
  %2 = getelementptr inbounds nuw i8, ptr %_1, i64 16
  %_17.0 = load ptr, ptr %2, align 8, !nonnull !3, !noundef !3
  %3 = getelementptr inbounds nuw i8, ptr %_1, i64 24
  %_17.1 = load i64, ptr %3, align 8, !noundef !3
  %_6.i = icmp samesign ult i64 %_17.1, 4
  %4 = getelementptr i8, ptr %_17.0, i64 %_17.1
  %pyend.i = getelementptr i8, ptr %4, i64 -4
  br i1 %_6.i, label %bb4.us.preheader, label %bb4

bb4.us.preheader:                                 ; preds = %bb3.preheader
  %exitcond.not.i.us = icmp eq i64 %_17.1, 0
  %exitcond.not.i.us.1 = icmp eq i64 %_17.1, 1
  %_3.i1.i.i.us.1 = getelementptr inbounds nuw i8, ptr %_17.0, i64 1
  %exitcond.not.i.us.2 = icmp eq i64 %_17.1, 2
  %_3.i1.i.i.us.2 = getelementptr inbounds nuw i8, ptr %_17.0, i64 2
  %exitcond.not.i.us.3 = icmp eq i64 %_17.1, 3
  br label %bb4.us

bb4.us:                                           ; preds = %bb4.us.preheader, %bb7.loopexit.us
  %mask.sroa.0.08.us = phi i16 [ %7, %bb7.loopexit.us ], [ %0, %bb4.us.preheader ]
  %5 = tail call range(i16 0, 17) i16 @llvm.cttz.i16(i16 %mask.sroa.0.08.us, i1 true)
  %_10.us = zext nneg i16 %5 to i64
  %6 = getelementptr i8, ptr %1, i64 %_10.us
  %_24.us = getelementptr i8, ptr %6, i64 1
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  br i1 %exitcond.not.i.us, label %bb9, label %bb5.i.us

bb5.i.us:                                         ; preds = %bb4.us
  %b1.i.us = load i8, ptr %_24.us, align 1, !alias.scope !8, !noalias !11, !noundef !3
  %b2.i.us = load i8, ptr %_17.0, align 1, !alias.scope !11, !noalias !8, !noundef !3
  %_16.not.i.us = icmp eq i8 %b1.i.us, %b2.i.us
  br i1 %_16.not.i.us, label %bb3.i.us.1, label %bb7.loopexit.us

bb3.i.us.1:                                       ; preds = %bb5.i.us
  br i1 %exitcond.not.i.us.1, label %bb9, label %bb5.i.us.1

bb5.i.us.1:                                       ; preds = %bb3.i.us.1
  %_3.i.i.i.us.1 = getelementptr i8, ptr %6, i64 2
  %b1.i.us.1 = load i8, ptr %_3.i.i.i.us.1, align 1, !alias.scope !8, !noalias !11, !noundef !3
  %b2.i.us.1 = load i8, ptr %_3.i1.i.i.us.1, align 1, !alias.scope !11, !noalias !8, !noundef !3
  %_16.not.i.us.1 = icmp eq i8 %b1.i.us.1, %b2.i.us.1
  br i1 %_16.not.i.us.1, label %bb3.i.us.2, label %bb7.loopexit.us

bb3.i.us.2:                                       ; preds = %bb5.i.us.1
  br i1 %exitcond.not.i.us.2, label %bb9, label %bb5.i.us.2

bb5.i.us.2:                                       ; preds = %bb3.i.us.2
  %_3.i.i.i.us.2 = getelementptr i8, ptr %6, i64 3
  %b1.i.us.2 = load i8, ptr %_3.i.i.i.us.2, align 1, !alias.scope !8, !noalias !11, !noundef !3
  %b2.i.us.2 = load i8, ptr %_3.i1.i.i.us.2, align 1, !alias.scope !11, !noalias !8, !noundef !3
  %_16.not.i.us.2 = icmp eq i8 %b1.i.us.2, %b2.i.us.2
  %_16.not.i.us.2.not = xor i1 %_16.not.i.us.2, true
  %exitcond.not.i.us.3.not = xor i1 %exitcond.not.i.us.3, true
  %brmerge = or i1 %_16.not.i.us.2.not, %exitcond.not.i.us.3.not
  br i1 %brmerge, label %bb7.loopexit.us, label %bb9

bb7.loopexit.us:                                  ; preds = %bb5.i.us.2, %bb5.i.us.1, %bb5.i.us
  %_15.us = shl nuw i16 1, %5
  %_14.us = xor i16 %_15.us, -1
  %7 = and i16 %mask.sroa.0.08.us, %_14.us
  %8 = icmp eq i16 %7, 0
  br i1 %8, label %bb9, label %bb4.us

bb4:                                              ; preds = %bb3.preheader, %bb7
  %mask.sroa.0.08 = phi i16 [ %13, %bb7 ], [ %0, %bb3.preheader ]
  %9 = tail call range(i16 0, 17) i16 @llvm.cttz.i16(i16 %mask.sroa.0.08, i1 true)
  %_10 = zext nneg i16 %9 to i64
  %10 = getelementptr i8, ptr %1, i64 %_10
  %_24 = getelementptr i8, ptr %10, i64 1
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %11 = getelementptr i8, ptr %_24, i64 %_17.1
  %pxend.i = getelementptr i8, ptr %11, i64 -4
  %_2619.i = icmp ult ptr %_24, %pxend.i
  br i1 %_2619.i, label %bb11.i, label %_RNvNtNtCsgtPOCBgevO_4core3str7pattern14small_slice_eq.exit

bb11.i:                                           ; preds = %bb4, %bb13.i
  %py.sroa.0.021.i = phi ptr [ %_36.i, %bb13.i ], [ %_17.0, %bb4 ]
  %px.sroa.0.020.i = phi ptr [ %_35.i, %bb13.i ], [ %_24, %bb4 ]
  %tmp.sroa.0.0.copyload.i = load i32, ptr %px.sroa.0.020.i, align 1, !alias.scope !8, !noalias !11
  %tmp2.sroa.0.0.copyload.i = load i32, ptr %py.sroa.0.021.i, align 1, !alias.scope !11, !noalias !8
  %_34.not.i = icmp eq i32 %tmp.sroa.0.0.copyload.i, %tmp2.sroa.0.0.copyload.i
  br i1 %_34.not.i, label %bb13.i, label %bb7

bb13.i:                                           ; preds = %bb11.i
  %_35.i = getelementptr inbounds nuw i8, ptr %px.sroa.0.020.i, i64 4
  %_36.i = getelementptr inbounds nuw i8, ptr %py.sroa.0.021.i, i64 4
  %_26.i = icmp ult ptr %_35.i, %pxend.i
  br i1 %_26.i, label %bb11.i, label %_RNvNtNtCsgtPOCBgevO_4core3str7pattern14small_slice_eq.exit

_RNvNtNtCsgtPOCBgevO_4core3str7pattern14small_slice_eq.exit: ; preds = %bb13.i, %bb4
  %tmp4.sroa.0.0.copyload.i = load i32, ptr %pxend.i, align 1, !alias.scope !8, !noalias !11
  %tmp6.sroa.0.0.copyload.i = load i32, ptr %pyend.i, align 1, !alias.scope !11, !noalias !8
  %12 = icmp eq i32 %tmp4.sroa.0.0.copyload.i, %tmp6.sroa.0.0.copyload.i
  br i1 %12, label %bb9, label %bb7

bb9:                                              ; preds = %bb5.i.us.2, %bb7, %_RNvNtNtCsgtPOCBgevO_4core3str7pattern14small_slice_eq.exit, %bb7.loopexit.us, %bb4.us, %bb3.i.us.1, %bb3.i.us.2, %start
  %_0.sroa.0.0.off0 = phi i1 [ true, %bb4.us ], [ false, %start ], [ false, %bb7.loopexit.us ], [ true, %bb5.i.us.2 ], [ true, %bb3.i.us.2 ], [ true, %bb3.i.us.1 ], [ true, %_RNvNtNtCsgtPOCBgevO_4core3str7pattern14small_slice_eq.exit ], [ false, %bb7 ]
  ret i1 %_0.sroa.0.0.off0

bb7:                                              ; preds = %bb11.i, %_RNvNtNtCsgtPOCBgevO_4core3str7pattern14small_slice_eq.exit
  %_15 = shl nuw i16 1, %9
  %_14 = xor i16 %_15, -1
  %13 = and i16 %mask.sroa.0.08, %_14
  %14 = icmp eq i16 %13, 0
  br i1 %14, label %bb9, label %bb4
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint uwtable
define internal noundef i32 @_RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs6tqTQJNM79Z_8type_dag(ptr noundef readonly captures(none) %_1) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = load ptr, ptr %_1, align 8, !nonnull !3, !noundef !3
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  tail call fastcc void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6tqTQJNM79Z_8type_dag(ptr noundef nonnull readonly %0), !noalias !13
  ret i32 0
}

; type_dag::assert_reject
; Function Attrs: uwtable
define internal fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(32) %_0, ptr noalias noundef nonnull readonly captures(address, read_provenance) %bytes.0, i64 noundef range(i64 0, 8) %bytes.1, i64 noundef range(i64 0, 3) %scratch_len, ptr dead_on_return noalias noundef nonnull readonly align 8 captures(address) dereferenceable(32) %expected) unnamed_addr #1 {
start:
  %_7 = alloca [40 x i8], align 8
  %error = alloca [32 x i8], align 8
  %before = alloca [16 x i8], align 4
  %scratch = alloca [16 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %scratch)
  call void @llvm.experimental.memset.pattern.p0.i64.i64(ptr nonnull align 4 %scratch, i64 256, i64 2, i1 false)
  call void @llvm.lifetime.start.p0(ptr nonnull %before)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(16) %before, ptr noundef nonnull align 4 dereferenceable(16) %scratch, i64 16, i1 false)
  call void @llvm.lifetime.start.p0(ptr nonnull %error)
  call void @llvm.lifetime.start.p0(ptr nonnull %_7)
; call <nudox_ir_format::type_dag::TypeDagView>::validate
  call void @_RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate(ptr noalias noundef nonnull sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_7, ptr noalias noundef nonnull readonly captures(address, read_provenance) %bytes.0, i64 noundef %bytes.1, ptr noalias noundef nonnull align 4 %scratch, i64 noundef %scratch_len)
  %_10 = load i64, ptr %_7, align 8, !range !16, !noundef !3
  %0 = trunc nuw i64 %_10 to i1
  br i1 %0, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_7, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %error, ptr noundef nonnull align 8 dereferenceable(32) %1, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7)
; call <nudox_ir_format::type_dag::TypeDagError as core::cmp::PartialEq>::eq
  %_15 = call fastcc noundef zeroext i1 @_RNvXsF_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %error, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %expected)
  br i1 %_15, label %bb6, label %bb7, !prof !17

bb3:                                              ; preds = %start
  store i8 6, ptr %_0, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_7)
  br label %bb10

bb10:                                             ; preds = %bb8, %bb3
  call void @llvm.lifetime.end.p0(ptr nonnull %error)
  call void @llvm.lifetime.end.p0(ptr nonnull %before)
  call void @llvm.lifetime.end.p0(ptr nonnull %scratch)
  ret void

bb7:                                              ; preds = %bb4
; call core::panicking::assert_failed::<nudox_ir_format::type_dag::TypeDagError, nudox_ir_format::type_dag::TypeDagError>
  call fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorBL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %error, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %expected) #18
  unreachable

bb6:                                              ; preds = %bb4
  call void @llvm.experimental.noalias.scope.decl(metadata !18)
  call void @llvm.experimental.noalias.scope.decl(metadata !21)
  call void @llvm.experimental.noalias.scope.decl(metadata !23)
  call void @llvm.experimental.noalias.scope.decl(metadata !26)
  %2 = load i8, ptr %scratch, align 4, !range !28, !alias.scope !29, !noalias !30, !noundef !3
  %3 = load i8, ptr %before, align 4, !range !28, !alias.scope !30, !noalias !29, !noundef !3
  %4 = trunc nuw i8 %3 to i1
  %_5.i.i.i = icmp eq i8 %2, %3
  br i1 %_5.i.i.i, label %bb1.i.i.i, label %bb9, !prof !31

bb1.i:                                            ; preds = %_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag.exit.i, %bb4.i.i.i
  %_9.1.i = getelementptr inbounds nuw i8, ptr %scratch, i64 8
  %_12.1.i = getelementptr inbounds nuw i8, ptr %before, i64 8
  call void @llvm.experimental.noalias.scope.decl(metadata !32)
  call void @llvm.experimental.noalias.scope.decl(metadata !34)
  call void @llvm.experimental.noalias.scope.decl(metadata !36)
  call void @llvm.experimental.noalias.scope.decl(metadata !38)
  %5 = load i8, ptr %_9.1.i, align 4, !range !28, !alias.scope !40, !noalias !41, !noundef !3
  %6 = load i8, ptr %_12.1.i, align 4, !range !28, !alias.scope !41, !noalias !40, !noundef !3
  %7 = trunc nuw i8 %6 to i1
  %_5.i.i.1.i = icmp eq i8 %5, %6
  br i1 %_5.i.i.1.i, label %bb1.i.i.1.i, label %bb9

bb1.i.i.1.i:                                      ; preds = %bb1.i
  %8 = trunc nuw i8 %5 to i1
  br i1 %8, label %bb4.i.i.1.i, label %_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag.exit.1.i

bb4.i.i.1.i:                                      ; preds = %bb1.i.i.1.i
  call void @llvm.assume(i1 %7)
  %9 = getelementptr inbounds nuw i8, ptr %scratch, i64 12
  %_10.i.i.1.i = load i32, ptr %9, align 4, !alias.scope !40, !noalias !41, !noundef !3
  %10 = getelementptr inbounds nuw i8, ptr %before, i64 12
  %_11.i.i.1.i = load i32, ptr %10, align 4, !alias.scope !41, !noalias !40, !noundef !3
  %11 = icmp eq i32 %_10.i.i.1.i, %_11.i.i.1.i
  br i1 %11, label %bb8, label %bb9

_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag.exit.1.i: ; preds = %bb1.i.i.1.i
  %12 = getelementptr inbounds nuw i8, ptr %scratch, i64 9
  %13 = load i8, ptr %12, align 1, !range !28, !alias.scope !40, !noalias !41, !noundef !3
  %14 = getelementptr inbounds nuw i8, ptr %before, i64 9
  %15 = load i8, ptr %14, align 1, !range !28, !alias.scope !41, !noalias !40, !noundef !3
  %16 = icmp eq i8 %13, %15
  br i1 %16, label %bb8, label %bb9

bb1.i.i.i:                                        ; preds = %bb6
  %17 = trunc nuw i8 %2 to i1
  br i1 %17, label %bb4.i.i.i, label %_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag.exit.i

bb4.i.i.i:                                        ; preds = %bb1.i.i.i
  call void @llvm.assume(i1 %4)
  %18 = getelementptr inbounds nuw i8, ptr %scratch, i64 4
  %_10.i.i.i = load i32, ptr %18, align 4, !alias.scope !29, !noalias !30, !noundef !3
  %19 = getelementptr inbounds nuw i8, ptr %before, i64 4
  %_11.i.i.i = load i32, ptr %19, align 4, !alias.scope !30, !noalias !29, !noundef !3
  %20 = icmp eq i32 %_10.i.i.i, %_11.i.i.i
  br i1 %20, label %bb1.i, label %bb9

_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag.exit.i: ; preds = %bb1.i.i.i
  %21 = getelementptr inbounds nuw i8, ptr %scratch, i64 1
  %22 = load i8, ptr %21, align 1, !range !28, !alias.scope !29, !noalias !30, !noundef !3
  %23 = getelementptr inbounds nuw i8, ptr %before, i64 1
  %24 = load i8, ptr %23, align 1, !range !28, !alias.scope !30, !noalias !29, !noundef !3
  %25 = icmp eq i8 %22, %24
  br i1 %25, label %bb1.i, label %bb9, !prof !31

bb9:                                              ; preds = %bb6, %_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag.exit.i, %bb1.i, %_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag.exit.1.i, %bb4.i.i.1.i, %bb4.i.i.i
; call core::panicking::assert_failed::<[nudox_ir_format::type_dag::TypeNode; 2], [nudox_ir_format::type_dag::TypeNode; 2]>
  call fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_BL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) %scratch, ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) %before) #18
  unreachable

bb8:                                              ; preds = %_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag.exit.1.i, %bb4.i.i.1.i
  store i8 -1, ptr %_0, align 8
  br label %bb10
}

; type_dag::recursive_consumer
; Function Attrs: noinline uwtable
define internal fastcc void @_RNvCs6tqTQJNM79Z_8type_dag18recursive_consumer(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(32) %_0, ptr noalias noundef nonnull readonly captures(address, read_provenance) %bytes.0, i64 noundef range(i64 0, -9223372036854775808) %bytes.1, ptr noalias noundef nonnull align 4 %scratch.0) unnamed_addr #3 personality ptr @rust_eh_personality {
start:
  %_4 = alloca [40 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_4)
; call <nudox_ir_format::type_dag::TypeDagView>::validate
  call void @_RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate(ptr noalias noundef nonnull sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_4, ptr noalias noundef nonnull readonly captures(address, read_provenance) %bytes.0, i64 noundef %bytes.1, ptr noalias noundef nonnull align 4 %scratch.0, i64 noundef 2)
  %_15 = load i64, ptr %_4, align 8, !range !16, !noundef !3
  %0 = trunc nuw i64 %_15 to i1
  %1 = getelementptr inbounds nuw i8, ptr %_4, i64 8
  %_17.sroa.0.0.copyload = load ptr, ptr %1, align 8
  br i1 %0, label %bb10, label %bb11

bb10:                                             ; preds = %start
  %_17.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_4, i64 16
  %_17.sroa.4.0.copyload = load i64, ptr %_17.sroa.4.0..sroa_idx, align 8
  %_17.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_4, i64 24
  %_17.sroa.5.0.copyload = load ptr, ptr %_17.sroa.5.0..sroa_idx, align 8
  %_17.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_4, i64 32
  %_17.sroa.6.0.copyload = load i64, ptr %_17.sroa.6.0..sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_4)
  store ptr %_17.sroa.0.0.copyload, ptr %_0, align 8
  %_20.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_17.sroa.4.0.copyload, ptr %_20.sroa.4.0._0.sroa_idx, align 8
  %_20.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store ptr %_17.sroa.5.0.copyload, ptr %_20.sroa.5.0._0.sroa_idx, align 8
  %_20.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %_17.sroa.6.0.copyload, ptr %_20.sroa.6.0._0.sroa_idx, align 8
  br label %bb9

bb11:                                             ; preds = %start
  %_16.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_4, i64 24
  %_16.sroa.5.0.copyload = load ptr, ptr %_16.sroa.5.0..sroa_idx, align 8, !nonnull !3, !noundef !3
  %_16.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_4, i64 32
  %_16.sroa.6.0.copyload = load i64, ptr %_16.sroa.6.0..sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_4)
  %2 = icmp ne ptr %_17.sroa.0.0.copyload, null
  tail call void @llvm.assume(i1 %2)
  %_24.not15 = icmp eq i64 %_16.sroa.6.0.copyload, 0
  br i1 %_24.not15, label %bb13, label %bb12

bb13:                                             ; preds = %bb8, %bb11
  %signature.sroa.0.0.lcssa = phi i32 [ 0, %bb11 ], [ %12, %bb8 ]
  %3 = getelementptr inbounds nuw i8, ptr %_0, i64 4
  store i32 %signature.sroa.0.0.lcssa, ptr %3, align 4
  store i8 -1, ptr %_0, align 8
  br label %bb9

bb12:                                             ; preds = %bb11, %bb8
  %view.sroa.5.018 = phi i64 [ %_26.1, %bb8 ], [ %_16.sroa.6.0.copyload, %bb11 ]
  %view.sroa.0.017 = phi ptr [ %_26.0, %bb8 ], [ %_16.sroa.5.0.copyload, %bb11 ]
  %signature.sroa.0.016 = phi i32 [ %12, %bb8 ], [ 0, %bb11 ]
  %_26.0 = getelementptr inbounds nuw i8, ptr %view.sroa.0.017, i64 8
  %_26.1 = add i64 %view.sroa.5.018, -1
  %4 = load i8, ptr %view.sroa.0.017, align 4, !range !28, !noundef !3
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb5, label %bb4

bb9:                                              ; preds = %bb10, %bb13
  ret void

bb5:                                              ; preds = %bb12
  %6 = getelementptr inbounds nuw i8, ptr %view.sroa.0.017, i64 4
  %_13 = load i32, ptr %6, align 4, !noundef !3
  %7 = xor i32 %_13, 3
  br label %bb8

bb4:                                              ; preds = %bb12
  %8 = getelementptr inbounds nuw i8, ptr %view.sroa.0.017, i64 1
  %9 = load i8, ptr %8, align 1, !range !28, !noundef !3
  %10 = trunc nuw i8 %9 to i1
  %. = select i1 %10, i32 2, i32 1
  br label %bb8

bb8:                                              ; preds = %bb4, %bb5
  %word.sroa.0.0 = phi i32 [ %7, %bb5 ], [ %., %bb4 ]
  %11 = tail call noundef i32 @llvm.fshl.i32(i32 %signature.sroa.0.016, i32 %signature.sroa.0.016, i32 3)
  %12 = xor i32 %word.sroa.0.0, %11
  %_24.not = icmp eq i64 %_26.1, 0
  br i1 %_24.not, label %bb13, label %bb12
}

; type_dag::main
; Function Attrs: uwtable
define hidden void @_RNvCs6tqTQJNM79Z_8type_dag4main() unnamed_addr #1 {
start:
; call test::test_main_static
  tail call void @_RNvCs3O4ZRUMviTO_4test16test_main_static(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) @alloc_4776006e0a43248bf4954eb5625408e7, i64 noundef 4)
  ret void
}

; <type_dag::TestFailure as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %self, ptr noalias noundef align 8 dereferenceable(24) %formatter) unnamed_addr #1 {
start:
  %_12 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  %0 = load i8, ptr %self, align 8, !range !42, !noundef !3
  %1 = icmp ne i8 %0, 7
  tail call void @llvm.assume(i1 %1)
  %2 = add nsw i8 %0, -6
  %3 = icmp samesign ugt i8 %0, 5
  %narrow = select i1 %3, i8 %2, i8 1
  switch i8 %narrow, label %bb1 [
    i8 0, label %bb5
    i8 1, label %bb4
    i8 2, label %bb3
    i8 3, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb5:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %4 = tail call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %formatter, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_200ebb91f49df6906629ddcf737a98f2, i64 noundef 25)
  br label %bb12

bb4:                                              ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %_7)
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter11debug_tuple(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(address) dereferenceable(24) %_7, ptr noalias noundef nonnull align 8 dereferenceable(24) %formatter, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_205495696f58003a123a312f976ed7c8, i64 noundef 15)
; call <core::fmt::builders::DebugTuple>::field
  %_5 = call noundef nonnull align 8 ptr @_RNvMs2_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_10DebugTuple5field(ptr noalias noundef nonnull align 8 dereferenceable(24) %_7, ptr noundef nonnull %self, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.9)
; call <core::fmt::builders::DebugTuple>::finish
  %5 = call noundef zeroext i1 @_RNvMs2_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %_5)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7)
  br label %bb12

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = tail call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %formatter, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_c9012ddda9c7d3e0809e5ad487d5dbaf, i64 noundef 26)
  br label %bb12

bb2:                                              ; preds = %start
  %item = getelementptr inbounds nuw i8, ptr %self, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_12)
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter11debug_tuple(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(address) dereferenceable(24) %_12, ptr noalias noundef nonnull align 8 dereferenceable(24) %formatter, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_37eecd02b27b2a803515d9677500278a, i64 noundef 14)
; call <core::fmt::builders::DebugTuple>::field
  %_10 = call noundef nonnull align 8 ptr @_RNvMs2_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_10DebugTuple5field(ptr noalias noundef nonnull align 8 dereferenceable(24) %_12, ptr noundef nonnull %item, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.a)
; call <core::fmt::builders::DebugTuple>::finish
  %7 = call noundef zeroext i1 @_RNvMs2_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %_10)
  call void @llvm.lifetime.end.p0(ptr nonnull %_12)
  br label %bb12

bb12:                                             ; preds = %bb2, %bb3, %bb4, %bb5
  %_0.sroa.0.0.in = phi i1 [ %4, %bb5 ], [ %5, %bb4 ], [ %6, %bb3 ], [ %7, %bb2 ]
  ret i1 %_0.sroa.0.0.in
}

; <&[nudox_ir_format::type_dag::TypeNode; 2] as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_NtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %entry.i.i.i = alloca [8 x i8], align 8
  %_5.i.i = alloca [16 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !43, !noundef !3
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i), !noalias !44
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter10debug_list(ptr noalias noundef nonnull sret([16 x i8]) align 8 captures(address) dereferenceable(16) %_5.i.i, ptr noalias noundef nonnull align 8 dereferenceable(24) %f), !noalias !51
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !52
  store ptr %_3, ptr %entry.i.i.i, align 8, !noalias !52
; call <core::fmt::builders::DebugList>::entry
  %_9.i.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !52
  %iter.sroa.0.08.i.ptr.1.i.i = getelementptr inbounds nuw i8, ptr %_3, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !52
  store ptr %iter.sroa.0.08.i.ptr.1.i.i, ptr %entry.i.i.i, align 8, !noalias !52
; call <core::fmt::builders::DebugList>::entry
  %_9.i.1.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !52
; call <core::fmt::builders::DebugList>::finish
  %_0.i.i = call noundef zeroext i1 @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList6finish(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i), !noalias !44
  ret i1 %_0.i.i
}

; <&nudox_ir_vocab::DenseId<nudox_ir_vocab::Type> as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtCsjj9WfcXSjwO_14nudox_ir_vocab7DenseIdNtBy_4TypeENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_7.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !43, !noundef !3
  call void @llvm.lifetime.start.p0(ptr nonnull %_7.i), !noalias !55
  %0 = getelementptr inbounds nuw i8, ptr %_3, i64 4
  store ptr %0, ptr %_7.i, align 8, !noalias !55
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %_0.i = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_1ab8f3bcfc18061e9d6f0217059b41f5, i64 noundef 7, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_005de03493e3aaea3890cf93afea4072, i64 noundef 3, ptr noundef nonnull readonly align 4 dereferenceable(4) %_3, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.g, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_8cc6661f3cf091aca5a7bc91c52031fe, i64 noundef 5, ptr noundef nonnull %_7.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.h)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i), !noalias !55
  ret i1 %_0.i
}

; <&core::marker::PhantomData<fn() -> nudox_ir_vocab::Type> as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6marker11PhantomDataFENtCsjj9WfcXSjwO_14nudox_ir_vocab4TypeENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias readonly align 8 captures(none) %self, ptr noalias noundef readonly align 8 captures(none) dereferenceable(24) %f) unnamed_addr #1 {
start:
  %args.i = alloca [16 x i8], align 8
  %_5.i = alloca [16 x i8], align 8
  %f.val = load ptr, ptr %f, align 8, !nonnull !3, !noundef !3
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 8
  %f.val1 = load ptr, ptr %0, align 8, !nonnull !3, !noundef !3
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i)
  store ptr @alloc_f281a46e9987443bf5658c5f394cb876, ptr %_5.i, align 8
  %1 = getelementptr inbounds nuw i8, ptr %_5.i, i64 8
  store i64 28, ptr %1, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i)
  store ptr %_5.i, ptr %args.i, align 8
  %_7.sroa.4.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %args.i, i64 8
  store ptr @_RNvXs1i_NtCsgtPOCBgevO_4core3fmtReNtB6_7Display3fmtCs6tqTQJNM79Z_8type_dag, ptr %_7.sroa.4.0..sroa_idx.i, align 8
; call core::fmt::write
  %2 = call noundef zeroext i1 @_RNvNtCsgtPOCBgevO_4core3fmt5write(ptr noundef nonnull %f.val, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(48) %f.val1, ptr noundef nonnull @alloc_ccb3afc2d9f98e5ced738fc09e93fead, ptr noundef nonnull %args.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i)
  ret i1 %2
}

; <&core::result::Result<u32, nudox_ir_format::type_dag::TypeDagError> as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6result6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_01.i = alloca [8 x i8], align 8
  %__self_0.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !59, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !60)
  %0 = load i8, ptr %_3, align 8, !range !63, !alias.scope !60, !noalias !64, !noundef !3
  %.not.i = icmp eq i8 %0, -1
  br i1 %.not.i, label %bb3.i, label %bb2.i

bb2.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01.i), !noalias !66
  store ptr %_3, ptr %__self_01.i, align 8, !noalias !66
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %1 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_bf301217d548e4f1fd13189dd935c554, i64 noundef 3, ptr noundef nonnull %__self_01.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.6)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01.i), !noalias !66
  br label %_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag.exit

bb3.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0.i), !noalias !66
  %2 = getelementptr inbounds nuw i8, ptr %_3, i64 4
  store ptr %2, ptr %__self_0.i, align 8, !noalias !66
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_c73d17da7498663a071b898ac2218935, i64 noundef 2, ptr noundef nonnull %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.k)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0.i), !noalias !66
  br label %_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag.exit

_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag.exit: ; preds = %bb2.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %1, %bb2.i ], [ %3, %bb3.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&nudox_ir_format::type_dag::TypeDagError as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !59, !noundef !3
; call <nudox_ir_format::type_dag::TypeDagError as core::fmt::Debug>::fmt
  %_0 = tail call noundef zeroext i1 @_RNvXsC_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(32) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  ret i1 %_0
}

; <&nudox_ir_format::type_dag::PrimitiveType as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag13PrimitiveTypeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !noundef !3
  %_3.val = load i8, ptr %_3, align 1, !range !28, !noundef !3
  %0 = trunc nuw i8 %_3.val to i1
  %..i = select i1 %0, i64 3, i64 4
  %alloc_e4fa82a2878eb5612d513befd6fc8a36.alloc_b94f1f40ebe2eb842bd4cc55034553f1.i = select i1 %0, ptr @alloc_e4fa82a2878eb5612d513befd6fc8a36, ptr @alloc_b94f1f40ebe2eb842bd4cc55034553f1
; call <core::fmt::Formatter>::write_str
  %_0.i = tail call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) %alloc_e4fa82a2878eb5612d513befd6fc8a36.alloc_b94f1f40ebe2eb842bd4cc55034553f1.i, i64 noundef %..i)
  ret i1 %_0.i
}

; <&nudox_ir_format::type_dag::TypeNodeFault as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag13TypeNodeFaultNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_12.i = alloca [8 x i8], align 8
  %__self_01.i = alloca [8 x i8], align 8
  %__self_0.i = alloca [8 x i8], align 8
  %__self_1.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !59, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !67)
  %0 = load i8, ptr %_3, align 8, !range !70, !alias.scope !67, !noalias !71, !noundef !3
  switch i8 %0, label %default.unreachable [
    i8 0, label %bb5.i
    i8 1, label %bb4.i
    i8 2, label %bb3.i
    i8 3, label %bb2.i
  ]

default.unreachable:                              ; preds = %start
  unreachable

bb5.i:                                            ; preds = %start
  %__self_03.i = getelementptr inbounds nuw i8, ptr %_3, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_1.i), !noalias !73
  %1 = getelementptr inbounds nuw i8, ptr %_3, i64 16
  store ptr %1, ptr %__self_1.i, align 8, !noalias !73
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %2 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_eb66dd8df2025c3378e51480905e26b5, i64 noundef 9, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_715ad17152b7a3dfcbb2abff840befeb, i64 noundef 8, ptr noundef nonnull readonly %__self_03.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.d, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_1.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.b)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_1.i), !noalias !73
  br label %_RNvXsv_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb4.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0.i), !noalias !73
  %3 = getelementptr inbounds nuw i8, ptr %_3, i64 1
  store ptr %3, ptr %__self_0.i, align 8, !noalias !73
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %4 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_cdb9aa4db1ff8f1d481eca6e672fb6b0, i64 noundef 3, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.1)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0.i), !noalias !73
  br label %_RNvXsv_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb3.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01.i), !noalias !73
  %5 = getelementptr inbounds nuw i8, ptr %_3, i64 1
  store ptr %5, ptr %__self_01.i, align 8, !noalias !73
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %6 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_2a28b803340a522af1d6fe0d14a5f8e5, i64 noundef 9, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_01.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.1)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01.i), !noalias !73
  br label %_RNvXsv_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb2.i:                                            ; preds = %start
  %__self_04.i = getelementptr inbounds nuw i8, ptr %_3, i64 4
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_12.i), !noalias !73
  %7 = getelementptr inbounds nuw i8, ptr %_3, i64 1
  store ptr %7, ptr %__self_12.i, align 8, !noalias !73
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %8 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_2af43630e845fc262d2a6f3b2fa9b1c0, i64 noundef 4, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_5de5b778237022f7dfbd4b14eca9b832, i64 noundef 6, ptr noundef nonnull readonly %__self_04.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.e, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_c662412d9acfc8d757cfe16257349ca3, i64 noundef 10, ptr noundef nonnull %__self_12.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.1)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_12.i), !noalias !73
  br label %_RNvXsv_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

_RNvXsv_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit: ; preds = %bb5.i, %bb4.i, %bb3.i, %bb2.i
  %_0.sroa.0.0.in.i = phi i1 [ %2, %bb5.i ], [ %4, %bb4.i ], [ %6, %bb3.i ], [ %8, %bb2.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&nudox_ir_format::type_dag::TypeDagHeaderError as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag18TypeDagHeaderErrorNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_02.i = alloca [8 x i8], align 8
  %__self_01.i = alloca [8 x i8], align 8
  %__self_0.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !74)
  %0 = load i8, ptr %_3, align 1, !range !77, !alias.scope !74, !noalias !78, !noundef !3
  %1 = getelementptr inbounds nuw i8, ptr %_3, i64 1
  switch i8 %0, label %default.unreachable [
    i8 0, label %bb4.i
    i8 1, label %bb3.i
    i8 2, label %bb2.i
  ]

default.unreachable:                              ; preds = %start
  unreachable

bb4.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0.i), !noalias !80
  store ptr %1, ptr %__self_0.i, align 8, !noalias !80
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %2 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_d7b9b6c1829de9592f5bc6e83c4fc424, i64 noundef 5, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.1)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0.i), !noalias !80
  br label %_RNvXso_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_18TypeDagHeaderErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb3.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01.i), !noalias !80
  store ptr %1, ptr %__self_01.i, align 8, !noalias !80
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %3 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_d102eb289abff9d0655d27bf114c0746, i64 noundef 6, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_01.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.1)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01.i), !noalias !80
  br label %_RNvXso_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_18TypeDagHeaderErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb2.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_02.i), !noalias !80
  store ptr %1, ptr %__self_02.i, align 8, !noalias !80
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %4 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_830cc47b3e97457eae2b6eb6d050e986, i64 noundef 9, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_02.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.1)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_02.i), !noalias !80
  br label %_RNvXso_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_18TypeDagHeaderErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

_RNvXso_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_18TypeDagHeaderErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit: ; preds = %bb4.i, %bb3.i, %bb2.i
  %_0.sroa.0.0.in.i = phi i1 [ %2, %bb4.i ], [ %3, %bb3.i ], [ %4, %bb2.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&nudox_ir_format::type_dag::TypeNode as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_01.i = alloca [8 x i8], align 8
  %__self_0.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !43, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !81)
  %0 = load i8, ptr %_3, align 4, !range !28, !alias.scope !81, !noalias !84, !noundef !3
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2.i, label %bb3.i

bb2.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01.i), !noalias !86
  %2 = getelementptr inbounds nuw i8, ptr %_3, i64 4
  store ptr %2, ptr %__self_01.i, align 8, !noalias !86
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_a67487da2e66b342314634b825542faf, i64 noundef 9, ptr noundef nonnull %__self_01.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.j)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01.i), !noalias !86
  br label %_RNvXsh_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

bb3.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0.i), !noalias !86
  %4 = getelementptr inbounds nuw i8, ptr %_3, i64 1
  store ptr %4, ptr %__self_0.i, align 8, !noalias !86
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_2a28b803340a522af1d6fe0d14a5f8e5, i64 noundef 9, ptr noundef nonnull %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0.i), !noalias !86
  br label %_RNvXsh_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit

_RNvXsh_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt.exit: ; preds = %bb2.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %3, %bb2.i ], [ %5, %bb3.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&&nudox_ir_format::type_dag::TypeNode as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_01.i.i = alloca [8 x i8], align 8
  %__self_0.i.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !59, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !87)
  %_3.i = load ptr, ptr %_3, align 8, !alias.scope !87, !noalias !90, !nonnull !3, !align !43, !noundef !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !92)
  %0 = load i8, ptr %_3.i, align 4, !range !28, !alias.scope !92, !noalias !95, !noundef !3
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2.i.i, label %bb3.i.i

bb2.i.i:                                          ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01.i.i), !noalias !97
  %2 = getelementptr inbounds nuw i8, ptr %_3.i, i64 4
  store ptr %2, ptr %__self_01.i.i, align 8, !noalias !97
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_a67487da2e66b342314634b825542faf, i64 noundef 9, ptr noundef nonnull %__self_01.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.j), !noalias !87
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01.i.i), !noalias !97
  br label %_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag.exit

bb3.i.i:                                          ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0.i.i), !noalias !97
  %4 = getelementptr inbounds nuw i8, ptr %_3.i, i64 1
  store ptr %4, ptr %__self_0.i.i, align 8, !noalias !97
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_2a28b803340a522af1d6fe0d14a5f8e5, i64 noundef 9, ptr noundef nonnull %__self_0.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.i), !noalias !87
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0.i.i), !noalias !97
  br label %_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag.exit

_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag.exit: ; preds = %bb2.i.i, %bb3.i.i
  %_0.sroa.0.0.in.i.i = phi i1 [ %3, %bb2.i.i ], [ %5, %bb3.i.i ]
  ret i1 %_0.sroa.0.0.in.i.i
}

; <&&[u8] as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRRShNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %entry.i.i.i = alloca [8 x i8], align 8
  %_5.i.i = alloca [16 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !59, !noundef !3
  %_3.val = load ptr, ptr %_3, align 8, !nonnull !3, !noundef !3
  %0 = getelementptr i8, ptr %_3, i64 8
  %_3.val1 = load i64, ptr %0, align 8, !noundef !3
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i), !noalias !98
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter10debug_list(ptr noalias noundef nonnull sret([16 x i8]) align 8 captures(address) dereferenceable(16) %_5.i.i, ptr noalias noundef nonnull align 8 dereferenceable(24) %f), !noalias !104
  %_11.i.i = getelementptr inbounds nuw i8, ptr %_3.val, i64 %_3.val1
  %_6.i7.i.i.i = icmp samesign eq i64 %_3.val1, 0
  br i1 %_6.i7.i.i.i, label %_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRShNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag.exit, label %bb5.i.i.i

bb5.i.i.i:                                        ; preds = %start, %bb5.i.i.i
  %iter.sroa.0.08.i.i.i = phi ptr [ %_16.i.i.i.i, %bb5.i.i.i ], [ %_3.val, %start ]
  %_16.i.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.08.i.i.i, i64 1
  call void @llvm.lifetime.start.p0(ptr nonnull %entry.i.i.i), !noalias !105
  store ptr %iter.sroa.0.08.i.i.i, ptr %entry.i.i.i, align 8, !noalias !105
; call <core::fmt::builders::DebugList>::entry
  %_9.i.i.i = call noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i, ptr noundef nonnull %entry.i.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.1)
  call void @llvm.lifetime.end.p0(ptr nonnull %entry.i.i.i), !noalias !105
  %_6.i.i.i.i = icmp eq ptr %_16.i.i.i.i, %_11.i.i
  br i1 %_6.i.i.i.i, label %_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRShNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag.exit, label %bb5.i.i.i

_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRShNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag.exit: ; preds = %bb5.i.i.i, %start
; call <core::fmt::builders::DebugList>::finish
  %_0.i.i = call noundef zeroext i1 @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList6finish(ptr noalias noundef nonnull align 8 dereferenceable(16) %_5.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i), !noalias !98
  ret i1 %_0.i.i
}

; <&str as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtReNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(16) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3.0 = load ptr, ptr %self, align 8, !nonnull !3, !noundef !3
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8, !noundef !3
; call <str as core::fmt::Debug>::fmt
  %_0 = tail call noundef zeroext i1 @_RNvXsh_NtCsgtPOCBgevO_4core3fmteNtB5_5Debug3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance) %_3.0, i64 noundef %_3.1, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  ret i1 %_0
}

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRhNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !noundef !3
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4.i = load i32, ptr %0, align 8, !alias.scope !108, !noalias !111, !noundef !3
  %_3.i = and i32 %_4.i, 33554432
  %1 = icmp eq i32 %_3.i, 0
  br i1 %1, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %start
  %_5.i = and i32 %_4.i, 67108864
  %2 = icmp eq i32 %_5.i, 0
  br i1 %2, label %bb4.i, label %bb3.i

bb1.i:                                            ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXse_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance) dereferenceable(1) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt.exit

bb4.i:                                            ; preds = %bb2.i
; call <u8 as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXNtNtNtCsgtPOCBgevO_4core3fmt3num3imphNtB6_7Display3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance) dereferenceable(1) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt.exit

bb3.i:                                            ; preds = %bb2.i
; call <u8 as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXsg_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance) dereferenceable(1) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt.exit

_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt.exit: ; preds = %bb1.i, %bb4.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %5, %bb3.i ], [ %3, %bb1.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&usize as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRjNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !59, !noundef !3
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4.i = load i32, ptr %0, align 8, !alias.scope !113, !noalias !116, !noundef !3
  %_3.i = and i32 %_4.i, 33554432
  %1 = icmp eq i32 %_3.i, 0
  br i1 %1, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %start
  %_5.i = and i32 %_4.i, 67108864
  %2 = icmp eq i32 %_5.i, 0
  br i1 %2, label %bb4.i, label %bb3.i

bb1.i:                                            ; preds = %start
; call <usize as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt.exit

bb4.i:                                            ; preds = %bb2.i
; call <usize as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt.exit

bb3.i:                                            ; preds = %bb2.i
; call <usize as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt.exit

_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt.exit: ; preds = %bb1.i, %bb4.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %5, %bb3.i ], [ %3, %bb1.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&u32 as core::fmt::Debug>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRmNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !3, !align !43, !noundef !3
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4.i = load i32, ptr %0, align 8, !alias.scope !118, !noalias !121, !noundef !3
  %_3.i = and i32 %_4.i, 33554432
  %1 = icmp eq i32 %_3.i, 0
  br i1 %1, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %start
  %_5.i = and i32 %_4.i, 67108864
  %2 = icmp eq i32 %_5.i, 0
  br i1 %2, label %bb4.i, label %bb3.i

bb1.i:                                            ; preds = %start
; call <u32 as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXsu_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(4) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt.exit

bb4.i:                                            ; preds = %bb2.i
; call <u32 as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXs8_NtNtNtCsgtPOCBgevO_4core3fmt3num3impmNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(4) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt.exit

bb3.i:                                            ; preds = %bb2.i
; call <u32 as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXsw_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(4) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %_RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt.exit

_RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt.exit: ; preds = %bb1.i, %bb4.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %5, %bb3.i ], [ %3, %bb1.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&str as core::fmt::Display>::fmt
; Function Attrs: uwtable
define internal noundef zeroext i1 @_RNvXs1i_NtCsgtPOCBgevO_4core3fmtReNtB6_7Display3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(none) dereferenceable(16) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3.0 = load ptr, ptr %self, align 8, !nonnull !3, !noundef !3
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8, !noundef !3
; call <str as core::fmt::Display>::fmt
  %_0 = tail call noundef zeroext i1 @_RNvXsi_NtCsgtPOCBgevO_4core3fmteNtB5_7Display3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance) %_3.0, i64 noundef %_3.1, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  ret i1 %_0
}

; <nudox_ir_format::type_dag::TypeDagError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint uwtable
define internal noundef zeroext i1 @_RNvXsC_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %__self_14 = alloca [8 x i8], align 8
  %__self_13 = alloca [8 x i8], align 8
  %__self_12 = alloca [8 x i8], align 8
  %__self_1 = alloca [8 x i8], align 8
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %0 = load i8, ptr %self, align 8, !range !123, !noundef !3
  switch i8 %0, label %default.unreachable9 [
    i8 0, label %bb7
    i8 1, label %bb6
    i8 2, label %bb5
    i8 3, label %bb4
    i8 4, label %bb3
    i8 5, label %bb2
  ]

default.unreachable9:                             ; preds = %start
  unreachable

bb7:                                              ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_0)
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 8
  store ptr %1, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %2 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_ea8e8baf0be5855bbef17ce48226036b, i64 noundef 17, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.b)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_0)
  br label %bb14

bb6:                                              ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_01)
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b2243a0a9fd6f5181b6e5ba2b6488d3a, i64 noundef 6, ptr noundef nonnull %__self_01, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.c)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_01)
  br label %bb14

bb5:                                              ; preds = %start
  %__self_05 = getelementptr inbounds nuw i8, ptr %self, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_1)
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 16
  store ptr %5, ptr %__self_1, align 8
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %6 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_4d3c10a7785e3cacd7635396354c2688, i64 noundef 8, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_bebfed686e6a6f31c99c69b171066b8a, i64 noundef 8, ptr noundef nonnull %__self_05, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.d, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.b)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_1)
  br label %bb14

bb4:                                              ; preds = %start
  %__self_06 = getelementptr inbounds nuw i8, ptr %self, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_12)
  %7 = getelementptr inbounds nuw i8, ptr %self, i64 16
  store ptr %7, ptr %__self_12, align 8
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %8 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_5c9910a63c1c5173176bd3aa76a8ac20, i64 noundef 15, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_715ad17152b7a3dfcbb2abff840befeb, i64 noundef 8, ptr noundef nonnull %__self_06, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.d, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_700d5d683c25860e3d40207214c9c99c, i64 noundef 9, ptr noundef nonnull %__self_12, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.b)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_12)
  br label %bb14

bb3:                                              ; preds = %start
  %__self_07 = getelementptr inbounds nuw i8, ptr %self, i64 4
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_13)
  %9 = getelementptr inbounds nuw i8, ptr %self, i64 8
  store ptr %9, ptr %__self_13, align 8
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %10 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_1e2d27e83e9b70f610a2d8f4ab61fc2e, i64 noundef 4, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_d466f777e26b5a6c15c5498a3130191d, i64 noundef 7, ptr noundef nonnull %__self_07, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.e, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_652e7c9d7b77be2ac6e01717f701606a, i64 noundef 5, ptr noundef nonnull %__self_13, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.f)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_13)
  br label %bb14

bb2:                                              ; preds = %start
  %__self_08 = getelementptr inbounds nuw i8, ptr %self, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_14)
  %11 = getelementptr inbounds nuw i8, ptr %self, i64 16
  store ptr %11, ptr %__self_14, align 8
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %12 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_d7a7f078b751cfeba410ab5cc24bfa07, i64 noundef 9, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_bebfed686e6a6f31c99c69b171066b8a, i64 noundef 8, ptr noundef nonnull %__self_08, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.d, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b31c6c8dca3d1da07e1eee656fa2f5cc, i64 noundef 6, ptr noundef nonnull %__self_14, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.b)
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_14)
  br label %bb14

bb14:                                             ; preds = %bb2, %bb3, %bb4, %bb5, %bb6, %bb7
  %_0.sroa.0.0.in = phi i1 [ %2, %bb7 ], [ %4, %bb6 ], [ %6, %bb5 ], [ %8, %bb4 ], [ %10, %bb3 ], [ %12, %bb2 ]
  ret i1 %_0.sroa.0.0.in
}

; <nudox_ir_format::type_dag::TypeDagError as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite) uwtable
define internal fastcc noundef zeroext i1 @_RNvXsF_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq(ptr noalias noundef nonnull readonly align 8 captures(none) dereferenceable(32) %self, ptr noalias noundef nonnull readonly align 8 captures(none) dereferenceable(32) %other) unnamed_addr #5 {
start:
  %0 = load i8, ptr %self, align 8, !range !123, !noundef !3
  %1 = load i8, ptr %other, align 8, !range !123, !noundef !3
  %_5 = icmp eq i8 %0, %1
  br i1 %_5, label %bb1, label %bb21

bb1:                                              ; preds = %start
  switch i8 %0, label %default.unreachable5 [
    i8 0, label %bb3
    i8 1, label %bb4
    i8 2, label %bb5
    i8 3, label %bb6
    i8 4, label %bb7
    i8 5, label %bb8
  ]

bb21:                                             ; preds = %bb10.i, %bb7.i, %bb6.i, %bb5.i, %bb4.i, %bb3.i, %bb15, %bb8, %bb7, %bb6, %bb5, %start, %bb18, %bb12, %bb9, %bb4, %bb3
  %_0.sroa.0.0.shrunk = phi i1 [ %4, %bb3 ], [ %spec.select.i, %bb4 ], [ %18, %bb9 ], [ false, %start ], [ %21, %bb12 ], [ false, %bb5 ], [ false, %bb8 ], [ false, %bb6 ], [ %42, %bb18 ], [ false, %bb7 ], [ %36, %bb7.i ], [ false, %bb15 ], [ %28, %bb4.i ], [ %31, %bb5.i ], [ %39, %bb10.i ], [ false, %bb3.i ], [ false, %bb6.i ]
  ret i1 %_0.sroa.0.0.shrunk

default.unreachable5:                             ; preds = %bb1.i, %bb1
  unreachable

bb3:                                              ; preds = %bb1
  %2 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_38 = load i64, ptr %2, align 8, !noundef !3
  %3 = getelementptr inbounds nuw i8, ptr %other, i64 8
  %_39 = load i64, ptr %3, align 8, !noundef !3
  %4 = icmp eq i64 %_38, %_39
  br label %bb21

bb4:                                              ; preds = %bb1
  %__self_0 = getelementptr inbounds nuw i8, ptr %self, i64 1
  %__arg1_0 = getelementptr inbounds nuw i8, ptr %other, i64 1
  %__self_0.val = load i8, ptr %__self_0, align 1, !range !77, !noundef !3
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 2
  %__self_0.val1 = load i8, ptr %5, align 2
  %__arg1_0.val = load i8, ptr %__arg1_0, align 1, !range !77, !noundef !3
  %6 = getelementptr inbounds nuw i8, ptr %other, i64 2
  %__arg1_0.val2 = load i8, ptr %6, align 2
  %_5.i = icmp eq i8 %__self_0.val, %__arg1_0.val
  %7 = icmp eq i8 %__self_0.val1, %__arg1_0.val2
  %spec.select.i = select i1 %_5.i, i1 %7, i1 false
  br label %bb21

bb5:                                              ; preds = %bb1
  %8 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_36 = load i64, ptr %8, align 8, !noundef !3
  %9 = getelementptr inbounds nuw i8, ptr %other, i64 8
  %_37 = load i64, ptr %9, align 8, !noundef !3
  %_14 = icmp eq i64 %_36, %_37
  br i1 %_14, label %bb9, label %bb21

bb6:                                              ; preds = %bb1
  %10 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_34 = load i64, ptr %10, align 8, !noundef !3
  %11 = getelementptr inbounds nuw i8, ptr %other, i64 8
  %_35 = load i64, ptr %11, align 8, !noundef !3
  %_19 = icmp eq i64 %_34, %_35
  br i1 %_19, label %bb12, label %bb21

bb7:                                              ; preds = %bb1
  %12 = getelementptr inbounds nuw i8, ptr %self, i64 4
  %_32 = load i32, ptr %12, align 4, !noundef !3
  %13 = getelementptr inbounds nuw i8, ptr %other, i64 4
  %_33 = load i32, ptr %13, align 4, !noundef !3
  %_31 = icmp eq i32 %_32, %_33
  br i1 %_31, label %bb15, label %bb21

bb8:                                              ; preds = %bb1
  %14 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_29 = load i64, ptr %14, align 8, !noundef !3
  %15 = getelementptr inbounds nuw i8, ptr %other, i64 8
  %_30 = load i64, ptr %15, align 8, !noundef !3
  %_28 = icmp eq i64 %_29, %_30
  br i1 %_28, label %bb18, label %bb21

bb9:                                              ; preds = %bb5
  %16 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_40 = load i64, ptr %16, align 8, !noundef !3
  %17 = getelementptr inbounds nuw i8, ptr %other, i64 16
  %_41 = load i64, ptr %17, align 8, !noundef !3
  %18 = icmp eq i64 %_40, %_41
  br label %bb21

bb12:                                             ; preds = %bb6
  %19 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_42 = load i64, ptr %19, align 8, !noundef !3
  %20 = getelementptr inbounds nuw i8, ptr %other, i64 16
  %_43 = load i64, ptr %20, align 8, !noundef !3
  %21 = icmp eq i64 %_42, %_43
  br label %bb21

bb15:                                             ; preds = %bb7
  %__arg1_1 = getelementptr inbounds nuw i8, ptr %other, i64 8
  %__self_1 = getelementptr inbounds nuw i8, ptr %self, i64 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !124)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !127)
  %22 = load i8, ptr %__self_1, align 8, !range !70, !alias.scope !124, !noalias !127, !noundef !3
  %23 = load i8, ptr %__arg1_1, align 8, !range !70, !alias.scope !127, !noalias !124, !noundef !3
  %_5.i3 = icmp eq i8 %22, %23
  br i1 %_5.i3, label %bb1.i, label %bb21

bb1.i:                                            ; preds = %bb15
  switch i8 %22, label %default.unreachable5 [
    i8 0, label %bb3.i
    i8 1, label %bb4.i
    i8 2, label %bb5.i
    i8 3, label %bb6.i
  ]

bb3.i:                                            ; preds = %bb1.i
  %24 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_26.i = load i64, ptr %24, align 8, !alias.scope !124, !noalias !127, !noundef !3
  %25 = getelementptr inbounds nuw i8, ptr %other, i64 16
  %_27.i = load i64, ptr %25, align 8, !alias.scope !127, !noalias !124, !noundef !3
  %_10.i = icmp eq i64 %_26.i, %_27.i
  br i1 %_10.i, label %bb7.i, label %bb21

bb4.i:                                            ; preds = %bb1.i
  %26 = getelementptr inbounds nuw i8, ptr %self, i64 9
  %_24.i = load i8, ptr %26, align 1, !alias.scope !124, !noalias !127, !noundef !3
  %27 = getelementptr inbounds nuw i8, ptr %other, i64 9
  %_25.i = load i8, ptr %27, align 1, !alias.scope !127, !noalias !124, !noundef !3
  %28 = icmp eq i8 %_24.i, %_25.i
  br label %bb21

bb5.i:                                            ; preds = %bb1.i
  %29 = getelementptr inbounds nuw i8, ptr %self, i64 9
  %_22.i = load i8, ptr %29, align 1, !alias.scope !124, !noalias !127, !noundef !3
  %30 = getelementptr inbounds nuw i8, ptr %other, i64 9
  %_23.i = load i8, ptr %30, align 1, !alias.scope !127, !noalias !124, !noundef !3
  %31 = icmp eq i8 %_22.i, %_23.i
  br label %bb21

bb6.i:                                            ; preds = %bb1.i
  %32 = getelementptr inbounds nuw i8, ptr %self, i64 9
  %_20.i = load i8, ptr %32, align 1, !alias.scope !124, !noalias !127, !noundef !3
  %33 = getelementptr inbounds nuw i8, ptr %other, i64 9
  %_21.i = load i8, ptr %33, align 1, !alias.scope !127, !noalias !124, !noundef !3
  %_19.i = icmp eq i8 %_20.i, %_21.i
  br i1 %_19.i, label %bb10.i, label %bb21

bb7.i:                                            ; preds = %bb3.i
  %34 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %_28.i = load i64, ptr %34, align 8, !alias.scope !124, !noalias !127, !noundef !3
  %35 = getelementptr inbounds nuw i8, ptr %other, i64 24
  %_29.i = load i64, ptr %35, align 8, !alias.scope !127, !noalias !124, !noundef !3
  %36 = icmp eq i64 %_28.i, %_29.i
  br label %bb21

bb10.i:                                           ; preds = %bb6.i
  %37 = getelementptr inbounds nuw i8, ptr %self, i64 12
  %_30.i = load i32, ptr %37, align 4, !alias.scope !124, !noalias !127, !noundef !3
  %38 = getelementptr inbounds nuw i8, ptr %other, i64 12
  %_31.i = load i32, ptr %38, align 4, !alias.scope !127, !noalias !124, !noundef !3
  %39 = icmp eq i32 %_30.i, %_31.i
  br label %bb21

bb18:                                             ; preds = %bb8
  %40 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_44 = load i64, ptr %40, align 8, !noundef !3
  %41 = getelementptr inbounds nuw i8, ptr %other, i64 16
  %_45 = load i64, ptr %41, align 8, !noundef !3
  %42 = icmp eq i64 %_44, %_45
  br label %bb21
}

; <u32 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint uwtable
define internal noundef zeroext i1 @_RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(4) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4 = load i32, ptr %0, align 8, !noundef !3
  %_3 = and i32 %_4, 33554432
  %1 = icmp eq i32 %_3, 0
  br i1 %1, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %_5 = and i32 %_4, 67108864
  %2 = icmp eq i32 %_5, 0
  br i1 %2, label %bb4, label %bb3

bb1:                                              ; preds = %start
; call <u32 as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXsu_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(4) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %bb6

bb4:                                              ; preds = %bb2
; call <u32 as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXs8_NtNtNtCsgtPOCBgevO_4core3fmt3num3impmNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(4) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %bb6

bb3:                                              ; preds = %bb2
; call <u32 as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXsw_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(4) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3, %bb1
  %_0.sroa.0.0.in = phi i1 [ %4, %bb4 ], [ %5, %bb3 ], [ %3, %bb1 ]
  ret i1 %_0.sroa.0.0.in
}

; <usize as core::fmt::Debug>::fmt
; Function Attrs: inlinehint uwtable
define internal noundef zeroext i1 @_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4 = load i32, ptr %0, align 8, !noundef !3
  %_3 = and i32 %_4, 33554432
  %1 = icmp eq i32 %_3, 0
  br i1 %1, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %_5 = and i32 %_4, 67108864
  %2 = icmp eq i32 %_5, 0
  br i1 %2, label %bb4, label %bb3

bb1:                                              ; preds = %start
; call <usize as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %bb6

bb4:                                              ; preds = %bb2
; call <usize as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %bb6

bb3:                                              ; preds = %bb2
; call <usize as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f)
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3, %bb1
  %_0.sroa.0.0.in = phi i1 [ %4, %bb4 ], [ %5, %bb3 ], [ %3, %bb1 ]
  ret i1 %_0.sroa.0.0.in
}

; <nudox_ir_vocab::DenseId<nudox_ir_vocab::Type> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint uwtable
define internal noundef zeroext i1 @_RNvXsf_Csjj9WfcXSjwO_14nudox_ir_vocabINtB5_7DenseIdNtB5_4TypeENtNtCsgtPOCBgevO_4core3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(4) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %_7 = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_7)
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 4
  store ptr %0, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %_0 = call noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_1ab8f3bcfc18061e9d6f0217059b41f5, i64 noundef 7, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_005de03493e3aaea3890cf93afea4072, i64 noundef 3, ptr noundef nonnull %self, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.g, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_8cc6661f3cf091aca5a7bc91c52031fe, i64 noundef 5, ptr noundef nonnull %_7, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.h)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7)
  ret i1 %_0
}

; <&str as core::str::pattern::Pattern>::is_contained_in
; Function Attrs: inlinehint uwtable
define internal fastcc noundef zeroext i1 @_RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in(ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.0, i64 noundef %self.1, ptr noalias noundef nonnull readonly captures(address, read_provenance) %haystack.0, i64 noundef %haystack.1) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %check_mask.i = alloca [32 x i8], align 8
  %_17 = alloca [104 x i8], align 8
  %_15 = alloca [24 x i8], align 8
  %0 = icmp eq i64 %self.1, 0
  br i1 %0, label %bb16, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp ult i64 %self.1, %haystack.1
  br i1 %1, label %bb4, label %bb3

bb16:                                             ; preds = %bb1.backedge.us.i.i, %bb3.us.i.i, %bb7.i, %bb2.i, %bb34.i, %bb3.lr.ph.split.us.i.i, %bb3, %start, %bb17, %bb12
  %result.sroa.0.0.off0 = phi i1 [ true, %start ], [ %5, %bb2.i ], [ false, %bb3 ], [ %extract.t3, %bb12 ], [ %64, %bb17 ], [ %result.sroa.0.5.off0.i, %bb34.i ], [ true, %bb3.lr.ph.split.us.i.i ], [ %_8.i, %bb7.i ], [ %_2.i.us.not.i.not.i.not.not, %bb3.us.i.i ], [ %_2.i.us.not.i.not.i.not.not, %bb1.backedge.us.i.i ]
  ret i1 %result.sroa.0.0.off0

bb4:                                              ; preds = %bb2
  %2 = icmp eq i64 %self.1, 1
  br i1 %2, label %bb6, label %bb7

bb3:                                              ; preds = %bb2
  %_24 = icmp eq i64 %self.1, %haystack.1
  br i1 %_24, label %bb17, label %bb16

bb7:                                              ; preds = %bb4
  %_11 = icmp ult i64 %self.1, 33
  br i1 %_11, label %bb8, label %bb12

bb6:                                              ; preds = %bb4
  %_32 = load i8, ptr %self.0, align 1, !noundef !3
  %_3.i = icmp samesign ult i64 %haystack.1, 16
  br i1 %_3.i, label %bb7.i, label %bb2.i

bb2.i:                                            ; preds = %bb6
; call core::slice::memchr::memchr_aligned
  %3 = tail call { i64, i64 } @_RNvNtNtCsgtPOCBgevO_4core5slice6memchr14memchr_aligned(i8 noundef %_32, ptr noalias noundef nonnull readonly captures(address, read_provenance) %haystack.0, i64 noundef range(i64 0, -9223372036854775808) %haystack.1)
  %4 = extractvalue { i64, i64 } %3, 0
  %5 = icmp eq i64 %4, 1
  br label %bb16

bb7.i:                                            ; preds = %bb6, %bb7.i
  %i.sroa.0.05.i = phi i64 [ %7, %bb7.i ], [ 0, %bb6 ]
  %6 = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %i.sroa.0.05.i
  %_9.i = load i8, ptr %6, align 1, !alias.scope !129, !noundef !3
  %_8.i = icmp eq i8 %_9.i, %_32
  %7 = add nuw nsw i64 %i.sroa.0.05.i, 1
  %exitcond.not.i = icmp eq i64 %7, %haystack.1
  %or.cond = select i1 %_8.i, i1 true, i1 %exitcond.not.i
  br i1 %or.cond, label %bb16, label %bb7.i

bb12:                                             ; preds = %bb1.i.i, %bb7
  call void @llvm.lifetime.start.p0(ptr nonnull %_15)
  call void @llvm.lifetime.start.p0(ptr nonnull %_17)
; call <core::str::pattern::StrSearcher>::new
  call void @_RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new(ptr noalias noundef nonnull sret([104 x i8]) align 8 captures(none) dereferenceable(104) %_17, ptr noalias noundef nonnull readonly captures(address, read_provenance) %haystack.0, i64 noundef %haystack.1, ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.0, i64 noundef %self.1)
; call <core::str::pattern::StrSearcher as core::str::pattern::Searcher>::next_match
  call fastcc void @_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_15, ptr noalias noundef align 8 dereferenceable(104) %_17)
  %_34 = load i64, ptr %_15, align 8, !range !16, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %_17)
  call void @llvm.lifetime.end.p0(ptr nonnull %_15)
  %extract.t3 = trunc nuw i64 %_34 to i1
  br label %bb16

bb8:                                              ; preds = %bb7
  tail call void @llvm.experimental.noalias.scope.decl(metadata !132)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !135)
  %8 = load i8, ptr %self.0, align 1, !alias.scope !132, !noalias !135, !noundef !3
  %last_byte_offset.i = add nsw i64 %self.1, -1
  %9 = icmp eq i64 %self.1, 2
  br i1 %9, label %bb4.thread.i, label %bb3.i

bb3.i:                                            ; preds = %bb8
  %10 = tail call i64 @llvm.usub.sat.i64(i64 range(i64 2, 33) %self.1, i64 4)
  br label %bb1.i.i

bb1.i.i:                                          ; preds = %_RNCINvNvNtNtNtNtCsgtPOCBgevO_4core4iter6traits12double_ended19DoubleEndedIterator5rfind5checkjNCNvNtNtBe_3str7pattern13simd_contains0E0Cs6tqTQJNM79Z_8type_dag.exit.i.i, %bb3.i
  %_0.i1.i.i8.i.i = phi i64 [ %_0.i1.i.i.i.i, %_RNCINvNvNtNtNtNtCsgtPOCBgevO_4core4iter6traits12double_ended19DoubleEndedIterator5rfind5checkjNCNvNtNtBe_3str7pattern13simd_contains0E0Cs6tqTQJNM79Z_8type_dag.exit.i.i ], [ %self.1, %bb3.i ]
  %_0.i.i.i.i.i = icmp ult i64 %10, %_0.i1.i.i8.i.i
  br i1 %_0.i.i.i.i.i, label %bb3.i.i, label %bb12

bb3.i.i:                                          ; preds = %bb1.i.i
  %_0.i1.i.i.i.i = add nsw i64 %_0.i1.i.i8.i.i, -1
  %_6.i.i.i.i = icmp ult i64 %_0.i1.i.i.i.i, %self.1
  br i1 %_6.i.i.i.i, label %_RNCINvNvNtNtNtNtCsgtPOCBgevO_4core4iter6traits12double_ended19DoubleEndedIterator5rfind5checkjNCNvNtNtBe_3str7pattern13simd_contains0E0Cs6tqTQJNM79Z_8type_dag.exit.i.i, label %panic.i.i.i.i

panic.i.i.i.i:                                    ; preds = %bb3.i.i
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef %_0.i1.i.i.i.i, i64 noundef range(i64 2, 33) %self.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_fc59cbe87b130fa4fa1d3a2e82d342fe) #18, !noalias !137
  unreachable

_RNCINvNvNtNtNtNtCsgtPOCBgevO_4core4iter6traits12double_ended19DoubleEndedIterator5rfind5checkjNCNvNtNtBe_3str7pattern13simd_contains0E0Cs6tqTQJNM79Z_8type_dag.exit.i.i: ; preds = %bb3.i.i
  %11 = getelementptr inbounds nuw i8, ptr %self.0, i64 %_0.i1.i.i.i.i
  %_4.i.i3.i.i = load i8, ptr %11, align 1, !alias.scope !132, !noalias !145, !noundef !3
  %_0.i.not.i.not.i.i = icmp eq i8 %_4.i.i3.i.i, %8
  br i1 %_0.i.not.i.not.i.i, label %bb1.i.i, label %bb4.i6

bb4.i6:                                           ; preds = %_RNCINvNvNtNtNtNtCsgtPOCBgevO_4core4iter6traits12double_ended19DoubleEndedIterator5rfind5checkjNCNvNtNtBe_3str7pattern13simd_contains0E0Cs6tqTQJNM79Z_8type_dag.exit.i.i
  %_19.i = add nuw nsw i64 %self.1, 15
  %_17.i = icmp ult i64 %haystack.1, %_19.i
  br i1 %_17.i, label %bb3.lr.ph.split.us.i.i, label %bb6.i

bb4.thread.i:                                     ; preds = %bb8
  %_1777.i = icmp ult i64 %haystack.1, 17
  br i1 %_1777.i, label %bb3.lr.ph.split.us.i.i, label %bb6.thread.i

bb6.thread.i:                                     ; preds = %bb4.thread.i
  %12 = insertelement <16 x i8> poison, i8 %8, i64 0
  %13 = shufflevector <16 x i8> %12, <16 x i8> poison, <16 x i32> zeroinitializer
  %.phi.trans.insert.i = getelementptr inbounds nuw i8, ptr %self.0, i64 1
  %value.pre.i = load i8, ptr %.phi.trans.insert.i, align 1, !alias.scope !132, !noalias !135
  br label %bb7.i7

bb6.i:                                            ; preds = %bb4.i6
  %14 = insertelement <16 x i8> poison, i8 %8, i64 0
  %15 = shufflevector <16 x i8> %14, <16 x i8> poison, <16 x i32> zeroinitializer
  br label %bb7.i7

bb3.lr.ph.split.us.i.i:                           ; preds = %bb4.i6, %bb4.thread.i
  %16 = tail call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(1) %haystack.0, ptr noundef nonnull readonly dereferenceable(1) %self.0, i64 range(i64 2, 33) %self.1), !alias.scope !146, !noalias !147
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %bb16, label %bb1.backedge.us.i.i

bb3.us.i.i:                                       ; preds = %bb1.backedge.us.i.i
  %_28.i.us21.i.i = getelementptr inbounds nuw i8, ptr %_28.i.us21.i.pn.i, i64 1
  %18 = tail call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(1) %_28.i.us21.i.i, ptr noundef nonnull readonly dereferenceable(1) %self.0, i64 range(i64 2, 33) %self.1), !alias.scope !146, !noalias !147
  %19 = icmp eq i32 %18, 0
  br i1 %19, label %bb16, label %bb1.backedge.us.i.i

bb1.backedge.us.i.i:                              ; preds = %bb3.lr.ph.split.us.i.i, %bb3.us.i.i
  %_28.i.us21.i.pn.i = phi ptr [ %_28.i.us21.i.i, %bb3.us.i.i ], [ %haystack.0, %bb3.lr.ph.split.us.i.i ]
  %new_len.i.us20.i.in.i = phi i64 [ %new_len.i.us20.i.i, %bb3.us.i.i ], [ %haystack.1, %bb3.lr.ph.split.us.i.i ]
  %new_len.i.us20.i.i = add i64 %new_len.i.us20.i.in.i, -1
  %_2.i.us.not.i.not.i.not.not = icmp ule i64 %self.1, %new_len.i.us20.i.i
  br i1 %_2.i.us.not.i.not.i.not.not, label %bb3.us.i.i, label %bb16

bb7.i7:                                           ; preds = %bb6.i, %bb6.thread.i
  %value.i = phi i8 [ %value.pre.i, %bb6.thread.i ], [ %_4.i.i3.i.i, %bb6.i ]
  %20 = phi <16 x i8> [ %13, %bb6.thread.i ], [ %15, %bb6.i ]
  %storemerge7881.i = phi i64 [ 1, %bb6.thread.i ], [ %_0.i1.i.i.i.i, %bb6.i ]
  %21 = insertelement <16 x i8> poison, i8 %value.i, i64 0
  %22 = shufflevector <16 x i8> %21, <16 x i8> poison, <16 x i32> zeroinitializer
  %_108.i = getelementptr inbounds nuw i8, ptr %self.0, i64 1
  call void @llvm.lifetime.start.p0(ptr nonnull %check_mask.i), !noalias !146
  store ptr %haystack.0, ptr %check_mask.i, align 8, !noalias !146
  %23 = getelementptr inbounds nuw i8, ptr %check_mask.i, i64 8
  store i64 %haystack.1, ptr %23, align 8, !noalias !146
  %24 = getelementptr inbounds nuw i8, ptr %check_mask.i, i64 16
  store ptr %_108.i, ptr %24, align 8, !noalias !146
  %25 = getelementptr inbounds nuw i8, ptr %check_mask.i, i64 24
  store i64 %last_byte_offset.i, ptr %25, align 8, !noalias !146
  %_40.i = add nuw nsw i64 %self.1, 63
  %_3886.not.i = icmp ult i64 %_40.i, %haystack.1
  br i1 %_3886.not.i, label %bb10.i, label %bb22.preheader.i

bb22.preheader.i:                                 ; preds = %bb19.3.i, %bb7.i7
  %i.sroa.0.0.lcssa.i8 = phi i64 [ 0, %bb7.i7 ], [ %50, %bb19.3.i ]
  %result.sroa.0.0.off0.lcssa.i = phi i1 [ false, %bb7.i7 ], [ %result.sroa.0.2.off0.3.i, %bb19.3.i ]
  %_70.i = add nuw nsw i64 %self.1, 15
  %_6989.i = add i64 %i.sroa.0.0.lcssa.i8, %_70.i
  %_6890.i = icmp uge i64 %_6989.i, %haystack.1
  %or.cond1491.i = or i1 %result.sroa.0.0.off0.lcssa.i, %_6890.i
  br i1 %or.cond1491.i, label %bb30.i, label %bb24.i

bb10.i:                                           ; preds = %bb7.i7, %bb19.3.i
  %i.sroa.0.087.i = phi i64 [ %50, %bb19.3.i ], [ 0, %bb7.i7 ]
  %26 = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %i.sroa.0.087.i
  %tmp.sroa.0.0.copyload.i.i = load <16 x i8>, ptr %26, align 1, !alias.scope !135, !noalias !151
  %self5.i.i = getelementptr inbounds nuw i8, ptr %26, i64 %storemerge7881.i
  %tmp1.sroa.0.0.copyload.i.i = load <16 x i8>, ptr %self5.i.i, align 1, !alias.scope !135, !noalias !151
  %27 = icmp eq <16 x i8> %tmp.sroa.0.0.copyload.i.i, %20
  %28 = icmp eq <16 x i8> %tmp1.sroa.0.0.copyload.i.i, %22
  %29 = and <16 x i1> %27, %28
  %30 = bitcast <16 x i1> %29 to i16
  %self3.i.1.i = getelementptr inbounds nuw i8, ptr %26, i64 16
  %tmp.sroa.0.0.copyload.i.1.i = load <16 x i8>, ptr %self3.i.1.i, align 1, !alias.scope !135, !noalias !151
  %self5.i.1.i = getelementptr inbounds nuw i8, ptr %self3.i.1.i, i64 %storemerge7881.i
  %tmp1.sroa.0.0.copyload.i.1.i = load <16 x i8>, ptr %self5.i.1.i, align 1, !alias.scope !135, !noalias !151
  %31 = icmp eq <16 x i8> %tmp.sroa.0.0.copyload.i.1.i, %20
  %32 = icmp eq <16 x i8> %tmp1.sroa.0.0.copyload.i.1.i, %22
  %33 = and <16 x i1> %31, %32
  %34 = bitcast <16 x i1> %33 to i16
  %self3.i.2.i = getelementptr inbounds nuw i8, ptr %26, i64 32
  %tmp.sroa.0.0.copyload.i.2.i = load <16 x i8>, ptr %self3.i.2.i, align 1, !alias.scope !135, !noalias !151
  %self5.i.2.i = getelementptr inbounds nuw i8, ptr %self3.i.2.i, i64 %storemerge7881.i
  %tmp1.sroa.0.0.copyload.i.2.i = load <16 x i8>, ptr %self5.i.2.i, align 1, !alias.scope !135, !noalias !151
  %35 = icmp eq <16 x i8> %tmp.sroa.0.0.copyload.i.2.i, %20
  %36 = icmp eq <16 x i8> %tmp1.sroa.0.0.copyload.i.2.i, %22
  %37 = and <16 x i1> %35, %36
  %38 = bitcast <16 x i1> %37 to i16
  %self3.i.3.i = getelementptr inbounds nuw i8, ptr %26, i64 48
  %tmp.sroa.0.0.copyload.i.3.i = load <16 x i8>, ptr %self3.i.3.i, align 1, !alias.scope !135, !noalias !151
  %self5.i.3.i = getelementptr inbounds nuw i8, ptr %self3.i.3.i, i64 %storemerge7881.i
  %tmp1.sroa.0.0.copyload.i.3.i = load <16 x i8>, ptr %self5.i.3.i, align 1, !alias.scope !135, !noalias !151
  %39 = icmp eq <16 x i8> %tmp.sroa.0.0.copyload.i.3.i, %20
  %40 = icmp eq <16 x i8> %tmp1.sroa.0.0.copyload.i.3.i, %22
  %41 = and <16 x i1> %39, %40
  %42 = bitcast <16 x i1> %41 to i16
  %43 = icmp eq i16 %30, 0
  br i1 %43, label %bb19.i, label %bb17.i

bb19.i:                                           ; preds = %bb17.i, %bb10.i
  %result.sroa.0.2.off0.i = phi i1 [ false, %bb10.i ], [ %_61.i, %bb17.i ]
  %44 = icmp eq i16 %34, 0
  br i1 %44, label %bb19.1.i, label %bb17.1.i

bb17.1.i:                                         ; preds = %bb19.i
  %_64.1.i = or disjoint i64 %i.sroa.0.087.i, 16
; call core::str::pattern::simd_contains::{closure#2}
  %_61.1.i = call fastcc noundef zeroext i1 @_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %check_mask.i, i64 noundef %_64.1.i, i16 noundef %34, i1 noundef zeroext %result.sroa.0.2.off0.i)
  %45 = or i1 %result.sroa.0.2.off0.i, %_61.1.i
  br label %bb19.1.i

bb19.1.i:                                         ; preds = %bb17.1.i, %bb19.i
  %result.sroa.0.2.off0.1.i = phi i1 [ %result.sroa.0.2.off0.i, %bb19.i ], [ %45, %bb17.1.i ]
  %46 = icmp eq i16 %38, 0
  br i1 %46, label %bb19.2.i, label %bb17.2.i

bb17.2.i:                                         ; preds = %bb19.1.i
  %_64.2.i = or disjoint i64 %i.sroa.0.087.i, 32
; call core::str::pattern::simd_contains::{closure#2}
  %_61.2.i = call fastcc noundef zeroext i1 @_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %check_mask.i, i64 noundef %_64.2.i, i16 noundef %38, i1 noundef zeroext %result.sroa.0.2.off0.1.i)
  %47 = or i1 %result.sroa.0.2.off0.1.i, %_61.2.i
  br label %bb19.2.i

bb19.2.i:                                         ; preds = %bb17.2.i, %bb19.1.i
  %result.sroa.0.2.off0.2.i = phi i1 [ %result.sroa.0.2.off0.1.i, %bb19.1.i ], [ %47, %bb17.2.i ]
  %48 = icmp eq i16 %42, 0
  br i1 %48, label %bb19.3.i, label %bb17.3.i

bb17.3.i:                                         ; preds = %bb19.2.i
  %_64.3.i = or disjoint i64 %i.sroa.0.087.i, 48
; call core::str::pattern::simd_contains::{closure#2}
  %_61.3.i = call fastcc noundef zeroext i1 @_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %check_mask.i, i64 noundef %_64.3.i, i16 noundef %42, i1 noundef zeroext %result.sroa.0.2.off0.2.i)
  %49 = or i1 %result.sroa.0.2.off0.2.i, %_61.3.i
  br label %bb19.3.i

bb19.3.i:                                         ; preds = %bb17.3.i, %bb19.2.i
  %result.sroa.0.2.off0.3.i = phi i1 [ %result.sroa.0.2.off0.2.i, %bb19.2.i ], [ %49, %bb17.3.i ]
  %50 = add i64 %i.sroa.0.087.i, 64
  %_39.i = add i64 %50, %_40.i
  %_38.i = icmp uge i64 %_39.i, %haystack.1
  %or.cond.i = or i1 %_38.i, %result.sroa.0.2.off0.3.i
  br i1 %or.cond.i, label %bb22.preheader.i, label %bb10.i

bb17.i:                                           ; preds = %bb10.i
; call core::str::pattern::simd_contains::{closure#2}
  %_61.i = call fastcc noundef zeroext i1 @_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %check_mask.i, i64 noundef %i.sroa.0.087.i, i16 noundef %30, i1 noundef zeroext false)
  br label %bb19.i

bb30.i:                                           ; preds = %bb28.i, %bb22.preheader.i
  %result.sroa.0.3.off0.lcssa.i = phi i1 [ %result.sroa.0.0.off0.lcssa.i, %bb22.preheader.i ], [ %result.sroa.0.4.i, %bb28.i ]
  %_83.i = sub i64 %haystack.1, %last_byte_offset.i
  %i12.i = add i64 %_83.i, -16
  %self3.i43.i = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %i12.i
  %tmp.sroa.0.0.copyload.i44.i = load <16 x i8>, ptr %self3.i43.i, align 1, !alias.scope !135, !noalias !154
  %self5.i47.i = getelementptr inbounds nuw i8, ptr %self3.i43.i, i64 %storemerge7881.i
  %tmp1.sroa.0.0.copyload.i48.i = load <16 x i8>, ptr %self5.i47.i, align 1, !alias.scope !135, !noalias !154
  %51 = icmp eq <16 x i8> %tmp.sroa.0.0.copyload.i44.i, %20
  %52 = icmp eq <16 x i8> %tmp1.sroa.0.0.copyload.i48.i, %22
  %53 = and <16 x i1> %51, %52
  %54 = bitcast <16 x i1> %53 to i16
  %55 = icmp eq i16 %54, 0
  br i1 %55, label %bb34.i, label %bb32.i

bb24.i:                                           ; preds = %bb22.preheader.i, %bb28.i
  %i.sroa.0.192.i = phi i64 [ %61, %bb28.i ], [ %i.sroa.0.0.lcssa.i8, %bb22.preheader.i ]
  %self3.i54.i = getelementptr inbounds nuw i8, ptr %haystack.0, i64 %i.sroa.0.192.i
  %tmp.sroa.0.0.copyload.i55.i = load <16 x i8>, ptr %self3.i54.i, align 1, !alias.scope !135, !noalias !157
  %self5.i58.i = getelementptr inbounds nuw i8, ptr %self3.i54.i, i64 %storemerge7881.i
  %tmp1.sroa.0.0.copyload.i59.i = load <16 x i8>, ptr %self5.i58.i, align 1, !alias.scope !135, !noalias !157
  %56 = icmp eq <16 x i8> %tmp.sroa.0.0.copyload.i55.i, %20
  %57 = icmp eq <16 x i8> %tmp1.sroa.0.0.copyload.i59.i, %22
  %58 = and <16 x i1> %56, %57
  %59 = bitcast <16 x i1> %58 to i16
  %60 = icmp eq i16 %59, 0
  br i1 %60, label %bb28.i, label %bb26.i

bb28.i:                                           ; preds = %bb26.i, %bb24.i
  %result.sroa.0.4.i = phi i1 [ false, %bb24.i ], [ %_77.i, %bb26.i ]
  %61 = add i64 %i.sroa.0.192.i, 16
  %_69.i = add i64 %61, %_70.i
  %_68.i = icmp uge i64 %_69.i, %haystack.1
  %or.cond14.i = or i1 %_68.i, %result.sroa.0.4.i
  br i1 %or.cond14.i, label %bb30.i, label %bb24.i

bb26.i:                                           ; preds = %bb24.i
; call core::str::pattern::simd_contains::{closure#2}
  %_77.i = call fastcc noundef zeroext i1 @_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %check_mask.i, i64 noundef %i.sroa.0.192.i, i16 noundef %59, i1 noundef zeroext false)
  br label %bb28.i

bb34.i:                                           ; preds = %bb32.i, %bb30.i
  %result.sroa.0.5.off0.i = phi i1 [ %result.sroa.0.3.off0.lcssa.i, %bb30.i ], [ %62, %bb32.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %check_mask.i), !noalias !146
  br label %bb16

bb32.i:                                           ; preds = %bb30.i
; call core::str::pattern::simd_contains::{closure#2}
  %_87.i = call fastcc noundef zeroext i1 @_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %check_mask.i, i64 noundef %i12.i, i16 noundef %54, i1 noundef zeroext %result.sroa.0.3.off0.lcssa.i)
  %62 = or i1 %result.sroa.0.3.off0.lcssa.i, %_87.i
  br label %bb34.i

bb17:                                             ; preds = %bb3
  %63 = tail call i32 @memcmp(ptr nonnull %self.0, ptr nonnull %haystack.0, i64 %self.1)
  %64 = icmp eq i32 %63, 0
  br label %bb16
}

; <core::str::pattern::StrSearcher as core::str::pattern::Searcher>::next_match
; Function Attrs: inlinehint uwtable
define internal fastcc void @_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef nonnull align 8 captures(none) dereferenceable(104) %self) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %_2 = load i64, ptr %self, align 8, !range !16, !noundef !3
  %0 = trunc nuw i64 %_2 to i1
  %searcher = getelementptr inbounds nuw i8, ptr %self, i64 8
  br i1 %0, label %bb2, label %bb3.preheader

bb3.preheader:                                    ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 26
  %2 = load i8, ptr %1, align 2, !range !28, !alias.scope !160, !noalias !163, !noundef !3
  %_4.i = trunc nuw i8 %2 to i1
  br i1 %_4.i, label %bb13, label %bb5.i.lr.ph

bb5.i.lr.ph:                                      ; preds = %bb3.preheader
  %.promoted = load i64, ptr %searcher, align 8
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %4 = getelementptr inbounds nuw i8, ptr %self, i64 72
  %self.0.i = load ptr, ptr %4, align 8, !alias.scope !160, !noalias !163, !nonnull !3, !noundef !3
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 80
  %self.1.i = load i64, ptr %5, align 8, !alias.scope !160, !noalias !163, !noundef !3
  %.promoted29 = load i8, ptr %3, align 8, !alias.scope !160, !noalias !163
  %extract.t = trunc i8 %.promoted29 to i1
  tail call void @llvm.experimental.noalias.scope.decl(metadata !165)
  %6 = icmp eq i64 %.promoted, 0
  br i1 %6, label %bb20.i.peel, label %bb5.i.i.peel

bb5.i.i.peel:                                     ; preds = %bb5.i.lr.ph
  %_8.not.i.i.peel = icmp ult i64 %.promoted, %self.1.i
  br i1 %_8.not.i.i.peel, label %bb9.i.i.peel, label %bb6.i.i.peel

bb6.i.i.peel:                                     ; preds = %bb5.i.i.peel
  %7 = icmp eq i64 %.promoted, %self.1.i
  br i1 %7, label %bb20.i.peel, label %bb19.i

bb9.i.i.peel:                                     ; preds = %bb5.i.i.peel
  %8 = getelementptr inbounds nuw i8, ptr %self.0.i, i64 %.promoted
  %self1.i.i.peel = load i8, ptr %8, align 1, !alias.scope !167, !noalias !170, !noundef !3
  %9 = icmp sgt i8 %self1.i.i.peel, -65
  br i1 %9, label %bb20.i.peel, label %bb19.i

bb20.i.peel:                                      ; preds = %bb9.i.i.peel, %bb6.i.i.peel, %bb5.i.lr.ph
  %data.i.i.peel = getelementptr inbounds nuw i8, ptr %self.0.i, i64 %.promoted
  %_6.i.i.i.peel = icmp samesign eq i64 %.promoted, %self.1.i
  br i1 %_6.i.i.i.peel, label %bb22.i, label %bb15.i.i.peel

bb15.i.i.peel:                                    ; preds = %bb20.i.peel
  %x.i.i.peel = load i8, ptr %data.i.i.peel, align 1, !noalias !171, !noundef !3
  %_7.i.i.peel = icmp sgt i8 %x.i.i.peel, -1
  br i1 %_7.i.i.peel, label %bb3.i.i.peel, label %bb4.i.i.peel

bb4.i.i.peel:                                     ; preds = %bb15.i.i.peel
  %_16.i.i.i.peel = getelementptr inbounds nuw i8, ptr %data.i.i.peel, i64 1
  %_33.i.i.peel = and i8 %x.i.i.peel, 31
  %init.i.i.peel = zext nneg i8 %_33.i.i.peel to i32
  %10 = add nuw nsw i64 %.promoted, 1
  %_6.i10.i.i.peel = icmp samesign ne i64 %10, %self.1.i
  tail call void @llvm.assume(i1 %_6.i10.i.i.peel)
  %y.i.i.peel = load i8, ptr %_16.i.i.i.peel, align 1, !noalias !171, !noundef !3
  %_36.i.i.peel = shl nuw nsw i32 %init.i.i.peel, 6
  %_38.i.i.peel = and i8 %y.i.i.peel, 63
  %_37.i.i.peel = zext nneg i8 %_38.i.i.peel to i32
  %11 = or disjoint i32 %_36.i.i.peel, %_37.i.i.peel
  %_14.i.i.peel = icmp samesign ugt i8 %x.i.i.peel, -33
  br i1 %_14.i.i.peel, label %bb6.i21.i.peel, label %bb23.i.peel

bb6.i21.i.peel:                                   ; preds = %bb4.i.i.peel
  %_16.i12.i.i.peel = getelementptr inbounds nuw i8, ptr %data.i.i.peel, i64 2
  %12 = add nuw nsw i64 %.promoted, 2
  %_6.i17.i.i.peel = icmp samesign ne i64 %12, %self.1.i
  tail call void @llvm.assume(i1 %_6.i17.i.i.peel)
  %z.i.i.peel = load i8, ptr %_16.i12.i.i.peel, align 1, !noalias !171, !noundef !3
  %_41.i.i.peel = shl nuw nsw i32 %_37.i.i.peel, 6
  %_43.i.i.peel = and i8 %z.i.i.peel, 63
  %_42.i.i.peel = zext nneg i8 %_43.i.i.peel to i32
  %y_z.i.i.peel = or disjoint i32 %_41.i.i.peel, %_42.i.i.peel
  %_21.i.i.peel = shl nuw nsw i32 %init.i.i.peel, 12
  %13 = or disjoint i32 %y_z.i.i.peel, %_21.i.i.peel
  %_22.i.i.peel = icmp samesign ugt i8 %x.i.i.peel, -17
  br i1 %_22.i.i.peel, label %bb8.i.i.peel, label %bb23.i.peel

bb8.i.i.peel:                                     ; preds = %bb6.i21.i.peel
  %_16.i19.i.i.peel = getelementptr inbounds nuw i8, ptr %data.i.i.peel, i64 3
  %14 = add nuw nsw i64 %.promoted, 3
  %_6.i24.i.i.peel = icmp samesign ne i64 %14, %self.1.i
  tail call void @llvm.assume(i1 %_6.i24.i.i.peel)
  %w.i.i.peel = load i8, ptr %_16.i19.i.i.peel, align 1, !noalias !171, !noundef !3
  %_27.i.i.peel = shl nuw nsw i32 %init.i.i.peel, 18
  %_26.i.i.peel = and i32 %_27.i.i.peel, 1835008
  %_46.i.i.peel = shl nuw nsw i32 %y_z.i.i.peel, 6
  %_48.i.i.peel = and i8 %w.i.i.peel, 63
  %_47.i.i.peel = zext nneg i8 %_48.i.i.peel to i32
  %_28.i.i.peel = or disjoint i32 %_46.i.i.peel, %_47.i.i.peel
  %15 = or disjoint i32 %_28.i.i.peel, %_26.i.i.peel
  br label %bb23.i.peel

bb3.i.i.peel:                                     ; preds = %bb15.i.i.peel
  %_8.i.i.peel = zext nneg i8 %x.i.i.peel to i32
  br label %bb23.i.peel

bb23.i.peel:                                      ; preds = %bb3.i.i.peel, %bb8.i.i.peel, %bb6.i21.i.peel, %bb4.i.i.peel
  %_0.sroa.4.0.i.ph.i.peel = phi i32 [ %13, %bb6.i21.i.peel ], [ %15, %bb8.i.i.peel ], [ %11, %bb4.i.i.peel ], [ %_8.i.i.peel, %bb3.i.i.peel ]
  %16 = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.peel, 1114112
  tail call void @llvm.assume(i1 %16)
  br i1 %extract.t, label %bb7.loopexit, label %bb40.i.peel

bb40.i.peel:                                      ; preds = %bb23.i.peel
  %_61.i.peel = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.peel, 128
  br i1 %_61.i.peel, label %bb26.i.peel, label %bb27.i.peel

bb27.i.peel:                                      ; preds = %bb40.i.peel
  %_62.i.peel = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.peel, 2048
  br i1 %_62.i.peel, label %bb26.i.peel, label %bb28.i.peel

bb28.i.peel:                                      ; preds = %bb27.i.peel
  %_63.i.peel = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i.peel, 65536
  %..i.peel = select i1 %_63.i.peel, i64 3, i64 4
  br label %bb26.i.peel

bb26.i.peel:                                      ; preds = %bb28.i.peel, %bb27.i.peel, %bb40.i.peel
  %_14.sroa.0.0.i.peel = phi i64 [ 2, %bb27.i.peel ], [ %..i.peel, %bb28.i.peel ], [ 1, %bb40.i.peel ]
  %17 = add i64 %_14.sroa.0.0.i.peel, %.promoted
  store i64 %17, ptr %searcher, align 8, !alias.scope !165, !noalias !163
  %18 = icmp eq i64 %17, 0
  %_8.not.i.i = icmp ult i64 %17, %self.1.i
  %19 = icmp eq i64 %17, %self.1.i
  %20 = getelementptr inbounds nuw i8, ptr %self.0.i, i64 %17
  %data.i.i = getelementptr inbounds nuw i8, ptr %self.0.i, i64 %17
  %_6.i.i.i = icmp samesign eq i64 %17, %self.1.i
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %data.i.i, i64 1
  %21 = add nuw nsw i64 %17, 1
  %_6.i10.i.i = icmp samesign ne i64 %21, %self.1.i
  %_16.i12.i.i = getelementptr inbounds nuw i8, ptr %data.i.i, i64 2
  %22 = add nuw nsw i64 %17, 2
  %_6.i17.i.i = icmp samesign ne i64 %22, %self.1.i
  %_16.i19.i.i = getelementptr inbounds nuw i8, ptr %data.i.i, i64 3
  %23 = add nuw nsw i64 %17, 3
  %_6.i24.i.i = icmp samesign ne i64 %23, %self.1.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !160)
  br i1 %18, label %bb20.i, label %bb5.i.i

bb2:                                              ; preds = %start
  %24 = getelementptr inbounds nuw i8, ptr %self, i64 56
  %_10 = load i64, ptr %24, align 8, !noundef !3
  %25 = icmp eq i64 %_10, -1
  %26 = getelementptr inbounds nuw i8, ptr %self, i64 72
  %self.0 = load ptr, ptr %26, align 8, !nonnull !3, !noundef !3
  %27 = getelementptr inbounds nuw i8, ptr %self, i64 80
  %self.1 = load i64, ptr %27, align 8, !noundef !3
  %28 = getelementptr inbounds nuw i8, ptr %self, i64 88
  %self.01 = load ptr, ptr %28, align 8, !nonnull !3, !noundef !3
  %29 = getelementptr inbounds nuw i8, ptr %self, i64 96
  %self.12 = load i64, ptr %29, align 8, !noundef !3
  br i1 %25, label %bb8, label %bb10

bb5.i.i:                                          ; preds = %bb26.i.peel
  br i1 %_8.not.i.i, label %bb9.i.i, label %bb6.i.i

bb6.i.i:                                          ; preds = %bb5.i.i
  br i1 %19, label %bb20.i, label %bb19.i

bb9.i.i:                                          ; preds = %bb5.i.i
  %self1.i.i = load i8, ptr %20, align 1, !alias.scope !167, !noalias !174, !noundef !3
  %30 = icmp sgt i8 %self1.i.i, -65
  br i1 %30, label %bb20.i, label %bb19.i

bb20.i:                                           ; preds = %bb9.i.i, %bb6.i.i, %bb26.i.peel
  br i1 %_6.i.i.i, label %bb7.critedge, label %bb15.i.i

bb15.i.i:                                         ; preds = %bb20.i
  %x.i.i = load i8, ptr %data.i.i, align 1, !noalias !175, !noundef !3
  %_7.i.i = icmp sgt i8 %x.i.i, -1
  br i1 %_7.i.i, label %bb3.i.i, label %bb4.i.i

bb4.i.i:                                          ; preds = %bb15.i.i
  %_33.i.i = and i8 %x.i.i, 31
  %init.i.i = zext nneg i8 %_33.i.i to i32
  tail call void @llvm.assume(i1 %_6.i10.i.i)
  %y.i.i = load i8, ptr %_16.i.i.i, align 1, !noalias !175, !noundef !3
  %_36.i.i = shl nuw nsw i32 %init.i.i, 6
  %_38.i.i = and i8 %y.i.i, 63
  %_37.i.i = zext nneg i8 %_38.i.i to i32
  %31 = or disjoint i32 %_36.i.i, %_37.i.i
  %_14.i.i = icmp samesign ugt i8 %x.i.i, -33
  br i1 %_14.i.i, label %bb6.i21.i, label %bb23.i

bb3.i.i:                                          ; preds = %bb15.i.i
  %_8.i.i = zext nneg i8 %x.i.i to i32
  br label %bb23.i

bb6.i21.i:                                        ; preds = %bb4.i.i
  tail call void @llvm.assume(i1 %_6.i17.i.i)
  %z.i.i = load i8, ptr %_16.i12.i.i, align 1, !noalias !175, !noundef !3
  %_41.i.i = shl nuw nsw i32 %_37.i.i, 6
  %_43.i.i = and i8 %z.i.i, 63
  %_42.i.i = zext nneg i8 %_43.i.i to i32
  %y_z.i.i = or disjoint i32 %_41.i.i, %_42.i.i
  %_21.i.i = shl nuw nsw i32 %init.i.i, 12
  %32 = or disjoint i32 %y_z.i.i, %_21.i.i
  %_22.i.i = icmp samesign ugt i8 %x.i.i, -17
  br i1 %_22.i.i, label %bb8.i.i, label %bb23.i

bb8.i.i:                                          ; preds = %bb6.i21.i
  tail call void @llvm.assume(i1 %_6.i24.i.i)
  %w.i.i = load i8, ptr %_16.i19.i.i, align 1, !noalias !175, !noundef !3
  %_27.i.i = shl nuw nsw i32 %init.i.i, 18
  %_26.i.i = and i32 %_27.i.i, 1835008
  %_46.i.i = shl nuw nsw i32 %y_z.i.i, 6
  %_48.i.i = and i8 %w.i.i, 63
  %_47.i.i = zext nneg i8 %_48.i.i to i32
  %_28.i.i = or disjoint i32 %_46.i.i, %_47.i.i
  %33 = or disjoint i32 %_28.i.i, %_26.i.i
  br label %bb23.i

bb19.i:                                           ; preds = %bb9.i.i, %bb6.i.i, %bb9.i.i.peel, %bb6.i.i.peel
  %.off0.lcssa = phi i1 [ %extract.t, %bb6.i.i.peel ], [ %extract.t, %bb9.i.i.peel ], [ true, %bb6.i.i ], [ true, %bb9.i.i ]
  %.lcssa = phi i64 [ %.promoted, %bb6.i.i.peel ], [ %.promoted, %bb9.i.i.peel ], [ %17, %bb6.i.i ], [ %17, %bb9.i.i ]
  %34 = xor i1 %.off0.lcssa, true
  %35 = zext i1 %34 to i8
  store i8 %35, ptr %3, align 8, !alias.scope !160, !noalias !163
; call core::str::slice_error_fail
  tail call void @_RNvNtCsgtPOCBgevO_4core3str16slice_error_fail(ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.0.i, i64 noundef %self.1.i, i64 noundef %.lcssa, i64 noundef %self.1.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_de5e2f1dd01253ae804bfe6ba3503da0) #18, !noalias !174
  unreachable

bb23.i:                                           ; preds = %bb8.i.i, %bb6.i21.i, %bb3.i.i, %bb4.i.i
  %_0.sroa.4.0.i.ph.i = phi i32 [ %32, %bb6.i21.i ], [ %33, %bb8.i.i ], [ %31, %bb4.i.i ], [ %_8.i.i, %bb3.i.i ]
  %36 = icmp samesign ult i32 %_0.sroa.4.0.i.ph.i, 1114112
  tail call void @llvm.assume(i1 %36)
  br label %bb7.loopexit

bb22.i:                                           ; preds = %bb20.i.peel
  %37 = xor i1 %extract.t, true
  %38 = zext i1 %37 to i8
  store i8 %38, ptr %3, align 8, !alias.scope !160, !noalias !163
  br i1 %extract.t, label %bb7, label %bb41.i

bb41.i:                                           ; preds = %bb22.i
  store i8 1, ptr %1, align 2, !alias.scope !160, !noalias !163
  br label %bb13

bb7.loopexit:                                     ; preds = %bb23.i, %bb23.i.peel
  %.lcssa62 = phi i64 [ %.promoted, %bb23.i.peel ], [ %17, %bb23.i ]
  store i8 0, ptr %3, align 8, !alias.scope !160, !noalias !163
  br label %bb7

bb7.critedge:                                     ; preds = %bb20.i
  store i8 0, ptr %3, align 8, !alias.scope !160, !noalias !163
  br label %bb7

bb7:                                              ; preds = %bb7.critedge, %bb7.loopexit, %bb22.i
  %39 = phi i64 [ %.lcssa62, %bb7.loopexit ], [ %self.1.i, %bb22.i ], [ %self.1.i, %bb7.critedge ]
  %40 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %39, ptr %40, align 8
  %41 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %39, ptr %41, align 8
  br label %bb13

bb13:                                             ; preds = %bb3.preheader, %bb41.i, %bb7
  %storemerge = phi i64 [ 1, %bb7 ], [ 0, %bb41.i ], [ 0, %bb3.preheader ]
  store i64 %storemerge, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb8, %bb10, %bb13
  ret void

bb8:                                              ; preds = %bb2
; call <core::str::pattern::TwoWaySearcher>::next::<core::str::pattern::MatchOnly>
  tail call fastcc void @_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs6tqTQJNM79Z_8type_dag(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_0, ptr noalias noundef align 8 dereferenceable(64) %searcher, ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.0, i64 noundef %self.1, ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.01, i64 noundef %self.12, i1 noundef zeroext true)
  br label %bb14

bb10:                                             ; preds = %bb2
; call <core::str::pattern::TwoWaySearcher>::next::<core::str::pattern::MatchOnly>
  tail call fastcc void @_RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs6tqTQJNM79Z_8type_dag(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_0, ptr noalias noundef align 8 dereferenceable(64) %searcher, ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.0, i64 noundef %self.1, ptr noalias noundef nonnull readonly captures(address, read_provenance) %self.01, i64 noundef %self.12, i1 noundef zeroext false)
  br label %bb14
}

; <type_dag::type_dag_layout_and_cursor_source_are_observed_on_this_host::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint uwtable
define internal void @_RNvYNCNvCs6tqTQJNM79Z_8type_dag59type_dag_layout_and_cursor_source_are_observed_on_this_host0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %args.i.i.i = alloca [16 x i8], align 8
  %err.i.i.i = alloca [32 x i8], align 8
  %args.i.i = alloca [16 x i8], align 8
  %code.i.i = alloca [4 x i8], align 4
  %_5.i10.i.i = alloca [24 x i8], align 8
  %_5.i.i.i = alloca [24 x i8], align 8
  %_5.i.i.i.i.i = alloca [24 x i8], align 8
  %_8.i.i = alloca [128 x i8], align 8
  %_3.i.i = alloca [128 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !176)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.i.i), !noalias !179
; call <core::str::pattern::StrSearcher>::new
  call void @_RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new(ptr noalias noundef nonnull sret([104 x i8]) align 8 captures(none) dereferenceable(104) %_3.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_a15ed431d12b61b552a8b4f468521cb1, i64 noundef 6203, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_caf81f150f8e2a3f46956011ce18ea9a, i64 noundef 23), !noalias !179
  %_34.sroa.4.0._3.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 104
  %_34.sroa.5.0._3.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 112
  store <2 x i64> <i64 0, i64 6203>, ptr %_34.sroa.4.0._3.sroa_idx.i.i, align 8, !noalias !179
  %_34.sroa.6.0._3.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 120
  store i8 1, ptr %_34.sroa.6.0._3.sroa_idx.i.i, align 8, !noalias !179
  %_34.sroa.7.0._3.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 121
  store i8 0, ptr %_34.sroa.7.0._3.sroa_idx.i.i, align 1, !noalias !179
  tail call void @llvm.experimental.noalias.scope.decl(metadata !182)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !185)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !188)
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i.i.i.i), !noalias !191
; call <core::str::pattern::StrSearcher as core::str::pattern::Searcher>::next_match
  call fastcc void @_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_5.i.i.i.i.i, ptr noalias noundef nonnull align 8 dereferenceable(128) %_3.i.i), !noalias !179
  %_7.i.i.i.i.i = load i64, ptr %_5.i.i.i.i.i, align 8, !range !16, !noalias !191, !noundef !3
  %0 = trunc nuw i64 %_7.i.i.i.i.i to i1
  br i1 %0, label %bb21.i.i, label %bb6.i.i.i.i.i

bb6.i.i.i.i.i:                                    ; preds = %start
  %1 = load i8, ptr %_34.sroa.7.0._3.sroa_idx.i.i, align 1, !range !28, !alias.scope !192, !noalias !179, !noundef !3
  %_2.i.i.i.i.i.i = trunc nuw i8 %1 to i1
  br i1 %_2.i.i.i.i.i.i, label %_RINvYINtNtNtCsgtPOCBgevO_4core3str4iter5SplitReENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldINtNtNtBa_3num7nonzero7NonZerojENCNvXs_NvBK_10advance_byB3_NtB2b_13SpecAdvanceBy15spec_advance_by0INtNtBa_6option6OptionB1y_EECs6tqTQJNM79Z_8type_dag.exit.thread.i.i, label %bb1.i.i.i.i.i.i

bb1.i.i.i.i.i.i:                                  ; preds = %bb6.i.i.i.i.i
  %2 = load i8, ptr %_34.sroa.6.0._3.sroa_idx.i.i, align 8, !range !28, !alias.scope !192, !noalias !179, !noundef !3
  %_3.i.i.i.i.i.i = trunc nuw i8 %2 to i1
  br i1 %_3.i.i.i.i.i.i, label %bb21.thread.i.i, label %bb2.i.i.i.i.i.i

bb2.i.i.i.i.i.i:                                  ; preds = %bb1.i.i.i.i.i.i
  %_6.i.i.i.i.i.i = load i64, ptr %_34.sroa.5.0._3.sroa_idx.i.i, align 8, !alias.scope !192, !noalias !179, !noundef !3
  %_7.i.i.i.i.i.i = load i64, ptr %_34.sroa.4.0._3.sroa_idx.i.i, align 8, !alias.scope !192, !noalias !179, !noundef !3
  %_4.not.i.i.i.i.i.i = icmp eq i64 %_6.i.i.i.i.i.i, %_7.i.i.i.i.i.i
  br i1 %_4.not.i.i.i.i.i.i, label %_RINvYINtNtNtCsgtPOCBgevO_4core3str4iter5SplitReENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldINtNtNtBa_3num7nonzero7NonZerojENCNvXs_NvBK_10advance_byB3_NtB2b_13SpecAdvanceBy15spec_advance_by0INtNtBa_6option6OptionB1y_EECs6tqTQJNM79Z_8type_dag.exit.thread.i.i, label %bb21.thread.i.i

_RINvYINtNtNtCsgtPOCBgevO_4core3str4iter5SplitReENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldINtNtNtBa_3num7nonzero7NonZerojENCNvXs_NvBK_10advance_byB3_NtB2b_13SpecAdvanceBy15spec_advance_by0INtNtBa_6option6OptionB1y_EECs6tqTQJNM79Z_8type_dag.exit.thread.i.i: ; preds = %bb2.i.i.i.i.i.i, %bb6.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i.i.i.i), !noalias !191
  br label %bb2.i.i

bb21.thread.i.i:                                  ; preds = %bb2.i.i.i.i.i.i, %bb1.i.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i.i.i.i), !noalias !191
  br label %bb2.i.i

bb21.i.i:                                         ; preds = %start
  %3 = getelementptr inbounds nuw i8, ptr %_5.i.i.i.i.i, i64 16
  %b.i.i.i.i.i = load i64, ptr %3, align 8, !noalias !191, !noundef !3
  store i64 %b.i.i.i.i.i, ptr %_34.sroa.4.0._3.sroa_idx.i.i, align 8, !alias.scope !195, !noalias !179
  %.pre.i.i = load i8, ptr %_34.sroa.7.0._3.sroa_idx.i.i, align 1, !range !28, !alias.scope !196, !noalias !179
  %extract.t.i.i = trunc nuw i8 %.pre.i.i to i1
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i.i.i.i), !noalias !191
  tail call void @llvm.experimental.noalias.scope.decl(metadata !196)
  br i1 %extract.t.i.i, label %bb2.i.i, label %bb2.i.i.i

bb2.i.i.i:                                        ; preds = %bb21.i.i
  %4 = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 72
  %self.val.i.i.i = load ptr, ptr %4, align 8, !alias.scope !196, !noalias !179, !nonnull !3, !noundef !3
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i.i), !noalias !199
; call <core::str::pattern::StrSearcher as core::str::pattern::Searcher>::next_match
  call fastcc void @_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_5.i.i.i, ptr noalias noundef nonnull align 8 dereferenceable(128) %_3.i.i), !noalias !179
  %_7.i.i.i = load i64, ptr %_5.i.i.i, align 8, !range !16, !noalias !199, !noundef !3
  %5 = trunc nuw i64 %_7.i.i.i to i1
  br i1 %5, label %bb7.i.i.i, label %bb6.i.i.i

bb7.i.i.i:                                        ; preds = %bb2.i.i.i
  %6 = getelementptr inbounds nuw i8, ptr %_5.i.i.i, i64 8
  %a.i.i.i = load i64, ptr %6, align 8, !noalias !199, !noundef !3
  %i.i.i.i = load i64, ptr %_34.sroa.4.0._3.sroa_idx.i.i, align 8, !alias.scope !196, !noalias !179, !noundef !3
  %new_len.i.i.i = sub nuw i64 %a.i.i.i, %i.i.i.i
  %data.i.i.i = getelementptr inbounds nuw i8, ptr %self.val.i.i.i, i64 %i.i.i.i
  br label %bb2.i12.i.i

bb6.i.i.i:                                        ; preds = %bb2.i.i.i
  %7 = load i8, ptr %_34.sroa.7.0._3.sroa_idx.i.i, align 1, !range !28, !alias.scope !200, !noalias !179, !noundef !3
  %_2.i.i.i.i = trunc nuw i8 %7 to i1
  br i1 %_2.i.i.i.i, label %_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag.exit.thread52.i.i, label %bb1.i.i.i.i

bb1.i.i.i.i:                                      ; preds = %bb6.i.i.i
  %8 = load i8, ptr %_34.sroa.6.0._3.sroa_idx.i.i, align 8, !range !28, !alias.scope !200, !noalias !179, !noundef !3
  %_3.i.i.i.i = trunc nuw i8 %8 to i1
  br i1 %_3.i.i.i.i, label %bb1.bb4_crit_edge.i.i.i.i, label %bb2.i.i.i.i

bb1.bb4_crit_edge.i.i.i.i:                        ; preds = %bb1.i.i.i.i
  %i.pre.i.i.i.i = load i64, ptr %_34.sroa.4.0._3.sroa_idx.i.i, align 8, !alias.scope !200, !noalias !179
  %i1.pre.i.i.i.i = load i64, ptr %_34.sroa.5.0._3.sroa_idx.i.i, align 8, !alias.scope !200, !noalias !179
  br label %bb4.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb1.i.i.i.i
  %_6.i.i.i.i = load i64, ptr %_34.sroa.5.0._3.sroa_idx.i.i, align 8, !alias.scope !200, !noalias !179, !noundef !3
  %_7.i.i.i.i = load i64, ptr %_34.sroa.4.0._3.sroa_idx.i.i, align 8, !alias.scope !200, !noalias !179, !noundef !3
  %_4.not.i.i.i.i = icmp eq i64 %_6.i.i.i.i, %_7.i.i.i.i
  br i1 %_4.not.i.i.i.i, label %_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag.exit.thread52.i.i, label %bb4.i.i.i.i

bb4.i.i.i.i:                                      ; preds = %bb2.i.i.i.i, %bb1.bb4_crit_edge.i.i.i.i
  %i1.i.i.i.i = phi i64 [ %i1.pre.i.i.i.i, %bb1.bb4_crit_edge.i.i.i.i ], [ %_6.i.i.i.i, %bb2.i.i.i.i ]
  %i.i.i.i.i = phi i64 [ %i.pre.i.i.i.i, %bb1.bb4_crit_edge.i.i.i.i ], [ %_7.i.i.i.i, %bb2.i.i.i.i ]
  %self.val.i.i.i.i = load ptr, ptr %4, align 8, !alias.scope !200, !noalias !179, !nonnull !3, !noundef !3
  %new_len.i.i.i.i = sub nuw i64 %i1.i.i.i.i, %i.i.i.i.i
  %data.i.i.i.i = getelementptr inbounds nuw i8, ptr %self.val.i.i.i.i, i64 %i.i.i.i.i
  br label %bb2.i12.i.i

_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag.exit.thread52.i.i: ; preds = %bb2.i.i.i.i, %bb6.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i.i), !noalias !199
  br label %bb2.i.i

bb2.i12.i.i:                                      ; preds = %bb4.i.i.i.i, %bb7.i.i.i
  %_0.sroa.4.0.i.i.i = phi i64 [ %new_len.i.i.i, %bb7.i.i.i ], [ %new_len.i.i.i.i, %bb4.i.i.i.i ]
  %_0.sroa.0.0.i9.i.i = phi ptr [ %data.i.i.i, %bb7.i.i.i ], [ %data.i.i.i.i, %bb4.i.i.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i.i), !noalias !199
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i.i), !noalias !179
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i), !noalias !179
; call <core::str::pattern::StrSearcher>::new
  call void @_RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new(ptr noalias noundef nonnull sret([104 x i8]) align 8 captures(none) dereferenceable(104) %_8.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_0.sroa.0.0.i9.i.i, i64 noundef %_0.sroa.4.0.i.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_81d08f51e9b46a96808970faccda49a8, i64 noundef 22), !noalias !179
  %_44.sroa.4.0._8.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 104
  store i64 0, ptr %_44.sroa.4.0._8.sroa_idx.i.i, align 8, !noalias !179
  %_44.sroa.5.0._8.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 112
  store i64 %_0.sroa.4.0.i.i.i, ptr %_44.sroa.5.0._8.sroa_idx.i.i, align 8, !noalias !179
  %_44.sroa.6.0._8.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 120
  store i8 1, ptr %_44.sroa.6.0._8.sroa_idx.i.i, align 8, !noalias !179
  %_44.sroa.7.0._8.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 121
  store i8 0, ptr %_44.sroa.7.0._8.sroa_idx.i.i, align 1, !noalias !179
  tail call void @llvm.experimental.noalias.scope.decl(metadata !203)
  %9 = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 72
  %self.val.i13.i.i = load ptr, ptr %9, align 8, !alias.scope !203, !noalias !179, !nonnull !3, !noundef !3
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i10.i.i), !noalias !206
; call <core::str::pattern::StrSearcher as core::str::pattern::Searcher>::next_match
  call fastcc void @_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_5.i10.i.i, ptr noalias noundef nonnull align 8 dereferenceable(128) %_8.i.i), !noalias !179
  %_7.i14.i.i = load i64, ptr %_5.i10.i.i, align 8, !range !16, !noalias !206, !noundef !3
  %10 = trunc nuw i64 %_7.i14.i.i to i1
  br i1 %10, label %bb7.i39.i.i, label %bb6.i15.i.i

bb7.i39.i.i:                                      ; preds = %bb2.i12.i.i
  %11 = getelementptr inbounds nuw i8, ptr %_5.i10.i.i, i64 8
  %a.i40.i.i = load i64, ptr %11, align 8, !noalias !206, !noundef !3
  %i.i42.i.i = load i64, ptr %_44.sroa.4.0._8.sroa_idx.i.i, align 8, !alias.scope !203, !noalias !179, !noundef !3
  %new_len.i43.i.i = sub nuw i64 %a.i40.i.i, %i.i42.i.i
  %data.i44.i.i = getelementptr inbounds nuw i8, ptr %self.val.i13.i.i, i64 %i.i42.i.i
  br label %bb5.i.i

bb6.i15.i.i:                                      ; preds = %bb2.i12.i.i
  %12 = load i8, ptr %_44.sroa.7.0._8.sroa_idx.i.i, align 1, !range !28, !alias.scope !207, !noalias !179, !noundef !3
  %_2.i.i16.i.i = trunc nuw i8 %12 to i1
  br i1 %_2.i.i16.i.i, label %bb4.i.i, label %bb1.i.i17.i.i

bb1.i.i17.i.i:                                    ; preds = %bb6.i15.i.i
  %13 = load i8, ptr %_44.sroa.6.0._8.sroa_idx.i.i, align 8, !range !28, !alias.scope !207, !noalias !179, !noundef !3
  %_3.i.i18.i.i = trunc nuw i8 %13 to i1
  br i1 %_3.i.i18.i.i, label %bb1.bb4_crit_edge.i.i34.i.i, label %bb2.i.i19.i.i

bb1.bb4_crit_edge.i.i34.i.i:                      ; preds = %bb1.i.i17.i.i
  %i.pre.i.i36.i.i = load i64, ptr %_44.sroa.4.0._8.sroa_idx.i.i, align 8, !alias.scope !207, !noalias !179
  %i1.pre.i.i38.i.i = load i64, ptr %_44.sroa.5.0._8.sroa_idx.i.i, align 8, !alias.scope !207, !noalias !179
  br label %bb4.i.i23.i.i

bb2.i.i19.i.i:                                    ; preds = %bb1.i.i17.i.i
  %_6.i.i20.i.i = load i64, ptr %_44.sroa.5.0._8.sroa_idx.i.i, align 8, !alias.scope !207, !noalias !179, !noundef !3
  %_7.i.i21.i.i = load i64, ptr %_44.sroa.4.0._8.sroa_idx.i.i, align 8, !alias.scope !207, !noalias !179, !noundef !3
  %_4.not.i.i22.i.i = icmp eq i64 %_6.i.i20.i.i, %_7.i.i21.i.i
  br i1 %_4.not.i.i22.i.i, label %bb4.i.i, label %bb4.i.i23.i.i

bb4.i.i23.i.i:                                    ; preds = %bb2.i.i19.i.i, %bb1.bb4_crit_edge.i.i34.i.i
  %i1.i.i24.i.i = phi i64 [ %i1.pre.i.i38.i.i, %bb1.bb4_crit_edge.i.i34.i.i ], [ %_6.i.i20.i.i, %bb2.i.i19.i.i ]
  %i.i.i25.i.i = phi i64 [ %i.pre.i.i36.i.i, %bb1.bb4_crit_edge.i.i34.i.i ], [ %_7.i.i21.i.i, %bb2.i.i19.i.i ]
  %self.val.i.i26.i.i = load ptr, ptr %9, align 8, !alias.scope !207, !noalias !179, !nonnull !3, !noundef !3
  %new_len.i.i27.i.i = sub nuw i64 %i1.i.i24.i.i, %i.i.i25.i.i
  %data.i.i28.i.i = getelementptr inbounds nuw i8, ptr %self.val.i.i26.i.i, i64 %i.i.i25.i.i
  br label %bb5.i.i

bb2.i.i:                                          ; preds = %_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag.exit.thread52.i.i, %bb21.i.i, %bb21.thread.i.i, %_RINvYINtNtNtCsgtPOCBgevO_4core3str4iter5SplitReENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldINtNtNtBa_3num7nonzero7NonZerojENCNvXs_NvBK_10advance_byB3_NtB2b_13SpecAdvanceBy15spec_advance_by0INtNtBa_6option6OptionB1y_EECs6tqTQJNM79Z_8type_dag.exit.thread.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i.i), !noalias !179
  br label %bb3.i.i

bb5.i.i:                                          ; preds = %bb4.i.i23.i.i, %bb7.i39.i.i
  %_0.sroa.4.0.i30.i.i = phi i64 [ %new_len.i43.i.i, %bb7.i39.i.i ], [ %new_len.i.i27.i.i, %bb4.i.i23.i.i ]
  %_0.sroa.0.0.i31.i.i = phi ptr [ %data.i44.i.i, %bb7.i39.i.i ], [ %data.i.i28.i.i, %bb4.i.i23.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i10.i.i), !noalias !206
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i), !noalias !179
; call <&str as core::str::pattern::Pattern>::is_contained_in
  %_12.i.i = tail call fastcc noundef zeroext i1 @_RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_c8234fd665543c28765ba1c6e15e759c, i64 noundef 11, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_0.sroa.0.0.i31.i.i, i64 noundef %_0.sroa.4.0.i30.i.i), !noalias !179
  br i1 %_12.i.i, label %bb6.i.i, label %bb7.i.i, !prof !17

bb4.i.i:                                          ; preds = %bb2.i.i19.i.i, %bb6.i15.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i10.i.i), !noalias !206
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i), !noalias !179
  br label %bb3.i.i

bb7.i.i:                                          ; preds = %bb5.i.i
; call core::panicking::panic
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking5panic(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_cd7c7f7dce8f9b264694ca2526c37516, i64 noundef 46, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6e2e0c0ec38458ba4fdfb65ea05a2eb2) #18, !noalias !179
  unreachable

bb6.i.i:                                          ; preds = %bb5.i.i
; call <&str as core::str::pattern::Pattern>::is_contained_in
  %_20.i.i = tail call fastcc noundef zeroext i1 @_RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_dd4ffb6a82fadbcfa53fa009063078f4, i64 noundef 5, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_0.sroa.0.0.i31.i.i, i64 noundef %_0.sroa.4.0.i30.i.i), !noalias !179
  br i1 %_20.i.i, label %bb11.i.i, label %bb8.i.i, !prof !210

bb8.i.i:                                          ; preds = %bb6.i.i
; call <&str as core::str::pattern::Pattern>::is_contained_in
  %_20.1.i.i = tail call fastcc noundef zeroext i1 @_RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_f4e8947ab4017184eb7a640b452ba22d, i64 noundef 11, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_0.sroa.0.0.i31.i.i, i64 noundef %_0.sroa.4.0.i30.i.i), !noalias !179
  br i1 %_20.1.i.i, label %bb11.i.i, label %bb8.1.i.i, !prof !210

bb8.1.i.i:                                        ; preds = %bb8.i.i
; call <&str as core::str::pattern::Pattern>::is_contained_in
  %_20.2.i.i = tail call fastcc noundef zeroext i1 @_RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_700d8946133bd552962b15338de36ae6, i64 noundef 9, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_0.sroa.0.0.i31.i.i, i64 noundef %_0.sroa.4.0.i30.i.i), !noalias !179
  br i1 %_20.2.i.i, label %bb11.i.i, label %bb8.2.i.i, !prof !210

bb8.2.i.i:                                        ; preds = %bb8.1.i.i
; call <&str as core::str::pattern::Pattern>::is_contained_in
  %_20.3.i.i = tail call fastcc noundef zeroext i1 @_RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_9b7e1a584d08fa8ad7c1a56b7ce8a44f, i64 noundef 6, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_0.sroa.0.0.i31.i.i, i64 noundef %_0.sroa.4.0.i30.i.i), !noalias !179
  br i1 %_20.3.i.i, label %bb11.i.i, label %bb8.3.i.i, !prof !210

bb8.3.i.i:                                        ; preds = %bb8.2.i.i
; call <&str as core::str::pattern::Pattern>::is_contained_in
  %_20.4.i.i = tail call fastcc noundef zeroext i1 @_RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_872ed60f4e9cc5929cf39c60b855d9ea, i64 noundef 6, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_0.sroa.0.0.i31.i.i, i64 noundef %_0.sroa.4.0.i30.i.i), !noalias !179
  br i1 %_20.4.i.i, label %bb11.i.i, label %bb2.i2.i, !prof !210

bb11.i.i:                                         ; preds = %bb8.3.i.i, %bb8.2.i.i, %bb8.1.i.i, %bb8.i.i, %bb6.i.i
; call core::panicking::panic
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking5panic(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_b3a99f180af7a4a365370845f4d61ecc, i64 noundef 43, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_b8d0ec36c0eead905460459f2e09257b) #18, !noalias !179
  unreachable

bb2.i2.i:                                         ; preds = %bb8.3.i.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !211)
  call void @llvm.lifetime.start.p0(ptr nonnull %code.i.i), !noalias !214
  store i64 -1, ptr %_0, align 8, !alias.scope !216, !noalias !217
  br label %_RNCNvCs6tqTQJNM79Z_8type_dag59type_dag_layout_and_cursor_source_are_observed_on_this_host0B3_.exit

bb3.i.i:                                          ; preds = %bb4.i.i, %bb2.i.i
  %_2.sroa.9.0.ph.i = phi i64 [ 15, %bb4.i.i ], [ 21, %bb2.i.i ]
  %_2.sroa.71.0.ph.i = phi ptr [ @alloc_c2dcc5662ba056ecce14533279e4b160, %bb4.i.i ], [ @alloc_54bb4d60df512e09680a75e9c196c327, %bb2.i.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %code.i.i), !noalias !218
  call void @llvm.lifetime.start.p0(ptr nonnull %err.i.i.i), !noalias !221
  store i8 9, ptr %err.i.i.i, align 8, !noalias !216
  %_2.sroa.71.0.err.i.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %err.i.i.i, i64 8
  store ptr %_2.sroa.71.0.ph.i, ptr %_2.sroa.71.0.err.i.i.sroa_idx.i, align 8, !noalias !216
  %_2.sroa.9.0.err.i.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %err.i.i.i, i64 16
  store i64 %_2.sroa.9.0.ph.i, ptr %_2.sroa.9.0.err.i.i.sroa_idx.i, align 8, !noalias !216
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i.i), !noalias !221
  store ptr %err.i.i.i, ptr %args.i.i.i, align 8, !noalias !221
  %_9.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %args.i.i.i, i64 8
  store ptr @_RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt, ptr %_9.sroa.4.0..sroa_idx.i.i.i, align 8, !noalias !221
; call std::io::stdio::attempt_print_to_stderr
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio23attempt_print_to_stderr(ptr noundef nonnull @alloc_26978532d6004174455ea2130c477035, ptr noundef nonnull %args.i.i.i), !noalias !221
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i.i), !noalias !221
  call void @llvm.lifetime.end.p0(ptr nonnull %err.i.i.i), !noalias !221
  store i32 1, ptr %code.i.i, align 4, !noalias !214
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i), !noalias !214
  store ptr %code.i.i, ptr %args.i.i, align 8, !noalias !214
  %_8.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %args.i.i, i64 8
  store ptr @_RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt, ptr %_8.sroa.4.0..sroa_idx.i.i, align 8, !noalias !214
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCslJsSqIQKwiA_5alloc3fmt6format12format_inner(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noundef nonnull @alloc_9e22aeedee7de67b6dbb357f0a3915a8, ptr noundef nonnull %args.i.i), !noalias !217
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i), !noalias !214
  br label %_RNCNvCs6tqTQJNM79Z_8type_dag59type_dag_layout_and_cursor_source_are_observed_on_this_host0B3_.exit

_RNCNvCs6tqTQJNM79Z_8type_dag59type_dag_layout_and_cursor_source_are_observed_on_this_host0B3_.exit: ; preds = %bb2.i2.i, %bb3.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %code.i.i), !noalias !214
  ret void
}

; <type_dag::type_dag_node_mutations_retain_ordinal_operands_and_priority::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint uwtable
define internal void @_RNvYNCNvCs6tqTQJNM79Z_8type_dag60type_dag_node_mutations_retain_ordinal_operands_and_priority0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %args.i.i.i = alloca [16 x i8], align 8
  %err.i.i.i = alloca [32 x i8], align 8
  %args.i.i = alloca [16 x i8], align 8
  %code.i.i = alloca [4 x i8], align 4
  %_34.i.i = alloca [32 x i8], align 8
  %_32.i.i = alloca [32 x i8], align 8
  %_28.i.i = alloca [32 x i8], align 8
  %_26.i.i = alloca [32 x i8], align 8
  %_22.i.i = alloca [32 x i8], align 8
  %_20.i.i = alloca [32 x i8], align 8
  %_16.i.i = alloca [32 x i8], align 8
  %_14.i.i = alloca [32 x i8], align 8
  %_10.i.i = alloca [32 x i8], align 8
  %_8.i.i = alloca [32 x i8], align 8
  %_4.i.i = alloca [32 x i8], align 8
  %_2.i.i = alloca [32 x i8], align 8
  %_2.sroa.11.i = alloca [31 x i8], align 1
  tail call void @llvm.experimental.noalias.scope.decl(metadata !224)
  call void @llvm.lifetime.start.p0(ptr nonnull %_2.sroa.11.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_2.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_4.i.i), !noalias !227
  %0 = getelementptr inbounds nuw i8, ptr %_4.i.i, i64 4
  store i32 0, ptr %0, align 4, !noalias !227
  %1 = getelementptr inbounds nuw i8, ptr %_4.i.i, i64 8
  store i8 0, ptr %1, align 8, !noalias !227
  %_5.sroa.46.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_4.i.i, i64 16
  store <2 x i64> <i64 1, i64 0>, ptr %_5.sroa.46.0..sroa_idx.i.i, align 8, !noalias !227
  store i8 4, ptr %_4.i.i, align 8, !noalias !227
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_2.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_d0ef803f235cc9da4d2f68db2ae7eecd, i64 noundef 4, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_4.i.i), !noalias !227
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.i.i), !noalias !227
  %2 = load i8, ptr %_2.i.i, align 8, !range !230, !noalias !227, !noundef !3
  %.not.i.i = icmp eq i8 %2, -1
  br i1 %.not.i.i, label %bb10.i.i, label %bb9.i.i

bb9.i.i:                                          ; preds = %start
  %_2.sroa.11.0._2.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_2.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._2.i.sroa_idx.i, i64 31, i1 false), !noalias !224
  call void @llvm.lifetime.end.p0(ptr nonnull %_2.i.i), !noalias !227
  br label %bb3.i.i

bb10.i.i:                                         ; preds = %start
  call void @llvm.lifetime.end.p0(ptr nonnull %_2.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_10.i.i), !noalias !227
  %3 = getelementptr inbounds nuw i8, ptr %_10.i.i, i64 4
  store i32 0, ptr %3, align 4, !noalias !227
  %4 = getelementptr inbounds nuw i8, ptr %_10.i.i, i64 8
  store i8 0, ptr %4, align 8, !noalias !227
  %_11.sroa.47.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_10.i.i, i64 16
  store <2 x i64> <i64 2, i64 1>, ptr %_11.sroa.47.0..sroa_idx.i.i, align 8, !noalias !227
  store i8 4, ptr %_10.i.i, align 8, !noalias !227
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_8.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_84e44d17547bb16feba7510e5887a46e, i64 noundef 5, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_10.i.i), !noalias !227
  call void @llvm.lifetime.end.p0(ptr nonnull %_10.i.i), !noalias !227
  %5 = load i8, ptr %_8.i.i, align 8, !range !230, !noalias !227, !noundef !3
  %.not9.i.i = icmp eq i8 %5, -1
  br i1 %.not9.i.i, label %bb12.i.i, label %bb11.i.i

bb11.i.i:                                         ; preds = %bb10.i.i
  %_2.sroa.11.0._8.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._8.i.sroa_idx.i, i64 31, i1 false), !noalias !224
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i), !noalias !227
  br label %bb3.i.i

bb12.i.i:                                         ; preds = %bb10.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_14.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_16.i.i), !noalias !227
  %6 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 4
  store i32 0, ptr %6, align 4, !noalias !227
  %7 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 8
  store i8 1, ptr %7, align 8, !noalias !227
  %_17.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 9
  store i8 7, ptr %_17.sroa.4.0..sroa_idx.i.i, align 1, !noalias !227
  store i8 4, ptr %_16.i.i, align 8, !noalias !227
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_14.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_dfa58342adb1b61c9b339d03997d4468, i64 noundef 6, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_16.i.i), !noalias !227
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i.i), !noalias !227
  %8 = load i8, ptr %_14.i.i, align 8, !range !230, !noalias !227, !noundef !3
  %.not10.i.i = icmp eq i8 %8, -1
  br i1 %.not10.i.i, label %bb14.i.i, label %bb13.i.i

bb13.i.i:                                         ; preds = %bb12.i.i
  %_2.sroa.11.0._14.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_14.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._14.i.sroa_idx.i, i64 31, i1 false), !noalias !224
  call void @llvm.lifetime.end.p0(ptr nonnull %_14.i.i), !noalias !227
  br label %bb3.i.i

bb14.i.i:                                         ; preds = %bb12.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_14.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_20.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_22.i.i), !noalias !227
  %9 = getelementptr inbounds nuw i8, ptr %_22.i.i, i64 4
  store i32 0, ptr %9, align 4, !noalias !227
  %10 = getelementptr inbounds nuw i8, ptr %_22.i.i, i64 8
  store i8 2, ptr %10, align 8, !noalias !227
  %_23.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_22.i.i, i64 9
  store i8 7, ptr %_23.sroa.4.0..sroa_idx.i.i, align 1, !noalias !227
  store i8 4, ptr %_22.i.i, align 8, !noalias !227
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_20.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_2deb6346c8c31952b5e510cfc673852c, i64 noundef 6, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_22.i.i), !noalias !227
  call void @llvm.lifetime.end.p0(ptr nonnull %_22.i.i), !noalias !227
  %11 = load i8, ptr %_20.i.i, align 8, !range !230, !noalias !227, !noundef !3
  %.not11.i.i = icmp eq i8 %11, -1
  br i1 %.not11.i.i, label %bb16.i.i, label %bb15.i.i

bb15.i.i:                                         ; preds = %bb14.i.i
  %_2.sroa.11.0._20.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_20.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._20.i.sroa_idx.i, i64 31, i1 false), !noalias !224
  call void @llvm.lifetime.end.p0(ptr nonnull %_20.i.i), !noalias !227
  br label %bb3.i.i

bb16.i.i:                                         ; preds = %bb14.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_20.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_26.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_28.i.i), !noalias !227
  %12 = getelementptr inbounds nuw i8, ptr %_28.i.i, i64 4
  store i32 0, ptr %12, align 4, !noalias !227
  %13 = getelementptr inbounds nuw i8, ptr %_28.i.i, i64 8
  store i8 3, ptr %13, align 8, !noalias !227
  %_29.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_28.i.i, i64 9
  store i8 1, ptr %_29.sroa.4.0..sroa_idx.i.i, align 1, !noalias !227
  %_29.sroa.58.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_28.i.i, i64 12
  store i32 1, ptr %_29.sroa.58.0..sroa_idx.i.i, align 4, !noalias !227
  store i8 4, ptr %_28.i.i, align 8, !noalias !227
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_26.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_ac5a6c5e09adc7e44b9ec58eff44f5a6, i64 noundef 6, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_28.i.i), !noalias !227
  call void @llvm.lifetime.end.p0(ptr nonnull %_28.i.i), !noalias !227
  %14 = load i8, ptr %_26.i.i, align 8, !range !230, !noalias !227, !noundef !3
  %.not12.i.i = icmp eq i8 %14, -1
  br i1 %.not12.i.i, label %bb18.i.i, label %bb17.i.i

bb17.i.i:                                         ; preds = %bb16.i.i
  %_2.sroa.11.0._26.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_26.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._26.i.sroa_idx.i, i64 31, i1 false), !noalias !224
  call void @llvm.lifetime.end.p0(ptr nonnull %_26.i.i), !noalias !227
  br label %bb3.i.i

bb18.i.i:                                         ; preds = %bb16.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_26.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_32.i.i), !noalias !227
  call void @llvm.lifetime.start.p0(ptr nonnull %_34.i.i), !noalias !227
  %15 = getelementptr inbounds nuw i8, ptr %_34.i.i, i64 8
  store <2 x i64> <i64 2, i64 3>, ptr %15, align 8, !noalias !227
  store i8 5, ptr %_34.i.i, align 8, !noalias !227
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_32.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_c1242df8626b9cf6c60c92fd6d618193, i64 noundef 7, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_34.i.i), !noalias !227
  call void @llvm.lifetime.end.p0(ptr nonnull %_34.i.i), !noalias !227
  %16 = load i8, ptr %_32.i.i, align 8, !range !230, !noalias !227, !noundef !3
  %.not13.i.i = icmp eq i8 %16, -1
  br i1 %.not13.i.i, label %bb2.i.i, label %bb19.i.i

bb19.i.i:                                         ; preds = %bb18.i.i
  %_2.sroa.11.0._32.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_32.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._32.i.sroa_idx.i, i64 31, i1 false), !noalias !224
  call void @llvm.lifetime.end.p0(ptr nonnull %_32.i.i), !noalias !227
  br label %bb3.i.i

bb2.i.i:                                          ; preds = %bb18.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_32.i.i), !noalias !227
  call void @llvm.experimental.noalias.scope.decl(metadata !231)
  call void @llvm.lifetime.start.p0(ptr nonnull %code.i.i), !noalias !234
  store i64 -1, ptr %_0, align 8, !alias.scope !236, !noalias !237
  br label %_RNCNvCs6tqTQJNM79Z_8type_dag60type_dag_node_mutations_retain_ordinal_operands_and_priority0B3_.exit

bb3.i.i:                                          ; preds = %bb19.i.i, %bb17.i.i, %bb15.i.i, %bb13.i.i, %bb11.i.i, %bb9.i.i
  %_2.sroa.0.0.ph.i = phi i8 [ %2, %bb9.i.i ], [ %5, %bb11.i.i ], [ %8, %bb13.i.i ], [ %11, %bb15.i.i ], [ %14, %bb17.i.i ], [ %16, %bb19.i.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %code.i.i), !noalias !238
  call void @llvm.lifetime.start.p0(ptr nonnull %err.i.i.i), !noalias !241
  store i8 %_2.sroa.0.0.ph.i, ptr %err.i.i.i, align 8, !noalias !236
  %_2.sroa.11.0.err.i.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %err.i.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0.err.i.i.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, i64 31, i1 false), !noalias !236
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i.i), !noalias !241
  store ptr %err.i.i.i, ptr %args.i.i.i, align 8, !noalias !241
  %_9.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %args.i.i.i, i64 8
  store ptr @_RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt, ptr %_9.sroa.4.0..sroa_idx.i.i.i, align 8, !noalias !241
; call std::io::stdio::attempt_print_to_stderr
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio23attempt_print_to_stderr(ptr noundef nonnull @alloc_26978532d6004174455ea2130c477035, ptr noundef nonnull %args.i.i.i), !noalias !241
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i.i), !noalias !241
  call void @llvm.lifetime.end.p0(ptr nonnull %err.i.i.i), !noalias !241
  store i32 1, ptr %code.i.i, align 4, !noalias !234
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i), !noalias !234
  store ptr %code.i.i, ptr %args.i.i, align 8, !noalias !234
  %_8.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %args.i.i, i64 8
  store ptr @_RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt, ptr %_8.sroa.4.0..sroa_idx.i.i, align 8, !noalias !234
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCslJsSqIQKwiA_5alloc3fmt6format12format_inner(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noundef nonnull @alloc_9e22aeedee7de67b6dbb357f0a3915a8, ptr noundef nonnull %args.i.i), !noalias !237
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i), !noalias !234
  br label %_RNCNvCs6tqTQJNM79Z_8type_dag60type_dag_node_mutations_retain_ordinal_operands_and_priority0B3_.exit

_RNCNvCs6tqTQJNM79Z_8type_dag60type_dag_node_mutations_retain_ordinal_operands_and_priority0B3_.exit: ; preds = %bb2.i.i, %bb3.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %code.i.i), !noalias !234
  call void @llvm.lifetime.end.p0(ptr nonnull %_2.sroa.11.i)
  ret void
}

; <type_dag::type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint uwtable
define internal void @_RNvYNCNvCs6tqTQJNM79Z_8type_dag64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %args.i.i.i = alloca [16 x i8], align 8
  %err.i.i.i = alloca [32 x i8], align 8
  %args.i.i = alloca [16 x i8], align 8
  %code.i.i = alloca [4 x i8], align 4
  %_33.i.i = alloca [32 x i8], align 8
  %_31.i.i = alloca [32 x i8], align 8
  %_28.i.i = alloca [32 x i8], align 8
  %_26.i.i = alloca [32 x i8], align 8
  %_23.i.i = alloca [32 x i8], align 8
  %_21.i.i = alloca [32 x i8], align 8
  %_18.i.i = alloca [32 x i8], align 8
  %_16.i.i = alloca [32 x i8], align 8
  %_13.i.i = alloca [32 x i8], align 8
  %_11.i.i = alloca [32 x i8], align 8
  %_8.i.i = alloca [32 x i8], align 8
  %_5.i.i = alloca [32 x i8], align 8
  %header.i.i = alloca [4 x i8], align 4
  %_2.sroa.11.i = alloca [31 x i8], align 1
  tail call void @llvm.experimental.noalias.scope.decl(metadata !244)
  call void @llvm.lifetime.start.p0(ptr nonnull %_2.sroa.11.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %header.i.i), !noalias !247
  store <4 x i8> <i8 -62, i8 1, i8 0, i8 0>, ptr %header.i.i, align 4, !noalias !247
  %0 = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i), !noalias !247
  store i64 0, ptr %0, align 8, !noalias !247
  store i8 0, ptr %_8.i.i, align 8, !noalias !247
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_5.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %header.i.i, i64 noundef 0, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_8.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i), !noalias !247
  %1 = load i8, ptr %_5.i.i, align 8, !noalias !244
  %.not11.i.i = icmp eq i8 %1, -1
  br i1 %.not11.i.i, label %bb18.i.i, label %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.i

bb19.i.i:                                         ; preds = %bb18.3.i.i
  %_2.sroa.11.0._11.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_11.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._11.i.sroa_idx.i, i64 31, i1 false), !noalias !244
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i), !noalias !247
  br label %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.thread.i

bb20.i.i:                                         ; preds = %bb18.3.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_16.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_18.i.i), !noalias !247
  %2 = getelementptr inbounds nuw i8, ptr %_18.i.i, i64 1
  store i8 1, ptr %2, align 1, !noalias !247
  %3 = getelementptr inbounds nuw i8, ptr %_18.i.i, i64 2
  store i8 0, ptr %3, align 2, !noalias !247
  store i8 1, ptr %_18.i.i, align 8, !noalias !247
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_16.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_29797342d601d1e047d79ddaf9206dc7, i64 noundef 4, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_18.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.i.i), !noalias !247
  %4 = load i8, ptr %_16.i.i, align 8, !range !230, !noalias !247, !noundef !3
  %.not7.i.i = icmp eq i8 %4, -1
  br i1 %.not7.i.i, label %bb22.i.i, label %bb21.i.i

bb21.i.i:                                         ; preds = %bb20.i.i
  %_2.sroa.11.0._16.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._16.i.sroa_idx.i, i64 31, i1 false), !noalias !244
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i.i), !noalias !247
  br label %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.thread.i

bb22.i.i:                                         ; preds = %bb20.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_21.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_23.i.i), !noalias !247
  %5 = getelementptr inbounds nuw i8, ptr %_23.i.i, i64 1
  store i8 2, ptr %5, align 1, !noalias !247
  %6 = getelementptr inbounds nuw i8, ptr %_23.i.i, i64 2
  store i8 3, ptr %6, align 2, !noalias !247
  store i8 1, ptr %_23.i.i, align 8, !noalias !247
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_21.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_060289bc9efbbf6030aff056af069676, i64 noundef 4, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_23.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %_23.i.i), !noalias !247
  %7 = load i8, ptr %_21.i.i, align 8, !range !230, !noalias !247, !noundef !3
  %.not8.i.i = icmp eq i8 %7, -1
  br i1 %.not8.i.i, label %bb24.i.i, label %bb23.i.i

bb23.i.i:                                         ; preds = %bb22.i.i
  %_2.sroa.11.0._21.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_21.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._21.i.sroa_idx.i, i64 31, i1 false), !noalias !244
  call void @llvm.lifetime.end.p0(ptr nonnull %_21.i.i), !noalias !247
  br label %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.thread.i

bb24.i.i:                                         ; preds = %bb22.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_21.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_26.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_28.i.i), !noalias !247
  %8 = getelementptr inbounds nuw i8, ptr %_28.i.i, i64 8
  store <2 x i64> <i64 6, i64 5>, ptr %8, align 8, !noalias !247
  store i8 2, ptr %_28.i.i, align 8, !noalias !247
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_26.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_7884c94991f6216c5ebb8eda5460e4b8, i64 noundef 5, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_28.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %_28.i.i), !noalias !247
  %9 = load i8, ptr %_26.i.i, align 8, !range !230, !noalias !247, !noundef !3
  %.not9.i.i = icmp eq i8 %9, -1
  br i1 %.not9.i.i, label %bb26.i.i, label %bb25.i.i

bb25.i.i:                                         ; preds = %bb24.i.i
  %_2.sroa.11.0._26.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_26.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._26.i.sroa_idx.i, i64 31, i1 false), !noalias !244
  call void @llvm.lifetime.end.p0(ptr nonnull %_26.i.i), !noalias !247
  br label %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.thread.i

bb26.i.i:                                         ; preds = %bb24.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_26.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_31.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_33.i.i), !noalias !247
  %10 = getelementptr inbounds nuw i8, ptr %_33.i.i, i64 8
  store <2 x i64> <i64 1, i64 0>, ptr %10, align 8, !noalias !247
  store i8 3, ptr %_33.i.i, align 8, !noalias !247
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_31.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_40eaf789987e2da79c4d5f3f8e4e709a, i64 noundef 6, i64 noundef 0, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_33.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %_33.i.i), !noalias !247
  %11 = load i8, ptr %_31.i.i, align 8, !range !230, !noalias !247, !noundef !3
  %.not10.i.i = icmp eq i8 %11, -1
  br i1 %.not10.i.i, label %bb2.i.i, label %bb27.i.i

bb27.i.i:                                         ; preds = %bb26.i.i
  %_2.sroa.11.0._31.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_31.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._31.i.sroa_idx.i, i64 31, i1 false), !noalias !244
  call void @llvm.lifetime.end.p0(ptr nonnull %_31.i.i), !noalias !247
  br label %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.thread.i

bb18.i.i:                                         ; preds = %start
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i), !noalias !247
  store i64 1, ptr %0, align 8, !noalias !247
  store i8 0, ptr %_8.i.i, align 8, !noalias !247
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_5.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %header.i.i, i64 noundef 1, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_8.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i), !noalias !247
  %12 = load i8, ptr %_5.i.i, align 8, !noalias !244
  %.not11.1.i.i = icmp eq i8 %12, -1
  br i1 %.not11.1.i.i, label %bb18.1.i.i, label %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.i

bb18.1.i.i:                                       ; preds = %bb18.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i), !noalias !247
  store i64 2, ptr %0, align 8, !noalias !247
  store i8 0, ptr %_8.i.i, align 8, !noalias !247
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_5.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %header.i.i, i64 noundef 2, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_8.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i), !noalias !247
  %13 = load i8, ptr %_5.i.i, align 8, !noalias !244
  %.not11.2.i.i = icmp eq i8 %13, -1
  br i1 %.not11.2.i.i, label %bb18.2.i.i, label %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.i

bb18.2.i.i:                                       ; preds = %bb18.1.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i), !noalias !247
  store i64 3, ptr %0, align 8, !noalias !247
  store i8 0, ptr %_8.i.i, align 8, !noalias !247
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_5.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %header.i.i, i64 noundef 3, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_8.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i), !noalias !247
  %14 = load i8, ptr %_5.i.i, align 8, !noalias !244
  %.not11.3.i.i = icmp eq i8 %14, -1
  br i1 %.not11.3.i.i, label %bb18.3.i.i, label %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.i

bb18.3.i.i:                                       ; preds = %bb18.2.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_11.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %_13.i.i), !noalias !247
  %15 = getelementptr inbounds nuw i8, ptr %_13.i.i, i64 1
  store i8 0, ptr %15, align 1, !noalias !247
  %16 = getelementptr inbounds nuw i8, ptr %_13.i.i, i64 2
  store i8 0, ptr %16, align 2, !noalias !247
  store i8 1, ptr %_13.i.i, align 8, !noalias !247
; call type_dag::assert_reject
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag13assert_reject(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_11.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_f6f7b3569446eafb281a38f3be526f22, i64 noundef 4, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address) dereferenceable(32) %_13.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %_13.i.i), !noalias !247
  %17 = load i8, ptr %_11.i.i, align 8, !range !230, !noalias !247, !noundef !3
  %.not.i.i = icmp eq i8 %17, -1
  br i1 %.not.i.i, label %bb20.i.i, label %bb19.i.i

_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.thread.i: ; preds = %bb27.i.i, %bb25.i.i, %bb23.i.i, %bb21.i.i, %bb19.i.i
  %_2.sroa.0.0.ph.i = phi i8 [ %17, %bb19.i.i ], [ %4, %bb21.i.i ], [ %7, %bb23.i.i ], [ %9, %bb25.i.i ], [ %11, %bb27.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %header.i.i), !noalias !247
  br label %bb3.i.i

_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.i: ; preds = %bb18.2.i.i, %bb18.1.i.i, %bb18.i.i, %start
  %_2.sroa.0.0.copyload.i = phi i8 [ %1, %start ], [ %12, %bb18.i.i ], [ %13, %bb18.1.i.i ], [ %14, %bb18.2.i.i ]
  %_2.sroa.11.0._5.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_5.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0._5.i.sroa_idx.i, i64 31, i1 false), !noalias !244
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %header.i.i), !noalias !247
  call void @llvm.experimental.noalias.scope.decl(metadata !250)
  br label %bb3.i.i

bb2.i.i:                                          ; preds = %bb26.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_31.i.i), !noalias !247
  call void @llvm.lifetime.end.p0(ptr nonnull %header.i.i), !noalias !247
  call void @llvm.lifetime.start.p0(ptr nonnull %code.i.i), !noalias !253
  store i64 -1, ptr %_0, align 8, !alias.scope !256, !noalias !257
  br label %_RNCNvCs6tqTQJNM79Z_8type_dag64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic0B3_.exit

bb3.i.i:                                          ; preds = %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.i, %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.thread.i
  %_2.sroa.0.09.i = phi i8 [ %_2.sroa.0.0.ph.i, %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.thread.i ], [ %_2.sroa.0.0.copyload.i, %_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic.exit.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %code.i.i), !noalias !244
  call void @llvm.lifetime.start.p0(ptr nonnull %err.i.i.i), !noalias !259
  store i8 %_2.sroa.0.09.i, ptr %err.i.i.i, align 8, !noalias !256
  %_2.sroa.11.0.err.i.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %err.i.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.0.err.i.i.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.11.i, i64 31, i1 false), !noalias !256
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i.i), !noalias !259
  store ptr %err.i.i.i, ptr %args.i.i.i, align 8, !noalias !259
  %_9.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %args.i.i.i, i64 8
  store ptr @_RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt, ptr %_9.sroa.4.0..sroa_idx.i.i.i, align 8, !noalias !259
; call std::io::stdio::attempt_print_to_stderr
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio23attempt_print_to_stderr(ptr noundef nonnull @alloc_26978532d6004174455ea2130c477035, ptr noundef nonnull %args.i.i.i), !noalias !259
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i.i), !noalias !259
  call void @llvm.lifetime.end.p0(ptr nonnull %err.i.i.i), !noalias !259
  store i32 1, ptr %code.i.i, align 4, !noalias !262
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i), !noalias !262
  store ptr %code.i.i, ptr %args.i.i, align 8, !noalias !262
  %_8.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %args.i.i, i64 8
  store ptr @_RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt, ptr %_8.sroa.4.0..sroa_idx.i.i, align 8, !noalias !262
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCslJsSqIQKwiA_5alloc3fmt6format12format_inner(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noundef nonnull @alloc_9e22aeedee7de67b6dbb357f0a3915a8, ptr noundef nonnull %args.i.i), !noalias !257
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i), !noalias !262
  br label %_RNCNvCs6tqTQJNM79Z_8type_dag64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic0B3_.exit

_RNCNvCs6tqTQJNM79Z_8type_dag64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic0B3_.exit: ; preds = %bb2.i.i, %bb3.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %code.i.i), !noalias !262
  call void @llvm.lifetime.end.p0(ptr nonnull %_2.sroa.11.i)
  ret void
}

; <type_dag::type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint uwtable
define internal void @_RNvYNCNvCs6tqTQJNM79Z_8type_dag66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %args.i.i.i = alloca [16 x i8], align 8
  %err.i.i.i = alloca [32 x i8], align 8
  %args.i.i = alloca [16 x i8], align 8
  %code.i.i = alloca [4 x i8], align 4
  %_96.i.i = alloca [32 x i8], align 8
  %_92.i.i = alloca [32 x i8], align 8
  %consumer_scratch.i.i = alloca [16 x i8], align 4
  %_82.i.i = alloca [8 x i8], align 8
  %_64.i.i = alloca [8 x i8], align 8
  %wanted.i.i = alloca [8 x i8], align 8
  %_58.i.i = alloca [8 x i8], align 8
  %_56.i.i = alloca [8 x i8], align 8
  %_48.i.i = alloca [8 x i8], align 8
  %_44.i.i = alloca [16 x i8], align 8
  %_36.i.i = alloca [40 x i8], align 8
  %input_start.i.i = alloca [8 x i8], align 8
  %scratch.i.i = alloca [16 x i8], align 4
  %_23.i.i = alloca [16 x i8], align 4
  %_17.i.i = alloca [8 x i8], align 4
  %_3.i.i = alloca [160 x i8], align 8
  %_2.sroa.7.i = alloca [31 x i8], align 1
  tail call void @llvm.experimental.noalias.scope.decl(metadata !263)
  call void @llvm.lifetime.start.p0(ptr nonnull %_2.sroa.7.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.i.i), !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_17.i.i), !noalias !266
  store i8 1, ptr %_17.i.i, align 4, !noalias !266
  %_18.sroa.37.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_17.i.i, i64 4
  store i32 0, ptr %_18.sroa.37.0..sroa_idx.i.i, align 4, !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_23.i.i), !noalias !266
  store i8 1, ptr %_23.i.i, align 4, !noalias !266
  %_24.sroa.410.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_23.i.i, i64 4
  store i32 1, ptr %_24.sroa.410.0..sroa_idx.i.i, align 4, !noalias !266
  %0 = getelementptr inbounds nuw i8, ptr %_23.i.i, i64 8
  store i8 1, ptr %0, align 4, !noalias !266
  %_18.sroa.37.0..sroa_idx8.i.i = getelementptr inbounds nuw i8, ptr %_23.i.i, i64 12
  store i32 0, ptr %_18.sroa.37.0..sroa_idx8.i.i, align 4, !noalias !266
  store ptr @alloc_c1b96e55b45c7736d2483852531d6cfa, ptr %_3.i.i, align 8, !noalias !266
  %_4.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 8
  store i64 4, ptr %_4.sroa.4.0..sroa_idx.i.i, align 8, !noalias !266
  %_4.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 16
  store ptr inttoptr (i64 4 to ptr), ptr %_4.sroa.5.0..sroa_idx.i.i, align 8, !noalias !266
  %_4.sroa.6.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 24
  store i64 0, ptr %_4.sroa.6.0..sroa_idx.i.i, align 8, !noalias !266
  %1 = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 32
  store ptr @alloc_40eaf789987e2da79c4d5f3f8e4e709a, ptr %1, align 8, !noalias !266
  %_7.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 40
  store i64 6, ptr %_7.sroa.4.0..sroa_idx.i.i, align 8, !noalias !266
  %_7.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 48
  store ptr @alloc_a4fec9de8264c27b2449b411fe17eeb0, ptr %_7.sroa.5.0..sroa_idx.i.i, align 8, !noalias !266
  %_7.sroa.6.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 56
  store i64 1, ptr %_7.sroa.6.0..sroa_idx.i.i, align 8, !noalias !266
  %2 = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 64
  store ptr @alloc_68d4241588b373d3827583e8b7e560bc, ptr %2, align 8, !noalias !266
  %_10.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 72
  store i64 6, ptr %_10.sroa.4.0..sroa_idx.i.i, align 8, !noalias !266
  %_10.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 80
  store ptr @alloc_cbf4874b1b147cfd09d259bc70f502f8, ptr %_10.sroa.5.0..sroa_idx.i.i, align 8, !noalias !266
  %_10.sroa.6.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 88
  store i64 1, ptr %_10.sroa.6.0..sroa_idx.i.i, align 8, !noalias !266
  %3 = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 96
  store ptr @alloc_fa61d42cbf53437402fcbcb23f6b9f14, ptr %3, align 8, !noalias !266
  %_13.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 104
  store i64 6, ptr %_13.sroa.4.0..sroa_idx.i.i, align 8, !noalias !266
  %_13.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 112
  store ptr %_17.i.i, ptr %_13.sroa.5.0..sroa_idx.i.i, align 8, !noalias !266
  %_13.sroa.6.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 120
  store i64 1, ptr %_13.sroa.6.0..sroa_idx.i.i, align 8, !noalias !266
  %4 = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 128
  store ptr @alloc_8e580bd0a57c3d4e874ce5e1d1608074, ptr %4, align 8, !noalias !266
  %_19.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 136
  store i64 8, ptr %_19.sroa.4.0..sroa_idx.i.i, align 8, !noalias !266
  %_19.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 144
  store ptr %_23.i.i, ptr %_19.sroa.5.0..sroa_idx.i.i, align 8, !noalias !266
  %_19.sroa.6.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 152
  store i64 2, ptr %_19.sroa.6.0..sroa_idx.i.i, align 8, !noalias !266
  %scratch_start.i.i = ptrtoint ptr %scratch.i.i to i64
  %5 = getelementptr inbounds nuw i8, ptr %_36.i.i, i64 8
  %6 = getelementptr inbounds nuw i8, ptr %_36.i.i, i64 16
  %7 = getelementptr inbounds nuw i8, ptr %_36.i.i, i64 24
  %8 = getelementptr inbounds nuw i8, ptr %_36.i.i, i64 32
  %9 = getelementptr inbounds nuw i8, ptr %_44.i.i, i64 8
  br label %bb27.i.i

bb27.i.i:                                         ; preds = %bb17.i.i, %start
  %iter.sroa.0.0.idx55.i.i = phi i64 [ 0, %start ], [ %iter.sroa.0.0.add.i.i, %bb17.i.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %scratch.i.i), !noalias !266
  call void @llvm.experimental.memset.pattern.p0.i64.i64(ptr nonnull align 4 %scratch.i.i, i64 256, i64 2, i1 false), !noalias !266
  %iter.sroa.0.0.ptr56.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i64 %iter.sroa.0.0.idx55.i.i
  %iter.sroa.0.0.add.i.i = add nuw nsw i64 %iter.sroa.0.0.idx55.i.i, 32
  call void @llvm.lifetime.start.p0(ptr nonnull %input_start.i.i), !noalias !266
  %_106.0.i.i = load ptr, ptr %iter.sroa.0.0.ptr56.i.i, align 8, !noalias !266, !nonnull !3, !noundef !3
  %10 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0.ptr56.i.i, i64 8
  %_106.1.i.i = load i64, ptr %10, align 8, !noalias !266, !noundef !3
  %11 = ptrtoint ptr %_106.0.i.i to i64
  store i64 %11, ptr %input_start.i.i, align 8, !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_36.i.i), !noalias !266
  %12 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0.ptr56.i.i, i64 16
  %_107.0.i.i = load ptr, ptr %12, align 8, !noalias !266, !nonnull !3, !align !43, !noundef !3
  %13 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0.ptr56.i.i, i64 24
  %_107.1.i.i = load i64, ptr %13, align 8, !noalias !266, !noundef !3
  %_131.i.i = icmp ult i64 %_107.1.i.i, 3
  br i1 %_131.i.i, label %bb28.i.i, label %bb29.i.i, !prof !269

bb26.i.i:                                         ; preds = %bb17.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %consumer_scratch.i.i), !noalias !266
  call void @llvm.experimental.memset.pattern.p0.i64.i64(ptr nonnull align 4 %consumer_scratch.i.i, i64 256, i64 2, i1 false), !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_92.i.i), !noalias !266
; call type_dag::recursive_consumer
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag18recursive_consumer(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_92.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_40eaf789987e2da79c4d5f3f8e4e709a, i64 noundef 6, ptr noalias noundef nonnull align 4 %consumer_scratch.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_96.i.i), !noalias !266
; call type_dag::recursive_consumer
  call fastcc void @_RNvCs6tqTQJNM79Z_8type_dag18recursive_consumer(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_96.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_8e580bd0a57c3d4e874ce5e1d1608074, i64 noundef 8, ptr noalias noundef nonnull align 4 %consumer_scratch.i.i)
  call void @llvm.experimental.noalias.scope.decl(metadata !270)
  call void @llvm.experimental.noalias.scope.decl(metadata !273)
  %14 = load i8, ptr %_92.i.i, align 8, !range !63, !alias.scope !270, !noalias !275, !noundef !3
  %15 = icmp ne i8 %14, -1
  %16 = load i8, ptr %_96.i.i, align 8, !range !63, !alias.scope !273, !noalias !276, !noundef !3
  %17 = icmp eq i8 %16, -1
  %not..i.i.i = xor i1 %17, true
  %_5.i.i.i = xor i1 %15, %17
  br i1 %_5.i.i.i, label %bb1.i.i.i, label %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.thread.i

bb29.i.i:                                         ; preds = %bb27.i.i
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef 0, i64 noundef %_107.1.i.i, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f11587fcc5df25a2c968fb538524ab02) #18, !noalias !266
  unreachable

bb28.i.i:                                         ; preds = %bb27.i.i
; call <nudox_ir_format::type_dag::TypeDagView>::validate
  call void @_RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate(ptr noalias noundef nonnull sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_36.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_106.0.i.i, i64 noundef %_106.1.i.i, ptr noalias noundef nonnull align 4 %scratch.i.i, i64 noundef %_107.1.i.i), !noalias !266
  %_40.i.i = load i64, ptr %_36.i.i, align 8, !range !16, !noalias !266, !noundef !3
  %18 = trunc nuw i64 %_40.i.i to i1
  br i1 %18, label %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.i, label %bb5.i.i

bb5.i.i:                                          ; preds = %bb28.i.i
  %view.0.i.i = load ptr, ptr %5, align 8, !noalias !266, !nonnull !3, !noundef !3
  %view.1.i.i = load i64, ptr %6, align 8, !noalias !266, !noundef !3
  %19 = load ptr, ptr %7, align 8, !noalias !266, !nonnull !3, !align !43, !noundef !3
  %20 = load i64, ptr %8, align 8, !noalias !266, !noundef !3
  call void @llvm.lifetime.end.p0(ptr nonnull %_36.i.i), !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_44.i.i), !noalias !266
  store ptr %view.0.i.i, ptr %_44.i.i, align 8, !noalias !266
  store i64 %view.1.i.i, ptr %9, align 8, !noalias !266
  %_138.i.i = icmp eq i64 %view.1.i.i, %_106.1.i.i
  br i1 %_138.i.i, label %bb32.i.i, label %bb6.i.i, !prof !17

bb32.i.i:                                         ; preds = %bb5.i.i
  %21 = call i32 @memcmp(ptr nonnull %view.0.i.i, ptr nonnull %_106.0.i.i, i64 %_106.1.i.i), !noalias !266
  %_45.i.i = icmp eq i32 %21, 0
  br i1 %_45.i.i, label %bb55.i.i, label %bb6.i.i, !prof !17

bb6.i.i:                                          ; preds = %bb32.i.i, %bb5.i.i
; call core::panicking::assert_failed::<&[u8], &[u8]>
  call fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedRShBL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(16) %_44.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(16) %iter.sroa.0.0.ptr56.i.i) #18
  unreachable

bb55.i.i:                                         ; preds = %bb32.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_44.i.i), !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_48.i.i), !noalias !266
  %22 = ptrtoint ptr %view.0.i.i to i64
  store i64 %22, ptr %_48.i.i, align 8, !noalias !266
  %_51.i.i = icmp eq ptr %view.0.i.i, %_106.0.i.i
  br i1 %_51.i.i, label %bb56.i.i, label %bb7.i.i, !prof !17

bb7.i.i:                                          ; preds = %bb55.i.i
; call core::panicking::assert_failed::<usize, usize>
  call void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_(i8 noundef 0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_48.i.i, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %input_start.i.i, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_800cf2779c59941b383445baad70eeb8) #18, !noalias !266
  unreachable

bb56.i.i:                                         ; preds = %bb55.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_48.i.i), !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_56.i.i), !noalias !266
  store i64 %20, ptr %_56.i.i, align 8, !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_58.i.i), !noalias !266
  store i64 %_107.1.i.i, ptr %_58.i.i, align 8, !noalias !266
  %_59.i.i = icmp eq i64 %20, %_107.1.i.i
  br i1 %_59.i.i, label %bb8.i.i, label %bb9.i.i, !prof !17

bb9.i.i:                                          ; preds = %bb56.i.i
; call core::panicking::assert_failed::<usize, usize>
  call void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_(i8 noundef 0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_56.i.i, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_58.i.i, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_98a68c254d2f16f24a30ac2be7568bfa) #18, !noalias !266
  unreachable

bb8.i.i:                                          ; preds = %bb56.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_58.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_56.i.i), !noalias !266
  %_15851.i.i = icmp eq i64 %_107.1.i.i, 0
  br i1 %_15851.i.i, label %bb35.thread.i.i, label %bb36.lr.ph.i.i

bb35.thread.i.i:                                  ; preds = %bb8.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_82.i.i), !noalias !266
  br label %bb17.i.i

bb36.lr.ph.i.i:                                   ; preds = %bb8.i.i
  %_151.idx.i.i = shl nuw nsw i64 %_107.1.i.i, 3
  %_74.i.i = add i64 %_151.idx.i.i, %scratch_start.i.i
  %_70.not.i.i = icmp ult ptr %19, %scratch.i.i
  br i1 %_70.not.i.i, label %bb37.i.us.i, label %bb36.i.i, !prof !210

bb37.i.us.i:                                      ; preds = %bb36.lr.ph.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %wanted.i.i), !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_64.i.i), !noalias !266
; call core::panicking::panic
  call void @_RNvNtCsgtPOCBgevO_4core9panicking5panic(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_41adb055745d596a22069a43cc6b96f0, i64 noundef 47, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_787cc3db1ede27825734bc2f561a73e1) #18, !noalias !266
  unreachable

bb36.i.i:                                         ; preds = %bb36.lr.ph.i.i
  %_164.i.i = getelementptr inbounds nuw i8, ptr %_107.0.i.i, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %wanted.i.i), !noalias !266
  store ptr %_107.0.i.i, ptr %wanted.i.i, align 8, !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_64.i.i), !noalias !266
  %_170.0.i.i = getelementptr inbounds nuw i8, ptr %19, i64 8
  %_170.1.i.i = add nsw i64 %_107.1.i.i, -1
  store ptr %19, ptr %_64.i.i, align 8, !noalias !266
  %node_address.i.i = ptrtoint ptr %19 to i64
  %_73.i.i = add i64 %node_address.i.i, 8
  %_72.not.i.i = icmp ugt i64 %_73.i.i, %_74.i.i
  br i1 %_72.not.i.i, label %bb14.i.i, label %bb13.i.i, !prof !210

bb35.i.i:                                         ; preds = %bb15.i.i.1, %bb15.i.i
  %_170.1.i.i.lcssa91 = phi i64 [ %_170.1.i.i, %bb15.i.i ], [ %_170.1.i.i.1, %bb15.i.i.1 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_82.i.i), !noalias !266
  store i64 %_170.1.i.i.lcssa91, ptr %_82.i.i, align 8, !noalias !266
  %23 = icmp eq i64 %_170.1.i.i.lcssa91, 0
  br i1 %23, label %bb17.i.i, label %bb18.i.i, !prof !277

_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.thread4.i: ; preds = %bb36.i.i.1
  call void @llvm.lifetime.end.p0(ptr nonnull %_64.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %wanted.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %input_start.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %scratch.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_23.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_17.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i.i), !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %code.i.i), !noalias !278
  br label %bb3.i.i

bb14.i.i:                                         ; preds = %bb37.i.i.1, %bb36.i.i
; call core::panicking::panic
  call void @_RNvNtCsgtPOCBgevO_4core9panicking5panic(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_ef0d0704052a8e970d69179d3ab3ec5d, i64 noundef 96, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_bed34f8f916518f97094735f53f0071b) #18, !noalias !266
  unreachable

bb13.i.i:                                         ; preds = %bb36.i.i
  %24 = load i8, ptr %19, align 4, !range !28, !noalias !266, !noundef !3
  %25 = load i8, ptr %_107.0.i.i, align 4, !range !28, !noalias !266, !noundef !3
  %26 = trunc nuw i8 %25 to i1
  %_178.i.i = icmp eq i8 %24, %25
  br i1 %_178.i.i, label %bb40.i.i, label %bb16.i.i, !prof !17

bb40.i.i:                                         ; preds = %bb13.i.i
  %27 = trunc nuw i8 %24 to i1
  br i1 %27, label %bb43.i.i, label %bb44.i.i

bb16.i.i:                                         ; preds = %bb43.i.i.1, %bb44.i.i.1, %bb13.i.i.1, %bb44.i.i, %bb43.i.i, %bb13.i.i
; call core::panicking::assert_failed::<&nudox_ir_format::type_dag::TypeNode, &nudox_ir_format::type_dag::TypeNode>
  call fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeBL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %_64.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %wanted.i.i) #18
  unreachable

bb43.i.i:                                         ; preds = %bb40.i.i
  call void @llvm.assume(i1 %26)
  %28 = getelementptr inbounds nuw i8, ptr %19, i64 4
  %_179.i.i = load i32, ptr %28, align 4, !noalias !266, !noundef !3
  %29 = getelementptr inbounds nuw i8, ptr %_107.0.i.i, i64 4
  %_180.i.i = load i32, ptr %29, align 4, !noalias !266, !noundef !3
  %30 = icmp eq i32 %_179.i.i, %_180.i.i
  br i1 %30, label %bb15.i.i, label %bb16.i.i, !prof !17

bb44.i.i:                                         ; preds = %bb40.i.i
  %31 = getelementptr inbounds nuw i8, ptr %19, i64 1
  %32 = load i8, ptr %31, align 1, !range !28, !noalias !266, !noundef !3
  %33 = getelementptr inbounds nuw i8, ptr %_107.0.i.i, i64 1
  %34 = load i8, ptr %33, align 1, !range !28, !noalias !266, !noundef !3
  %35 = icmp eq i8 %32, %34
  br i1 %35, label %bb15.i.i, label %bb16.i.i, !prof !17

bb15.i.i:                                         ; preds = %bb44.i.i, %bb43.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_64.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %wanted.i.i), !noalias !266
  %_158.i.i = icmp eq i64 %_107.1.i.i, 1
  br i1 %_158.i.i, label %bb35.i.i, label %bb36.i.i.1

bb36.i.i.1:                                       ; preds = %bb15.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %wanted.i.i), !noalias !266
  store ptr %_164.i.i, ptr %wanted.i.i, align 8, !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %_64.i.i), !noalias !266
  %_168.not.i.i.1 = icmp eq i64 %_170.1.i.i, 0
  br i1 %_168.not.i.i.1, label %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.thread4.i, label %bb37.i.i.1

bb37.i.i.1:                                       ; preds = %bb36.i.i.1
  %_170.1.i.i.1 = add nsw i64 %_107.1.i.i, -2
  store ptr %_170.0.i.i, ptr %_64.i.i, align 8, !noalias !266
  %node_address.i.i.1 = ptrtoint ptr %_170.0.i.i to i64
  %_73.i.i.1 = add i64 %node_address.i.i.1, 8
  %_72.not.i.i.1 = icmp ugt i64 %_73.i.i.1, %_74.i.i
  br i1 %_72.not.i.i.1, label %bb14.i.i, label %bb13.i.i.1, !prof !210

bb13.i.i.1:                                       ; preds = %bb37.i.i.1
  %36 = load i8, ptr %_170.0.i.i, align 4, !range !28, !noalias !266, !noundef !3
  %37 = load i8, ptr %_164.i.i, align 4, !range !28, !noalias !266, !noundef !3
  %38 = trunc nuw i8 %37 to i1
  %_178.i.i.1 = icmp eq i8 %36, %37
  br i1 %_178.i.i.1, label %bb40.i.i.1, label %bb16.i.i, !prof !17

bb40.i.i.1:                                       ; preds = %bb13.i.i.1
  %39 = trunc nuw i8 %36 to i1
  br i1 %39, label %bb43.i.i.1, label %bb44.i.i.1

bb44.i.i.1:                                       ; preds = %bb40.i.i.1
  %40 = getelementptr inbounds nuw i8, ptr %19, i64 9
  %41 = load i8, ptr %40, align 1, !range !28, !noalias !266, !noundef !3
  %42 = getelementptr inbounds nuw i8, ptr %_107.0.i.i, i64 9
  %43 = load i8, ptr %42, align 1, !range !28, !noalias !266, !noundef !3
  %44 = icmp eq i8 %41, %43
  br i1 %44, label %bb15.i.i.1, label %bb16.i.i, !prof !17

bb43.i.i.1:                                       ; preds = %bb40.i.i.1
  call void @llvm.assume(i1 %38)
  %45 = getelementptr inbounds nuw i8, ptr %19, i64 12
  %_179.i.i.1 = load i32, ptr %45, align 4, !noalias !266, !noundef !3
  %46 = getelementptr inbounds nuw i8, ptr %_107.0.i.i, i64 12
  %_180.i.i.1 = load i32, ptr %46, align 4, !noalias !266, !noundef !3
  %47 = icmp eq i32 %_179.i.i.1, %_180.i.i.1
  br i1 %47, label %bb15.i.i.1, label %bb16.i.i, !prof !17

bb15.i.i.1:                                       ; preds = %bb43.i.i.1, %bb44.i.i.1
  call void @llvm.lifetime.end.p0(ptr nonnull %_64.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %wanted.i.i), !noalias !266
  br label %bb35.i.i

bb17.i.i:                                         ; preds = %bb35.i.i, %bb35.thread.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_82.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %input_start.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %scratch.i.i), !noalias !266
  %_120.i.i = icmp eq i64 %iter.sroa.0.0.add.i.i, 160
  br i1 %_120.i.i, label %bb26.i.i, label %bb27.i.i

bb18.i.i:                                         ; preds = %bb35.i.i
; call core::panicking::assert_failed::<usize, usize>
  call void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_(i8 noundef 0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_82.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) @alloc_53973d2fe29b4adba8bb7390b5678745, ptr noundef null, ptr undef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8a3150ea8ce92a0b4c407d9443666eec) #18, !noalias !266
  unreachable

bb1.i.i.i:                                        ; preds = %bb26.i.i
  br i1 %15, label %bb4.i.i.i, label %_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3cmp9PartialEq2eqCs6tqTQJNM79Z_8type_dag.exit.i.i

bb4.i.i.i:                                        ; preds = %bb1.i.i.i
  call void @llvm.assume(i1 %not..i.i.i)
; call <nudox_ir_format::type_dag::TypeDagError as core::cmp::PartialEq>::eq
  %48 = call fastcc noundef zeroext i1 @_RNvXsF_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(32) %_92.i.i, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(32) %_96.i.i), !noalias !266
  br i1 %48, label %bb22.i.i, label %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.thread.i, !prof !282

_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3cmp9PartialEq2eqCs6tqTQJNM79Z_8type_dag.exit.i.i: ; preds = %bb1.i.i.i
  call void @llvm.assume(i1 %17)
  %__self_0.i.i.i = getelementptr inbounds nuw i8, ptr %_92.i.i, i64 4
  %__arg1_0.i.i.i = getelementptr inbounds nuw i8, ptr %_96.i.i, i64 4
  %__self_0.val.i.i.i = load i32, ptr %__self_0.i.i.i, align 4, !alias.scope !270, !noalias !275, !noundef !3
  %__arg1_0.val.i.i.i = load i32, ptr %__arg1_0.i.i.i, align 4, !alias.scope !273, !noalias !276, !noundef !3
  %_0.i.i.i.i = icmp eq i32 %__self_0.val.i.i.i, %__arg1_0.val.i.i.i
  br i1 %_0.i.i.i.i, label %bb22.i.i, label %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.thread.i, !prof !282

_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.thread.i: ; preds = %_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3cmp9PartialEq2eqCs6tqTQJNM79Z_8type_dag.exit.i.i, %bb4.i.i.i, %bb26.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_96.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_92.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %consumer_scratch.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_23.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_17.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i.i), !noalias !266
  call void @llvm.lifetime.start.p0(ptr nonnull %code.i.i), !noalias !283
  br label %bb2.i.i

bb22.i.i:                                         ; preds = %_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3cmp9PartialEq2eqCs6tqTQJNM79Z_8type_dag.exit.i.i, %bb4.i.i.i
; call core::panicking::assert_failed::<core::result::Result<u32, nudox_ir_format::type_dag::TypeDagError>, core::result::Result<u32, nudox_ir_format::type_dag::TypeDagError>>
  call fastcc void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedINtNtB4_6result6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorEBL_ECs6tqTQJNM79Z_8type_dag(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %_92.i.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) %_96.i.i) #18
  unreachable

_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.i: ; preds = %bb28.i.i
  %_2.sroa.0.0.copyload.i = load i8, ptr %5, align 8, !noalias !263
  %_2.sroa.7.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_36.i.i, i64 9
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.7.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.7.0..sroa_idx.i, i64 31, i1 false), !noalias !263
  call void @llvm.lifetime.end.p0(ptr nonnull %_36.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %input_start.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %scratch.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_23.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_17.i.i), !noalias !266
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i.i), !noalias !266
  call void @llvm.experimental.noalias.scope.decl(metadata !286)
  call void @llvm.lifetime.start.p0(ptr nonnull %code.i.i), !noalias !288
  %.not.i.i.i = icmp eq i8 %_2.sroa.0.0.copyload.i, -1
  br i1 %.not.i.i.i, label %bb2.i.i, label %bb3.i.i

bb2.i.i:                                          ; preds = %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.i, %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.thread.i
  store i64 -1, ptr %_0, align 8, !alias.scope !290, !noalias !291
  br label %_RNCNvCs6tqTQJNM79Z_8type_dag66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused0B3_.exit

bb3.i.i:                                          ; preds = %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.i, %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.thread4.i
  %_2.sroa.0.07.i = phi i8 [ 8, %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.thread4.i ], [ %_2.sroa.0.0.copyload.i, %_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused.exit.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %err.i.i.i), !noalias !292
  store i8 %_2.sroa.0.07.i, ptr %err.i.i.i, align 8, !noalias !290
  %_2.sroa.7.0.err.i.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %err.i.i.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.7.0.err.i.i.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(31) %_2.sroa.7.i, i64 31, i1 false), !noalias !290
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i.i), !noalias !292
  store ptr %err.i.i.i, ptr %args.i.i.i, align 8, !noalias !292
  %_9.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %args.i.i.i, i64 8
  store ptr @_RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt, ptr %_9.sroa.4.0..sroa_idx.i.i.i, align 8, !noalias !292
; call std::io::stdio::attempt_print_to_stderr
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio23attempt_print_to_stderr(ptr noundef nonnull @alloc_26978532d6004174455ea2130c477035, ptr noundef nonnull %args.i.i.i), !noalias !292
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i.i), !noalias !292
  call void @llvm.lifetime.end.p0(ptr nonnull %err.i.i.i), !noalias !292
  store i32 1, ptr %code.i.i, align 4, !noalias !288
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i), !noalias !288
  store ptr %code.i.i, ptr %args.i.i, align 8, !noalias !288
  %_8.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %args.i.i, i64 8
  store ptr @_RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt, ptr %_8.sroa.4.0..sroa_idx.i.i, align 8, !noalias !288
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCslJsSqIQKwiA_5alloc3fmt6format12format_inner(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noundef nonnull @alloc_9e22aeedee7de67b6dbb357f0a3915a8, ptr noundef nonnull %args.i.i), !noalias !291
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i), !noalias !288
  br label %_RNCNvCs6tqTQJNM79Z_8type_dag66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused0B3_.exit

_RNCNvCs6tqTQJNM79Z_8type_dag66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused0B3_.exit: ; preds = %bb2.i.i, %bb3.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %code.i.i), !noalias !288
  call void @llvm.lifetime.end.p0(ptr nonnull %_2.sroa.7.i)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #7

; <i32 as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(4), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #6

; Function Attrs: nounwind uwtable
declare noundef range(i32 0, 10) i32 @rust_eh_personality(i32 noundef, i32 noundef, i64 noundef, ptr noundef, ptr noundef) unnamed_addr #9

; <core::fmt::builders::DebugList>::entry
; Function Attrs: uwtable
declare noundef nonnull align 8 ptr @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry(ptr noalias noundef align 8 dereferenceable(16), ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #2

; std::rt::lang_start_internal
; Function Attrs: uwtable
declare noundef i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48), i64 noundef, ptr noundef, i8 noundef) unnamed_addr #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshl.i32(i32, i32, i32) #10

; core::panicking::assert_failed_inner
; Function Attrs: cold minsize noinline noreturn optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner(i8 noundef range(i8 0, 3), ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noundef, ptr, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #2

; alloc::fmt::format::format_inner
; Function Attrs: uwtable
declare void @_RNvNvNtCslJsSqIQKwiA_5alloc3fmt6format12format_inner(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24), ptr noundef nonnull, ptr noundef nonnull) unnamed_addr #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.cttz.i16(i16, i1 immarg) #11

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: read)
declare i32 @memcmp(ptr captures(none), ptr captures(none), i64) local_unnamed_addr #12

; <nudox_ir_format::type_dag::TypeDagView>::validate
; Function Attrs: uwtable
declare void @_RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate(ptr dead_on_unwind noalias noundef writable sret([40 x i8]) align 8 captures(none) dereferenceable(40), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808), ptr noalias noundef nonnull align 4, i64 noundef range(i64 0, 1152921504606846976)) unnamed_addr #1

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef, i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #13

; test::test_main_static
; Function Attrs: uwtable
declare void @_RNvCs3O4ZRUMviTO_4test16test_main_static(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance), i64 noundef range(i64 0, 1152921504606846976)) unnamed_addr #1

; <core::str::pattern::StrSearcher>::new
; Function Attrs: uwtable
declare void @_RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new(ptr dead_on_unwind noalias noundef writable sret([104 x i8]) align 8 captures(none) dereferenceable(104), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef) unnamed_addr #1

; core::panicking::panic
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking5panic(ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #13

; core::panicking::assert_failed::<usize, usize>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
declare void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_(i8 noundef range(i8 0, 3), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noundef, ptr, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.usub.sat.i64(i64, i64) #10

; core::slice::memchr::memchr_aligned
; Function Attrs: uwtable
declare { i64, i64 } @_RNvNtNtCsgtPOCBgevO_4core5slice6memchr14memchr_aligned(i8 noundef, ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808)) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: uwtable
declare void @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter11debug_tuple(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(address) dereferenceable(24), ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: uwtable
declare noundef nonnull align 8 ptr @_RNvMs2_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_10DebugTuple5field(ptr noalias noundef align 8 dereferenceable(24), ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMs2_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; std::io::stdio::attempt_print_to_stderr
; Function Attrs: uwtable
declare void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio23attempt_print_to_stderr(ptr noundef nonnull, ptr noundef nonnull) unnamed_addr #1

; <str as core::fmt::Debug>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXsh_NtCsgtPOCBgevO_4core3fmteNtB5_5Debug3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <str as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXsi_NtCsgtPOCBgevO_4core3fmteNtB5_7Display3fmt(ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field2_finish
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXNtNtNtCsgtPOCBgevO_4core3fmt3num3imphNtB6_7Display3fmt(ptr noalias noundef readonly captures(address, read_provenance) dereferenceable(1), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXsg_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8UpperHex3fmt(ptr noalias noundef readonly captures(address, read_provenance) dereferenceable(1), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXse_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8LowerHex3fmt(ptr noalias noundef readonly captures(address, read_provenance) dereferenceable(1), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <u32 as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXs8_NtNtNtCsgtPOCBgevO_4core3fmt3num3impmNtB9_7Display3fmt(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(4), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <u32 as core::fmt::UpperHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXsw_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8UpperHex3fmt(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(4), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <u32 as core::fmt::LowerHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXsu_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(4), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <usize as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <usize as core::fmt::UpperHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <usize as core::fmt::LowerHex>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: uwtable
declare void @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter10debug_list(ptr dead_on_unwind noalias noundef writable sret([16 x i8]) align 8 captures(address) dereferenceable(16), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <core::fmt::builders::DebugList>::finish
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList6finish(ptr noalias noundef align 8 dereferenceable(16)) unnamed_addr #1

; core::fmt::write
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvNtCsgtPOCBgevO_4core3fmt5write(ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48), ptr noundef nonnull, ptr noundef nonnull) unnamed_addr #1

; core::str::slice_error_fail
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtCsgtPOCBgevO_4core3str16slice_error_fail(ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #13

define noundef i32 @main(i32 %0, ptr %1) unnamed_addr #14 {
top:
  %_7.i = alloca [8 x i8], align 8
  %2 = sext i32 %0 to i64
  call void @llvm.lifetime.start.p0(ptr nonnull %_7.i)
  store ptr @_RNvCs6tqTQJNM79Z_8type_dag4main, ptr %_7.i, align 8
; call std::rt::lang_start_internal
  %_0.i = call noundef i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr noundef nonnull %_7.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48) @vtable.2, i64 noundef %2, ptr noundef %1, i8 noundef 0)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i)
  %3 = trunc i64 %_0.i to i32
  ret i32 %3
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #15

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.experimental.memset.pattern.p0.i64.i64(ptr writeonly captures(none), i64, i64, i1 immarg) #16

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #17

attributes #0 = { inlinehint uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #1 = { uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #2 = { cold minsize noinline noreturn optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #3 = { noinline uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #4 = { cold inlinehint nofree norecurse nosync nounwind memory(read, inaccessiblemem: readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #5 = { inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read, inaccessiblemem: readwrite) uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #8 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #9 = { nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #10 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: read) }
attributes #13 = { cold noinline noreturn uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #14 = { "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #16 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #17 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #18 = { noreturn }
attributes #19 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{!"rustc version 1.97.1 (8bab26f4f 2026-07-14)"}
!3 = !{}
!4 = !{!5}
!5 = distinct !{!5, !6, !"_RNvXsy_NtNtCsgtPOCBgevO_4core3str7patternNtB5_9MatchOnlyNtB5_14TwoWayStrategy8matching: %_0"}
!6 = distinct !{!6, !"_RNvXsy_NtNtCsgtPOCBgevO_4core3str7patternNtB5_9MatchOnlyNtB5_14TwoWayStrategy8matching"}
!7 = !{i64 16917601304975957}
!8 = !{!9}
!9 = distinct !{!9, !10, !"_RNvNtNtCsgtPOCBgevO_4core3str7pattern14small_slice_eq: %x.0"}
!10 = distinct !{!10, !"_RNvNtNtCsgtPOCBgevO_4core3str7pattern14small_slice_eq"}
!11 = !{!12}
!12 = distinct !{!12, !10, !"_RNvNtNtCsgtPOCBgevO_4core3str7pattern14small_slice_eq: %y.0"}
!13 = !{!14}
!14 = distinct !{!14, !15, !"_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs6tqTQJNM79Z_8type_dag: %_1"}
!15 = distinct !{!15, !"_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs6tqTQJNM79Z_8type_dag"}
!16 = !{i64 0, i64 2}
!17 = !{!"branch_weights", !"expected", i32 2000, i32 1}
!18 = !{!19}
!19 = distinct !{!19, !20, !"_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag: %self"}
!20 = distinct !{!20, !"_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag"}
!21 = !{!22}
!22 = distinct !{!22, !20, !"_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag: %other"}
!23 = !{!24}
!24 = distinct !{!24, !25, !"_RNvXsk_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %self"}
!25 = distinct !{!25, !"_RNvXsk_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq"}
!26 = !{!27}
!27 = distinct !{!27, !25, !"_RNvXsk_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %other"}
!28 = !{i8 0, i8 2}
!29 = !{!24, !19}
!30 = !{!27, !22}
!31 = !{!"branch_weights", i32 2146410443, i32 1073205}
!32 = !{!33}
!33 = distinct !{!33, !20, !"_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag: %self:It1"}
!34 = !{!35}
!35 = distinct !{!35, !20, !"_RNvYNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2neCs6tqTQJNM79Z_8type_dag: %other:It1"}
!36 = !{!37}
!37 = distinct !{!37, !25, !"_RNvXsk_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %self:It1"}
!38 = !{!39}
!39 = distinct !{!39, !25, !"_RNvXsk_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %other:It1"}
!40 = !{!37, !33}
!41 = !{!39, !35}
!42 = !{i8 0, i8 10}
!43 = !{i64 4}
!44 = !{!45, !47, !48, !50}
!45 = distinct !{!45, !46, !"_RNvXsr_NtCsgtPOCBgevO_4core3fmtSNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB5_5Debug3fmtCs6tqTQJNM79Z_8type_dag: %self.0"}
!46 = distinct !{!46, !"_RNvXsr_NtCsgtPOCBgevO_4core3fmtSNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB5_5Debug3fmtCs6tqTQJNM79Z_8type_dag"}
!47 = distinct !{!47, !46, !"_RNvXsr_NtCsgtPOCBgevO_4core3fmtSNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB5_5Debug3fmtCs6tqTQJNM79Z_8type_dag: %f"}
!48 = distinct !{!48, !49, !"_RNvXsa_NtCsgtPOCBgevO_4core5arrayANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_NtNtB7_3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag: %self"}
!49 = distinct !{!49, !"_RNvXsa_NtCsgtPOCBgevO_4core5arrayANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_NtNtB7_3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag"}
!50 = distinct !{!50, !49, !"_RNvXsa_NtCsgtPOCBgevO_4core5arrayANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_NtNtB7_3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag: %f"}
!51 = !{!45, !48}
!52 = !{!53, !45, !47, !48, !50}
!53 = distinct !{!53, !54, !"_RINvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB6_9DebugList7entriesRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeINtNtNtBa_5slice4iter4IterB13_EECs6tqTQJNM79Z_8type_dag: %self"}
!54 = distinct !{!54, !"_RINvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB6_9DebugList7entriesRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeINtNtNtBa_5slice4iter4IterB13_EECs6tqTQJNM79Z_8type_dag"}
!55 = !{!56, !58}
!56 = distinct !{!56, !57, !"_RNvXsf_Csjj9WfcXSjwO_14nudox_ir_vocabINtB5_7DenseIdNtB5_4TypeENtNtCsgtPOCBgevO_4core3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag: %self"}
!57 = distinct !{!57, !"_RNvXsf_Csjj9WfcXSjwO_14nudox_ir_vocabINtB5_7DenseIdNtB5_4TypeENtNtCsgtPOCBgevO_4core3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag"}
!58 = distinct !{!58, !57, !"_RNvXsf_Csjj9WfcXSjwO_14nudox_ir_vocabINtB5_7DenseIdNtB5_4TypeENtNtCsgtPOCBgevO_4core3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag: %f"}
!59 = !{i64 8}
!60 = !{!61}
!61 = distinct !{!61, !62, !"_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag: %self"}
!62 = distinct !{!62, !"_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag"}
!63 = !{i8 -1, i8 6}
!64 = !{!65}
!65 = distinct !{!65, !62, !"_RNvXst_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag: %f"}
!66 = !{!61, !65}
!67 = !{!68}
!68 = distinct !{!68, !69, !"_RNvXsv_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %self"}
!69 = distinct !{!69, !"_RNvXsv_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt"}
!70 = !{i8 0, i8 4}
!71 = !{!72}
!72 = distinct !{!72, !69, !"_RNvXsv_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %f"}
!73 = !{!68, !72}
!74 = !{!75}
!75 = distinct !{!75, !76, !"_RNvXso_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_18TypeDagHeaderErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %self"}
!76 = distinct !{!76, !"_RNvXso_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_18TypeDagHeaderErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt"}
!77 = !{i8 0, i8 3}
!78 = !{!79}
!79 = distinct !{!79, !76, !"_RNvXso_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_18TypeDagHeaderErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %f"}
!80 = !{!75, !79}
!81 = !{!82}
!82 = distinct !{!82, !83, !"_RNvXsh_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %self"}
!83 = distinct !{!83, !"_RNvXsh_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt"}
!84 = !{!85}
!85 = distinct !{!85, !83, !"_RNvXsh_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %f"}
!86 = !{!82, !85}
!87 = !{!88}
!88 = distinct !{!88, !89, !"_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag: %self"}
!89 = distinct !{!89, !"_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag"}
!90 = !{!91}
!91 = distinct !{!91, !89, !"_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag: %f"}
!92 = !{!93}
!93 = distinct !{!93, !94, !"_RNvXsh_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %self"}
!94 = distinct !{!94, !"_RNvXsh_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt"}
!95 = !{!96, !88, !91}
!96 = distinct !{!96, !94, !"_RNvXsh_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_8TypeNodeNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt: %f"}
!97 = !{!93, !96, !88, !91}
!98 = !{!99, !101, !102}
!99 = distinct !{!99, !100, !"_RNvXsr_NtCsgtPOCBgevO_4core3fmtShNtB5_5Debug3fmtCs6tqTQJNM79Z_8type_dag: %self.0"}
!100 = distinct !{!100, !"_RNvXsr_NtCsgtPOCBgevO_4core3fmtShNtB5_5Debug3fmtCs6tqTQJNM79Z_8type_dag"}
!101 = distinct !{!101, !100, !"_RNvXsr_NtCsgtPOCBgevO_4core3fmtShNtB5_5Debug3fmtCs6tqTQJNM79Z_8type_dag: %f"}
!102 = distinct !{!102, !103, !"_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRShNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag: %f"}
!103 = distinct !{!103, !"_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRShNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag"}
!104 = !{!99}
!105 = !{!106, !99, !101, !102}
!106 = distinct !{!106, !107, !"_RINvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB6_9DebugList7entriesRhINtNtNtBa_5slice4iter4IterhEECs6tqTQJNM79Z_8type_dag: %self"}
!107 = distinct !{!107, !"_RINvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB6_9DebugList7entriesRhINtNtNtBa_5slice4iter4IterhEECs6tqTQJNM79Z_8type_dag"}
!108 = !{!109}
!109 = distinct !{!109, !110, !"_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt: %f"}
!110 = distinct !{!110, !"_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt"}
!111 = !{!112}
!112 = distinct !{!112, !110, !"_RNvXsU_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_5Debug3fmt: %self"}
!113 = !{!114}
!114 = distinct !{!114, !115, !"_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt: %f"}
!115 = distinct !{!115, !"_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt"}
!116 = !{!117}
!117 = distinct !{!117, !115, !"_RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt: %self"}
!118 = !{!119}
!119 = distinct !{!119, !120, !"_RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt: %f"}
!120 = distinct !{!120, !"_RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt"}
!121 = !{!122}
!122 = distinct !{!122, !120, !"_RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt: %self"}
!123 = !{i8 0, i8 6}
!124 = !{!125}
!125 = distinct !{!125, !126, !"_RNvXsy_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %self"}
!126 = distinct !{!126, !"_RNvXsy_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq"}
!127 = !{!128}
!128 = distinct !{!128, !126, !"_RNvXsy_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_13TypeNodeFaultNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq: %other"}
!129 = !{!130}
!130 = distinct !{!130, !131, !"_RNvNtNtCsgtPOCBgevO_4core5slice6memchr6memchr: %text.0"}
!131 = distinct !{!131, !"_RNvNtNtCsgtPOCBgevO_4core5slice6memchr6memchr"}
!132 = !{!133}
!133 = distinct !{!133, !134, !"_RNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_contains: %needle.0"}
!134 = distinct !{!134, !"_RNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_contains"}
!135 = !{!136}
!136 = distinct !{!136, !134, !"_RNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_contains: %haystack.0"}
!137 = !{!138, !140, !142, !144, !133, !136}
!138 = distinct !{!138, !139, !"_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_contains0Cs6tqTQJNM79Z_8type_dag: %_1"}
!139 = distinct !{!139, !"_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_contains0Cs6tqTQJNM79Z_8type_dag"}
!140 = distinct !{!140, !141, !"_RNCINvNvNtNtNtNtCsgtPOCBgevO_4core4iter6traits12double_ended19DoubleEndedIterator5rfind5checkjNCNvNtNtBe_3str7pattern13simd_contains0E0Cs6tqTQJNM79Z_8type_dag: %_1"}
!141 = distinct !{!141, !"_RNCINvNvNtNtNtNtCsgtPOCBgevO_4core4iter6traits12double_ended19DoubleEndedIterator5rfind5checkjNCNvNtNtBe_3str7pattern13simd_contains0E0Cs6tqTQJNM79Z_8type_dag"}
!142 = distinct !{!142, !143, !"_RINvYINtNtNtCsgtPOCBgevO_4core3ops5range5RangejENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9try_rfolduNCINvNvBK_5rfind5checkjNCNvNtNtBa_3str7pattern13simd_contains0E0INtNtB8_12control_flow11ControlFlowjEECs6tqTQJNM79Z_8type_dag: %self"}
!143 = distinct !{!143, !"_RINvYINtNtNtCsgtPOCBgevO_4core3ops5range5RangejENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9try_rfolduNCINvNvBK_5rfind5checkjNCNvNtNtBa_3str7pattern13simd_contains0E0INtNtB8_12control_flow11ControlFlowjEECs6tqTQJNM79Z_8type_dag"}
!144 = distinct !{!144, !143, !"_RINvYINtNtNtCsgtPOCBgevO_4core3ops5range5RangejENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9try_rfolduNCINvNvBK_5rfind5checkjNCNvNtNtBa_3str7pattern13simd_contains0E0INtNtB8_12control_flow11ControlFlowjEECs6tqTQJNM79Z_8type_dag: %f"}
!145 = !{!138, !140, !142, !144, !136}
!146 = !{!133, !136}
!147 = !{!148, !150}
!148 = distinct !{!148, !149, !"_RINvYINtNtNtCsgtPOCBgevO_4core5slice4iter7WindowshENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBN_3any5checkRShNCNvNtNtBa_3str7pattern13simd_containss_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEECs6tqTQJNM79Z_8type_dag: %self"}
!149 = distinct !{!149, !"_RINvYINtNtNtCsgtPOCBgevO_4core5slice4iter7WindowshENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBN_3any5checkRShNCNvNtNtBa_3str7pattern13simd_containss_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEECs6tqTQJNM79Z_8type_dag"}
!150 = distinct !{!150, !149, !"_RINvYINtNtNtCsgtPOCBgevO_4core5slice4iter7WindowshENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBN_3any5checkRShNCNvNtNtBa_3str7pattern13simd_containss_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEECs6tqTQJNM79Z_8type_dag: argument 1"}
!151 = !{!152, !133}
!152 = distinct !{!152, !153, !"_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss1_0Cs6tqTQJNM79Z_8type_dag: %_1"}
!153 = distinct !{!153, !"_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss1_0Cs6tqTQJNM79Z_8type_dag"}
!154 = !{!155, !133}
!155 = distinct !{!155, !156, !"_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss1_0Cs6tqTQJNM79Z_8type_dag: %_1"}
!156 = distinct !{!156, !"_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss1_0Cs6tqTQJNM79Z_8type_dag"}
!157 = !{!158, !133}
!158 = distinct !{!158, !159, !"_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss1_0Cs6tqTQJNM79Z_8type_dag: %_1"}
!159 = distinct !{!159, !"_RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss1_0Cs6tqTQJNM79Z_8type_dag"}
!160 = !{!161}
!161 = distinct !{!161, !162, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next: %self"}
!162 = distinct !{!162, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next"}
!163 = !{!164}
!164 = distinct !{!164, !162, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next: %otherwise"}
!165 = !{!166}
!166 = distinct !{!166, !162, !"_RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher4next: %self:Peel0"}
!167 = !{!168}
!168 = distinct !{!168, !169, !"_RNvXs9_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE3get: %slice.0"}
!169 = distinct !{!169, !"_RNvXs9_NtNtCsgtPOCBgevO_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE3get"}
!170 = !{!164, !166}
!171 = !{!172, !164, !166}
!172 = distinct !{!172, !173, !"_RINvNtNtCsgtPOCBgevO_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs6tqTQJNM79Z_8type_dag: %bytes"}
!173 = distinct !{!173, !"_RINvNtNtCsgtPOCBgevO_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs6tqTQJNM79Z_8type_dag"}
!174 = !{!164, !161}
!175 = !{!172, !164, !161}
!176 = !{!177}
!177 = distinct !{!177, !178, !"_RNCNvCs6tqTQJNM79Z_8type_dag59type_dag_layout_and_cursor_source_are_observed_on_this_host0B3_: %_0"}
!178 = distinct !{!178, !"_RNCNvCs6tqTQJNM79Z_8type_dag59type_dag_layout_and_cursor_source_are_observed_on_this_host0B3_"}
!179 = !{!180, !177}
!180 = distinct !{!180, !181, !"_RNvCs6tqTQJNM79Z_8type_dags_59type_dag_layout_and_cursor_source_are_observed_on_this_host: %_0"}
!181 = distinct !{!181, !"_RNvCs6tqTQJNM79Z_8type_dags_59type_dag_layout_and_cursor_source_are_observed_on_this_host"}
!182 = !{!183}
!183 = distinct !{!183, !184, !"_RINvYINtNtNtCsgtPOCBgevO_4core3str4iter5SplitReENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldINtNtNtBa_3num7nonzero7NonZerojENCNvXs_NvBK_10advance_byB3_NtB2b_13SpecAdvanceBy15spec_advance_by0INtNtBa_6option6OptionB1y_EECs6tqTQJNM79Z_8type_dag: %self"}
!184 = distinct !{!184, !"_RINvYINtNtNtCsgtPOCBgevO_4core3str4iter5SplitReENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldINtNtNtBa_3num7nonzero7NonZerojENCNvXs_NvBK_10advance_byB3_NtB2b_13SpecAdvanceBy15spec_advance_by0INtNtBa_6option6OptionB1y_EECs6tqTQJNM79Z_8type_dag"}
!185 = !{!186}
!186 = distinct !{!186, !187, !"_RNvXsX_NtNtCsgtPOCBgevO_4core3str4iterINtB5_5SplitReENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs6tqTQJNM79Z_8type_dag: %self"}
!187 = distinct !{!187, !"_RNvXsX_NtNtCsgtPOCBgevO_4core3str4iterINtB5_5SplitReENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs6tqTQJNM79Z_8type_dag"}
!188 = !{!189}
!189 = distinct !{!189, !190, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag: %self"}
!190 = distinct !{!190, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag"}
!191 = !{!189, !186, !183, !180, !177}
!192 = !{!193, !189, !186, !183}
!193 = distinct !{!193, !194, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE7get_endCs6tqTQJNM79Z_8type_dag: %self"}
!194 = distinct !{!194, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE7get_endCs6tqTQJNM79Z_8type_dag"}
!195 = !{!189, !186, !183}
!196 = !{!197}
!197 = distinct !{!197, !198, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag: %self"}
!198 = distinct !{!198, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag"}
!199 = !{!197, !180, !177}
!200 = !{!201, !197}
!201 = distinct !{!201, !202, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE7get_endCs6tqTQJNM79Z_8type_dag: %self"}
!202 = distinct !{!202, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE7get_endCs6tqTQJNM79Z_8type_dag"}
!203 = !{!204}
!204 = distinct !{!204, !205, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag: %self"}
!205 = distinct !{!205, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE4nextCs6tqTQJNM79Z_8type_dag"}
!206 = !{!204, !180, !177}
!207 = !{!208, !204}
!208 = distinct !{!208, !209, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE7get_endCs6tqTQJNM79Z_8type_dag: %self"}
!209 = distinct !{!209, !"_RNvMsf_NtNtCsgtPOCBgevO_4core3str4iterINtB5_13SplitInternalReE7get_endCs6tqTQJNM79Z_8type_dag"}
!210 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!211 = !{!212}
!212 = distinct !{!212, !213, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %_0"}
!213 = distinct !{!213, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_"}
!214 = !{!212, !215, !177}
!215 = distinct !{!215, !213, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %result"}
!216 = !{!212, !177}
!217 = !{!215}
!218 = !{!219, !220, !177}
!219 = distinct !{!219, !213, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %_0:thread"}
!220 = distinct !{!220, !213, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %result:thread"}
!221 = !{!222, !212, !215, !177}
!222 = distinct !{!222, !223, !"_RNvXs13_NtCsa9BKTri5B3M_3std7processINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureENtB6_11Termination6reportB1c_: %self"}
!223 = distinct !{!223, !"_RNvXs13_NtCsa9BKTri5B3M_3std7processINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureENtB6_11Termination6reportB1c_"}
!224 = !{!225}
!225 = distinct !{!225, !226, !"_RNCNvCs6tqTQJNM79Z_8type_dag60type_dag_node_mutations_retain_ordinal_operands_and_priority0B3_: %_0"}
!226 = distinct !{!226, !"_RNCNvCs6tqTQJNM79Z_8type_dag60type_dag_node_mutations_retain_ordinal_operands_and_priority0B3_"}
!227 = !{!228, !225}
!228 = distinct !{!228, !229, !"_RNvCs6tqTQJNM79Z_8type_dags_60type_dag_node_mutations_retain_ordinal_operands_and_priority: %_0"}
!229 = distinct !{!229, !"_RNvCs6tqTQJNM79Z_8type_dags_60type_dag_node_mutations_retain_ordinal_operands_and_priority"}
!230 = !{i8 -1, i8 10}
!231 = !{!232}
!232 = distinct !{!232, !233, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %_0"}
!233 = distinct !{!233, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_"}
!234 = !{!232, !235, !225}
!235 = distinct !{!235, !233, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %result"}
!236 = !{!232, !225}
!237 = !{!235}
!238 = !{!239, !240, !225}
!239 = distinct !{!239, !233, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %_0:thread"}
!240 = distinct !{!240, !233, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %result:thread"}
!241 = !{!242, !232, !235, !225}
!242 = distinct !{!242, !243, !"_RNvXs13_NtCsa9BKTri5B3M_3std7processINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureENtB6_11Termination6reportB1c_: %self"}
!243 = distinct !{!243, !"_RNvXs13_NtCsa9BKTri5B3M_3std7processINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureENtB6_11Termination6reportB1c_"}
!244 = !{!245}
!245 = distinct !{!245, !246, !"_RNCNvCs6tqTQJNM79Z_8type_dag64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic0B3_: %_0"}
!246 = distinct !{!246, !"_RNCNvCs6tqTQJNM79Z_8type_dag64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic0B3_"}
!247 = !{!248, !245}
!248 = distinct !{!248, !249, !"_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic: %_0"}
!249 = distinct !{!249, !"_RNvCs6tqTQJNM79Z_8type_dags_64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic"}
!250 = !{!251}
!251 = distinct !{!251, !252, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %_0"}
!252 = distinct !{!252, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_"}
!253 = !{!254, !255, !245}
!254 = distinct !{!254, !252, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %_0:thread"}
!255 = distinct !{!255, !252, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %result:thread"}
!256 = !{!251, !245}
!257 = !{!258}
!258 = distinct !{!258, !252, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %result"}
!259 = !{!260, !251, !258, !245}
!260 = distinct !{!260, !261, !"_RNvXs13_NtCsa9BKTri5B3M_3std7processINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureENtB6_11Termination6reportB1c_: %self"}
!261 = distinct !{!261, !"_RNvXs13_NtCsa9BKTri5B3M_3std7processINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureENtB6_11Termination6reportB1c_"}
!262 = !{!251, !258, !245}
!263 = !{!264}
!264 = distinct !{!264, !265, !"_RNCNvCs6tqTQJNM79Z_8type_dag66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused0B3_: %_0"}
!265 = distinct !{!265, !"_RNCNvCs6tqTQJNM79Z_8type_dag66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused0B3_"}
!266 = !{!267, !264}
!267 = distinct !{!267, !268, !"_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused: %_0"}
!268 = distinct !{!268, !"_RNvCs6tqTQJNM79Z_8type_dags_66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused"}
!269 = !{!"branch_weights", i32 4000000, i32 4001}
!270 = !{!271}
!271 = distinct !{!271, !272, !"_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3cmp9PartialEq2eqCs6tqTQJNM79Z_8type_dag: %self"}
!272 = distinct !{!272, !"_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3cmp9PartialEq2eqCs6tqTQJNM79Z_8type_dag"}
!273 = !{!274}
!274 = distinct !{!274, !272, !"_RNvXsw_NtCsgtPOCBgevO_4core6resultINtB5_6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtNtB7_3cmp9PartialEq2eqCs6tqTQJNM79Z_8type_dag: %other"}
!275 = !{!274, !267, !264}
!276 = !{!271, !267, !264}
!277 = !{!"branch_weights", !"expected", i32 2145059253, i32 2424395}
!278 = !{!279, !281, !264}
!279 = distinct !{!279, !280, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %_0:thread"}
!280 = distinct !{!280, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_"}
!281 = distinct !{!281, !280, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %result:thread"}
!282 = !{!"branch_weights", !"expected", i32 2146410, i32 2145337238}
!283 = !{!284, !285, !264}
!284 = distinct !{!284, !280, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %_0:thread"}
!285 = distinct !{!285, !280, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %result:thread"}
!286 = !{!287}
!287 = distinct !{!287, !280, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %_0"}
!288 = !{!287, !289, !264}
!289 = distinct !{!289, !280, !"_RINvCs3O4ZRUMviTO_4test18assert_test_resultINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureEEB1j_: %result"}
!290 = !{!287, !264}
!291 = !{!289}
!292 = !{!293, !287, !289, !264}
!293 = distinct !{!293, !294, !"_RNvXs13_NtCsa9BKTri5B3M_3std7processINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureENtB6_11Termination6reportB1c_: %self"}
!294 = distinct !{!294, !"_RNvXs13_NtCsa9BKTri5B3M_3std7processINtNtCsgtPOCBgevO_4core6result6ResultuNtCs6tqTQJNM79Z_8type_dag11TestFailureENtB6_11Termination6reportB1c_"}
