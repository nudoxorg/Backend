	.build_version macos, 11, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI0_0:
	.quad	1
	.quad	0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate
	.p2align	2
__RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x19, x1
	subs	x1, x1, #4
	b.hs	LBB0_3
	strb	wzr, [x8, #8]
	str	x19, [x8, #16]
LBB0_2:
	mov	w9, #1
	str	x9, [x8]
	b	LBB0_8
LBB0_3:
	ldrb	w9, [x0]
	cmp	w9, #194
	b.ne	LBB0_7
	ldrb	w9, [x0, #1]
	cmp	w9, #1
	b.ne	LBB0_9
	ldrb	w20, [x0, #2]
	cmp	w20, #3
	b.lo	LBB0_10
	mov	w9, #513
	strh	w9, [x8, #8]
	strb	w20, [x8, #10]
	b	LBB0_2
LBB0_7:
	mov	w10, #1
	strh	w10, [x8, #8]
	strb	w9, [x8, #10]
	str	x10, [x8]
LBB0_8:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB0_9:
	.cfi_restore_state
	mov	w10, #257
	strh	w10, [x8, #8]
	strb	w9, [x8, #10]
	b	LBB0_2
LBB0_10:
	ldrb	w9, [x0, #3]
	add	x9, x9, #4
	cmp	x19, x9
	b.ne	LBB0_13
	cmp	x3, x20
	b.hs	LBB0_14
	mov	w9, #3
	strb	w9, [x8, #8]
	stp	x20, x3, [x8, #16]
	b	LBB0_2
LBB0_13:
	mov	w10, #2
	strb	w10, [x8, #8]
	stp	x9, x19, [x8, #16]
	b	LBB0_2
LBB0_14:
	strh	wzr, [sp]
	strh	wzr, [sp, #8]
	cbz	w20, LBB0_21
	cbz	x1, LBB0_24
	ldrb	w9, [x0, #4]
	cbz	w9, LBB0_27
	cmp	w9, #1
	b.ne	LBB0_30
	cmp	x1, #1
	b.eq	LBB0_28
	ldrb	w10, [x0, #5]
	cmp	w10, w20
	b.hs	LBB0_39
	lsl	x10, x10, #32
	b	LBB0_35
LBB0_21:
	mov	x9, #0
LBB0_22:
	cmp	x9, x1
	b.ne	LBB0_26
	lsl	x9, x20, #3
	mov	x1, sp
	mov	x21, x0
	mov	x0, x2
	mov	x22, x2
	mov	x2, x9
	mov	x23, x8
	bl	_memcpy
	stp	x19, x22, [x23, #16]
	str	x20, [x23, #32]
	stp	xzr, x21, [x23]
	b	LBB0_8
LBB0_24:
	mov	w9, #0
LBB0_25:
	mov	w10, #4
	strb	w10, [x8, #8]
	str	w9, [x8, #12]
	strb	wzr, [x8, #16]
Lloh0:
	adrp	x9, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x9, lCPI0_0@PAGEOFF]
	stur	q0, [x8, #24]
	b	LBB0_2
LBB0_26:
	mov	w10, #5
	strb	w10, [x8, #8]
	stp	x9, x1, [x8, #16]
	b	LBB0_2
LBB0_27:
	cmp	x1, #1
	b.ne	LBB0_32
LBB0_28:
	mov	w9, #0
LBB0_29:
	mov	w10, #4
	strb	w10, [x8, #8]
	str	w9, [x8, #12]
	strb	wzr, [x8, #16]
	mov	w9, #2
	stp	x9, x1, [x8, #24]
	b	LBB0_2
LBB0_30:
	mov	w10, #0
LBB0_31:
	mov	w11, #4
	strb	w11, [x8, #8]
	str	w10, [x8, #12]
	mov	w10, #1
	strb	w10, [x8, #16]
	strb	w9, [x8, #17]
	b	LBB0_2
LBB0_32:
	ldrb	w10, [x0, #5]
	cbz	w10, LBB0_35
	cmp	w10, #1
	b.ne	LBB0_40
	mov	w10, #256
LBB0_35:
	orr	x9, x10, x9
	str	x9, [sp]
	cmp	w20, #1
	b.ne	LBB0_37
	mov	w9, #2
	b	LBB0_22
LBB0_37:
	cmp	x1, #2
	b.ne	LBB0_43
	mov	w9, #1
	b	LBB0_25
LBB0_39:
	mov	x9, #0
	mov	x11, #12884901888
	b	LBB0_42
LBB0_40:
	mov	x9, #0
LBB0_41:
	mov	w20, w10
	mov	x11, #8589934592
LBB0_42:
	orr	x11, x11, x20, lsl #40
	mov	w12, #4
	strb	w12, [x8, #8]
	orr	x9, x11, x9
	stur	x9, [x8, #12]
	str	w10, [x8, #20]
	b	LBB0_2
LBB0_43:
	cmp	x1, #3
	b.lo	LBB0_60
	sub	x10, x19, #6
	ldrb	w9, [x0, #6]
	cbz	w9, LBB0_50
	cmp	w9, #1
	b.ne	LBB0_52
	cmp	x10, #2
	b.lo	LBB0_51
	cmp	x1, #3
	b.eq	LBB0_61
	ldrb	w10, [x0, #7]
	cmp	w10, w20
	b.hs	LBB0_58
	lsl	x11, x10, #32
	b	LBB0_57
LBB0_50:
	cmp	x10, #2
	b.hs	LBB0_53
LBB0_51:
	mov	w9, #1
	mov	x1, x10
	b	LBB0_29
LBB0_52:
	mov	w10, #1
	b	LBB0_31
LBB0_53:
	cmp	x1, #3
	b.eq	LBB0_61
	ldrb	w11, [x0, #7]
	cbz	w11, LBB0_57
	mov	x10, x11
	cmp	w11, #1
	b.ne	LBB0_59
	mov	w11, #256
LBB0_57:
	orr	x9, x11, x9
	str	x9, [sp, #8]
	mov	w9, #4
	b	LBB0_22
LBB0_58:
	mov	x11, #12884901888
	mov	w9, #1
	b	LBB0_42
LBB0_59:
	mov	w9, #1
	b	LBB0_41
LBB0_60:
Lloh2:
	adrp	x2, l_alloc_c672143cd1043046b7905c290530150a@PAGE
Lloh3:
	add	x2, x2, l_alloc_c672143cd1043046b7905c290530150a@PAGEOFF
	mov	w0, #2
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB0_61:
Lloh4:
	adrp	x2, l_alloc_5c9d608bbe9dc88f3da25cb1ea5bd4e0@PAGE
Lloh5:
	add	x2, x2, l_alloc_5c9d608bbe9dc88f3da25cb1ea5bd4e0@PAGEOFF
	mov	w0, #3
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc

	.globl	__RNvMs0_Csks33AUGQlhz_15nudox_ir_formatNtB5_16PreparedFragment10write_into
	.p2align	2
__RNvMs0_Csks33AUGQlhz_15nudox_ir_formatNtB5_16PreparedFragment10write_into:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	mov	x9, x2
	ldr	x2, [x0, #32]
	cmp	x9, x2
	b.hs	LBB1_2
	str	x2, [x8, #8]
	mov	w10, #1
	mov	x2, x9
	b	LBB1_16
LBB1_2:
	cbz	x2, LBB1_19
	mov	w9, #193
	strb	w9, [x1]
	cmp	x2, #1
	b.eq	LBB1_20
	mov	w9, #1
	strb	w9, [x1, #1]
	cmp	x2, #2
	b.ls	LBB1_21
	ldrb	w9, [x0, #40]
	strb	w9, [x1, #2]
	cmp	x2, #3
	b.eq	LBB1_22
	ldrb	w9, [x0, #41]
	strb	w9, [x1, #3]
	ldr	x11, [x0, #8]
	cbz	x11, LBB1_11
	mov	x9, #0
	ldr	x10, [x0]
	lsl	x11, x11, #2
	add	x12, x1, #4
LBB1_8:
	add	x13, x9, #7
	cmp	x13, x2
	b.hs	LBB1_17
	ldr	w13, [x10, x9]
	str	w13, [x12, x9]
	add	x9, x9, #4
	cmp	x11, x9
	b.ne	LBB1_8
	add	x9, x9, #4
	ldr	x11, [x0, #24]
	cbnz	x11, LBB1_12
	b	LBB1_15
LBB1_11:
	mov	w9, #4
	ldr	x11, [x0, #24]
	cbz	x11, LBB1_15
LBB1_12:
	ldr	x10, [x0, #16]
	lsl	x11, x11, #2
LBB1_13:
	add	x12, x9, #3
	cmp	x12, x2
	b.hs	LBB1_18
	ldr	w12, [x10], #4
	str	w12, [x1, x9]
	add	x9, x9, #4
	subs	x11, x11, #4
	b.ne	LBB1_13
LBB1_15:
	mov	x10, #0
	str	x1, [x8, #8]
LBB1_16:
	str	x2, [x8, #16]
	str	x10, [x8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB1_17:
	.cfi_restore_state
Lloh6:
	adrp	x3, l_alloc_0966d361313acda3c6c1c3538daaf6b7@PAGE
Lloh7:
	add	x3, x3, l_alloc_0966d361313acda3c6c1c3538daaf6b7@PAGEOFF
	add	x0, x9, #4
	add	x1, x9, #8
	bl	__RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail
LBB1_18:
Lloh8:
	adrp	x3, l_alloc_28b37f6ccb4f7c4ae275fb5bca43814b@PAGE
Lloh9:
	add	x3, x3, l_alloc_28b37f6ccb4f7c4ae275fb5bca43814b@PAGEOFF
	add	x1, x9, #4
	mov	x0, x9
	bl	__RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail
LBB1_19:
Lloh10:
	adrp	x2, l_alloc_214d2fa2c4b94f413c2db57477a8f4cd@PAGE
Lloh11:
	add	x2, x2, l_alloc_214d2fa2c4b94f413c2db57477a8f4cd@PAGEOFF
	mov	x0, #0
	mov	x1, #0
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB1_20:
Lloh12:
	adrp	x2, l_alloc_103b510be5829ee530b70a46424978c9@PAGE
Lloh13:
	add	x2, x2, l_alloc_103b510be5829ee530b70a46424978c9@PAGEOFF
	mov	w0, #1
	mov	w1, #1
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB1_21:
Lloh14:
	adrp	x2, l_alloc_5032ac117485716a222333652ddc6e45@PAGE
Lloh15:
	add	x2, x2, l_alloc_5032ac117485716a222333652ddc6e45@PAGEOFF
	mov	w0, #2
	mov	w1, #2
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB1_22:
Lloh16:
	adrp	x2, l_alloc_cfd935b0b09784177dc9721f4f0274e7@PAGE
Lloh17:
	add	x2, x2, l_alloc_cfd935b0b09784177dc9721f4f0274e7@PAGEOFF
	mov	w0, #3
	mov	w1, #3
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.cfi_endproc

	.globl	__RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate
	.p2align	2
__RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate:
	.cfi_startproc
	cmp	x1, #4
	b.hs	LBB2_2
	strb	wzr, [x8, #8]
	str	x1, [x8, #16]
	str	xzr, [x8]
	ret
LBB2_2:
	ldrb	w9, [x0]
	cmp	w9, #193
	b.ne	LBB2_6
	ldrb	w9, [x0, #1]
	cmp	w9, #1
	b.ne	LBB2_7
	ldrb	w9, [x0, #2]
	cmp	w9, #3
	b.lo	LBB2_8
	mov	w10, #3
	strb	w10, [x8, #8]
	strb	w9, [x8, #9]
	str	xzr, [x8]
	ret
LBB2_6:
	mov	w10, #1
	strb	w10, [x8, #8]
	strb	w9, [x8, #9]
	str	xzr, [x8]
	ret
LBB2_7:
	mov	w10, #2
	strb	w10, [x8, #8]
	strb	w9, [x8, #9]
	str	xzr, [x8]
	ret
LBB2_8:
	ldrb	w10, [x0, #3]
	cmp	w10, #2
	b.ls	LBB2_10
	mov	w9, #4
	strb	w9, [x8, #8]
	strb	w10, [x8, #9]
	str	xzr, [x8]
	ret
LBB2_10:
	lsl	x9, x9, #2
	add	x11, x9, #4
	add	x10, x11, x10, lsl #2
	cmp	x1, x10
	b.ne	LBB2_12
	add	x10, x0, #4
	sub	x12, x1, x11
	add	x11, x0, x11
	stp	x0, x1, [x8]
	stp	x10, x9, [x8, #16]
	stp	x11, x12, [x8, #32]
	ret
LBB2_12:
	mov	w9, #5
	strb	w9, [x8, #8]
	stp	x10, x1, [x8, #16]
	str	xzr, [x8]
	ret
	.cfi_endproc

	.section	__TEXT,__cstring,cstring_literals
l_alloc_41f3d5135f162260a668aae5b03337a2:
	.asciz	"crates/nudox-ir-format/src/type_dag.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_c672143cd1043046b7905c290530150a:
	.quad	l_alloc_41f3d5135f162260a668aae5b03337a2
	.asciz	"&\000\000\000\000\000\000\000~\000\000\000\036\000\000"

	.p2align	3, 0x0
l_alloc_5c9d608bbe9dc88f3da25cb1ea5bd4e0:
	.quad	l_alloc_41f3d5135f162260a668aae5b03337a2
	.asciz	"&\000\000\000\000\000\000\000\214\000\000\0009\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_alloc_90b0c124cbead942e81c194f9359718c:
	.asciz	"crates/nudox-ir-format/src/lib.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_214d2fa2c4b94f413c2db57477a8f4cd:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\264\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_103b510be5829ee530b70a46424978c9:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\265\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_5032ac117485716a222333652ddc6e45:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\266\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_cfd935b0b09784177dc9721f4f0274e7:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\267\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_0966d361313acda3c6c1c3538daaf6b7:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\272\000\000\000\024\000\000"

	.p2align	3, 0x0
l_alloc_28b37f6ccb4f7c4ae275fb5bca43814b:
	.quad	l_alloc_90b0c124cbead942e81c194f9359718c
	.asciz	"!\000\000\000\000\000\000\000\276\000\000\000\024\000\000"

.subsections_via_symbols
