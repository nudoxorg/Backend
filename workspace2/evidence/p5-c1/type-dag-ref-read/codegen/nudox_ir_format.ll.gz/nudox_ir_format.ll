; ModuleID = 'nudox_ir_format.ee38cb3857691817-cgu.0'
source_filename = "nudox_ir_format.ee38cb3857691817-cgu.0"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx11.0.0"

@alloc_41f3d5135f162260a668aae5b03337a2 = private unnamed_addr constant [39 x i8] c"crates/nudox-ir-format/src/type_dag.rs\00", align 1
@alloc_c672143cd1043046b7905c290530150a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_41f3d5135f162260a668aae5b03337a2, [16 x i8] c"&\00\00\00\00\00\00\00~\00\00\00\1E\00\00\00" }>, align 8
@alloc_5c9d608bbe9dc88f3da25cb1ea5bd4e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_41f3d5135f162260a668aae5b03337a2, [16 x i8] c"&\00\00\00\00\00\00\00\8C\00\00\009\00\00\00" }>, align 8
@alloc_90b0c124cbead942e81c194f9359718c = private unnamed_addr constant [34 x i8] c"crates/nudox-ir-format/src/lib.rs\00", align 1
@alloc_214d2fa2c4b94f413c2db57477a8f4cd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\B4\00\00\00\09\00\00\00" }>, align 8
@alloc_103b510be5829ee530b70a46424978c9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\B5\00\00\00\09\00\00\00" }>, align 8
@alloc_5032ac117485716a222333652ddc6e45 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\B6\00\00\00\09\00\00\00" }>, align 8
@alloc_cfd935b0b09784177dc9721f4f0274e7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\B7\00\00\00\09\00\00\00" }>, align 8
@alloc_0966d361313acda3c6c1c3538daaf6b7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\BA\00\00\00\14\00\00\00" }>, align 8
@alloc_28b37f6ccb4f7c4ae275fb5bca43814b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_90b0c124cbead942e81c194f9359718c, [16 x i8] c"!\00\00\00\00\00\00\00\BE\00\00\00\14\00\00\00" }>, align 8

; <nudox_ir_format::type_dag::TypeDagView>::validate
; Function Attrs: uwtable
define void @_RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate(ptr dead_on_unwind noalias noundef writable writeonly sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_0, ptr noalias noundef nonnull readonly captures(address, read_provenance) %bytes.0, i64 noundef range(i64 0, -9223372036854775808) %bytes.1, ptr noalias noundef nonnull align 4 %scratch.0, i64 noundef range(i64 0, 1152921504606846976) %scratch.1) unnamed_addr #0 {
start:
  %decoded = alloca [16 x i8], align 8
  %_3 = icmp samesign ult i64 %bytes.1, 4
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = load i8, ptr %bytes.0, align 1, !noundef !2
  %0 = icmp eq i8 %_6, -62
  br i1 %0, label %bb7, label %bb5

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 0, ptr %1, align 8
  %_5.sroa.410.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %bytes.1, ptr %_5.sroa.410.0..sroa_idx, align 8
  store i64 1, ptr %_0, align 8
  br label %bb36

bb7:                                              ; preds = %bb2
  %2 = getelementptr inbounds nuw i8, ptr %bytes.0, i64 1
  %_10 = load i8, ptr %2, align 1, !noundef !2
  %3 = icmp eq i8 %_10, 1
  br i1 %3, label %bb11, label %bb9

bb11:                                             ; preds = %bb7
  %4 = getelementptr inbounds nuw i8, ptr %bytes.0, i64 2
  %node_count = load i8, ptr %4, align 1, !noundef !2
  %_16 = icmp ugt i8 %node_count, 2
  br i1 %_16, label %bb12, label %bb14

bb12:                                             ; preds = %bb11
  %5 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 1, ptr %5, align 8
  %_17.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 2, ptr %_17.sroa.4.0..sroa_idx, align 1
  %_17.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 10
  store i8 %node_count, ptr %_17.sroa.5.0..sroa_idx, align 2
  store i64 1, ptr %_0, align 8
  br label %bb36

bb14:                                             ; preds = %bb11
  %6 = getelementptr inbounds nuw i8, ptr %bytes.0, i64 3
  %_21 = load i8, ptr %6, align 1, !noundef !2
  %_20 = zext i8 %_21 to i64
  %expected = add nuw nsw i64 %_20, 4
  %_23.not = icmp eq i64 %bytes.1, %expected
  br i1 %_23.not, label %bb16, label %bb15

bb16:                                             ; preds = %bb14
  %required = zext nneg i8 %node_count to i64
  %_26 = icmp samesign ult i64 %scratch.1, %required
  br i1 %_26, label %bb17, label %bb18

bb15:                                             ; preds = %bb14
  %7 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 2, ptr %7, align 8
  %_24.sroa.411.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %expected, ptr %_24.sroa.411.0..sroa_idx, align 8
  %_24.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %bytes.1, ptr %_24.sroa.5.0..sroa_idx, align 8
  store i64 1, ptr %_0, align 8
  br label %bb36

bb18:                                             ; preds = %bb16
  call void @llvm.lifetime.start.p0(ptr nonnull %decoded)
  store i8 0, ptr %decoded, align 8
  %decoded.1..sroa_idx = getelementptr inbounds nuw i8, ptr %decoded, i64 1
  store i8 0, ptr %decoded.1..sroa_idx, align 1
  %decoded.8..sroa_idx277 = getelementptr inbounds nuw i8, ptr %decoded, i64 8
  store i8 0, ptr %decoded.8..sroa_idx277, align 8
  %decoded.9..sroa_idx = getelementptr inbounds nuw i8, ptr %decoded, i64 9
  store i8 0, ptr %decoded.9..sroa_idx, align 1
  %_70 = add nsw i64 %bytes.1, -4
  %_74 = getelementptr inbounds nuw i8, ptr %bytes.0, i64 4
  %_75117.not = icmp eq i8 %node_count, 0
  br i1 %_75117.not, label %bb40, label %bb39

bb17:                                             ; preds = %bb16
  %8 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 3, ptr %8, align 8
  %_28.sroa.412.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %required, ptr %_28.sroa.412.0..sroa_idx, align 8
  %_28.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %scratch.1, ptr %_28.sroa.5.0..sroa_idx, align 8
  store i64 1, ptr %_0, align 8
  br label %bb36

bb40:                                             ; preds = %bb27, %bb27.1, %bb18
  %cursor.sroa.0.0.lcssa = phi i64 [ 0, %bb18 ], [ 2, %bb27 ], [ 4, %bb27.1 ]
  %_59.not = icmp eq i64 %cursor.sroa.0.0.lcssa, %_70
  br i1 %_59.not, label %bb49, label %bb28

bb39:                                             ; preds = %bb18
  %9 = icmp eq i64 %_70, 0
  br i1 %9, label %bb20, label %bb22

bb28:                                             ; preds = %bb40
  %10 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 5, ptr %10, align 8
  %_61.sroa.445.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %cursor.sroa.0.0.lcssa, ptr %_61.sroa.445.0..sroa_idx, align 8
  %_61.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %_70, ptr %_61.sroa.5.0..sroa_idx, align 8
  br label %bb32

bb49:                                             ; preds = %bb40
  %11 = shl nuw nsw i64 %required, 3
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 4 %scratch.0, ptr nonnull readonly align 8 %decoded, i64 %11, i1 false), !alias.scope !3
  %12 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %bytes.0, ptr %12, align 8
  %_66.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %bytes.1, ptr %_66.sroa.4.0..sroa_idx, align 8
  %_66.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store ptr %scratch.0, ptr %_66.sroa.5.0..sroa_idx, align 8
  %_66.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store i64 %required, ptr %_66.sroa.6.0..sroa_idx, align 8
  store i64 0, ptr %_0, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %decoded)
  br label %bb36

bb36:                                             ; preds = %bb12, %bb32, %bb17, %bb15, %bb1, %bb5, %bb9, %bb49
  ret void

bb32:                                             ; preds = %bb55, %bb26, %bb23, %bb20, %bb28
  store i64 1, ptr %_0, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %decoded)
  br label %bb36

bb20:                                             ; preds = %bb39.1, %bb39
  %indvars.iv.lcssa = phi i32 [ 0, %bb39 ], [ 1, %bb39.1 ]
  %13 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 4, ptr %13, align 8
  %_38.sroa.419.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 12
  store i32 %indvars.iv.lcssa, ptr %_38.sroa.419.0..sroa_idx, align 4
  %_38.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i8 0, ptr %_38.sroa.5.0..sroa_idx, align 8
  %_38.sroa.5.sroa.5.0._38.sroa.5.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store <2 x i64> <i64 1, i64 0>, ptr %_38.sroa.5.sroa.5.0._38.sroa.5.0..sroa_idx.sroa_idx, align 8
  br label %bb32

bb22:                                             ; preds = %bb39
  %14 = load i8, ptr %_74, align 1, !noundef !2
  switch i8 %14, label %bb23 [
    i8 0, label %bb25
    i8 1, label %bb24
  ]

panic4:                                           ; preds = %bb21.1
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 2, i64 noundef %_70, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_c672143cd1043046b7905c290530150a) #6
  unreachable

bb23:                                             ; preds = %bb22.1, %bb22
  %.lcssa269 = phi i8 [ %14, %bb22 ], [ %28, %bb22.1 ]
  %indvars.iv.lcssa261 = phi i32 [ 0, %bb22 ], [ 1, %bb22.1 ]
  %15 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 4, ptr %15, align 8
  %_44.sroa.421.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 12
  store i32 %indvars.iv.lcssa261, ptr %_44.sroa.421.0..sroa_idx, align 4
  %_44.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i8 1, ptr %_44.sroa.5.0..sroa_idx, align 8
  %_44.sroa.5.sroa.4.0._44.sroa.5.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 17
  store i8 %.lcssa269, ptr %_44.sroa.5.sroa.4.0._44.sroa.5.0..sroa_idx.sroa_idx, align 1
  br label %bb32

bb25:                                             ; preds = %bb22
  %16 = icmp eq i64 %_70, 1
  br i1 %16, label %bb26, label %bb57

bb24:                                             ; preds = %bb22
  %17 = icmp eq i64 %_70, 1
  br i1 %17, label %bb26, label %bb53

bb26:                                             ; preds = %bb25.1, %bb24.1, %bb24, %bb25
  %indvars.iv.lcssa262 = phi i32 [ 0, %bb24 ], [ 0, %bb25 ], [ 1, %bb24.1 ], [ 1, %bb25.1 ]
  %available.lcssa246 = phi i64 [ %_70, %bb24 ], [ %_70, %bb25 ], [ %available.1, %bb24.1 ], [ %available.1, %bb25.1 ]
  %18 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 4, ptr %18, align 8
  %_47.sroa.423.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 12
  store i32 %indvars.iv.lcssa262, ptr %_47.sroa.423.0..sroa_idx, align 4
  %_47.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i8 0, ptr %_47.sroa.5.0..sroa_idx, align 8
  %_47.sroa.5.sroa.5.0._47.sroa.5.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 2, ptr %_47.sroa.5.sroa.5.0._47.sroa.5.0..sroa_idx.sroa_idx, align 8
  %_47.sroa.5.sroa.6.0._47.sroa.5.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store i64 %available.lcssa246, ptr %_47.sroa.5.sroa.6.0._47.sroa.5.0..sroa_idx.sroa_idx, align 8
  br label %bb32

bb57:                                             ; preds = %bb25
  %19 = getelementptr inbounds nuw i8, ptr %bytes.0, i64 5
  %20 = load i8, ptr %19, align 1, !noundef !2
  switch i8 %20, label %bb41 [
    i8 0, label %bb27
    i8 1, label %bb42
  ]

panic5:                                           ; preds = %bb56.1
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 3, i64 noundef %_70, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5c9d608bbe9dc88f3da25cb1ea5bd4e0) #6
  unreachable

bb41:                                             ; preds = %bb57.1, %bb57
  %indvars.iv.lcssa266 = phi i64 [ 0, %bb57 ], [ 1, %bb57.1 ]
  %.lcssa243 = phi i8 [ %20, %bb57 ], [ %36, %bb57.1 ]
  %_82.sroa.0.1.insert.ext = zext i8 %.lcssa243 to i64
  br label %bb55

bb42:                                             ; preds = %bb57
  br label %bb27

bb55:                                             ; preds = %bb45, %bb41
  %indvars.iv268 = phi i64 [ %indvars.iv.lcssa264, %bb45 ], [ %indvars.iv.lcssa266, %bb41 ]
  %required.sink = phi i64 [ %required, %bb45 ], [ %_82.sroa.0.1.insert.ext, %bb41 ]
  %.sink = phi i64 [ 12884901888, %bb45 ], [ 8589934592, %bb41 ]
  %_50.sroa.14.sroa.0.0 = phi i32 [ %_90, %bb45 ], [ undef, %bb41 ]
  %_88.sroa.0.1.insert.shift = shl nuw nsw i64 %required.sink, 40
  %_88.sroa.0.0.insert.insert = or disjoint i64 %_88.sroa.0.1.insert.shift, %.sink
  %_93.sroa.6.4.insert.ext = and i64 %indvars.iv268, 255
  %_93.sroa.6.8.insert.insert = or disjoint i64 %_88.sroa.0.0.insert.insert, %_93.sroa.6.4.insert.ext
  %21 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 4, ptr %21, align 8
  %_95.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 12
  store i64 %_93.sroa.6.8.insert.insert, ptr %_95.sroa.5.0..sroa_idx, align 4
  %_95.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 20
  store i32 %_50.sroa.14.sroa.0.0, ptr %_95.sroa.6.0..sroa_idx, align 4
  br label %bb32

bb53:                                             ; preds = %bb24
  %22 = getelementptr inbounds nuw i8, ptr %bytes.0, i64 5
  %23 = load i8, ptr %22, align 1, !noundef !2
  %_83 = icmp ult i8 %23, %node_count
  br i1 %_83, label %bb44, label %bb45

panic6:                                           ; preds = %bb52.1
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 3, i64 noundef %_70, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5c9d608bbe9dc88f3da25cb1ea5bd4e0) #6
  unreachable

bb45:                                             ; preds = %bb53.1, %bb53
  %indvars.iv.lcssa264 = phi i64 [ 0, %bb53 ], [ 1, %bb53.1 ]
  %.lcssa240 = phi i8 [ %23, %bb53 ], [ %31, %bb53.1 ]
  %_90 = zext i8 %.lcssa240 to i32
  br label %bb55

bb44:                                             ; preds = %bb53
  %24 = zext nneg i8 %23 to i64
  %25 = shl nuw nsw i64 %24, 32
  br label %bb27

bb27:                                             ; preds = %bb42, %bb44, %bb57
  %_91.sroa.4.0.insert.insert = phi i64 [ %25, %bb44 ], [ 256, %bb42 ], [ 0, %bb57 ]
  %_91.sroa.0.0.insert.ext = zext nneg i8 %14 to i64
  %_91.sroa.0.0.insert.insert = or disjoint i64 %_91.sroa.4.0.insert.insert, %_91.sroa.0.0.insert.ext
  store i64 %_91.sroa.0.0.insert.insert, ptr %decoded, align 8
  %exitcond.not = icmp eq i8 %node_count, 1
  br i1 %exitcond.not, label %bb40, label %bb39.1

bb39.1:                                           ; preds = %bb27
  %available.1 = add nsw i64 %bytes.1, -6
  %26 = icmp eq i64 %_70, 2
  br i1 %26, label %bb20, label %bb21.1

bb21.1:                                           ; preds = %bb39.1
  %_42.1 = icmp ugt i64 %_70, 2
  br i1 %_42.1, label %bb22.1, label %panic4

bb22.1:                                           ; preds = %bb21.1
  %27 = getelementptr inbounds nuw i8, ptr %bytes.0, i64 6
  %28 = load i8, ptr %27, align 1, !noundef !2
  switch i8 %28, label %bb23 [
    i8 0, label %bb25.1
    i8 1, label %bb24.1
  ]

bb24.1:                                           ; preds = %bb22.1
  %29 = icmp ult i64 %available.1, 2
  br i1 %29, label %bb26, label %bb52.1

bb52.1:                                           ; preds = %bb24.1
  %.not = icmp eq i64 %_70, 3
  br i1 %.not, label %panic6, label %bb53.1

bb53.1:                                           ; preds = %bb52.1
  %30 = getelementptr inbounds nuw i8, ptr %bytes.0, i64 7
  %31 = load i8, ptr %30, align 1, !noundef !2
  %_83.1 = icmp ult i8 %31, %node_count
  br i1 %_83.1, label %bb44.1, label %bb45

bb44.1:                                           ; preds = %bb53.1
  %32 = zext nneg i8 %31 to i64
  %33 = shl nuw nsw i64 %32, 32
  br label %bb27.1

bb25.1:                                           ; preds = %bb22.1
  %34 = icmp ult i64 %available.1, 2
  br i1 %34, label %bb26, label %bb56.1

bb56.1:                                           ; preds = %bb25.1
  %.not278 = icmp eq i64 %_70, 3
  br i1 %.not278, label %panic5, label %bb57.1

bb57.1:                                           ; preds = %bb56.1
  %35 = getelementptr inbounds nuw i8, ptr %bytes.0, i64 7
  %36 = load i8, ptr %35, align 1, !noundef !2
  switch i8 %36, label %bb41 [
    i8 0, label %bb27.1
    i8 1, label %bb42.1
  ]

bb42.1:                                           ; preds = %bb57.1
  br label %bb27.1

bb27.1:                                           ; preds = %bb42.1, %bb57.1, %bb44.1
  %_91.sroa.4.0.insert.insert.1 = phi i64 [ %33, %bb44.1 ], [ 256, %bb42.1 ], [ 0, %bb57.1 ]
  %_91.sroa.0.0.insert.ext.1 = zext nneg i8 %28 to i64
  %_91.sroa.0.0.insert.insert.1 = or disjoint i64 %_91.sroa.4.0.insert.insert.1, %_91.sroa.0.0.insert.ext.1
  %decoded.8..sroa_idx = getelementptr inbounds nuw i8, ptr %decoded, i64 8
  store i64 %_91.sroa.0.0.insert.insert.1, ptr %decoded.8..sroa_idx, align 8
  br label %bb40

bb9:                                              ; preds = %bb7
  %37 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 1, ptr %37, align 8
  %_12.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 1, ptr %_12.sroa.4.0..sroa_idx, align 1
  %_12.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 10
  store i8 %_10, ptr %_12.sroa.5.0..sroa_idx, align 2
  store i64 1, ptr %_0, align 8
  br label %bb36

bb5:                                              ; preds = %bb2
  %38 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 1, ptr %38, align 8
  %_8.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 0, ptr %_8.sroa.4.0..sroa_idx, align 1
  %_8.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 10
  store i8 %_6, ptr %_8.sroa.5.0..sroa_idx, align 2
  store i64 1, ptr %_0, align 8
  br label %bb36
}

; <nudox_ir_format::PreparedFragment>::write_into
; Function Attrs: uwtable
define void @_RNvMs0_Csks33AUGQlhz_15nudox_ir_formatNtB5_16PreparedFragment10write_into(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, ptr noalias noundef nonnull %output.0, i64 noundef range(i64 0, -9223372036854775808) %output.1) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_5 = load i64, ptr %0, align 8, !noundef !2
  %_3 = icmp ult i64 %output.1, %_5
  br i1 %_3, label %bb1, label %bb10

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_5, ptr %1, align 8
  br label %bb9

bb10:                                             ; preds = %start
  %_8.not = icmp eq i64 %_5, 0
  br i1 %_8.not, label %panic, label %bb3

bb3:                                              ; preds = %bb10
  store i8 -63, ptr %output.0, align 1
  %_9.not = icmp eq i64 %_5, 1
  br i1 %_9.not, label %panic2, label %bb4

panic:                                            ; preds = %bb10
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 0, i64 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_214d2fa2c4b94f413c2db57477a8f4cd) #6
  unreachable

bb4:                                              ; preds = %bb3
  %2 = getelementptr inbounds nuw i8, ptr %output.0, i64 1
  store i8 1, ptr %2, align 1
  %_11 = icmp samesign ugt i64 %_5, 2
  br i1 %_11, label %bb5, label %panic3

panic2:                                           ; preds = %bb3
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 1, i64 noundef 1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_103b510be5829ee530b70a46424978c9) #6
  unreachable

bb5:                                              ; preds = %bb4
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_10 = load i8, ptr %3, align 8, !noundef !2
  %4 = getelementptr inbounds nuw i8, ptr %output.0, i64 2
  store i8 %_10, ptr %4, align 1
  %_13.not = icmp eq i64 %_5, 3
  br i1 %_13.not, label %panic4, label %bb6

panic3:                                           ; preds = %bb4
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 2, i64 noundef 2, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5032ac117485716a222333652ddc6e45) #6
  unreachable

bb6:                                              ; preds = %bb5
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 41
  %_12 = load i8, ptr %5, align 1, !noundef !2
  %6 = getelementptr inbounds nuw i8, ptr %output.0, i64 3
  store i8 %_12, ptr %6, align 1
  %_16.0 = load ptr, ptr %self, align 8, !nonnull !2, !align !7, !noundef !2
  %7 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_16.1 = load i64, ptr %7, align 8, !noundef !2
  %_52.idx = shl nuw nsw i64 %_16.1, 2
  %_52 = getelementptr inbounds nuw i8, ptr %_16.0, i64 %_52.idx
  %_5913 = icmp eq i64 %_16.1, 0
  br i1 %_5913, label %bb14, label %bb15

panic4:                                           ; preds = %bb5
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef 3, i64 noundef 3, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_cfd935b0b09784177dc9721f4f0274e7) #6
  unreachable

bb15:                                             ; preds = %bb6, %bb16
  %cursor.sroa.0.015 = phi i64 [ %_22, %bb16 ], [ 4, %bb6 ]
  %iter.sroa.0.014 = phi ptr [ %_65, %bb16 ], [ %_16.0, %bb6 ]
  %_22 = add i64 %cursor.sroa.0.015, 4
  %8 = or disjoint i64 %cursor.sroa.0.015, 3
  %or.cond.not = icmp ult i64 %8, %_5
  br i1 %or.cond.not, label %bb16, label %bb17, !prof !8

bb14:                                             ; preds = %bb16, %bb6
  %cursor.sroa.0.0.lcssa = phi i64 [ 4, %bb6 ], [ %_22, %bb16 ]
  %9 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_29.0 = load ptr, ptr %9, align 8, !nonnull !2, !align !7, !noundef !2
  %10 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %_29.1 = load i64, ptr %10, align 8, !noundef !2
  %_79.idx = shl nuw nsw i64 %_29.1, 2
  %_79 = getelementptr inbounds nuw i8, ptr %_29.0, i64 %_79.idx
  %_8616 = icmp eq i64 %_29.1, 0
  br i1 %_8616, label %bb21, label %bb22

bb17:                                             ; preds = %bb15
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef %cursor.sroa.0.015, i64 noundef %_22, i64 noundef %_5, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0966d361313acda3c6c1c3538daaf6b7) #6
  unreachable

bb16:                                             ; preds = %bb15
  %_65 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.014, i64 4
  %_74 = getelementptr inbounds nuw i8, ptr %output.0, i64 %cursor.sroa.0.015
  %_27 = load i32, ptr %iter.sroa.0.014, align 4, !noundef !2
  store i32 %_27, ptr %_74, align 1, !alias.scope !9
  %_59 = icmp eq ptr %_65, %_52
  br i1 %_59, label %bb14, label %bb15

bb22:                                             ; preds = %bb14, %bb23
  %cursor.sroa.0.118 = phi i64 [ %_35, %bb23 ], [ %cursor.sroa.0.0.lcssa, %bb14 ]
  %iter1.sroa.0.017 = phi ptr [ %_92, %bb23 ], [ %_29.0, %bb14 ]
  %_35 = add i64 %cursor.sroa.0.118, 4
  %11 = or disjoint i64 %cursor.sroa.0.118, 3
  %or.cond10.not = icmp ult i64 %11, %_5
  br i1 %or.cond10.not, label %bb23, label %bb24, !prof !8

bb21:                                             ; preds = %bb23, %bb14
  %12 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %output.0, ptr %12, align 8
  br label %bb9

bb24:                                             ; preds = %bb22
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef %cursor.sroa.0.118, i64 noundef %_35, i64 noundef %_5, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_28b37f6ccb4f7c4ae275fb5bca43814b) #6
  unreachable

bb23:                                             ; preds = %bb22
  %_92 = getelementptr inbounds nuw i8, ptr %iter1.sroa.0.017, i64 4
  %_101 = getelementptr inbounds nuw i8, ptr %output.0, i64 %cursor.sroa.0.118
  %_40 = load i32, ptr %iter1.sroa.0.017, align 4, !noundef !2
  store i32 %_40, ptr %_101, align 1, !alias.scope !12
  %_86 = icmp eq ptr %_92, %_79
  br i1 %_86, label %bb21, label %bb22

bb9:                                              ; preds = %bb1, %bb21
  %output.1.sink = phi i64 [ %output.1, %bb1 ], [ %_5, %bb21 ]
  %storemerge = phi i64 [ 1, %bb1 ], [ 0, %bb21 ]
  %13 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %output.1.sink, ptr %13, align 8
  store i64 %storemerge, ptr %_0, align 8
  ret void
}

; <nudox_ir_format::FragmentView>::validate
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define void @_RNvMs_Csks33AUGQlhz_15nudox_ir_formatNtB4_12FragmentView8validate(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) initializes((0, 9)) %_0, ptr noalias noundef nonnull readonly captures(address, read_provenance) %envelope.0, i64 noundef range(i64 0, -9223372036854775808) %envelope.1) unnamed_addr #1 {
start:
  %_2 = icmp samesign ult i64 %envelope.1, 4
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_5 = load i8, ptr %envelope.0, align 1, !noundef !2
  %0 = icmp eq i8 %_5, -63
  br i1 %0, label %bb7, label %bb5

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 0, ptr %1, align 8
  %_4.sroa.46.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %envelope.1, ptr %_4.sroa.46.0..sroa_idx, align 8
  store ptr null, ptr %_0, align 8
  br label %bb21

bb7:                                              ; preds = %bb2
  %2 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 1
  %_8 = load i8, ptr %2, align 1, !noundef !2
  %3 = icmp eq i8 %_8, 1
  br i1 %3, label %bb11, label %bb9

bb11:                                             ; preds = %bb7
  %4 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 2
  %entity_count = load i8, ptr %4, align 1, !noundef !2
  %_13 = icmp ugt i8 %entity_count, 2
  br i1 %_13, label %bb12, label %bb14

bb12:                                             ; preds = %bb11
  %5 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 3, ptr %5, align 8
  %_14.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 %entity_count, ptr %_14.sroa.4.0..sroa_idx, align 1
  store ptr null, ptr %_0, align 8
  br label %bb21

bb14:                                             ; preds = %bb11
  %6 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 3
  %type_count = load i8, ptr %6, align 1, !noundef !2
  %_17 = icmp ugt i8 %type_count, 2
  br i1 %_17, label %bb15, label %bb16

bb16:                                             ; preds = %bb14
  %7 = shl nuw nsw i8 %entity_count, 2
  %_20 = zext nneg i8 %7 to i64
  %entity_end = add nuw nsw i64 %_20, 4
  %8 = shl nuw nsw i8 %type_count, 2
  %_23 = zext nneg i8 %8 to i64
  %expected = add nuw nsw i64 %entity_end, %_23
  %_25.not = icmp eq i64 %envelope.1, %expected
  br i1 %_25.not, label %bb22, label %bb17

bb15:                                             ; preds = %bb14
  %9 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 4, ptr %9, align 8
  %_18.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 %type_count, ptr %_18.sroa.4.0..sroa_idx, align 1
  store ptr null, ptr %_0, align 8
  br label %bb21

bb17:                                             ; preds = %bb16
  %10 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 5, ptr %10, align 8
  %_26.sroa.47.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %expected, ptr %_26.sroa.47.0..sroa_idx, align 8
  %_26.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %envelope.1, ptr %_26.sroa.5.0..sroa_idx, align 8
  store ptr null, ptr %_0, align 8
  br label %bb21

bb22:                                             ; preds = %bb16
  %_37 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 4
  %_40 = sub nuw nsw i64 %envelope.1, %entity_end
  %_44 = getelementptr inbounds nuw i8, ptr %envelope.0, i64 %entity_end
  store ptr %envelope.0, ptr %_0, align 8
  %_27.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %envelope.1, ptr %_27.sroa.4.0._0.sroa_idx, align 8
  %_27.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store ptr %_37, ptr %_27.sroa.5.0._0.sroa_idx, align 8
  %_27.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %_20, ptr %_27.sroa.6.0._0.sroa_idx, align 8
  %_27.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store ptr %_44, ptr %_27.sroa.7.0._0.sroa_idx, align 8
  %_27.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40
  store i64 %_40, ptr %_27.sroa.8.0._0.sroa_idx, align 8
  br label %bb21

bb21:                                             ; preds = %bb12, %bb15, %bb17, %bb1, %bb5, %bb9, %bb22
  ret void

bb9:                                              ; preds = %bb7
  %11 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 2, ptr %11, align 8
  %_10.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 %_8, ptr %_10.sroa.4.0..sroa_idx, align 1
  store ptr null, ptr %_0, align 8
  br label %bb21

bb5:                                              ; preds = %bb2
  %12 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 1, ptr %12, align 8
  %_7.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9
  store i8 %_5, ptr %_7.sroa.4.0..sroa_idx, align 1
  store ptr null, ptr %_0, align 8
  br label %bb21
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check(i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #4

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail(i64 noundef, i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #5

attributes #0 = { uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #2 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { cold minsize noinline noreturn optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { cold noinline noreturn uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #6 = { noreturn }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{!"rustc version 1.97.1 (8bab26f4f 2026-07-14)"}
!2 = !{}
!3 = !{!4, !6}
!4 = distinct !{!4, !5, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeEBS_: %dest.0"}
!5 = distinct !{!5, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeEBS_"}
!6 = distinct !{!6, !5, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeEBS_: %src.0"}
!7 = !{i64 4}
!8 = !{!"branch_weights", i32 4000000, i32 4001}
!9 = !{!10}
!10 = distinct !{!10, !11, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECsks33AUGQlhz_15nudox_ir_format: %dest.0"}
!11 = distinct !{!11, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECsks33AUGQlhz_15nudox_ir_format"}
!12 = !{!13}
!13 = distinct !{!13, !14, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECsks33AUGQlhz_15nudox_ir_format: %dest.0"}
!14 = distinct !{!14, !"_RINvNtCsgtPOCBgevO_4core5slice20copy_from_slice_implhECsks33AUGQlhz_15nudox_ir_format"}
