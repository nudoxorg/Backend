	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	stp	x22, x21, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x20, x19, [sp, #16]
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	sub	x10, x5, #1
	ldr	x16, [x1, #32]
	add	x9, x10, x16
	cmp	x9, x3
	b.hs	LBB0_18
	ldr	x11, [x1]
	ldp	x13, x12, [x1, #16]
	ldr	x15, [x1, #48]
	neg	x14, x11
	b	LBB0_4
LBB0_2:
	str	x9, [x1, #48]
	mov	x15, x9
LBB0_3:
	add	x9, x10, x8
	cmp	x9, x3
	mov	x16, x8
	b.hs	LBB0_18
LBB0_4:
	ldrb	w8, [x2, x9]
	lsr	x8, x12, x8
	tbz	w8, #0, LBB0_10
	cmp	x15, x11
	csel	x8, x15, x11, hi
	cmp	w6, #0
	csel	x9, x11, x8, ne
	add	x17, x9, x16
	add	x8, x17, x14
	add	x7, x4, x9
	subs	x19, x5, x9
	csel	x19, xzr, x19, lo
LBB0_6:
	cbz	x19, LBB0_12
	cmp	x17, x3
	b.hs	LBB0_23
	ldrb	w20, [x7], #1
	ldrb	w21, [x2, x17]
	add	x8, x8, #1
	add	x17, x17, #1
	sub	x19, x19, #1
	cmp	w20, w21
	b.eq	LBB0_6
	str	x8, [x1, #32]
	tbnz	w6, #0, LBB0_3
	b	LBB0_11
LBB0_10:
	add	x8, x16, x5
	str	x8, [x1, #32]
	tbnz	w6, #0, LBB0_3
LBB0_11:
	mov	x9, #0
	b	LBB0_2
LBB0_12:
	cmp	w6, #0
	csel	x17, xzr, x15, ne
	mov	x8, x11
LBB0_13:
	cmp	x17, x8
	b.hs	LBB0_19
	sub	x8, x8, #1
	cmp	x8, x5
	b.hs	LBB0_25
	add	x9, x8, x16
	cmp	x9, x3
	b.hs	LBB0_24
	ldrb	w7, [x4, x8]
	ldrb	w9, [x2, x9]
	cmp	w7, w9
	b.eq	LBB0_13
	add	x8, x13, x16
	str	x8, [x1, #32]
	sub	x9, x5, x13
	tbz	w6, #0, LBB0_2
	b	LBB0_3
LBB0_18:
	mov	x8, #0
	str	x3, [x1, #32]
	b	LBB0_22
LBB0_19:
	add	x8, x16, x5
	str	x8, [x1, #32]
	tbnz	w6, #0, LBB0_21
	str	xzr, [x1, #48]
LBB0_21:
	stp	x16, x8, [x0, #8]
	mov	w8, #1
LBB0_22:
	str	x8, [x0]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	ldp	x20, x19, [sp, #16]
	ldp	x22, x21, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB0_23:
	.cfi_restore_state
	add	x8, x9, x16
	cmp	x3, x8
	csel	x0, x3, x8, hi
Lloh0:
	adrp	x2, l_alloc_8ae9795802ad53c9398ce2776784dbc3@PAGE
Lloh1:
	add	x2, x2, l_alloc_8ae9795802ad53c9398ce2776784dbc3@PAGEOFF
	mov	x1, x3
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB0_24:
Lloh2:
	adrp	x2, l_alloc_8deac4fa778727f9c004a28bc20bcda6@PAGE
Lloh3:
	add	x2, x2, l_alloc_8deac4fa778727f9c004a28bc20bcda6@PAGEOFF
	mov	x0, x9
	mov	x1, x3
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
LBB0_25:
Lloh4:
	adrp	x2, l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2@PAGE
Lloh5:
	add	x2, x2, l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2@PAGEOFF
	mov	x0, x8
	mov	x1, x5
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc

	.private_extern	__RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs6tqTQJNM79Z_8type_dag
	.globl	__RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs6tqTQJNM79Z_8type_dag
	.p2align	2
__RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x4, x3
	mov	x3, x2
	mov	x2, x1
	str	x0, [sp, #8]
Lloh6:
	adrp	x1, l_vtable.2@PAGE
Lloh7:
	add	x1, x1, l_vtable.2@PAGEOFF
	add	x0, sp, #8
	bl	__RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc

	.p2align	2
__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_BL_ECs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	x0, x1, [sp]
Lloh8:
	adrp	x2, l_vtable.3@PAGE
Lloh9:
	add	x2, x2, l_vtable.3@PAGEOFF
Lloh10:
	adrp	x7, l_alloc_7fe41e4be0c7245e8ff7e83adb85e94f@PAGE
Lloh11:
	add	x7, x7, l_alloc_7fe41e4be0c7245e8ff7e83adb85e94f@PAGEOFF
	bl	_OUTLINED_FUNCTION_0
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc

	.p2align	2
__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedINtNtB4_6result6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorEBL_ECs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	x0, x1, [sp]
Lloh12:
	adrp	x2, l_vtable.5@PAGE
Lloh13:
	add	x2, x2, l_vtable.5@PAGEOFF
Lloh14:
	adrp	x7, l_alloc_20850533bf96e06227afa83f2bc9aa63@PAGE
Lloh15:
	add	x7, x7, l_alloc_20850533bf96e06227afa83f2bc9aa63@PAGEOFF
	mov	x1, sp
	add	x3, sp, #8
	mov	w0, #1
	mov	x4, x2
	mov	x5, #0
	bl	__RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc

	.p2align	2
__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorBL_ECs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	x0, x1, [sp]
Lloh16:
	adrp	x2, l_vtable.6@PAGE
Lloh17:
	add	x2, x2, l_vtable.6@PAGEOFF
Lloh18:
	adrp	x7, l_alloc_0cbc87dd977768d531eddd3dcebd568b@PAGE
Lloh19:
	add	x7, x7, l_alloc_0cbc87dd977768d531eddd3dcebd568b@PAGEOFF
	bl	_OUTLINED_FUNCTION_0
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh16, Lloh17
	.cfi_endproc

	.p2align	2
__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeBL_ECs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	x0, x1, [sp]
Lloh20:
	adrp	x2, l_vtable.7@PAGE
Lloh21:
	add	x2, x2, l_vtable.7@PAGEOFF
Lloh22:
	adrp	x7, l_alloc_345a3daa91d0eb883779457fc7280ed5@PAGE
Lloh23:
	add	x7, x7, l_alloc_345a3daa91d0eb883779457fc7280ed5@PAGEOFF
	bl	_OUTLINED_FUNCTION_0
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh20, Lloh21
	.cfi_endproc

	.p2align	2
__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedRShBL_ECs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	x0, x1, [sp]
Lloh24:
	adrp	x2, l_vtable.8@PAGE
Lloh25:
	add	x2, x2, l_vtable.8@PAGEOFF
Lloh26:
	adrp	x7, l_alloc_366a20069fba01ea1b12f1ee9bd96211@PAGE
Lloh27:
	add	x7, x7, l_alloc_366a20069fba01ea1b12f1ee9bd96211@PAGEOFF
	bl	_OUTLINED_FUNCTION_0
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh24, Lloh25
	.cfi_endproc

	.p2align	2
__RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	blr	x0
	; InlineAsm Start
	; InlineAsm End
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6tqTQJNM79Z_8type_dag
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	tbz	w3, #0, LBB9_2
LBB9_1:
	mov	w0, #0
	ret
LBB9_2:
	ldr	x8, [x0]
	add	x8, x8, x1
	ldp	x9, x10, [x0, #16]
	cmp	x10, #4
	b.hs	LBB9_12
	mov	w11, #1
	b	LBB9_5
LBB9_4:
	lsl	w12, w11, w12
	bic	w2, w2, w12
	tst	w2, #0xffff
	b.eq	LBB9_1
LBB9_5:
	cbz	x10, LBB9_11
	rbit	w12, w2
	clz	w12, w12
	add	x13, x8, x12
	ldrb	w14, [x13, #1]
	ldrb	w15, [x9]
	cmp	w14, w15
	b.ne	LBB9_4
	cmp	x10, #1
	b.eq	LBB9_11
	ldrb	w14, [x13, #2]
	ldrb	w15, [x9, #1]
	cmp	w14, w15
	b.ne	LBB9_4
	cmp	x10, #2
	b.eq	LBB9_11
	ldrb	w13, [x13, #3]
	ldrb	w14, [x9, #2]
	cmp	w13, w14
	ccmp	x10, #3, #0, eq
	b.ne	LBB9_4
LBB9_11:
	mov	w0, #1
	ret
LBB9_12:
	add	x11, x9, x10
	mov	w12, #1
	b	LBB9_15
LBB9_13:
	ldr	w14, [x14]
	ldur	w15, [x11, #-4]
	cmp	w14, w15
	b.eq	LBB9_11
LBB9_14:
	lsl	w13, w12, w13
	bic	w2, w2, w13
	tst	w2, #0xffff
	b.eq	LBB9_1
LBB9_15:
	rbit	w13, w2
	clz	w13, w13
	add	x14, x8, x13
	add	x15, x14, #1
	add	x14, x15, x10
	sub	x14, x14, #4
	cmp	x15, x14
	b.hs	LBB9_13
	mov	x16, x9
LBB9_17:
	ldr	w17, [x15], #4
	ldr	w0, [x16], #4
	cmp	w17, w0
	b.ne	LBB9_14
	cmp	x15, x14
	b.lo	LBB9_17
	b	LBB9_13
	.cfi_endproc

	.p2align	2
__RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6tqTQJNM79Z_8type_dag
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNvCs6tqTQJNM79Z_8type_dag13assert_reject:
	.cfi_startproc
	sub	sp, sp, #176
	.cfi_def_cfa_offset 176
	stp	x24, x23, [sp, #112]
	stp	x22, x21, [sp, #128]
	stp	x20, x19, [sp, #144]
	stp	x29, x30, [sp, #160]
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x23, x1
	mov	x19, x0
Lloh28:
	adrp	x1, l_.memset_pattern@PAGE
Lloh29:
	add	x1, x1, l_.memset_pattern@PAGEOFF
	mov	x0, sp
	mov	w2, #16
	bl	_memset_pattern16
	ldr	q0, [sp]
	str	q0, [sp, #16]
	add	x8, sp, #72
	mov	x2, sp
	mov	x0, x23
	mov	x1, x22
	mov	x3, x21
	bl	__RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate
	ldr	x8, [sp, #72]
	cmp	x8, #1
	b.ne	LBB11_5
	ldp	q0, q1, [sp, #80]
	stp	q0, q1, [sp, #32]
	add	x0, sp, #32
	mov	x1, x20
	bl	__RNvXsF_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq
	tbz	w0, #0, LBB11_16
	ldrb	w8, [sp]
	ldrb	w9, [sp, #16]
	cmp	w8, w9
	b.ne	LBB11_15
	cbz	w8, LBB11_6
	ldr	w8, [sp, #4]
	ldr	w9, [sp, #20]
	b	LBB11_7
LBB11_5:
	mov	w8, #6
	b	LBB11_14
LBB11_6:
	ldrb	w8, [sp, #1]
	ldrb	w9, [sp, #17]
LBB11_7:
	cmp	w8, w9
	b.ne	LBB11_15
	ldrb	w8, [sp, #8]
	ldrb	w9, [sp, #24]
	cmp	w8, w9
	b.ne	LBB11_15
	cbz	w8, LBB11_11
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #28]
	b	LBB11_12
LBB11_11:
	ldrb	w8, [sp, #9]
	ldrb	w9, [sp, #25]
LBB11_12:
	cmp	w8, w9
	b.ne	LBB11_15
	mov	w8, #255
LBB11_14:
	strb	w8, [x19]
	.cfi_def_cfa wsp, 176
	ldp	x29, x30, [sp, #160]
	ldp	x20, x19, [sp, #144]
	ldp	x22, x21, [sp, #128]
	ldp	x24, x23, [sp, #112]
	add	sp, sp, #176
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB11_15:
	.cfi_restore_state
	mov	x0, sp
	add	x1, sp, #16
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_BL_ECs6tqTQJNM79Z_8type_dag
LBB11_16:
	add	x0, sp, #32
	mov	x1, x20
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorBL_ECs6tqTQJNM79Z_8type_dag
	.loh AdrpAdd	Lloh28, Lloh29
	.cfi_endproc

	.p2align	2
__RNvCs6tqTQJNM79Z_8type_dag18recursive_consumer:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x8, sp, #8
	mov	x0, x1
	mov	x1, x2
	mov	x2, x3
	mov	w3, #2
	bl	__RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate
	ldr	x8, [sp, #8]
	cmp	x8, #1
	b.ne	LBB12_2
	ldr	x8, [sp, #16]
	ldur	q0, [sp, #24]
	ldr	x9, [sp, #40]
	str	x8, [x19]
	stur	q0, [x19, #8]
	str	x9, [x19, #24]
	b	LBB12_9
LBB12_2:
	ldr	x9, [sp, #40]
	cbz	x9, LBB12_7
	mov	w8, #0
	ldr	x12, [sp, #32]
	mov	w10, #1
	mov	x11, x12
	b	LBB12_5
LBB12_4:
	ldr	w12, [x12, #4]
	eor	w12, w12, #0x3
	eor	w8, w12, w8, ror #29
	mov	x12, x11
	sub	x9, x9, #1
	cbz	x9, LBB12_8
LBB12_5:
	ldrb	w13, [x11], #8
	tbnz	w13, #0, LBB12_4
	ldrb	w12, [x12, #1]
	cmp	w12, #0
	cinc	w12, w10, ne
	eor	w8, w12, w8, ror #29
	mov	x12, x11
	sub	x9, x9, #1
	cbnz	x9, LBB12_5
	b	LBB12_8
LBB12_7:
	mov	w8, #0
LBB12_8:
	str	w8, [x19, #4]
	mov	w8, #255
	strb	w8, [x19]
LBB12_9:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.cfi_endproc

	.private_extern	__RNvCs6tqTQJNM79Z_8type_dag4main
	.globl	__RNvCs6tqTQJNM79Z_8type_dag4main
	.p2align	2
__RNvCs6tqTQJNM79Z_8type_dag4main:
	.cfi_startproc
Lloh30:
	adrp	x0, l_alloc_4776006e0a43248bf4954eb5625408e7@PAGE
Lloh31:
	add	x0, x0, l_alloc_4776006e0a43248bf4954eb5625408e7@PAGEOFF
	mov	w1, #4
	b	__RNvCs3O4ZRUMviTO_4test16test_main_static
	.loh AdrpAdd	Lloh30, Lloh31
	.cfi_endproc

	.p2align	2
__RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt:
	.cfi_startproc
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x20, x19, [sp, #32]
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	mov	x9, x1
	mov	x19, x0
	ldrb	w8, [x0]
	sub	w10, w8, #6
	cmp	w8, #5
	csinc	w8, w10, wzr, hi
	and	w8, w8, #0xff
	cmp	w8, #1
	b.gt	LBB14_3
	cbnz	w8, LBB14_6
Lloh32:
	adrp	x1, l_alloc_200ebb91f49df6906629ddcf737a98f2@PAGE
Lloh33:
	add	x1, x1, l_alloc_200ebb91f49df6906629ddcf737a98f2@PAGEOFF
	mov	x0, x9
	mov	w2, #25
	.cfi_def_cfa wsp, 64
	b	LBB14_5
LBB14_3:
	.cfi_restore_state
	.cfi_remember_state
	cmp	w8, #2
	b.ne	LBB14_7
Lloh34:
	adrp	x1, l_alloc_c9012ddda9c7d3e0809e5ad487d5dbaf@PAGE
Lloh35:
	add	x1, x1, l_alloc_c9012ddda9c7d3e0809e5ad487d5dbaf@PAGEOFF
	mov	x0, x9
	mov	w2, #26
	.cfi_def_cfa wsp, 64
LBB14_5:
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter9write_str
LBB14_6:
	.cfi_restore_state
Lloh36:
	adrp	x1, l_alloc_205495696f58003a123a312f976ed7c8@PAGE
Lloh37:
	add	x1, x1, l_alloc_205495696f58003a123a312f976ed7c8@PAGEOFF
	add	x8, sp, #8
	mov	x0, x9
	mov	w2, #15
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter11debug_tuple
Lloh38:
	adrp	x2, l_vtable.9@PAGE
Lloh39:
	add	x2, x2, l_vtable.9@PAGEOFF
	add	x0, sp, #8
	mov	x1, x19
	b	LBB14_8
LBB14_7:
Lloh40:
	adrp	x1, l_alloc_37eecd02b27b2a803515d9677500278a@PAGE
Lloh41:
	add	x1, x1, l_alloc_37eecd02b27b2a803515d9677500278a@PAGEOFF
	add	x8, sp, #8
	mov	x0, x9
	mov	w2, #14
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter11debug_tuple
Lloh42:
	adrp	x2, l_vtable.a@PAGE
Lloh43:
	add	x2, x2, l_vtable.a@PAGEOFF
	add	x0, sp, #8
	add	x1, x19, #8
LBB14_8:
	bl	__RNvMs2_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_10DebugTuple5field
	bl	__RNvMs2_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_10DebugTuple6finish
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh40, Lloh41
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_NtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x20, x19, [sp, #32]
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x20, [x0]
	add	x8, sp, #8
	mov	x0, x1
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter10debug_list
	str	x20, [sp, #24]
Lloh44:
	adrp	x19, l_vtable.0@PAGE
Lloh45:
	add	x19, x19, l_vtable.0@PAGEOFF
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x8, x20, #8
	str	x8, [sp, #24]
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	add	x0, sp, #8
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList6finish
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.loh AdrpAdd	Lloh44, Lloh45
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtCsjj9WfcXSjwO_14nudox_ir_vocab7DenseIdNtBy_4TypeENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x5, [x0]
	add	x9, x5, #4
	stur	x9, [x29, #-8]
Lloh46:
	adrp	x9, l_vtable.h@PAGE
Lloh47:
	add	x11, x9, l_vtable.h@PAGEOFF
	sub	x9, x29, #8
	mov	w10, #5
	stp	x9, x11, [sp, #8]
	str	x10, [sp]
Lloh48:
	adrp	x1, l_alloc_1ab8f3bcfc18061e9d6f0217059b41f5@PAGE
Lloh49:
	add	x1, x1, l_alloc_1ab8f3bcfc18061e9d6f0217059b41f5@PAGEOFF
Lloh50:
	adrp	x3, l_alloc_005de03493e3aaea3890cf93afea4072@PAGE
Lloh51:
	add	x3, x3, l_alloc_005de03493e3aaea3890cf93afea4072@PAGEOFF
Lloh52:
	adrp	x6, l_vtable.g@PAGE
Lloh53:
	add	x6, x6, l_vtable.g@PAGEOFF
Lloh54:
	adrp	x7, l_alloc_8cc6661f3cf091aca5a7bc91c52031fe@PAGE
Lloh55:
	add	x7, x7, l_alloc_8cc6661f3cf091aca5a7bc91c52031fe@PAGEOFF
	mov	x0, x8
	mov	w2, #7
	mov	w4, #3
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh46, Lloh47
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6marker11PhantomDataFENtCsjj9WfcXSjwO_14nudox_ir_vocab4TypeENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldp	x0, x1, [x1]
Lloh56:
	adrp	x8, l_alloc_f281a46e9987443bf5658c5f394cb876@PAGE
Lloh57:
	add	x8, x8, l_alloc_f281a46e9987443bf5658c5f394cb876@PAGEOFF
	mov	w9, #28
	stp	x8, x9, [sp]
	mov	x8, sp
Lloh58:
	adrp	x9, __RNvXs1i_NtCsgtPOCBgevO_4core3fmtReNtB6_7Display3fmtCs6tqTQJNM79Z_8type_dag@PAGE
Lloh59:
	add	x9, x9, __RNvXs1i_NtCsgtPOCBgevO_4core3fmtReNtB6_7Display3fmtCs6tqTQJNM79Z_8type_dag@PAGEOFF
	stp	x8, x9, [sp, #16]
Lloh60:
	adrp	x2, l_alloc_ccb3afc2d9f98e5ced738fc09e93fead@PAGE
Lloh61:
	add	x2, x2, l_alloc_ccb3afc2d9f98e5ced738fc09e93fead@PAGEOFF
	add	x3, sp, #16
	bl	__RNvNtCsgtPOCBgevO_4core3fmt5write
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh56, Lloh57
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6result6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w10, [x9]
	cmp	w10, #255
	b.eq	LBB18_2
	str	x9, [sp, #8]
Lloh62:
	adrp	x1, l_alloc_bf301217d548e4f1fd13189dd935c554@PAGE
Lloh63:
	add	x1, x1, l_alloc_bf301217d548e4f1fd13189dd935c554@PAGEOFF
Lloh64:
	adrp	x4, l_vtable.6@PAGE
Lloh65:
	add	x4, x4, l_vtable.6@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #3
	b	LBB18_3
LBB18_2:
	add	x9, x9, #4
	str	x9, [sp, #8]
Lloh66:
	adrp	x1, l_alloc_c73d17da7498663a071b898ac2218935@PAGE
Lloh67:
	add	x1, x1, l_alloc_c73d17da7498663a071b898ac2218935@PAGEOFF
Lloh68:
	adrp	x4, l_vtable.k@PAGE
Lloh69:
	add	x4, x4, l_vtable.k@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #2
LBB18_3:
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh66, Lloh67
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	ldr	x0, [x0]
	b	__RNvXsC_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag13PrimitiveTypeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w9, [x9]
	cmp	w9, #0
	mov	w9, #3
	cinc	x2, x9, eq
Lloh70:
	adrp	x9, l_alloc_b94f1f40ebe2eb842bd4cc55034553f1@PAGE
Lloh71:
	add	x9, x9, l_alloc_b94f1f40ebe2eb842bd4cc55034553f1@PAGEOFF
Lloh72:
	adrp	x10, l_alloc_e4fa82a2878eb5612d513befd6fc8a36@PAGE
Lloh73:
	add	x10, x10, l_alloc_e4fa82a2878eb5612d513befd6fc8a36@PAGEOFF
	csel	x1, x10, x9, ne
	mov	x0, x8
	b	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter9write_str
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh70, Lloh71
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag13TypeNodeFaultNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w10, [x9]
	cmp	w10, #1
	b.gt	LBB21_3
	cbnz	w10, LBB21_5
	add	x10, x9, #16
	stur	x10, [x29, #-8]
Lloh74:
	adrp	x10, l_vtable.b@PAGE
Lloh75:
	add	x10, x10, l_vtable.b@PAGEOFF
	str	x10, [sp, #16]
	sub	x10, x29, #8
	mov	w11, #6
	stp	x11, x10, [sp]
Lloh76:
	adrp	x1, l_alloc_eb66dd8df2025c3378e51480905e26b5@PAGE
Lloh77:
	add	x1, x1, l_alloc_eb66dd8df2025c3378e51480905e26b5@PAGEOFF
Lloh78:
	adrp	x3, l_alloc_715ad17152b7a3dfcbb2abff840befeb@PAGE
Lloh79:
	add	x3, x3, l_alloc_715ad17152b7a3dfcbb2abff840befeb@PAGEOFF
Lloh80:
	adrp	x6, l_vtable.d@PAGE
Lloh81:
	add	x6, x6, l_vtable.d@PAGEOFF
	add	x5, x9, #8
Lloh82:
	adrp	x7, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh83:
	add	x7, x7, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
	mov	x0, x8
	mov	w2, #9
	mov	w4, #8
	b	LBB21_8
LBB21_3:
	cmp	w10, #2
	b.ne	LBB21_7
	add	x9, x9, #1
	stur	x9, [x29, #-8]
Lloh84:
	adrp	x1, l_alloc_2a28b803340a522af1d6fe0d14a5f8e5@PAGE
Lloh85:
	add	x1, x1, l_alloc_2a28b803340a522af1d6fe0d14a5f8e5@PAGEOFF
Lloh86:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh87:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh88:
	adrp	x6, l_vtable.1@PAGE
Lloh89:
	add	x6, x6, l_vtable.1@PAGEOFF
	sub	x5, x29, #8
	mov	x0, x8
	mov	w2, #9
	b	LBB21_6
LBB21_5:
	add	x9, x9, #1
	stur	x9, [x29, #-8]
Lloh90:
	adrp	x1, l_alloc_cdb9aa4db1ff8f1d481eca6e672fb6b0@PAGE
Lloh91:
	add	x1, x1, l_alloc_cdb9aa4db1ff8f1d481eca6e672fb6b0@PAGEOFF
Lloh92:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh93:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh94:
	adrp	x6, l_vtable.1@PAGE
Lloh95:
	add	x6, x6, l_vtable.1@PAGEOFF
	sub	x5, x29, #8
	mov	x0, x8
	mov	w2, #3
LBB21_6:
	mov	w4, #6
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish
	b	LBB21_9
LBB21_7:
	add	x10, x9, #1
	stur	x10, [x29, #-8]
Lloh96:
	adrp	x10, l_vtable.1@PAGE
Lloh97:
	add	x10, x10, l_vtable.1@PAGEOFF
	str	x10, [sp, #16]
	sub	x10, x29, #8
	mov	w11, #10
	stp	x11, x10, [sp]
Lloh98:
	adrp	x1, l_alloc_2af43630e845fc262d2a6f3b2fa9b1c0@PAGE
Lloh99:
	add	x1, x1, l_alloc_2af43630e845fc262d2a6f3b2fa9b1c0@PAGEOFF
Lloh100:
	adrp	x3, l_alloc_5de5b778237022f7dfbd4b14eca9b832@PAGE
Lloh101:
	add	x3, x3, l_alloc_5de5b778237022f7dfbd4b14eca9b832@PAGEOFF
Lloh102:
	adrp	x6, l_vtable.e@PAGE
Lloh103:
	add	x6, x6, l_vtable.e@PAGEOFF
	add	x5, x9, #4
Lloh104:
	adrp	x7, l_alloc_c662412d9acfc8d757cfe16257349ca3@PAGE
Lloh105:
	add	x7, x7, l_alloc_c662412d9acfc8d757cfe16257349ca3@PAGEOFF
	mov	x0, x8
	mov	w2, #4
	mov	w4, #6
LBB21_8:
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish
LBB21_9:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh100, Lloh101
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdd	Lloh96, Lloh97
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag18TypeDagHeaderErrorNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w10, [x9], #1
	cbz	w10, LBB22_3
	cmp	w10, #1
	b.ne	LBB22_4
	str	x9, [sp, #8]
Lloh106:
	adrp	x1, l_alloc_d102eb289abff9d0655d27bf114c0746@PAGE
Lloh107:
	add	x1, x1, l_alloc_d102eb289abff9d0655d27bf114c0746@PAGEOFF
Lloh108:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh109:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh110:
	adrp	x6, l_vtable.1@PAGE
Lloh111:
	add	x6, x6, l_vtable.1@PAGEOFF
	add	x5, sp, #8
	mov	x0, x8
	mov	w2, #6
	b	LBB22_5
LBB22_3:
	str	x9, [sp, #8]
Lloh112:
	adrp	x1, l_alloc_d7b9b6c1829de9592f5bc6e83c4fc424@PAGE
Lloh113:
	add	x1, x1, l_alloc_d7b9b6c1829de9592f5bc6e83c4fc424@PAGEOFF
Lloh114:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh115:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh116:
	adrp	x6, l_vtable.1@PAGE
Lloh117:
	add	x6, x6, l_vtable.1@PAGEOFF
	add	x5, sp, #8
	mov	x0, x8
	mov	w2, #5
	b	LBB22_5
LBB22_4:
	str	x9, [sp, #8]
Lloh118:
	adrp	x1, l_alloc_830cc47b3e97457eae2b6eb6d050e986@PAGE
Lloh119:
	add	x1, x1, l_alloc_830cc47b3e97457eae2b6eb6d050e986@PAGEOFF
Lloh120:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh121:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh122:
	adrp	x6, l_vtable.1@PAGE
Lloh123:
	add	x6, x6, l_vtable.1@PAGEOFF
	add	x5, sp, #8
	mov	x0, x8
	mov	w2, #9
LBB22_5:
	mov	w4, #6
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh110, Lloh111
	.loh AdrpAdd	Lloh108, Lloh109
	.loh AdrpAdd	Lloh106, Lloh107
	.loh AdrpAdd	Lloh116, Lloh117
	.loh AdrpAdd	Lloh114, Lloh115
	.loh AdrpAdd	Lloh112, Lloh113
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh120, Lloh121
	.loh AdrpAdd	Lloh118, Lloh119
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB23_2
	add	x9, x9, #4
	str	x9, [sp, #8]
Lloh124:
	adrp	x1, l_alloc_a67487da2e66b342314634b825542faf@PAGE
Lloh125:
	add	x1, x1, l_alloc_a67487da2e66b342314634b825542faf@PAGEOFF
Lloh126:
	adrp	x4, l_vtable.j@PAGE
Lloh127:
	add	x4, x4, l_vtable.j@PAGEOFF
	b	LBB23_3
LBB23_2:
	add	x9, x9, #1
	str	x9, [sp, #8]
Lloh128:
	adrp	x1, l_alloc_2a28b803340a522af1d6fe0d14a5f8e5@PAGE
Lloh129:
	add	x1, x1, l_alloc_2a28b803340a522af1d6fe0d14a5f8e5@PAGEOFF
Lloh130:
	adrp	x4, l_vtable.i@PAGE
Lloh131:
	add	x4, x4, l_vtable.i@PAGEOFF
LBB23_3:
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #9
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh126, Lloh127
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh128, Lloh129
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x9, [x0]
	ldr	x9, [x9]
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB24_2
	add	x9, x9, #4
	str	x9, [sp, #8]
Lloh132:
	adrp	x1, l_alloc_a67487da2e66b342314634b825542faf@PAGE
Lloh133:
	add	x1, x1, l_alloc_a67487da2e66b342314634b825542faf@PAGEOFF
Lloh134:
	adrp	x4, l_vtable.j@PAGE
Lloh135:
	add	x4, x4, l_vtable.j@PAGEOFF
	b	LBB24_3
LBB24_2:
	add	x9, x9, #1
	str	x9, [sp, #8]
Lloh136:
	adrp	x1, l_alloc_2a28b803340a522af1d6fe0d14a5f8e5@PAGE
Lloh137:
	add	x1, x1, l_alloc_2a28b803340a522af1d6fe0d14a5f8e5@PAGEOFF
Lloh138:
	adrp	x4, l_vtable.i@PAGE
Lloh139:
	add	x4, x4, l_vtable.i@PAGEOFF
LBB24_3:
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #9
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh136, Lloh137
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRRShNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x8, [x0]
	ldp	x21, x20, [x8]
	add	x8, sp, #8
	mov	x0, x1
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter10debug_list
	cbz	x20, LBB25_3
Lloh140:
	adrp	x19, l_vtable.1@PAGE
Lloh141:
	add	x19, x19, l_vtable.1@PAGEOFF
LBB25_2:
	str	x21, [sp, #24]
	add	x21, x21, #1
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x2, x19
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList5entry
	subs	x20, x20, #1
	b.ne	LBB25_2
LBB25_3:
	add	x0, sp, #8
	bl	__RNvMs5_NtNtCsgtPOCBgevO_4core3fmt8buildersNtB5_9DebugList6finish
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
	.loh AdrpAdd	Lloh140, Lloh141
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtReNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	mov	x2, x1
	ldp	x8, x1, [x0]
	mov	x0, x8
	b	__RNvXsh_NtCsgtPOCBgevO_4core3fmteNtB5_5Debug3fmt
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRhNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB27_3
	tbnz	w8, #26, LBB27_4
	b	__RNvXNtNtNtCsgtPOCBgevO_4core3fmt3num3imphNtB6_7Display3fmt
LBB27_3:
	b	__RNvXse_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8LowerHex3fmt
LBB27_4:
	b	__RNvXsg_NtNtCsgtPOCBgevO_4core3fmt3numhNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRjNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB28_3
	tbnz	w8, #26, LBB28_4
	b	__RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt
LBB28_3:
	b	__RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt
LBB28_4:
	b	__RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRmNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB29_3
	tbnz	w8, #26, LBB29_4
	b	__RNvXs8_NtNtNtCsgtPOCBgevO_4core3fmt3num3impmNtB9_7Display3fmt
LBB29_3:
	b	__RNvXsu_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8LowerHex3fmt
LBB29_4:
	b	__RNvXsw_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXs1i_NtCsgtPOCBgevO_4core3fmtReNtB6_7Display3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	mov	x2, x1
	ldp	x8, x1, [x0]
	mov	x0, x8
	b	__RNvXsi_NtCsgtPOCBgevO_4core3fmteNtB5_7Display3fmt
	.cfi_endproc

	.p2align	2
__RNvXsC_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldrb	w9, [x0]
	cmp	w9, #2
	b.gt	LBB31_4
	cbz	w9, LBB31_7
	cmp	w9, #1
	b.ne	LBB31_9
	add	x9, x0, #1
	stur	x9, [x29, #-8]
Lloh142:
	adrp	x1, l_alloc_b2243a0a9fd6f5181b6e5ba2b6488d3a@PAGE
Lloh143:
	add	x1, x1, l_alloc_b2243a0a9fd6f5181b6e5ba2b6488d3a@PAGEOFF
Lloh144:
	adrp	x4, l_vtable.c@PAGE
Lloh145:
	add	x4, x4, l_vtable.c@PAGEOFF
	sub	x3, x29, #8
	mov	x0, x8
	mov	w2, #6
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish
	b	LBB31_13
LBB31_4:
	cmp	w9, #3
	b.eq	LBB31_8
	cmp	w9, #4
	b.ne	LBB31_10
	add	x9, x0, #8
	stur	x9, [x29, #-8]
Lloh146:
	adrp	x9, l_vtable.f@PAGE
Lloh147:
	add	x11, x9, l_vtable.f@PAGEOFF
	sub	x9, x29, #8
	mov	w10, #5
	stp	x9, x11, [sp, #8]
	str	x10, [sp]
Lloh148:
	adrp	x1, l_alloc_1e2d27e83e9b70f610a2d8f4ab61fc2e@PAGE
Lloh149:
	add	x1, x1, l_alloc_1e2d27e83e9b70f610a2d8f4ab61fc2e@PAGEOFF
Lloh150:
	adrp	x3, l_alloc_d466f777e26b5a6c15c5498a3130191d@PAGE
Lloh151:
	add	x3, x3, l_alloc_d466f777e26b5a6c15c5498a3130191d@PAGEOFF
Lloh152:
	adrp	x6, l_vtable.e@PAGE
Lloh153:
	add	x6, x6, l_vtable.e@PAGEOFF
	add	x5, x0, #4
Lloh154:
	adrp	x7, l_alloc_652e7c9d7b77be2ac6e01717f701606a@PAGE
Lloh155:
	add	x7, x7, l_alloc_652e7c9d7b77be2ac6e01717f701606a@PAGEOFF
	mov	x0, x8
	mov	w2, #4
	mov	w4, #7
	b	LBB31_12
LBB31_7:
	add	x9, x0, #8
	stur	x9, [x29, #-8]
Lloh156:
	adrp	x1, l_alloc_ea8e8baf0be5855bbef17ce48226036b@PAGE
Lloh157:
	add	x1, x1, l_alloc_ea8e8baf0be5855bbef17ce48226036b@PAGEOFF
Lloh158:
	adrp	x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh159:
	add	x3, x3, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
Lloh160:
	adrp	x6, l_vtable.b@PAGE
Lloh161:
	add	x6, x6, l_vtable.b@PAGEOFF
	sub	x5, x29, #8
	mov	x0, x8
	mov	w2, #17
	mov	w4, #6
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field1_finish
	b	LBB31_13
LBB31_8:
	add	x9, x0, #16
	stur	x9, [x29, #-8]
Lloh162:
	adrp	x9, l_vtable.b@PAGE
Lloh163:
	add	x11, x9, l_vtable.b@PAGEOFF
	sub	x9, x29, #8
	mov	w10, #9
	stp	x9, x11, [sp, #8]
	str	x10, [sp]
Lloh164:
	adrp	x1, l_alloc_5c9910a63c1c5173176bd3aa76a8ac20@PAGE
Lloh165:
	add	x1, x1, l_alloc_5c9910a63c1c5173176bd3aa76a8ac20@PAGEOFF
Lloh166:
	adrp	x3, l_alloc_715ad17152b7a3dfcbb2abff840befeb@PAGE
Lloh167:
	add	x3, x3, l_alloc_715ad17152b7a3dfcbb2abff840befeb@PAGEOFF
Lloh168:
	adrp	x6, l_vtable.d@PAGE
Lloh169:
	add	x6, x6, l_vtable.d@PAGEOFF
	add	x5, x0, #8
Lloh170:
	adrp	x7, l_alloc_700d5d683c25860e3d40207214c9c99c@PAGE
Lloh171:
	add	x7, x7, l_alloc_700d5d683c25860e3d40207214c9c99c@PAGEOFF
	mov	x0, x8
	mov	w2, #15
	b	LBB31_11
LBB31_9:
	add	x9, x0, #16
	stur	x9, [x29, #-8]
Lloh172:
	adrp	x9, l_vtable.b@PAGE
Lloh173:
	add	x11, x9, l_vtable.b@PAGEOFF
	sub	x9, x29, #8
	mov	w10, #6
	stp	x9, x11, [sp, #8]
	str	x10, [sp]
Lloh174:
	adrp	x1, l_alloc_4d3c10a7785e3cacd7635396354c2688@PAGE
Lloh175:
	add	x1, x1, l_alloc_4d3c10a7785e3cacd7635396354c2688@PAGEOFF
Lloh176:
	adrp	x3, l_alloc_bebfed686e6a6f31c99c69b171066b8a@PAGE
Lloh177:
	add	x3, x3, l_alloc_bebfed686e6a6f31c99c69b171066b8a@PAGEOFF
Lloh178:
	adrp	x6, l_vtable.d@PAGE
Lloh179:
	add	x6, x6, l_vtable.d@PAGEOFF
	add	x5, x0, #8
Lloh180:
	adrp	x7, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh181:
	add	x7, x7, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
	mov	x0, x8
	mov	w2, #8
	b	LBB31_11
LBB31_10:
	add	x9, x0, #16
	stur	x9, [x29, #-8]
Lloh182:
	adrp	x9, l_vtable.b@PAGE
Lloh183:
	add	x11, x9, l_vtable.b@PAGEOFF
	sub	x9, x29, #8
	mov	w10, #6
	stp	x9, x11, [sp, #8]
	str	x10, [sp]
Lloh184:
	adrp	x1, l_alloc_d7a7f078b751cfeba410ab5cc24bfa07@PAGE
Lloh185:
	add	x1, x1, l_alloc_d7a7f078b751cfeba410ab5cc24bfa07@PAGEOFF
Lloh186:
	adrp	x3, l_alloc_bebfed686e6a6f31c99c69b171066b8a@PAGE
Lloh187:
	add	x3, x3, l_alloc_bebfed686e6a6f31c99c69b171066b8a@PAGEOFF
Lloh188:
	adrp	x6, l_vtable.d@PAGE
Lloh189:
	add	x6, x6, l_vtable.d@PAGEOFF
	add	x5, x0, #8
Lloh190:
	adrp	x7, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGE
Lloh191:
	add	x7, x7, l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc@PAGEOFF
	mov	x0, x8
	mov	w2, #9
LBB31_11:
	mov	w4, #8
LBB31_12:
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish
LBB31_13:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh156, Lloh157
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdd	Lloh168, Lloh169
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh180, Lloh181
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdd	Lloh190, Lloh191
	.loh AdrpAdd	Lloh188, Lloh189
	.loh AdrpAdd	Lloh186, Lloh187
	.loh AdrpAdd	Lloh184, Lloh185
	.loh AdrpAdd	Lloh182, Lloh183
	.cfi_endproc

	.p2align	2
__RNvXsF_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq:
	.cfi_startproc
	ldrb	w8, [x0]
	ldrb	w9, [x1]
	cmp	w8, w9
	b.ne	LBB32_20
	cmp	w8, #2
	b.gt	LBB32_5
	cbz	w8, LBB32_15
	cmp	w8, #1
	b.ne	LBB32_13
	ldrb	w8, [x0, #1]
	ldrb	w9, [x0, #2]
	and	w9, w9, #0xff
	ldrb	w10, [x1, #1]
	ldrb	w11, [x1, #2]
	and	w11, w11, #0xff
	cmp	w8, w10
	ccmp	w9, w11, #0, eq
	cset	w0, eq
	ret
LBB32_5:
	cmp	w8, #3
	b.eq	LBB32_13
	cmp	w8, #4
	b.ne	LBB32_13
	ldr	w8, [x0, #4]
	ldr	w9, [x1, #4]
	cmp	w8, w9
	b.ne	LBB32_20
	ldrb	w8, [x0, #8]
	ldrb	w9, [x1, #8]
	cmp	w8, w9
	b.ne	LBB32_20
	cmp	w8, #1
	b.gt	LBB32_16
	cbnz	w8, LBB32_17
	ldr	x8, [x0, #16]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.ne	LBB32_20
	ldr	x8, [x0, #24]
	ldr	x9, [x1, #24]
	cmp	x8, x9
	cset	w0, eq
	ret
LBB32_13:
	ldr	x8, [x0, #8]
	ldr	x9, [x1, #8]
	cmp	x8, x9
	b.ne	LBB32_20
	ldr	x8, [x0, #16]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	cset	w0, eq
	ret
LBB32_15:
	ldr	x8, [x0, #8]
	ldr	x9, [x1, #8]
	cmp	x8, x9
	cset	w0, eq
	ret
LBB32_16:
	cmp	w8, #2
	b.ne	LBB32_18
LBB32_17:
	ldrb	w8, [x0, #9]
	ldrb	w9, [x1, #9]
	cmp	w8, w9
	cset	w0, eq
	ret
LBB32_18:
	ldrb	w8, [x0, #9]
	ldrb	w9, [x1, #9]
	cmp	w8, w9
	b.ne	LBB32_20
	ldr	w8, [x0, #12]
	ldr	w9, [x1, #12]
	cmp	w8, w9
	cset	w0, eq
	ret
LBB32_20:
	mov	w0, #0
	ret
	.cfi_endproc

	.p2align	2
__RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt:
	.cfi_startproc
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB33_3
	tbnz	w8, #26, LBB33_4
	b	__RNvXs8_NtNtNtCsgtPOCBgevO_4core3fmt3num3impmNtB9_7Display3fmt
LBB33_3:
	b	__RNvXsu_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8LowerHex3fmt
LBB33_4:
	b	__RNvXsw_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt:
	.cfi_startproc
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB34_3
	tbnz	w8, #26, LBB34_4
	b	__RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt
LBB34_3:
	b	__RNvXs6_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8LowerHex3fmt
LBB34_4:
	b	__RNvXs8_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXsf_Csjj9WfcXSjwO_14nudox_ir_vocabINtB5_7DenseIdNtB5_4TypeENtNtCsgtPOCBgevO_4core3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	mov	x5, x0
	add	x9, x0, #4
	stur	x9, [x29, #-8]
Lloh192:
	adrp	x9, l_vtable.h@PAGE
Lloh193:
	add	x11, x9, l_vtable.h@PAGEOFF
	sub	x9, x29, #8
	mov	w10, #5
	stp	x9, x11, [sp, #8]
	str	x10, [sp]
Lloh194:
	adrp	x1, l_alloc_1ab8f3bcfc18061e9d6f0217059b41f5@PAGE
Lloh195:
	add	x1, x1, l_alloc_1ab8f3bcfc18061e9d6f0217059b41f5@PAGEOFF
Lloh196:
	adrp	x3, l_alloc_005de03493e3aaea3890cf93afea4072@PAGE
Lloh197:
	add	x3, x3, l_alloc_005de03493e3aaea3890cf93afea4072@PAGEOFF
Lloh198:
	adrp	x6, l_vtable.g@PAGE
Lloh199:
	add	x6, x6, l_vtable.g@PAGEOFF
Lloh200:
	adrp	x7, l_alloc_8cc6661f3cf091aca5a7bc91c52031fe@PAGE
Lloh201:
	add	x7, x7, l_alloc_8cc6661f3cf091aca5a7bc91c52031fe@PAGEOFF
	mov	x0, x8
	mov	w2, #7
	mov	w4, #3
	bl	__RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter26debug_struct_field2_finish
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh200, Lloh201
	.loh AdrpAdd	Lloh198, Lloh199
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh192, Lloh193
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI36_0:
	.byte	1
	.byte	2
	.byte	4
	.byte	8
	.byte	16
	.byte	32
	.byte	64
	.byte	128
	.byte	1
	.byte	2
	.byte	4
	.byte	8
	.byte	16
	.byte	32
	.byte	64
	.byte	128
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in:
	.cfi_startproc
	sub	sp, sp, #384
	.cfi_def_cfa_offset 384
	stp	x28, x27, [sp, #288]
	stp	x26, x25, [sp, #304]
	stp	x24, x23, [sp, #320]
	stp	x22, x21, [sp, #336]
	stp	x20, x19, [sp, #352]
	stp	x29, x30, [sp, #368]
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	cbz	x1, LBB36_23
	mov	x19, x1
	cmp	x1, x3
	b.hs	LBB36_6
	subs	x24, x19, #1
	b.ne	LBB36_8
	ldrb	w0, [x0]
	cmp	x3, #15
	b.hi	LBB36_13
	sub	x8, x3, #1
LBB36_5:
	ldrb	w9, [x2], #1
	cmp	w9, w0
	cset	w21, eq
	ccmp	x8, #0, #4, ne
	sub	x8, x8, #1
	b.ne	LBB36_5
	b	LBB36_48
LBB36_6:
	b.ne	LBB36_12
	mov	x1, x2
	mov	x2, x19
	bl	_memcmp
	cmp	w0, #0
	cset	w21, eq
	b	LBB36_48
LBB36_8:
	cmp	x19, #33
	b.hs	LBB36_24
	ldrb	w8, [x0]
	cmp	x19, #2
	mov	x26, x2
	str	x3, [sp, #144]
	b.ne	LBB36_14
	cmp	x3, #17
	b.lo	LBB36_19
	dup.16b	v2, w8
	ldrb	w9, [x0, #1]
	mov	w20, #1
	b	LBB36_26
LBB36_12:
	mov	w21, #0
	b	LBB36_48
LBB36_13:
	mov	x1, x2
	mov	x2, x3
	bl	__RNvNtNtCsgtPOCBgevO_4core5slice6memchr14memchr_aligned
	cmp	x0, #1
	cset	w21, eq
	b	LBB36_48
LBB36_14:
	subs	x9, x19, #4
	csel	x10, xzr, x9, lo
	sub	x11, x0, #1
	mov	x12, x19
LBB36_15:
	cmp	x10, x12
	b.hs	LBB36_24
	sub	x20, x12, #1
	cmp	x20, x19
	b.hs	LBB36_50
	ldrb	w9, [x11, x12]
	mov	x12, x20
	cmp	w9, w8
	b.eq	LBB36_15
	add	x10, x19, #15
	cmp	x3, x10
	b.hs	LBB36_25
LBB36_19:
	mov	x1, x0
	mov	x0, x2
	mov	x20, x1
	mov	x2, x19
	bl	_memcmp
	cbz	w0, LBB36_23
	add	x22, x26, #1
	ldr	x8, [sp, #144]
	sub	x23, x8, #1
LBB36_21:
	cmp	x19, x23
	cset	w21, ls
	b.hi	LBB36_48
	mov	x0, x22
	mov	x1, x20
	mov	x2, x19
	bl	_memcmp
	add	x22, x22, #1
	sub	x23, x23, #1
	cbnz	w0, LBB36_21
	b	LBB36_48
LBB36_23:
	mov	w21, #1
	b	LBB36_48
LBB36_24:
	add	x8, sp, #176
	mov	x9, x0
	mov	x0, x2
	mov	x1, x3
	mov	x2, x9
	mov	x3, x19
	bl	__RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new
	add	x0, sp, #152
	add	x1, sp, #176
	bl	__RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match
	ldr	w21, [sp, #152]
	b	LBB36_48
LBB36_25:
	dup.16b	v2, w8
LBB36_26:
	dup.16b	v3, w9
	add	x8, x0, #1
	stp	x2, x3, [sp, #176]
	add	x9, x19, #63
	adrp	x10, lCPI36_0@PAGE
	stp	x8, x24, [sp, #192]
	cmp	x9, x3
	stp	q3, q2, [sp, #112]
	b.hs	LBB36_39
	mov	x22, #0
	add	x28, x19, #127
	add	x8, x20, x2
	add	x27, x8, #32
	add	x25, x2, #48
	ldr	q4, [x10, lCPI36_0@PAGEOFF]
	str	q4, [sp, #64]
LBB36_28:
	add	x8, x25, x22
	add	x9, x27, x22
	ldp	q0, q17, [x8, #-48]
	cmeq.16b	v0, v0, v2
	ldp	q1, q18, [x9, #-32]
	cmeq.16b	v1, v1, v3
	and.16b	v0, v0, v1
	ldp	q7, q5, [x8, #-16]
	ldp	q16, q6, [x9]
	umaxv.16b	b1, v0
	fmov	w8, s1
	tbnz	w8, #0, LBB36_35
	mov	w21, #0
LBB36_30:
	cmeq.16b	v0, v17, v2
	cmeq.16b	v1, v18, v3
	and.16b	v0, v0, v1
	and.16b	v0, v0, v4
	ext.16b	v1, v0, v0, #8
	zip1.16b	v0, v0, v1
	addv.8h	h0, v0
	fmov	w8, s0
	tst	w8, #0xffff
	b.ne	LBB36_36
LBB36_31:
	cmeq.16b	v0, v7, v2
	cmeq.16b	v1, v16, v3
	and.16b	v0, v0, v1
	and.16b	v0, v0, v4
	ext.16b	v1, v0, v0, #8
	zip1.16b	v0, v0, v1
	addv.8h	h0, v0
	fmov	w8, s0
	tst	w8, #0xffff
	b.ne	LBB36_37
LBB36_32:
	cmeq.16b	v0, v5, v2
	cmeq.16b	v1, v6, v3
	and.16b	v0, v0, v1
	and.16b	v0, v0, v4
	ext.16b	v1, v0, v0, #8
	zip1.16b	v0, v0, v1
	addv.8h	h0, v0
	fmov	w8, s0
	tst	w8, #0xffff
	b.ne	LBB36_38
	add	x23, x22, #64
	add	x8, x28, x22
	cmp	x8, x3
	b.hs	LBB36_40
LBB36_34:
	mov	x22, x23
	tbz	w21, #0, LBB36_28
	b	LBB36_40
LBB36_35:
	and.16b	v0, v0, v4
	ext.16b	v1, v0, v0, #8
	zip1.16b	v0, v0, v1
	addv.8h	h0, v0
	fmov	w2, s0
	add	x0, sp, #176
	mov	x1, x22
	mov	w3, #0
	stp	q6, q5, [sp, #80]
	stp	q16, q7, [sp, #32]
	stp	q18, q17, [sp]
	bl	__RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag
	ldp	q18, q17, [sp]
	ldp	q16, q7, [sp, #32]
	ldp	q6, q5, [sp, #80]
	ldr	q4, [sp, #64]
	ldp	q3, q2, [sp, #112]
	ldr	x3, [sp, #144]
	mov	x2, x26
	mov	x21, x0
	b	LBB36_30
LBB36_36:
	add	x0, sp, #176
	add	x1, x22, #16
	mov	x2, x8
	mov	x3, x21
	stp	q6, q5, [sp, #80]
	stp	q16, q7, [sp, #32]
	bl	__RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag
	ldp	q16, q7, [sp, #32]
	ldp	q6, q5, [sp, #80]
	ldr	q4, [sp, #64]
	ldp	q3, q2, [sp, #112]
	ldr	x3, [sp, #144]
	mov	x2, x26
	orr	w21, w21, w0
	b	LBB36_31
LBB36_37:
	add	x0, sp, #176
	add	x1, x22, #32
	mov	x2, x8
	mov	x3, x21
	stp	q6, q5, [sp, #80]
	bl	__RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag
	ldp	q6, q5, [sp, #80]
	ldr	q4, [sp, #64]
	ldp	q3, q2, [sp, #112]
	ldr	x3, [sp, #144]
	mov	x2, x26
	orr	w21, w21, w0
	b	LBB36_32
LBB36_38:
	add	x0, sp, #176
	add	x1, x22, #48
	mov	x2, x8
	mov	x3, x21
	bl	__RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag
	ldr	q4, [sp, #64]
	ldp	q3, q2, [sp, #112]
	ldr	x3, [sp, #144]
	mov	x2, x26
	orr	w21, w21, w0
	add	x23, x22, #64
	add	x8, x28, x22
	cmp	x8, x3
	b.lo	LBB36_34
	b	LBB36_40
LBB36_39:
	mov	x23, #0
	mov	w21, #0
LBB36_40:
	tbnz	w21, #0, LBB36_47
	add	x8, x19, x23
	add	x8, x8, #15
	cmp	x8, x3
	b.hs	LBB36_47
	add	x19, x19, #31
	add	x22, x2, x20
Lloh202:
	adrp	x8, lCPI36_0@PAGE
Lloh203:
	ldr	q0, [x8, lCPI36_0@PAGEOFF]
	str	q0, [sp, #96]
LBB36_43:
	ldr	q0, [x2, x23]
	ldr	q1, [x22, x23]
	cmeq.16b	v0, v0, v2
	cmeq.16b	v1, v1, v3
	and.16b	v0, v0, v1
	umaxv.16b	b1, v0
	fmov	w8, s1
	tbnz	w8, #0, LBB36_46
	mov	w21, #0
	add	x8, x19, x23
	cmp	x8, x3
	b.hs	LBB36_47
LBB36_45:
	add	x23, x23, #16
	tbz	w21, #0, LBB36_43
	b	LBB36_47
LBB36_46:
	ldr	q1, [sp, #96]
	and.16b	v0, v0, v1
	ext.16b	v1, v0, v0, #8
	zip1.16b	v0, v0, v1
	addv.8h	h0, v0
	fmov	w2, s0
	add	x0, sp, #176
	mov	x1, x23
	mov	w3, #0
	bl	__RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag
	ldp	q3, q2, [sp, #112]
	ldr	x3, [sp, #144]
	mov	x2, x26
	mov	x21, x0
	add	x8, x19, x23
	cmp	x8, x3
	b.lo	LBB36_45
LBB36_47:
	sub	x8, x3, x24
	sub	x1, x8, #16
	add	x8, x2, x1
	ldr	q0, [x8, x20]
	ldr	q1, [x8]
	cmeq.16b	v1, v1, v2
	cmeq.16b	v0, v0, v3
	and.16b	v0, v1, v0
	umaxv.16b	b1, v0
	fmov	w8, s1
	tbnz	w8, #0, LBB36_49
LBB36_48:
	mov	x0, x21
	.cfi_def_cfa wsp, 384
	ldp	x29, x30, [sp, #368]
	ldp	x20, x19, [sp, #352]
	ldp	x22, x21, [sp, #336]
	ldp	x24, x23, [sp, #320]
	ldp	x26, x25, [sp, #304]
	ldp	x28, x27, [sp, #288]
	add	sp, sp, #384
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB36_49:
	.cfi_restore_state
Lloh204:
	adrp	x8, lCPI36_0@PAGE
Lloh205:
	ldr	q1, [x8, lCPI36_0@PAGEOFF]
	and.16b	v0, v0, v1
	ext.16b	v1, v0, v0, #8
	zip1.16b	v0, v0, v1
	addv.8h	h0, v0
	fmov	w2, s0
	add	x0, sp, #176
	mov	x3, x21
	bl	__RNCNvNtNtCsgtPOCBgevO_4core3str7pattern13simd_containss0_0Cs6tqTQJNM79Z_8type_dag
	orr	w21, w21, w0
	b	LBB36_48
LBB36_50:
Lloh206:
	adrp	x2, l_alloc_fc59cbe87b130fa4fa1d3a2e82d342fe@PAGE
Lloh207:
	add	x2, x2, l_alloc_fc59cbe87b130fa4fa1d3a2e82d342fe@PAGEOFF
	mov	x0, x20
	mov	x1, x19
	bl	__RNvNtCsgtPOCBgevO_4core9panicking18panic_bounds_check
	.loh AdrpLdr	Lloh202, Lloh203
	.loh AdrpLdr	Lloh204, Lloh205
	.loh AdrpAdd	Lloh206, Lloh207
	.cfi_endproc

	.p2align	2
__RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match:
	.cfi_startproc
	mov	x9, x1
	ldr	w8, [x9], #8
	tbz	w8, #0, LBB37_3
	ldr	x8, [x1, #56]
	ldp	x2, x3, [x1, #72]
	ldp	x4, x5, [x1, #88]
	mov	x1, x9
	cmn	x8, #1
	b.eq	LBB37_8
	mov	w6, #0
	b	__RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs6tqTQJNM79Z_8type_dag
LBB37_3:
	ldrb	w8, [x1, #26]
	tbz	w8, #0, LBB37_5
	str	xzr, [x0]
	ret
LBB37_5:
	ldr	x2, [x1, #8]
	ldp	x8, x3, [x1, #72]
	ldrb	w10, [x1, #24]
	cbz	x2, LBB37_10
	cmp	x2, x3
	b.hs	LBB37_9
	ldrsb	w11, [x8, x2]
	cmn	w11, #64
	b.ge	LBB37_10
	b	LBB37_28
LBB37_8:
	mov	w6, #1
	b	__RINvMsx_NtNtCsgtPOCBgevO_4core3str7patternNtB6_14TwoWaySearcher4nextNtB6_9MatchOnlyECs6tqTQJNM79Z_8type_dag
LBB37_9:
	b.ne	LBB37_28
LBB37_10:
	cmp	x2, x3
	b.ne	LBB37_13
	mov	w9, #1
	bic	w8, w9, w10
	strb	w8, [x1, #24]
	tbnz	w10, #0, LBB37_35
	strb	w9, [x1, #26]
	str	xzr, [x0]
	ret
LBB37_13:
	add	x12, x8, x2
	ldrsb	w13, [x12]
	and	w11, w13, #0xff
	tbz	w13, #31, LBB37_18
	ldrb	w13, [x12, #1]
	and	w14, w13, #0x3f
	cmp	w11, #224
	b.lo	LBB37_17
	and	w13, w11, #0x1f
	ldrb	w15, [x12, #2]
	and	w15, w15, #0x3f
	orr	w14, w15, w14, lsl #6
	cmp	w11, #240
	b.lo	LBB37_36
	ldrb	w11, [x12, #3]
	and	w11, w11, #0x3f
	orr	w11, w11, w14, lsl #6
	bfi	w11, w13, #18, #3
	tbz	w10, #0, LBB37_19
	b	LBB37_34
LBB37_17:
	bfi	w14, w11, #6, #5
	mov	x11, x14
LBB37_18:
	tbnz	w10, #0, LBB37_34
LBB37_19:
	cmp	w11, #128
	b.hs	LBB37_21
	mov	w10, #1
	b	LBB37_24
LBB37_21:
	cmp	w11, #2048
	b.hs	LBB37_23
	mov	w10, #2
	b	LBB37_24
LBB37_23:
	cmp	w11, #16, lsl #12
	mov	w10, #3
	cinc	x10, x10, hs
LBB37_24:
	adds	x11, x10, x2
	str	x11, [x9]
	b.eq	LBB37_30
	cmp	x11, x3
	b.hs	LBB37_29
	ldrsb	w9, [x8, x11]
	cmn	w9, #64
	b.ge	LBB37_30
LBB37_27:
	mov	w10, #1
	mov	x2, x11
LBB37_28:
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w9, #1
	bic	w9, w9, w10
	strb	w9, [x1, #24]
Lloh208:
	adrp	x4, l_alloc_de5e2f1dd01253ae804bfe6ba3503da0@PAGE
Lloh209:
	add	x4, x4, l_alloc_de5e2f1dd01253ae804bfe6ba3503da0@PAGEOFF
	mov	x0, x8
	mov	x1, x3
	bl	__RNvNtCsgtPOCBgevO_4core3str16slice_error_fail
LBB37_29:
	.cfi_def_cfa wsp, 0
	.cfi_same_value w30
	.cfi_same_value w29
	b.ne	LBB37_27
LBB37_30:
	mov	x2, x3
	cmp	x11, x3
	b.eq	LBB37_34
	ldrsb	w8, [x8, x11]
	tbz	w8, #31, LBB37_33
	and	w8, w8, #0xff
	cmp	w8, #224
LBB37_33:
	mov	x2, x11
LBB37_34:
	strb	wzr, [x1, #24]
	mov	x3, x2
LBB37_35:
	stp	x3, x3, [x0, #8]
	mov	w8, #1
	str	x8, [x0]
	ret
LBB37_36:
	orr	w11, w14, w13, lsl #12
	tbz	w10, #0, LBB37_19
	b	LBB37_34
	.loh AdrpAdd	Lloh208, Lloh209
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI38_0:
	.quad	0
	.quad	6203
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvYNCNvCs6tqTQJNM79Z_8type_dag59type_dag_layout_and_cursor_source_are_observed_on_this_host0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_:
	.cfi_startproc
	sub	sp, sp, #208
	.cfi_def_cfa_offset 208
	stp	x22, x21, [sp, #160]
	stp	x20, x19, [sp, #176]
	stp	x29, x30, [sp, #192]
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	mov	x19, x8
Lloh210:
	adrp	x0, l_alloc_a15ed431d12b61b552a8b4f468521cb1@PAGE
Lloh211:
	add	x0, x0, l_alloc_a15ed431d12b61b552a8b4f468521cb1@PAGEOFF
Lloh212:
	adrp	x2, l_alloc_caf81f150f8e2a3f46956011ce18ea9a@PAGE
Lloh213:
	add	x2, x2, l_alloc_caf81f150f8e2a3f46956011ce18ea9a@PAGEOFF
	mov	x8, sp
	mov	w1, #6203
	mov	w3, #23
	bl	__RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new
Lloh214:
	adrp	x8, lCPI38_0@PAGE
Lloh215:
	ldr	q0, [x8, lCPI38_0@PAGEOFF]
	stur	q0, [sp, #104]
	mov	w8, #1
	strh	w8, [sp, #120]
	sub	x0, x29, #64
	mov	x1, sp
	bl	__RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match
	ldur	w8, [x29, #-64]
	tbz	w8, #0, LBB38_4
	ldur	x8, [x29, #-48]
	str	x8, [sp, #104]
	ldrb	w8, [sp, #121]
	tbnz	w8, #0, LBB38_8
	ldr	x21, [sp, #72]
	sub	x0, x29, #64
	mov	x1, sp
	bl	__RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match
	ldur	x8, [x29, #-64]
	cmp	x8, #1
	b.ne	LBB38_7
	ldur	x8, [x29, #-56]
	ldr	x9, [sp, #104]
	sub	x20, x8, x9
	add	x0, x21, x9
	b	LBB38_15
LBB38_4:
	ldrb	w8, [sp, #121]
	tbnz	w8, #0, LBB38_8
	ldrb	w8, [sp, #120]
	tbnz	w8, #0, LBB38_8
	ldp	x9, x8, [sp, #104]
	cmp	x8, x9
	b	LBB38_8
LBB38_7:
	ldrb	w8, [sp, #121]
	tbz	w8, #0, LBB38_11
LBB38_8:
Lloh216:
	adrp	x8, l_alloc_54bb4d60df512e09680a75e9c196c327@PAGE
Lloh217:
	add	x8, x8, l_alloc_54bb4d60df512e09680a75e9c196c327@PAGEOFF
	mov	w9, #21
LBB38_9:
	mov	w10, #9
	strb	w10, [sp]
	stp	x8, x9, [sp, #8]
	mov	x8, sp
Lloh218:
	adrp	x9, __RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt@PAGE
Lloh219:
	add	x9, x9, __RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt@PAGEOFF
	stp	x8, x9, [x29, #-64]
Lloh220:
	adrp	x0, l_alloc_26978532d6004174455ea2130c477035@PAGE
Lloh221:
	add	x0, x0, l_alloc_26978532d6004174455ea2130c477035@PAGEOFF
	sub	x1, x29, #64
	bl	__RNvNtNtCsa9BKTri5B3M_3std2io5stdio23attempt_print_to_stderr
	mov	w8, #1
	stur	w8, [x29, #-36]
	sub	x8, x29, #36
Lloh222:
	adrp	x9, __RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGE
Lloh223:
	ldr	x9, [x9, __RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGEOFF]
	stp	x8, x9, [sp]
Lloh224:
	adrp	x0, l_alloc_9e22aeedee7de67b6dbb357f0a3915a8@PAGE
Lloh225:
	add	x0, x0, l_alloc_9e22aeedee7de67b6dbb357f0a3915a8@PAGEOFF
	mov	x1, sp
	mov	x8, x19
	bl	__RNvNvNtCslJsSqIQKwiA_5alloc3fmt6format12format_inner
LBB38_10:
	.cfi_def_cfa wsp, 208
	ldp	x29, x30, [sp, #192]
	ldp	x20, x19, [sp, #176]
	ldp	x22, x21, [sp, #160]
	add	sp, sp, #208
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB38_11:
	.cfi_restore_state
	ldrb	w8, [sp, #120]
	cmp	w8, #1
	b.ne	LBB38_13
	ldp	x8, x9, [sp, #104]
	b	LBB38_14
LBB38_13:
	ldp	x8, x9, [sp, #104]
	cmp	x9, x8
	b.eq	LBB38_8
LBB38_14:
	ldr	x10, [sp, #72]
	sub	x20, x9, x8
	add	x0, x10, x8
LBB38_15:
Lloh226:
	adrp	x2, l_alloc_81d08f51e9b46a96808970faccda49a8@PAGE
Lloh227:
	add	x2, x2, l_alloc_81d08f51e9b46a96808970faccda49a8@PAGEOFF
	mov	x8, sp
	mov	x1, x20
	mov	w3, #22
	bl	__RNvMsu_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcher3new
	stp	xzr, x20, [sp, #104]
	mov	w8, #1
	strh	w8, [sp, #120]
	ldr	x21, [sp, #72]
	sub	x0, x29, #64
	mov	x1, sp
	bl	__RNvXsv_NtNtCsgtPOCBgevO_4core3str7patternNtB5_11StrSearcherNtB5_8Searcher10next_match
	ldur	x8, [x29, #-64]
	cmp	x8, #1
	b.ne	LBB38_17
	ldur	x8, [x29, #-56]
	ldr	x9, [sp, #104]
	sub	x20, x8, x9
	add	x21, x21, x9
	b	LBB38_23
LBB38_17:
	ldrb	w8, [sp, #121]
	tbz	w8, #0, LBB38_19
LBB38_18:
Lloh228:
	adrp	x8, l_alloc_c2dcc5662ba056ecce14533279e4b160@PAGE
Lloh229:
	add	x8, x8, l_alloc_c2dcc5662ba056ecce14533279e4b160@PAGEOFF
	mov	w9, #15
	b	LBB38_9
LBB38_19:
	ldrb	w8, [sp, #120]
	cmp	w8, #1
	b.ne	LBB38_21
	ldp	x8, x9, [sp, #104]
	b	LBB38_22
LBB38_21:
	ldp	x8, x9, [sp, #104]
	cmp	x9, x8
	b.eq	LBB38_18
LBB38_22:
	ldr	x10, [sp, #72]
	sub	x20, x9, x8
	add	x21, x10, x8
LBB38_23:
Lloh230:
	adrp	x0, l_alloc_c8234fd665543c28765ba1c6e15e759c@PAGE
Lloh231:
	add	x0, x0, l_alloc_c8234fd665543c28765ba1c6e15e759c@PAGEOFF
	mov	w1, #11
	mov	x2, x21
	mov	x3, x20
	bl	__RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in
	tbz	w0, #0, LBB38_31
Lloh232:
	adrp	x0, l_alloc_dd4ffb6a82fadbcfa53fa009063078f4@PAGE
Lloh233:
	add	x0, x0, l_alloc_dd4ffb6a82fadbcfa53fa009063078f4@PAGEOFF
	mov	w1, #5
	mov	x2, x21
	mov	x3, x20
	bl	__RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in
	tbnz	w0, #0, LBB38_30
Lloh234:
	adrp	x0, l_alloc_f4e8947ab4017184eb7a640b452ba22d@PAGE
Lloh235:
	add	x0, x0, l_alloc_f4e8947ab4017184eb7a640b452ba22d@PAGEOFF
	mov	w1, #11
	mov	x2, x21
	mov	x3, x20
	bl	__RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in
	tbnz	w0, #0, LBB38_30
Lloh236:
	adrp	x0, l_alloc_700d8946133bd552962b15338de36ae6@PAGE
Lloh237:
	add	x0, x0, l_alloc_700d8946133bd552962b15338de36ae6@PAGEOFF
	mov	w1, #9
	mov	x2, x21
	mov	x3, x20
	bl	__RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in
	tbnz	w0, #0, LBB38_30
Lloh238:
	adrp	x0, l_alloc_9b7e1a584d08fa8ad7c1a56b7ce8a44f@PAGE
Lloh239:
	add	x0, x0, l_alloc_9b7e1a584d08fa8ad7c1a56b7ce8a44f@PAGEOFF
	mov	w1, #6
	mov	x2, x21
	mov	x3, x20
	bl	__RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in
	tbnz	w0, #0, LBB38_30
Lloh240:
	adrp	x0, l_alloc_872ed60f4e9cc5929cf39c60b855d9ea@PAGE
Lloh241:
	add	x0, x0, l_alloc_872ed60f4e9cc5929cf39c60b855d9ea@PAGEOFF
	mov	w1, #6
	mov	x2, x21
	mov	x3, x20
	bl	__RNvXst_NtNtCsgtPOCBgevO_4core3str7patternReNtB5_7Pattern15is_contained_in
	cbnz	w0, LBB38_30
	mov	x8, #-1
	str	x8, [x19]
	b	LBB38_10
LBB38_30:
Lloh242:
	adrp	x0, l_alloc_b3a99f180af7a4a365370845f4d61ecc@PAGE
Lloh243:
	add	x0, x0, l_alloc_b3a99f180af7a4a365370845f4d61ecc@PAGEOFF
Lloh244:
	adrp	x2, l_alloc_b8d0ec36c0eead905460459f2e09257b@PAGE
Lloh245:
	add	x2, x2, l_alloc_b8d0ec36c0eead905460459f2e09257b@PAGEOFF
	mov	w1, #43
	bl	__RNvNtCsgtPOCBgevO_4core9panicking5panic
LBB38_31:
Lloh246:
	adrp	x0, l_alloc_cd7c7f7dce8f9b264694ca2526c37516@PAGE
Lloh247:
	add	x0, x0, l_alloc_cd7c7f7dce8f9b264694ca2526c37516@PAGEOFF
Lloh248:
	adrp	x2, l_alloc_6e2e0c0ec38458ba4fdfb65ea05a2eb2@PAGE
Lloh249:
	add	x2, x2, l_alloc_6e2e0c0ec38458ba4fdfb65ea05a2eb2@PAGEOFF
	mov	w1, #46
	bl	__RNvNtCsgtPOCBgevO_4core9panicking5panic
	.loh AdrpLdr	Lloh214, Lloh215
	.loh AdrpAdd	Lloh212, Lloh213
	.loh AdrpAdd	Lloh210, Lloh211
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpLdrGot	Lloh222, Lloh223
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpAdd	Lloh218, Lloh219
	.loh AdrpAdd	Lloh226, Lloh227
	.loh AdrpAdd	Lloh228, Lloh229
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpAdd	Lloh232, Lloh233
	.loh AdrpAdd	Lloh234, Lloh235
	.loh AdrpAdd	Lloh236, Lloh237
	.loh AdrpAdd	Lloh238, Lloh239
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdd	Lloh244, Lloh245
	.loh AdrpAdd	Lloh242, Lloh243
	.loh AdrpAdd	Lloh248, Lloh249
	.loh AdrpAdd	Lloh246, Lloh247
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI39_0:
	.quad	1
	.quad	0
lCPI39_1:
	.quad	2
	.quad	1
lCPI39_2:
	.quad	2
	.quad	3
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvYNCNvCs6tqTQJNM79Z_8type_dag60type_dag_node_mutations_retain_ordinal_operands_and_priority0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_:
	.cfi_startproc
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x20, x19, [sp, #112]
	stp	x29, x30, [sp, #128]
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x8
	stur	wzr, [x29, #-44]
	sturb	wzr, [x29, #-40]
Lloh250:
	adrp	x8, lCPI39_0@PAGE
Lloh251:
	ldr	q0, [x8, lCPI39_0@PAGEOFF]
	stur	q0, [x29, #-32]
	mov	w20, #4
	sturb	w20, [x29, #-48]
Lloh252:
	adrp	x1, l_alloc_d0ef803f235cc9da4d2f68db2ae7eecd@PAGE
Lloh253:
	add	x1, x1, l_alloc_d0ef803f235cc9da4d2f68db2ae7eecd@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #4
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB39_7
	stur	wzr, [x29, #-44]
	sturb	wzr, [x29, #-40]
Lloh254:
	adrp	x8, lCPI39_1@PAGE
Lloh255:
	ldr	q0, [x8, lCPI39_1@PAGEOFF]
	stur	q0, [x29, #-32]
	sturb	w20, [x29, #-48]
Lloh256:
	adrp	x1, l_alloc_84e44d17547bb16feba7510e5887a46e@PAGE
Lloh257:
	add	x1, x1, l_alloc_84e44d17547bb16feba7510e5887a46e@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #5
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB39_7
	stur	wzr, [x29, #-44]
	mov	w8, #1793
	sturh	w8, [x29, #-40]
	mov	w20, #4
	sturb	w20, [x29, #-48]
Lloh258:
	adrp	x1, l_alloc_dfa58342adb1b61c9b339d03997d4468@PAGE
Lloh259:
	add	x1, x1, l_alloc_dfa58342adb1b61c9b339d03997d4468@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #6
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB39_7
	stur	wzr, [x29, #-44]
	mov	w8, #1794
	sturh	w8, [x29, #-40]
	sturb	w20, [x29, #-48]
Lloh260:
	adrp	x1, l_alloc_2deb6346c8c31952b5e510cfc673852c@PAGE
Lloh261:
	add	x1, x1, l_alloc_2deb6346c8c31952b5e510cfc673852c@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #6
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB39_7
	stur	wzr, [x29, #-44]
	mov	w8, #259
	sturh	w8, [x29, #-40]
	mov	w8, #1
	stur	w8, [x29, #-36]
	mov	w8, #4
	sturb	w8, [x29, #-48]
Lloh262:
	adrp	x1, l_alloc_ac5a6c5e09adc7e44b9ec58eff44f5a6@PAGE
Lloh263:
	add	x1, x1, l_alloc_ac5a6c5e09adc7e44b9ec58eff44f5a6@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #6
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB39_7
Lloh264:
	adrp	x8, lCPI39_2@PAGE
Lloh265:
	ldr	q0, [x8, lCPI39_2@PAGEOFF]
	stur	q0, [x29, #-40]
	mov	w8, #5
	sturb	w8, [x29, #-48]
Lloh266:
	adrp	x1, l_alloc_c1242df8626b9cf6c60c92fd6d618193@PAGE
Lloh267:
	add	x1, x1, l_alloc_c1242df8626b9cf6c60c92fd6d618193@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #7
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB39_7
	mov	x8, #-1
	str	x8, [x19]
	b	LBB39_8
LBB39_7:
	ldur	q0, [sp, #41]
	str	q0, [sp]
	ldur	q0, [sp, #56]
	stur	q0, [sp, #15]
	sturb	w8, [x29, #-48]
	ldr	q0, [sp]
	stur	q0, [x29, #-47]
	ldur	q0, [sp, #15]
	stur	q0, [x29, #-32]
	sub	x8, x29, #48
Lloh268:
	adrp	x9, __RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt@PAGE
Lloh269:
	add	x9, x9, __RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt@PAGEOFF
	stp	x8, x9, [sp, #40]
Lloh270:
	adrp	x0, l_alloc_26978532d6004174455ea2130c477035@PAGE
Lloh271:
	add	x0, x0, l_alloc_26978532d6004174455ea2130c477035@PAGEOFF
	add	x1, sp, #40
	bl	__RNvNtNtCsa9BKTri5B3M_3std2io5stdio23attempt_print_to_stderr
	mov	w8, #1
	stur	w8, [x29, #-52]
	sub	x8, x29, #52
Lloh272:
	adrp	x9, __RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGE
Lloh273:
	ldr	x9, [x9, __RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGEOFF]
	stp	x8, x9, [x29, #-48]
Lloh274:
	adrp	x0, l_alloc_9e22aeedee7de67b6dbb357f0a3915a8@PAGE
Lloh275:
	add	x0, x0, l_alloc_9e22aeedee7de67b6dbb357f0a3915a8@PAGEOFF
	sub	x1, x29, #48
	mov	x8, x19
	bl	__RNvNvNtCslJsSqIQKwiA_5alloc3fmt6format12format_inner
LBB39_8:
	.cfi_def_cfa wsp, 144
	ldp	x29, x30, [sp, #128]
	ldp	x20, x19, [sp, #112]
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpLdr	Lloh250, Lloh251
	.loh AdrpAdd	Lloh256, Lloh257
	.loh AdrpLdr	Lloh254, Lloh255
	.loh AdrpAdd	Lloh258, Lloh259
	.loh AdrpAdd	Lloh260, Lloh261
	.loh AdrpAdd	Lloh262, Lloh263
	.loh AdrpAdd	Lloh266, Lloh267
	.loh AdrpLdr	Lloh264, Lloh265
	.loh AdrpAdd	Lloh274, Lloh275
	.loh AdrpLdrGot	Lloh272, Lloh273
	.loh AdrpAdd	Lloh270, Lloh271
	.loh AdrpAdd	Lloh268, Lloh269
	.cfi_endproc

	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI40_0:
	.byte	194
	.byte	1
	.byte	0
	.byte	0
	.space	1
	.space	1
	.space	1
	.space	1
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI40_1:
	.quad	6
	.quad	5
lCPI40_2:
	.quad	1
	.quad	0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvYNCNvCs6tqTQJNM79Z_8type_dag64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_:
	.cfi_startproc
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x20, x19, [sp, #112]
	stp	x29, x30, [sp, #128]
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x8
Lloh276:
	adrp	x8, lCPI40_0@PAGE
Lloh277:
	ldr	d0, [x8, lCPI40_0@PAGEOFF]
	stur	s0, [x29, #-52]
	stur	xzr, [x29, #-40]
	sturb	wzr, [x29, #-48]
	add	x0, sp, #40
	sub	x1, x29, #52
	sub	x4, x29, #48
	mov	x2, #0
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB40_10
	mov	w8, #1
	stur	x8, [x29, #-40]
	sturb	wzr, [x29, #-48]
	add	x0, sp, #40
	sub	x1, x29, #52
	sub	x4, x29, #48
	mov	w2, #1
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB40_10
	mov	w8, #2
	stur	x8, [x29, #-40]
	sturb	wzr, [x29, #-48]
	add	x0, sp, #40
	sub	x1, x29, #52
	sub	x4, x29, #48
	mov	w2, #2
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB40_10
	mov	w8, #3
	stur	x8, [x29, #-40]
	sturb	wzr, [x29, #-48]
	add	x0, sp, #40
	sub	x1, x29, #52
	sub	x4, x29, #48
	mov	w2, #3
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB40_10
	sturb	wzr, [x29, #-46]
	mov	w8, #1
	sturh	w8, [x29, #-48]
Lloh278:
	adrp	x1, l_alloc_f6f7b3569446eafb281a38f3be526f22@PAGE
Lloh279:
	add	x1, x1, l_alloc_f6f7b3569446eafb281a38f3be526f22@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #4
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB40_10
	sturb	wzr, [x29, #-46]
	mov	w8, #257
	sturh	w8, [x29, #-48]
Lloh280:
	adrp	x1, l_alloc_29797342d601d1e047d79ddaf9206dc7@PAGE
Lloh281:
	add	x1, x1, l_alloc_29797342d601d1e047d79ddaf9206dc7@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #4
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB40_10
	mov	w8, #3
	sturb	w8, [x29, #-46]
	mov	w8, #513
	sturh	w8, [x29, #-48]
Lloh282:
	adrp	x1, l_alloc_060289bc9efbbf6030aff056af069676@PAGE
Lloh283:
	add	x1, x1, l_alloc_060289bc9efbbf6030aff056af069676@PAGEOFF
	mov	w20, #2
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #4
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB40_10
Lloh284:
	adrp	x8, lCPI40_1@PAGE
Lloh285:
	ldr	q0, [x8, lCPI40_1@PAGEOFF]
	stur	q0, [x29, #-40]
	sturb	w20, [x29, #-48]
Lloh286:
	adrp	x1, l_alloc_7884c94991f6216c5ebb8eda5460e4b8@PAGE
Lloh287:
	add	x1, x1, l_alloc_7884c94991f6216c5ebb8eda5460e4b8@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #5
	mov	w3, #2
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB40_10
Lloh288:
	adrp	x8, lCPI40_2@PAGE
Lloh289:
	ldr	q0, [x8, lCPI40_2@PAGEOFF]
	stur	q0, [x29, #-40]
	mov	w8, #3
	sturb	w8, [x29, #-48]
Lloh290:
	adrp	x1, l_alloc_40eaf789987e2da79c4d5f3f8e4e709a@PAGE
Lloh291:
	add	x1, x1, l_alloc_40eaf789987e2da79c4d5f3f8e4e709a@PAGEOFF
	add	x0, sp, #40
	sub	x4, x29, #48
	mov	w2, #6
	mov	x3, #0
	bl	__RNvCs6tqTQJNM79Z_8type_dag13assert_reject
	ldrb	w8, [sp, #40]
	cmp	w8, #255
	b.ne	LBB40_10
	mov	x8, #-1
	str	x8, [x19]
	b	LBB40_11
LBB40_10:
	ldur	q0, [sp, #41]
	str	q0, [sp]
	ldur	q0, [sp, #56]
	stur	q0, [sp, #15]
	sturb	w8, [x29, #-48]
	ldr	q0, [sp]
	stur	q0, [x29, #-47]
	ldur	q0, [sp, #15]
	stur	q0, [x29, #-32]
	sub	x8, x29, #48
Lloh292:
	adrp	x9, __RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt@PAGE
Lloh293:
	add	x9, x9, __RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt@PAGEOFF
	stp	x8, x9, [sp, #40]
Lloh294:
	adrp	x0, l_alloc_26978532d6004174455ea2130c477035@PAGE
Lloh295:
	add	x0, x0, l_alloc_26978532d6004174455ea2130c477035@PAGEOFF
	add	x1, sp, #40
	bl	__RNvNtNtCsa9BKTri5B3M_3std2io5stdio23attempt_print_to_stderr
	mov	w8, #1
	stur	w8, [x29, #-52]
	sub	x8, x29, #52
Lloh296:
	adrp	x9, __RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGE
Lloh297:
	ldr	x9, [x9, __RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGEOFF]
	stp	x8, x9, [x29, #-48]
Lloh298:
	adrp	x0, l_alloc_9e22aeedee7de67b6dbb357f0a3915a8@PAGE
Lloh299:
	add	x0, x0, l_alloc_9e22aeedee7de67b6dbb357f0a3915a8@PAGEOFF
	sub	x1, x29, #48
	mov	x8, x19
	bl	__RNvNvNtCslJsSqIQKwiA_5alloc3fmt6format12format_inner
LBB40_11:
	.cfi_def_cfa wsp, 144
	ldp	x29, x30, [sp, #128]
	ldp	x20, x19, [sp, #112]
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.loh AdrpLdr	Lloh276, Lloh277
	.loh AdrpAdd	Lloh278, Lloh279
	.loh AdrpAdd	Lloh280, Lloh281
	.loh AdrpAdd	Lloh282, Lloh283
	.loh AdrpAdd	Lloh286, Lloh287
	.loh AdrpLdr	Lloh284, Lloh285
	.loh AdrpAdd	Lloh290, Lloh291
	.loh AdrpLdr	Lloh288, Lloh289
	.loh AdrpAdd	Lloh298, Lloh299
	.loh AdrpLdrGot	Lloh296, Lloh297
	.loh AdrpAdd	Lloh294, Lloh295
	.loh AdrpAdd	Lloh292, Lloh293
	.cfi_endproc

	.p2align	2
__RNvYNCNvCs6tqTQJNM79Z_8type_dag66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_:
	.cfi_startproc
	sub	sp, sp, #400
	.cfi_def_cfa_offset 400
	stp	x28, x27, [sp, #304]
	stp	x26, x25, [sp, #320]
	stp	x24, x23, [sp, #336]
	stp	x22, x21, [sp, #352]
	stp	x20, x19, [sp, #368]
	stp	x29, x30, [sp, #384]
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	str	x8, [sp]
	mov	w8, #1
	strb	w8, [sp, #168]
	str	wzr, [sp, #172]
	strb	w8, [sp, #176]
	str	w8, [sp, #180]
	strb	w8, [sp, #184]
	str	wzr, [sp, #188]
Lloh300:
	adrp	x9, l_alloc_c1b96e55b45c7736d2483852531d6cfa@PAGE
Lloh301:
	add	x9, x9, l_alloc_c1b96e55b45c7736d2483852531d6cfa@PAGEOFF
	mov	w10, #4
	stp	x9, x10, [sp, #8]
Lloh302:
	adrp	x9, l_alloc_40eaf789987e2da79c4d5f3f8e4e709a@PAGE
Lloh303:
	add	x9, x9, l_alloc_40eaf789987e2da79c4d5f3f8e4e709a@PAGEOFF
	mov	w11, #6
	stp	x9, x11, [sp, #40]
Lloh304:
	adrp	x9, l_alloc_a4fec9de8264c27b2449b411fe17eeb0@PAGE
Lloh305:
	add	x9, x9, l_alloc_a4fec9de8264c27b2449b411fe17eeb0@PAGEOFF
Lloh306:
	adrp	x12, l_alloc_68d4241588b373d3827583e8b7e560bc@PAGE
Lloh307:
	add	x12, x12, l_alloc_68d4241588b373d3827583e8b7e560bc@PAGEOFF
	stp	x9, x8, [sp, #56]
	stp	x12, x11, [sp, #72]
Lloh308:
	adrp	x9, l_alloc_cbf4874b1b147cfd09d259bc70f502f8@PAGE
Lloh309:
	add	x9, x9, l_alloc_cbf4874b1b147cfd09d259bc70f502f8@PAGEOFF
	stp	x9, x8, [sp, #88]
Lloh310:
	adrp	x9, l_alloc_fa61d42cbf53437402fcbcb23f6b9f14@PAGE
Lloh311:
	add	x9, x9, l_alloc_fa61d42cbf53437402fcbcb23f6b9f14@PAGEOFF
	stp	x9, x11, [sp, #104]
	add	x9, sp, #168
	stp	x9, x8, [sp, #120]
Lloh312:
	adrp	x8, l_alloc_8e580bd0a57c3d4e874ce5e1d1608074@PAGE
Lloh313:
	add	x8, x8, l_alloc_8e580bd0a57c3d4e874ce5e1d1608074@PAGEOFF
	mov	w9, #8
	stp	x8, x9, [sp, #136]
	add	x8, sp, #176
	mov	w9, #2
	stp	x8, x9, [sp, #152]
	add	x20, sp, #8
	mov	w27, #160
	sub	x28, x29, #144
	stp	x10, xzr, [sp, #24]
	b	LBB41_2
LBB41_1:
	ldrb	w8, [x26, #9]
	ldrb	w9, [x19, #9]
	cmp	w8, w9
	b.eq	LBB41_22
	b	LBB41_36
LBB41_2:
	sub	x0, x29, #144
Lloh314:
	adrp	x1, l_.memset_pattern@PAGE
Lloh315:
	add	x1, x1, l_.memset_pattern@PAGEOFF
	mov	w2, #16
	bl	_memset_pattern16
	ldp	x23, x24, [x20]
	str	x23, [sp, #192]
	ldr	x22, [x20, #24]
	cmp	x22, #3
	b.hs	LBB41_34
	ldr	x19, [x20, #16]
	sub	x8, x29, #184
	sub	x2, x29, #144
	mov	x0, x23
	mov	x1, x24
	mov	x3, x22
	bl	__RNvMNtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB2_11TypeDagView8validate
	ldur	w8, [x29, #-184]
	tbnz	w8, #0, LBB41_28
	ldp	x25, x8, [x29, #-176]
	ldp	x26, x21, [x29, #-160]
	stp	x25, x8, [x29, #-184]
	cmp	x8, x24
	b.ne	LBB41_35
	mov	x0, x25
	mov	x1, x23
	mov	x2, x24
	bl	_memcmp
	cbnz	w0, LBB41_35
	stur	x25, [x29, #-184]
	cmp	x25, x23
	b.ne	LBB41_38
	stur	x21, [x29, #-128]
	stur	x22, [x29, #-184]
	cmp	x21, x22
	b.ne	LBB41_39
	cbz	x22, LBB41_24
	cmp	x26, x28
	b.lo	LBB41_41
	add	x9, x28, x22, lsl #3
	stur	x19, [x29, #-128]
	add	x8, x26, #8
	stur	x26, [x29, #-184]
	cmp	x8, x9
	b.hi	LBB41_40
	ldrb	w10, [x26]
	ldrb	w11, [x19]
	cmp	w10, w11
	b.ne	LBB41_36
	tbz	w10, #0, LBB41_14
	ldr	w10, [x26, #4]
	ldr	w11, [x19, #4]
	b	LBB41_15
LBB41_14:
	ldrb	w10, [x26, #1]
	ldrb	w11, [x19, #1]
LBB41_15:
	cmp	w10, w11
	b.ne	LBB41_36
	sub	x10, x22, #1
	cmp	x22, #1
	b.eq	LBB41_23
	add	x11, x19, #8
	stur	x11, [x29, #-128]
	cbz	x10, LBB41_29
	stur	x8, [x29, #-184]
	add	x10, x8, #8
	cmp	x10, x9
	b.hi	LBB41_40
	ldrb	w8, [x8]
	ldrb	w9, [x11]
	cmp	w8, w9
	b.ne	LBB41_36
	tbz	w8, #0, LBB41_1
	ldr	w8, [x26, #12]
	ldr	w9, [x19, #12]
	cmp	w8, w9
	b.ne	LBB41_36
LBB41_22:
	sub	x10, x22, #2
LBB41_23:
	stur	x10, [x29, #-184]
	cbnz	x10, LBB41_37
LBB41_24:
	add	x20, x20, #32
	subs	x27, x27, #32
	b.ne	LBB41_2
Lloh316:
	adrp	x1, l_.memset_pattern@PAGE
Lloh317:
	add	x1, x1, l_.memset_pattern@PAGEOFF
	sub	x0, x29, #144
	mov	w2, #16
	bl	_memset_pattern16
Lloh318:
	adrp	x1, l_alloc_40eaf789987e2da79c4d5f3f8e4e709a@PAGE
Lloh319:
	add	x1, x1, l_alloc_40eaf789987e2da79c4d5f3f8e4e709a@PAGEOFF
	sub	x0, x29, #128
	sub	x3, x29, #144
	mov	w2, #6
	bl	__RNvCs6tqTQJNM79Z_8type_dag18recursive_consumer
Lloh320:
	adrp	x1, l_alloc_8e580bd0a57c3d4e874ce5e1d1608074@PAGE
Lloh321:
	add	x1, x1, l_alloc_8e580bd0a57c3d4e874ce5e1d1608074@PAGEOFF
	sub	x0, x29, #184
	sub	x3, x29, #144
	mov	w2, #8
	bl	__RNvCs6tqTQJNM79Z_8type_dag18recursive_consumer
	ldurb	w8, [x29, #-128]
	cmp	w8, #255
	cset	w9, ne
	ldurb	w10, [x29, #-184]
	cmp	w10, #255
	cset	w10, eq
	eor	w9, w9, w10
	tbz	w9, #0, LBB41_32
	cmp	w8, #255
	b.eq	LBB41_31
	sub	x0, x29, #128
	sub	x1, x29, #184
	bl	__RNvXsF_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3cmp9PartialEq2eq
	tbz	w0, #0, LBB41_32
	b	LBB41_42
LBB41_28:
	ldurb	w8, [x29, #-176]
	sub	x9, x29, #184
	ldur	q0, [x9, #9]
	stur	q0, [x9, #56]
	ldur	q0, [x9, #24]
	stur	q0, [x9, #71]
	cmp	w8, #255
	b.ne	LBB41_30
	b	LBB41_32
LBB41_29:
	mov	w8, #8
	sub	x9, x29, #184
LBB41_30:
	strb	w8, [sp, #8]
	ldur	q0, [x9, #56]
	stur	q0, [sp, #9]
	ldur	q0, [x9, #71]
	stur	q0, [sp, #24]
	add	x8, sp, #8
Lloh322:
	adrp	x9, __RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt@PAGE
Lloh323:
	add	x9, x9, __RNvXCs6tqTQJNM79Z_8type_dagNtB2_11TestFailureNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt@PAGEOFF
	stp	x8, x9, [x29, #-184]
Lloh324:
	adrp	x0, l_alloc_26978532d6004174455ea2130c477035@PAGE
Lloh325:
	add	x0, x0, l_alloc_26978532d6004174455ea2130c477035@PAGEOFF
	sub	x1, x29, #184
	bl	__RNvNtNtCsa9BKTri5B3M_3std2io5stdio23attempt_print_to_stderr
	mov	w8, #1
	stur	w8, [x29, #-144]
	sub	x8, x29, #144
Lloh326:
	adrp	x9, __RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGE
Lloh327:
	ldr	x9, [x9, __RNvXs9_NtNtNtCsgtPOCBgevO_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGEOFF]
	stp	x8, x9, [sp, #8]
Lloh328:
	adrp	x0, l_alloc_9e22aeedee7de67b6dbb357f0a3915a8@PAGE
Lloh329:
	add	x0, x0, l_alloc_9e22aeedee7de67b6dbb357f0a3915a8@PAGEOFF
	add	x1, sp, #8
	ldr	x8, [sp]
	bl	__RNvNvNtCslJsSqIQKwiA_5alloc3fmt6format12format_inner
	b	LBB41_33
LBB41_31:
	ldur	w8, [x29, #-124]
	ldur	w9, [x29, #-180]
	cmp	w8, w9
	b.eq	LBB41_42
LBB41_32:
	mov	x8, #-1
	ldr	x9, [sp]
	str	x8, [x9]
LBB41_33:
	.cfi_def_cfa wsp, 400
	ldp	x29, x30, [sp, #384]
	ldp	x20, x19, [sp, #368]
	ldp	x22, x21, [sp, #352]
	ldp	x24, x23, [sp, #336]
	ldp	x26, x25, [sp, #320]
	ldp	x28, x27, [sp, #304]
	add	sp, sp, #400
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB41_34:
	.cfi_restore_state
Lloh330:
	adrp	x3, l_alloc_f11587fcc5df25a2c968fb538524ab02@PAGE
Lloh331:
	add	x3, x3, l_alloc_f11587fcc5df25a2c968fb538524ab02@PAGEOFF
	mov	x0, #0
	mov	x1, x22
	mov	w2, #2
	bl	__RNvNtNtCsgtPOCBgevO_4core5slice5index16slice_index_fail
LBB41_35:
	sub	x0, x29, #184
	mov	x1, x20
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedRShBL_ECs6tqTQJNM79Z_8type_dag
LBB41_36:
	sub	x0, x29, #184
	sub	x1, x29, #128
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeBL_ECs6tqTQJNM79Z_8type_dag
LBB41_37:
Lloh332:
	adrp	x2, l_alloc_53973d2fe29b4adba8bb7390b5678745@PAGE
Lloh333:
	add	x2, x2, l_alloc_53973d2fe29b4adba8bb7390b5678745@PAGEOFF
Lloh334:
	adrp	x5, l_alloc_8a3150ea8ce92a0b4c407d9443666eec@PAGE
Lloh335:
	add	x5, x5, l_alloc_8a3150ea8ce92a0b4c407d9443666eec@PAGEOFF
	sub	x1, x29, #184
	mov	w0, #0
	mov	x3, #0
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_
LBB41_38:
Lloh336:
	adrp	x5, l_alloc_800cf2779c59941b383445baad70eeb8@PAGE
Lloh337:
	add	x5, x5, l_alloc_800cf2779c59941b383445baad70eeb8@PAGEOFF
	sub	x1, x29, #184
	add	x2, sp, #192
	mov	w0, #0
	mov	x3, #0
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_
LBB41_39:
Lloh338:
	adrp	x5, l_alloc_98a68c254d2f16f24a30ac2be7568bfa@PAGE
Lloh339:
	add	x5, x5, l_alloc_98a68c254d2f16f24a30ac2be7568bfa@PAGEOFF
	sub	x1, x29, #128
	sub	x2, x29, #184
	mov	w0, #0
	mov	x3, #0
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedjjEB4_
LBB41_40:
Lloh340:
	adrp	x0, l_alloc_ef0d0704052a8e970d69179d3ab3ec5d@PAGE
Lloh341:
	add	x0, x0, l_alloc_ef0d0704052a8e970d69179d3ab3ec5d@PAGEOFF
Lloh342:
	adrp	x2, l_alloc_bed34f8f916518f97094735f53f0071b@PAGE
Lloh343:
	add	x2, x2, l_alloc_bed34f8f916518f97094735f53f0071b@PAGEOFF
	mov	w1, #96
	bl	__RNvNtCsgtPOCBgevO_4core9panicking5panic
LBB41_41:
Lloh344:
	adrp	x0, l_alloc_41adb055745d596a22069a43cc6b96f0@PAGE
Lloh345:
	add	x0, x0, l_alloc_41adb055745d596a22069a43cc6b96f0@PAGEOFF
Lloh346:
	adrp	x2, l_alloc_787cc3db1ede27825734bc2f561a73e1@PAGE
Lloh347:
	add	x2, x2, l_alloc_787cc3db1ede27825734bc2f561a73e1@PAGEOFF
	mov	w1, #47
	bl	__RNvNtCsgtPOCBgevO_4core9panicking5panic
LBB41_42:
	sub	x0, x29, #128
	sub	x1, x29, #184
	bl	__RINvNtCsgtPOCBgevO_4core9panicking13assert_failedINtNtB4_6result6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorEBL_ECs6tqTQJNM79Z_8type_dag
	.loh AdrpAdd	Lloh312, Lloh313
	.loh AdrpAdd	Lloh310, Lloh311
	.loh AdrpAdd	Lloh308, Lloh309
	.loh AdrpAdd	Lloh306, Lloh307
	.loh AdrpAdd	Lloh304, Lloh305
	.loh AdrpAdd	Lloh302, Lloh303
	.loh AdrpAdd	Lloh300, Lloh301
	.loh AdrpAdd	Lloh314, Lloh315
	.loh AdrpAdd	Lloh320, Lloh321
	.loh AdrpAdd	Lloh318, Lloh319
	.loh AdrpAdd	Lloh316, Lloh317
	.loh AdrpAdd	Lloh328, Lloh329
	.loh AdrpLdrGot	Lloh326, Lloh327
	.loh AdrpAdd	Lloh324, Lloh325
	.loh AdrpAdd	Lloh322, Lloh323
	.loh AdrpAdd	Lloh330, Lloh331
	.loh AdrpAdd	Lloh334, Lloh335
	.loh AdrpAdd	Lloh332, Lloh333
	.loh AdrpAdd	Lloh336, Lloh337
	.loh AdrpAdd	Lloh338, Lloh339
	.loh AdrpAdd	Lloh342, Lloh343
	.loh AdrpAdd	Lloh340, Lloh341
	.loh AdrpAdd	Lloh346, Lloh347
	.loh AdrpAdd	Lloh344, Lloh345
	.cfi_endproc

	.globl	_main
	.p2align	2
_main:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x3, x1
	sxtw	x2, w0
Lloh348:
	adrp	x8, __RNvCs6tqTQJNM79Z_8type_dag4main@PAGE
Lloh349:
	add	x8, x8, __RNvCs6tqTQJNM79Z_8type_dag4main@PAGEOFF
	str	x8, [sp, #8]
Lloh350:
	adrp	x1, l_vtable.2@PAGE
Lloh351:
	add	x1, x1, l_vtable.2@PAGEOFF
	add	x0, sp, #8
	mov	w4, #0
	bl	__RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh350, Lloh351
	.loh AdrpAdd	Lloh348, Lloh349
	.cfi_endproc

	.p2align	2
_OUTLINED_FUNCTION_0:
	.cfi_startproc
	mov	x1, sp
	add	x3, sp, #8
	mov	w0, #0
	mov	x4, x2
	mov	x5, #0
	b	__RNvNtCsgtPOCBgevO_4core9panicking19assert_failed_inner
	.cfi_endproc

	.section	__TEXT,__cstring,cstring_literals
l_alloc_9e22aeedee7de67b6dbb357f0a3915a8:
	.asciz	"Cthe test returned a termination value with a non-zero status code (\300\033) which indicates a failure"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.p2align	3, 0x0
l_vtable.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRhNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.section	__TEXT,__cstring,cstring_literals
l_alloc_ee38938c8929eed18faaff5d8f37cd9b:
	.asciz	"/nix/store/p5s0g9nqgaf3024n3g2ib80f3si3bn9s-rust-mixed/lib/rustlib/src/rust/library/core/src/str/pattern.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_68bb27fa7fd7af0b8edb2570ef014cd2:
	.quad	l_alloc_ee38938c8929eed18faaff5d8f37cd9b
	.asciz	"k\000\000\000\000\000\000\000\347\005\000\000\024\000\000"

	.p2align	3, 0x0
l_alloc_8deac4fa778727f9c004a28bc20bcda6:
	.quad	l_alloc_ee38938c8929eed18faaff5d8f37cd9b
	.asciz	"k\000\000\000\000\000\000\000\347\005\000\000!\000\000"

	.p2align	3, 0x0
l_alloc_8ae9795802ad53c9398ce2776784dbc3:
	.quad	l_alloc_ee38938c8929eed18faaff5d8f37cd9b
	.asciz	"k\000\000\000\000\000\000\000\333\005\000\000!\000\000"

	.p2align	3, 0x0
l_vtable.2:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs6tqTQJNM79Z_8type_dag
	.quad	__RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs6tqTQJNM79Z_8type_dag
	.quad	__RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs6tqTQJNM79Z_8type_dag

	.p2align	3, 0x0
l_vtable.3:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRANtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodej2_NtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.p2align	3, 0x0
l_vtable.5:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6result6ResultmNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.p2align	3, 0x0
l_vtable.6:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag12TypeDagErrorNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.p2align	3, 0x0
l_vtable.7:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag8TypeNodeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.p2align	3, 0x0
l_vtable.8:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRRShNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.p2align	3, 0x0
l_alloc_fc59cbe87b130fa4fa1d3a2e82d342fe:
	.quad	l_alloc_ee38938c8929eed18faaff5d8f37cd9b
	.asciz	"k\000\000\000\000\000\000\000\025\007\000\000I\000\000"

	.section	__TEXT,__literal8,8byte_literals
	.p2align	2, 0x0
l_alloc_cbf4874b1b147cfd09d259bc70f502f8:
	.ascii	"\000\001"
	.space	6

	.section	__TEXT,__cstring,cstring_literals
l_alloc_ad7306ae0224e62badd99f32f4d8d58c:
	.asciz	"crates/nudox-ir-format/tests/type_dag.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_0cbc87dd977768d531eddd3dcebd568b:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\0000\000\000\000\005\000\000"

	.p2align	3, 0x0
l_alloc_7fe41e4be0c7245e8ff7e83adb85e94f:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\0001\000\000\000\005\000\000"

	.section	__TEXT,__const
l_alloc_7404500edb0ae603b6d675589f316978:
	.ascii	"type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused"

l_alloc_be81d0a65128fe8aa6f6d55c0b15d059:
	.ascii	"crates/nudox-ir-format/tests/type_dag.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_6b19a81fd0d9220b3b120a9b4bc1899a:
	.space	8
	.space	16
	.ascii	"\000\000\000\000\000\000\000\200"
	.quad	l_alloc_7404500edb0ae603b6d675589f316978
	.asciz	"B\000\000\000\000\000\000"
	.space	8
	.quad	l_alloc_be81d0a65128fe8aa6f6d55c0b15d059
	.asciz	"(\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.space	8
	.ascii	"E\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000E\000\000\000\000\000\000\000F\000\000\000\000\000\000\000\000\000\000\001"
	.space	4
	.space	8
	.quad	__RNvYNCNvCs6tqTQJNM79Z_8type_dag66type_dag_empty_primitive_and_recursive_goldens_are_exact_and_fused0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_
	.space	8

	.section	__TEXT,__const
l_alloc_cdb6725c7915b088e5aa36e528c366c6:
	.ascii	"type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_4aa485b89b48004fc7817892989be4c4:
	.space	8
	.space	16
	.ascii	"\000\000\000\000\000\000\000\200"
	.quad	l_alloc_cdb6725c7915b088e5aa36e528c366c6
	.asciz	"@\000\000\000\000\000\000"
	.space	8
	.quad	l_alloc_be81d0a65128fe8aa6f6d55c0b15d059
	.asciz	"(\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.space	8
	.ascii	"\200\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\200\000\000\000\000\000\000\000D\000\000\000\000\000\000\000\000\000\000\001"
	.space	4
	.space	8
	.quad	__RNvYNCNvCs6tqTQJNM79Z_8type_dag64type_dag_header_geometry_and_scratch_errors_are_exact_and_atomic0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_
	.space	8

	.section	__TEXT,__const
l_alloc_6062f6044dd9f7474ceb5fda6361d69e:
	.ascii	"type_dag_layout_and_cursor_source_are_observed_on_this_host"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_88ca7db97edc20dc7f24542e26d80fb2:
	.space	8
	.space	16
	.ascii	"\000\000\000\000\000\000\000\200"
	.quad	l_alloc_6062f6044dd9f7474ceb5fda6361d69e
	.asciz	";\000\000\000\000\000\000"
	.space	8
	.quad	l_alloc_be81d0a65128fe8aa6f6d55c0b15d059
	.asciz	"(\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.space	8
	.ascii	"\352\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\352\000\000\000\000\000\000\000?\000\000\000\000\000\000\000\000\000\000\001"
	.space	4
	.space	8
	.quad	__RNvYNCNvCs6tqTQJNM79Z_8type_dag59type_dag_layout_and_cursor_source_are_observed_on_this_host0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_
	.space	8

	.section	__TEXT,__const
l_alloc_cb3e15bf75992dca2db71edf954b0c16:
	.ascii	"type_dag_node_mutations_retain_ordinal_operands_and_priority"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_8f0759b75afaab4655dc6fac252fd0c3:
	.space	8
	.space	16
	.ascii	"\000\000\000\000\000\000\000\200"
	.quad	l_alloc_cb3e15bf75992dca2db71edf954b0c16
	.asciz	"<\000\000\000\000\000\000"
	.space	8
	.quad	l_alloc_be81d0a65128fe8aa6f6d55c0b15d059
	.asciz	"(\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.space	8
	.ascii	"\254\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\254\000\000\000\000\000\000\000@\000\000\000\000\000\000\000\000\000\000\001"
	.space	4
	.space	8
	.quad	__RNvYNCNvCs6tqTQJNM79Z_8type_dag60type_dag_node_mutations_retain_ordinal_operands_and_priority0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceB6_
	.space	8

	.p2align	3, 0x0
l_alloc_4776006e0a43248bf4954eb5625408e7:
	.quad	l_alloc_6b19a81fd0d9220b3b120a9b4bc1899a
	.quad	l_alloc_4aa485b89b48004fc7817892989be4c4
	.quad	l_alloc_88ca7db97edc20dc7f24542e26d80fb2
	.quad	l_alloc_8f0759b75afaab4655dc6fac252fd0c3

	.section	__TEXT,__const
l_alloc_a15ed431d12b61b552a8b4f468521cb1:
	.ascii	"use nudox_ir_vocab::TypeId;\n\npub const TYPE_DAG_HEADER_BYTES: usize = 4;\npub const TYPE_DAG_MAGIC: u8 = 0xc2;\npub const TYPE_DAG_SCHEMA: u8 = 1;\npub const MAX_TYPE_DAG_NODES: u8 = 2;\n\n#[derive(Clone, Copy)]\nenum RecordKind {\n    Primitive,\n    Reference,\n}\n\n#[derive(Clone, Copy, Debug, Eq, PartialEq)]\npub enum PrimitiveType {\n    Bool,\n    I32,\n}\n\n#[derive(Clone, Copy, Debug, Eq, PartialEq)]\npub enum TypeNode {\n    Primitive(PrimitiveType),\n    Reference(TypeId),\n}\n\n#[derive(Clone, Copy, Debug, Eq, PartialEq)]\npub enum TypeDagHeaderError {\n    Magic { actual: u8 },\n    Schema { actual: u8 },\n    NodeCount { actual: u8 },\n}\n\n#[derive(Clone, Copy, Debug, Eq, PartialEq)]\npub enum TypeNodeFault {\n    Truncated { required: usize, actual: usize },\n    Tag { actual: u8 },\n    Primitive { actual: u8 },\n    Edge { target: TypeId, node_count: u8 },\n}\n\n#[derive(Clone, Copy, Debug, Eq, PartialEq)]\npub enum TypeDagError {\n    TruncatedEnvelope {\n        actual: usize,\n    },\n    Header(TypeDagHeaderError),\n    Geometry {\n        expected: usize,\n        actual: usize,\n    },\n    ScratchTooSmall {\n        required: usize,\n        available: usize,\n    },\n    Node {\n        ordinal: TypeId,\n        fault: TypeNodeFault,\n    },\n    NodeBytes {\n        expected: usize,\n        actual: usize,\n    },\n}\n\npub struct TypeDagView<'bytes, 'scratch> {\n    bytes: &'bytes [u8],\n    proof: &'scratch [TypeNode],\n}\n\nimpl<'bytes, 'scratch> TypeDagView<'bytes, 'scratch> {\n    pub fn validate(\n        bytes: &'bytes [u8],\n        scratch: &'scratch mut [TypeNode],\n    ) -> Result<Self, TypeDagError> {\n        if bytes.len() < TYPE_DAG_HEADER_BYTES {\n            return Err(TypeDagError::TruncatedEnvelope {\n                actual: bytes.len(),\n            });\n        }\n        if bytes[0] != TYPE_DAG_MAGIC {\n            return Err(TypeDagError::Header(TypeDagHeaderError::Magic {\n                actual: bytes[0],\n            }));\n        }\n        if bytes[1] != TYPE_DAG_SCHEMA {\n            return Err(TypeDagError::Header(TypeDagHeaderError::Schema {\n                actual: bytes[1],\n            }));\n        }\n        let node_count = bytes[2];\n        if node_count > MAX_TYPE_DAG_NODES {\n            return Err(TypeDagError::Header(TypeDagHeaderError::NodeCount {\n                actual: node_count,\n            }));\n        }\n        let expected = TYPE_DAG_HEADER_BYTES + usize::from(bytes[3]);\n        if bytes.len() != expected {\n            return Err(TypeDagError::Geometry {\n                expected,\n                actual: bytes.len(),\n            });\n        }\n        let required = usize::from(node_count);\n        if scratch.len() < required {\n            return Err(TypeDagError::ScratchTooSmall {\n                required,\n                available: scratch.len(),\n            });\n        }\n\n        let mut decoded = [TypeNode::Primitive(PrimitiveType::Bool); MAX_TYPE_DAG_NODES as usize];\n        let body = &bytes[TYPE_DAG_HEADER_BYTES..];\n        let mut cursor = 0;\n        for ordinal in 0..node_count {\n            let source = TypeId::new(u32::from(ordinal));\n            let available = body.len() - cursor;\n            if available == 0 {\n                return Err(node_error(\n                    source,\n                    TypeNodeFault::Truncated {\n                        required: 1,\n                        actual: 0,\n                    },\n                ));\n            }\n            let kind = match body[cursor] {\n                0 => RecordKind::Primitive,\n                1 => RecordKind::Reference,\n                actual => return Err(node_error(source, TypeNodeFault::Tag { actual })),\n            };\n            if available < 2 {\n                return Err(node_error(\n                    source,\n                    TypeNodeFault::Truncated {\n                        required: 2,\n                        actual: available,\n                    },\n                ));\n            }\n            decoded[usize::from(ordinal)] = kind.decode(body[cursor + 1], source, node_count)?;\n            cursor += 2;\n        }\n        if cursor != body.len() {\n            return Err(TypeDagError::NodeBytes {\n                expected: cursor,\n                actual: body.len(),\n            });\n        }\n        scratch[..required].copy_from_slice(&decoded[..required]);\n        Ok(Self {\n            bytes,\n            proof: &scratch[..required],\n        })\n    }\n\n    pub fn nodes(&self) -> TypeNodeCursor<'scratch> {\n        TypeNodeCursor {\n            remaining: self.proof,\n        }\n    }\n\n    pub fn input_len(&self) -> usize {\n        self.bytes.len()\n    }\n}\n\nimpl AsRef<[u8]> for TypeDagView<'_, '_> {\n    fn as_ref(&self) -> &[u8] {\n        self.bytes\n    }\n}\n\npub struct TypeNodeCursor<'scratch> {\n    remaining: &'scratch [TypeNode],\n}\n\nimpl<'scratch> Iterator for TypeNodeCursor<'scratch> {\n    type Item = &'scratch TypeNode;\n\n    fn next(&mut self) -> Option<Self::Item> {\n        let (node, remaining) = self.remaining.split_first()?;\n        self.remaining = remaining;\n        Some(node)\n    }\n\n    fn size_hint(&self) -> (usize, Option<usize>) {\n        (self.remaining.len(), Some(self.remaining.len()))\n    }\n}\n\nimpl ExactSizeIterator for TypeNodeCursor<'_> {}\nimpl core::iter::FusedIterator for TypeNodeCursor<'_> {}\n\nimpl RecordKind {\n    fn decode(self, raw: u8, source: TypeId, node_count: u8) -> Result<TypeNode, TypeDagError> {\n        match self {\n            Self::Primitive => match raw {\n                0 => Ok(TypeNode::Primitive(PrimitiveType::Bool)),\n                1 => Ok(TypeNode::Primitive(PrimitiveType::I32)),\n                actual => Err(node_error(source, TypeNodeFault::Primitive { actual })),\n            },\n            Self::Reference if raw < node_count => {\n                Ok(TypeNode::Reference(TypeId::new(u32::from(raw))))\n            }\n            Self::Reference => Err(node_error(\n                source,\n                TypeNodeFault::Edge {\n                    target: TypeId::new(u32::from(raw)),\n                    node_count,\n                },\n            )),\n        }\n    }\n}\n\nconst fn node_error(ordinal: TypeId, fault: TypeNodeFault) -> TypeDagError {\n    TypeDagError::Node { ordinal, fault }\n}\n"

l_alloc_caf81f150f8e2a3f46956011ce18ea9a:
	.ascii	"impl<'scratch> Iterator"

l_alloc_81d08f51e9b46a96808970faccda49a8:
	.ascii	"impl ExactSizeIterator"

l_alloc_c2dcc5662ba056ecce14533279e4b160:
	.ascii	"cursor boundary"

l_alloc_c8234fd665543c28765ba1c6e15e759c:
	.ascii	"split_first"

l_alloc_cd7c7f7dce8f9b264694ca2526c37516:
	.ascii	"assertion failed: body.contains(\"split_first\")"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_6e2e0c0ec38458ba4fdfb65ea05a2eb2:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000\372\000\000\000\005\000\000"

	.section	__TEXT,__const
l_alloc_dd4ffb6a82fadbcfa53fa009063078f4:
	.ascii	"bytes"

l_alloc_f4e8947ab4017184eb7a640b452ba22d:
	.ascii	"TypeId::new"

l_alloc_700d8946133bd552962b15338de36ae6:
	.ascii	"match raw"

l_alloc_9b7e1a584d08fa8ad7c1a56b7ce8a44f:
	.ascii	"unwrap"

l_alloc_872ed60f4e9cc5929cf39c60b855d9ea:
	.ascii	"expect"

l_alloc_b3a99f180af7a4a365370845f4d61ecc:
	.ascii	"assertion failed: !body.contains(forbidden)"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_b8d0ec36c0eead905460459f2e09257b:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000\374\000\000\000\t\000\000"

	.section	__TEXT,__const
l_alloc_54bb4d60df512e09680a75e9c196c327:
	.ascii	"cursor implementation"

	.section	__TEXT,__cstring,cstring_literals
l_alloc_d0ef803f235cc9da4d2f68db2ae7eecd:
	.asciz	"\302\001\001"

l_alloc_84e44d17547bb16feba7510e5887a46e:
	.asciz	"\302\001\001\001"

l_alloc_dfa58342adb1b61c9b339d03997d4468:
	.asciz	"\302\001\001\002\007"

	.section	__TEXT,__const
l_alloc_2deb6346c8c31952b5e510cfc673852c:
	.ascii	"\302\001\001\002\000\007"

l_alloc_ac5a6c5e09adc7e44b9ec58eff44f5a6:
	.ascii	"\302\001\001\002\001\001"

l_alloc_c1242df8626b9cf6c60c92fd6d618193:
	.asciz	"\302\001\001\003\000\000"

	.section	__TEXT,__literal4,4byte_literals
l_alloc_f6f7b3569446eafb281a38f3be526f22:
	.asciz	"\000\001\000"

l_alloc_29797342d601d1e047d79ddaf9206dc7:
	.asciz	"\302\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_alloc_060289bc9efbbf6030aff056af069676:
	.asciz	"\302\001\003"

l_alloc_7884c94991f6216c5ebb8eda5460e4b8:
	.asciz	"\302\001\001\002"

	.section	__TEXT,__const
l_alloc_40eaf789987e2da79c4d5f3f8e4e709a:
	.asciz	"\302\001\001\002\000"

	.section	__TEXT,__literal4,4byte_literals
l_alloc_c1b96e55b45c7736d2483852531d6cfa:
	.asciz	"\302\001\000"

	.section	__TEXT,__literal8,8byte_literals
	.p2align	2, 0x0
l_alloc_a4fec9de8264c27b2449b411fe17eeb0:
	.space	2
	.space	6

	.section	__TEXT,__const
l_alloc_68d4241588b373d3827583e8b7e560bc:
	.ascii	"\302\001\001\002\000\001"

	.section	__TEXT,__cstring,cstring_literals
l_alloc_fa61d42cbf53437402fcbcb23f6b9f14:
	.asciz	"\302\001\001\002\001"

l_alloc_8e580bd0a57c3d4e874ce5e1d1608074:
	.asciz	"\302\001\002\004\001\001\001"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_366a20069fba01ea1b12f1ee9bd96211:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000d\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_800cf2779c59941b383445baad70eeb8:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000e\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_98a68c254d2f16f24a30ac2be7568bfa:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000h\000\000\000\t\000\000"

	.section	__TEXT,__const
l_alloc_41adb055745d596a22069a43cc6b96f0:
	.ascii	"assertion failed: scratch_start <= node_address"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_787cc3db1ede27825734bc2f561a73e1:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000o\000\000\000\r\000\000"

	.section	__TEXT,__const
l_alloc_ef0d0704052a8e970d69179d3ab3ec5d:
	.ascii	"assertion failed: node_address + size_of::<TypeNode>() <= scratch_start + size_of_val(*expected)"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_bed34f8f916518f97094735f53f0071b:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000p\000\000\000\r\000\000"

	.p2align	3, 0x0
l_alloc_345a3daa91d0eb883779457fc7280ed5:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000q\000\000\000\r\000\000"

	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
l_alloc_53973d2fe29b4adba8bb7390b5678745:
	.space	8

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_8a3150ea8ce92a0b4c407d9443666eec:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000s\000\000\000\t\000\000"

	.p2align	3, 0x0
l_alloc_f11587fcc5df25a2c968fb538524ab02:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000`\000\000\000C\000\000"

	.p2align	3, 0x0
l_alloc_20850533bf96e06227afa83f2bc9aa63:
	.quad	l_alloc_ad7306ae0224e62badd99f32f4d8d58c
	.asciz	"(\000\000\000\000\000\000\000x\000\000\000\005\000\000"

	.section	__TEXT,__const
l_alloc_200ebb91f49df6906629ddcf737a98f2:
	.ascii	"invalid type DAG accepted"

l_alloc_205495696f58003a123a312f976ed7c8:
	.ascii	"golden rejected"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.9:
	.asciz	"\000\000\000\000\000\000\000\000 \000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXsC_NtCsks33AUGQlhz_15nudox_ir_format8type_dagNtB5_12TypeDagErrorNtNtCsgtPOCBgevO_4core3fmt5Debug3fmt

	.section	__TEXT,__const
l_alloc_c9012ddda9c7d3e0809e5ad487d5dbaf:
	.ascii	"validated cursor shortened"

l_alloc_37eecd02b27b2a803515d9677500278a:
	.ascii	"missing source"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.a:
	.asciz	"\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtReNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.section	__TEXT,__cstring,cstring_literals
l_alloc_26978532d6004174455ea2130c477035:
	.asciz	"\007Error: \300\001\n"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.b:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRjNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.section	__TEXT,__const
l_alloc_ea8e8baf0be5855bbef17ce48226036b:
	.ascii	"TruncatedEnvelope"

l_alloc_b31c6c8dca3d1da07e1eee656fa2f5cc:
	.ascii	"actual"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.c:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag18TypeDagHeaderErrorNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.section	__TEXT,__const
l_alloc_b2243a0a9fd6f5181b6e5ba2b6488d3a:
	.ascii	"Header"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.d:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXsZ_NtNtCsgtPOCBgevO_4core3fmt3numjNtB7_5Debug3fmt

	.section	__TEXT,__literal8,8byte_literals
l_alloc_4d3c10a7785e3cacd7635396354c2688:
	.ascii	"Geometry"

l_alloc_bebfed686e6a6f31c99c69b171066b8a:
	.ascii	"expected"

	.section	__TEXT,__const
l_alloc_5c9910a63c1c5173176bd3aa76a8ac20:
	.ascii	"ScratchTooSmall"

	.section	__TEXT,__literal8,8byte_literals
l_alloc_715ad17152b7a3dfcbb2abff840befeb:
	.ascii	"required"

	.section	__TEXT,__const
l_alloc_700d5d683c25860e3d40207214c9c99c:
	.ascii	"available"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.e:
	.asciz	"\000\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\004\000\000\000\000\000\000"
	.quad	__RNvXsf_Csjj9WfcXSjwO_14nudox_ir_vocabINtB5_7DenseIdNtB5_4TypeENtNtCsgtPOCBgevO_4core3fmt5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.p2align	3, 0x0
l_vtable.f:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag13TypeNodeFaultNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.section	__TEXT,__literal4,4byte_literals
l_alloc_1e2d27e83e9b70f610a2d8f4ab61fc2e:
	.ascii	"Node"

	.section	__TEXT,__const
l_alloc_d466f777e26b5a6c15c5498a3130191d:
	.ascii	"ordinal"

l_alloc_652e7c9d7b77be2ac6e01717f701606a:
	.ascii	"fault"

l_alloc_d7a7f078b751cfeba410ab5cc24bfa07:
	.ascii	"NodeBytes"

	.section	__TEXT,__literal4,4byte_literals
l_alloc_b94f1f40ebe2eb842bd4cc55034553f1:
	.ascii	"Bool"

	.section	__TEXT,__const
l_alloc_e4fa82a2878eb5612d513befd6fc8a36:
	.ascii	"I32"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.g:
	.asciz	"\000\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\004\000\000\000\000\000\000"
	.quad	__RNvXsW_NtNtCsgtPOCBgevO_4core3fmt3nummNtB7_5Debug3fmt

	.p2align	3, 0x0
l_vtable.h:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtNtB8_6marker11PhantomDataFENtCsjj9WfcXSjwO_14nudox_ir_vocab4TypeENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.section	__TEXT,__const
l_alloc_1ab8f3bcfc18061e9d6f0217059b41f5:
	.ascii	"DenseId"

l_alloc_005de03493e3aaea3890cf93afea4072:
	.ascii	"raw"

l_alloc_8cc6661f3cf091aca5a7bc91c52031fe:
	.ascii	"owner"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.i:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtCsks33AUGQlhz_15nudox_ir_format8type_dag13PrimitiveTypeNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.section	__TEXT,__const
l_alloc_2a28b803340a522af1d6fe0d14a5f8e5:
	.ascii	"Primitive"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.j:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRINtCsjj9WfcXSjwO_14nudox_ir_vocab7DenseIdNtBy_4TypeENtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.section	__TEXT,__const
l_alloc_a67487da2e66b342314634b825542faf:
	.ascii	"Reference"

l_alloc_d7b9b6c1829de9592f5bc6e83c4fc424:
	.ascii	"Magic"

l_alloc_d102eb289abff9d0655d27bf114c0746:
	.ascii	"Schema"

l_alloc_830cc47b3e97457eae2b6eb6d050e986:
	.ascii	"NodeCount"

l_alloc_f281a46e9987443bf5658c5f394cb876:
	.ascii	"fn() -> nudox_ir_vocab::Type"

	.section	__TEXT,__cstring,cstring_literals
l_alloc_ccb3afc2d9f98e5ced738fc09e93fead:
	.asciz	"\fPhantomData<\300\001>"

	.section	__DATA,__const
	.p2align	3, 0x0
l_vtable.k:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgtPOCBgevO_4core3fmtRmNtB6_5Debug3fmtCs6tqTQJNM79Z_8type_dag

	.section	__TEXT,__const
l_alloc_c73d17da7498663a071b898ac2218935:
	.ascii	"Ok"

l_alloc_bf301217d548e4f1fd13189dd935c554:
	.ascii	"Err"

l_alloc_eb66dd8df2025c3378e51480905e26b5:
	.ascii	"Truncated"

l_alloc_cdb9aa4db1ff8f1d481eca6e672fb6b0:
	.ascii	"Tag"

	.section	__TEXT,__literal4,4byte_literals
l_alloc_2af43630e845fc262d2a6f3b2fa9b1c0:
	.ascii	"Edge"

	.section	__TEXT,__const
l_alloc_5de5b778237022f7dfbd4b14eca9b832:
	.ascii	"target"

l_alloc_c662412d9acfc8d757cfe16257349ca3:
	.ascii	"node_count"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_de5e2f1dd01253ae804bfe6ba3503da0:
	.quad	l_alloc_ee38938c8929eed18faaff5d8f37cd9b
	.asciz	"k\000\000\000\000\000\000\000k\004\000\000$\000\000"

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
l_.memset_pattern:
	.quad	256
	.quad	256

.subsections_via_symbols
